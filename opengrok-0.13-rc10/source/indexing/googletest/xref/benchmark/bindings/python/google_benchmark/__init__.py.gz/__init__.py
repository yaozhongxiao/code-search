<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["__all__",49],["__version__",67],["initialize",155],["option",113],["run_benchmarks",156]]],["Class","xc",[["Options",76],["__OptionMaker",70]]],["Namespace","xn",[["_benchmark",31],["app",30]]],["Function","xf",[["__builder_method",94],["__decorator",98],["_flags_parser",139],["_run_benchmarks",144],["main",150],["register",116]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c"># Copyright 2020 Google Inc. All rights reserved.</span>
<a class="l" name="2" href="#2">2</a><span class="c">#</span>
<a class="l" name="3" href="#3">3</a><span class="c"># Licensed under the Apache License, Version 2.0 (the "License");</span>
<a class="l" name="4" href="#4">4</a><span class="c"># you may not use this file except in compliance with the License.</span>
<a class="l" name="5" href="#5">5</a><span class="c"># You may obtain a copy of the License at</span>
<a class="l" name="6" href="#6">6</a><span class="c">#</span>
<a class="l" name="7" href="#7">7</a><span class="c">#     <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a></span>
<a class="l" name="8" href="#8">8</a><span class="c">#</span>
<a class="l" name="9" href="#9">9</a><span class="c"># Unless required by applicable law or agreed to in writing, software</span>
<a class="hl" name="10" href="#10">10</a><span class="c"># distributed under the License is distributed on an "AS IS" BASIS,</span>
<a class="l" name="11" href="#11">11</a><span class="c"># WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.</span>
<a class="l" name="12" href="#12">12</a><span class="c"># See the License for the specific language governing permissions and</span>
<a class="l" name="13" href="#13">13</a><span class="c"># limitations under the License.</span>
<a class="l" name="14" href="#14">14</a><span class="s">"""Python benchmarking utilities.
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a>Example usage:
<a class="l" name="17" href="#17">17</a>  import google_benchmark as benchmark
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a>  @benchmark.register
<a class="hl" name="20" href="#20">20</a>  def my_benchmark(state):
<a class="l" name="21" href="#21">21</a>      ...  # Code executed outside `while` loop is not timed.
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a>      while state:
<a class="l" name="24" href="#24">24</a>        ...  # Code executed within `while` loop is timed.
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a>  if __name__ == '__main__':
<a class="l" name="27" href="#27">27</a>    benchmark.main()
<a class="l" name="28" href="#28">28</a>"""</span>
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a><b>from</b> <a href="/googletest/s?defs=absl&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">absl</a> <b>import</b> <a class="xn" name="app"/><a href="/googletest/s?refs=app&amp;project=benchmark" class="xn intelliWindow-symbol" data-definition-place="def">app</a>
<a class="l" name="31" href="#31">31</a><b>from</b> <a href="/googletest/s?defs=google_benchmark&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">google_benchmark</a> <b>import</b> <a href="/googletest/s?refs=_benchmark&amp;project=benchmark" class="xn intelliWindow-symbol" data-definition-place="def">_benchmark</a>
<a class="l" name="32" href="#32">32</a><b>from</b> <a href="/googletest/s?defs=google_benchmark&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">google_benchmark</a>.<a class="d intelliWindow-symbol" href="#_benchmark" data-definition-place="defined-in-file">_benchmark</a> <b>import</b> (
<a class="l" name="33" href="#33">33</a>    <a href="/googletest/s?defs=Counter&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Counter</a>,
<a class="l" name="34" href="#34">34</a>    <a href="/googletest/s?defs=kNanosecond&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">kNanosecond</a>,
<a class="l" name="35" href="#35">35</a>    <a href="/googletest/s?defs=kMicrosecond&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">kMicrosecond</a>,
<a class="l" name="36" href="#36">36</a>    <a href="/googletest/s?defs=kMillisecond&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">kMillisecond</a>,
<a class="l" name="37" href="#37">37</a>    <a href="/googletest/s?defs=oNone&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">oNone</a>,
<a class="l" name="38" href="#38">38</a>    <a href="/googletest/s?defs=o1&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">o1</a>,
<a class="l" name="39" href="#39">39</a>    <a href="/googletest/s?defs=oN&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">oN</a>,
<a class="hl" name="40" href="#40">40</a>    <a href="/googletest/s?defs=oNSquared&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">oNSquared</a>,
<a class="l" name="41" href="#41">41</a>    <a href="/googletest/s?defs=oNCubed&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">oNCubed</a>,
<a class="l" name="42" href="#42">42</a>    <a href="/googletest/s?defs=oLogN&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">oLogN</a>,
<a class="l" name="43" href="#43">43</a>    <a href="/googletest/s?defs=oNLogN&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">oNLogN</a>,
<a class="l" name="44" href="#44">44</a>    <a href="/googletest/s?defs=oAuto&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">oAuto</a>,
<a class="l" name="45" href="#45">45</a>    <a href="/googletest/s?defs=oLambda&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">oLambda</a>,
<a class="l" name="46" href="#46">46</a>)
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a><a href="/googletest/s?refs=__all__&amp;project=benchmark" class="xv intelliWindow-symbol" data-definition-place="def">__all__</a> = [
<a class="hl" name="50" href="#50">50</a>    <span class="s">"register"</span>,
<a class="l" name="51" href="#51">51</a>    <span class="s">"main"</span>,
<a class="l" name="52" href="#52">52</a>    <span class="s">"Counter"</span>,
<a class="l" name="53" href="#53">53</a>    <span class="s">"kNanosecond"</span>,
<a class="l" name="54" href="#54">54</a>    <span class="s">"kMicrosecond"</span>,
<a class="l" name="55" href="#55">55</a>    <span class="s">"kMillisecond"</span>,
<a class="l" name="56" href="#56">56</a>    <span class="s">"oNone"</span>,
<a class="l" name="57" href="#57">57</a>    <span class="s">"o1"</span>,
<a class="l" name="58" href="#58">58</a>    <span class="s">"oN"</span>,
<a class="l" name="59" href="#59">59</a>    <span class="s">"oNSquared"</span>,
<a class="hl" name="60" href="#60">60</a>    <span class="s">"oNCubed"</span>,
<a class="l" name="61" href="#61">61</a>    <span class="s">"oLogN"</span>,
<a class="l" name="62" href="#62">62</a>    <span class="s">"oNLogN"</span>,
<a class="l" name="63" href="#63">63</a>    <span class="s">"oAuto"</span>,
<a class="l" name="64" href="#64">64</a>    <span class="s">"oLambda"</span>,
<a class="l" name="65" href="#65">65</a>]
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a><a href="/googletest/s?refs=__version__&amp;project=benchmark" class="xv intelliWindow-symbol" data-definition-place="def">__version__</a> = <span class="s">"0.2.0"</span>
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a><b>class</b> <a href="/googletest/s?refs=__OptionMaker&amp;project=benchmark" class="xc intelliWindow-symbol" data-definition-place="def">__OptionMaker</a>:
<a class="l" name="71" href="#71">71</a>    <span class="s">"""A stateless class to collect benchmark options.
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>    Collect all decorator calls like @option.range(start=0, limit=1&lt;&lt;5).
<a class="l" name="74" href="#74">74</a>    """</span>
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a>    <b>class</b> <a class="xc" name="Options"/><a href="/googletest/s?refs=Options&amp;project=benchmark" class="xc intelliWindow-symbol" data-definition-place="def">Options</a>:
<a class="l" name="77" href="#77">77</a>        <span class="s">"""Pure data class to store options calls, along with the benchmarked function."""</span>
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>        <b>def</b> <a href="/googletest/s?refs=__init__&amp;project=benchmark" class="xmb intelliWindow-symbol" data-definition-place="def">__init__</a>(<a href="/googletest/s?defs=self&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>, <a href="/googletest/s?defs=func&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">func</a>):
<a class="hl" name="80" href="#80">80</a>            <a href="/googletest/s?defs=self&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=func&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">func</a> = <a href="/googletest/s?defs=func&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">func</a>
<a class="l" name="81" href="#81">81</a>            <a href="/googletest/s?defs=self&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=builder_calls&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">builder_calls</a> = []
<a class="l" name="82" href="#82">82</a>
<a class="l" name="83" href="#83">83</a>    @<a href="/googletest/s?defs=classmethod&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">classmethod</a>
<a class="l" name="84" href="#84">84</a>    <b>def</b> <a class="xmb" name="make"/><a href="/googletest/s?refs=make&amp;project=benchmark" class="xmb intelliWindow-symbol" data-definition-place="def">make</a>(<a href="/googletest/s?defs=cls&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cls</a>, <a href="/googletest/s?defs=func_or_options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">func_or_options</a>):
<a class="l" name="85" href="#85">85</a>        <span class="s">"""Make Options from Options or the benchmarked function."""</span>
<a class="l" name="86" href="#86">86</a>        <b>if</b> <a href="/googletest/s?defs=isinstance&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">isinstance</a>(<a href="/googletest/s?defs=func_or_options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">func_or_options</a>, <a href="/googletest/s?defs=cls&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cls</a>.<a class="d intelliWindow-symbol" href="#Options" data-definition-place="defined-in-file">Options</a>):
<a class="l" name="87" href="#87">87</a>            <b>return</b> <a href="/googletest/s?defs=func_or_options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">func_or_options</a>
<a class="l" name="88" href="#88">88</a>        <b>return</b> <a href="/googletest/s?defs=cls&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cls</a>.<a class="d intelliWindow-symbol" href="#Options" data-definition-place="defined-in-file">Options</a>(<a href="/googletest/s?defs=func_or_options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">func_or_options</a>)
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>    <b>def</b> <a href="/googletest/s?refs=__getattr__&amp;project=benchmark" class="xmb intelliWindow-symbol" data-definition-place="def">__getattr__</a>(<a href="/googletest/s?defs=self&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>, <a href="/googletest/s?defs=builder_name&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">builder_name</a>):
<a class="l" name="91" href="#91">91</a>        <span class="s">"""Append option call in the Options."""</span>
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>        <span class="c"># The function that get returned on @option.range(start=0, limit=1&lt;&lt;5).</span>
<a class="l" name="94" href="#94">94</a>        <b>def</b> <a href="/googletest/s?refs=__builder_method&amp;project=benchmark" class="xf intelliWindow-symbol" data-definition-place="def">__builder_method</a>(*<a href="/googletest/s?defs=args&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">args</a>, **<a href="/googletest/s?defs=kwargs&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">kwargs</a>):
<a class="l" name="95" href="#95">95</a>
<a class="l" name="96" href="#96">96</a>            <span class="c"># The decorator that get called, either with the benchmared function</span>
<a class="l" name="97" href="#97">97</a>            <span class="c"># or the previous Options</span>
<a class="l" name="98" href="#98">98</a>            <b>def</b> <a href="/googletest/s?refs=__decorator&amp;project=benchmark" class="xf intelliWindow-symbol" data-definition-place="def">__decorator</a>(<a href="/googletest/s?defs=func_or_options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">func_or_options</a>):
<a class="l" name="99" href="#99">99</a>                <a href="/googletest/s?defs=options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">options</a> = <a href="/googletest/s?defs=self&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#make" data-definition-place="defined-in-file">make</a>(<a href="/googletest/s?defs=func_or_options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">func_or_options</a>)
<a class="hl" name="100" href="#100">100</a>                <a href="/googletest/s?defs=options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">options</a>.<a href="/googletest/s?defs=builder_calls&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">builder_calls</a>.<a href="/googletest/s?defs=append&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">append</a>((<a href="/googletest/s?defs=builder_name&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">builder_name</a>, <a href="/googletest/s?defs=args&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">args</a>, <a href="/googletest/s?defs=kwargs&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">kwargs</a>))
<a class="l" name="101" href="#101">101</a>                <span class="c"># The decorator returns Options so it is not technically a decorator</span>
<a class="l" name="102" href="#102">102</a>                <span class="c"># and needs a final call to @regiser</span>
<a class="l" name="103" href="#103">103</a>                <b>return</b> <a href="/googletest/s?defs=options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">options</a>
<a class="l" name="104" href="#104">104</a>
<a class="l" name="105" href="#105">105</a>            <b>return</b> <a class="d intelliWindow-symbol" href="#__decorator" data-definition-place="defined-in-file">__decorator</a>
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>        <b>return</b> <a class="d intelliWindow-symbol" href="#__builder_method" data-definition-place="defined-in-file">__builder_method</a>
<a class="l" name="108" href="#108">108</a>
<a class="l" name="109" href="#109">109</a>
<a class="hl" name="110" href="#110">110</a><span class="c"># Alias for nicer API.</span>
<a class="l" name="111" href="#111">111</a><span class="c"># We have to instanciate an object, even if stateless, to be able to use __getattr__</span>
<a class="l" name="112" href="#112">112</a><span class="c"># on option.range</span>
<a class="l" name="113" href="#113">113</a><a class="xv" name="option"/><a href="/googletest/s?refs=option&amp;project=benchmark" class="xv intelliWindow-symbol" data-definition-place="def">option</a> = <a class="d intelliWindow-symbol" href="#__OptionMaker" data-definition-place="defined-in-file">__OptionMaker</a>()
<a class="l" name="114" href="#114">114</a>
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a><b>def</b> <a class="xf" name="register"/><a href="/googletest/s?refs=register&amp;project=benchmark" class="xf intelliWindow-symbol" data-definition-place="def">register</a>(<a href="/googletest/s?defs=undefined&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">undefined</a>=<b>None</b>, *, <a href="/googletest/s?defs=name&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">name</a>=<b>None</b>):
<a class="l" name="117" href="#117">117</a>    <span class="s">"""Register function for benchmarking."""</span>
<a class="l" name="118" href="#118">118</a>    <b>if</b> <a href="/googletest/s?defs=undefined&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">undefined</a> <b>is</b> <b>None</b>:
<a class="l" name="119" href="#119">119</a>        <span class="c"># Decorator is called without parenthesis so we return a decorator</span>
<a class="hl" name="120" href="#120">120</a>        <b>return</b> <b>lambda</b> f: <a class="d intelliWindow-symbol" href="#register" data-definition-place="defined-in-file">register</a>(f, <a href="/googletest/s?defs=name&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">name</a>=<a href="/googletest/s?defs=name&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">name</a>)
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>    <span class="c"># We have either the function to benchmark (simple case) or an instance of Options</span>
<a class="l" name="123" href="#123">123</a>    <span class="c"># (@option._ case).</span>
<a class="l" name="124" href="#124">124</a>    <a href="/googletest/s?defs=options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">options</a> = <a class="d intelliWindow-symbol" href="#__OptionMaker" data-definition-place="defined-in-file">__OptionMaker</a>.<a class="d intelliWindow-symbol" href="#make" data-definition-place="defined-in-file">make</a>(<a href="/googletest/s?defs=undefined&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">undefined</a>)
<a class="l" name="125" href="#125">125</a>
<a class="l" name="126" href="#126">126</a>    <b>if</b> <a href="/googletest/s?defs=name&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">name</a> <b>is</b> <b>None</b>:
<a class="l" name="127" href="#127">127</a>        <a href="/googletest/s?defs=name&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">name</a> = <a href="/googletest/s?defs=options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">options</a>.<a href="/googletest/s?defs=func&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">func</a>.<a href="/googletest/s?defs=__name__&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__name__</a>
<a class="l" name="128" href="#128">128</a>
<a class="l" name="129" href="#129">129</a>    <span class="c"># We register the benchmark and reproduce all the @option._ calls onto the</span>
<a class="hl" name="130" href="#130">130</a>    <span class="c"># benchmark builder pattern</span>
<a class="l" name="131" href="#131">131</a>    <a href="/googletest/s?defs=benchmark&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">benchmark</a> = <a class="d intelliWindow-symbol" href="#_benchmark" data-definition-place="defined-in-file">_benchmark</a>.<a href="/googletest/s?defs=RegisterBenchmark&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">RegisterBenchmark</a>(<a href="/googletest/s?defs=name&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">name</a>, <a href="/googletest/s?defs=options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">options</a>.<a href="/googletest/s?defs=func&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">func</a>)
<a class="l" name="132" href="#132">132</a>    <b>for</b> <a href="/googletest/s?defs=name&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">name</a>, <a href="/googletest/s?defs=args&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">args</a>, <a href="/googletest/s?defs=kwargs&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">kwargs</a> <b>in</b> <a href="/googletest/s?defs=options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">options</a>.<a href="/googletest/s?defs=builder_calls&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">builder_calls</a>[::-<span class="n">1</span>]:
<a class="l" name="133" href="#133">133</a>        <a href="/googletest/s?defs=getattr&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">getattr</a>(<a href="/googletest/s?defs=benchmark&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">benchmark</a>, <a href="/googletest/s?defs=name&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">name</a>)(*<a href="/googletest/s?defs=args&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">args</a>, **<a href="/googletest/s?defs=kwargs&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">kwargs</a>)
<a class="l" name="134" href="#134">134</a>
<a class="l" name="135" href="#135">135</a>    <span class="c"># return the benchmarked function because the decorator does not modify it</span>
<a class="l" name="136" href="#136">136</a>    <b>return</b> <a href="/googletest/s?defs=options&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">options</a>.<a href="/googletest/s?defs=func&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">func</a>
<a class="l" name="137" href="#137">137</a>
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a><b>def</b> <a href="/googletest/s?refs=_flags_parser&amp;project=benchmark" class="xf intelliWindow-symbol" data-definition-place="def">_flags_parser</a>(<a href="/googletest/s?defs=argv&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>):
<a class="hl" name="140" href="#140">140</a>    <a href="/googletest/s?defs=argv&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a> = <a class="d intelliWindow-symbol" href="#_benchmark" data-definition-place="defined-in-file">_benchmark</a>.<a href="/googletest/s?defs=Initialize&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Initialize</a>(<a href="/googletest/s?defs=argv&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>)
<a class="l" name="141" href="#141">141</a>    <b>return</b> <a class="d intelliWindow-symbol" href="#app" data-definition-place="defined-in-file">app</a>.<a href="/googletest/s?defs=parse_flags_with_usage&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">parse_flags_with_usage</a>(<a href="/googletest/s?defs=argv&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>)
<a class="l" name="142" href="#142">142</a>
<a class="l" name="143" href="#143">143</a>
<a class="l" name="144" href="#144">144</a><b>def</b> <a href="/googletest/s?refs=_run_benchmarks&amp;project=benchmark" class="xf intelliWindow-symbol" data-definition-place="def">_run_benchmarks</a>(<a href="/googletest/s?defs=argv&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>):
<a class="l" name="145" href="#145">145</a>    <b>if</b> <a href="/googletest/s?defs=len&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">len</a>(<a href="/googletest/s?defs=argv&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>) &gt; <span class="n">1</span>:
<a class="l" name="146" href="#146">146</a>        <b>raise</b> <a class="d intelliWindow-symbol" href="#app" data-definition-place="defined-in-file">app</a>.<a href="/googletest/s?defs=UsageError&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">UsageError</a>(<span class="s">"Too many command-line arguments."</span>)
<a class="l" name="147" href="#147">147</a>    <b>return</b> <a class="d intelliWindow-symbol" href="#_benchmark" data-definition-place="defined-in-file">_benchmark</a>.<a href="/googletest/s?defs=RunSpecifiedBenchmarks&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">RunSpecifiedBenchmarks</a>()
<a class="l" name="148" href="#148">148</a>
<a class="l" name="149" href="#149">149</a>
<a class="hl" name="150" href="#150">150</a><b>def</b> <a class="xf" name="main"/><a href="/googletest/s?refs=main&amp;project=benchmark" class="xf intelliWindow-symbol" data-definition-place="def">main</a>(<a href="/googletest/s?defs=argv&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>=<b>None</b>):
<a class="l" name="151" href="#151">151</a>    <b>return</b> <a class="d intelliWindow-symbol" href="#app" data-definition-place="defined-in-file">app</a>.<a href="/googletest/s?defs=run&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">run</a>(<a class="d intelliWindow-symbol" href="#_run_benchmarks" data-definition-place="defined-in-file">_run_benchmarks</a>, <a href="/googletest/s?defs=argv&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>=<a href="/googletest/s?defs=argv&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>, <a href="/googletest/s?defs=flags_parser&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">flags_parser</a>=<a class="d intelliWindow-symbol" href="#_flags_parser" data-definition-place="defined-in-file">_flags_parser</a>)
<a class="l" name="152" href="#152">152</a>
<a class="l" name="153" href="#153">153</a>
<a class="l" name="154" href="#154">154</a><span class="c"># Methods for use with custom main function.</span>
<a class="l" name="155" href="#155">155</a><a class="xv" name="initialize"/><a href="/googletest/s?refs=initialize&amp;project=benchmark" class="xv intelliWindow-symbol" data-definition-place="def">initialize</a> = <a class="d intelliWindow-symbol" href="#_benchmark" data-definition-place="defined-in-file">_benchmark</a>.<a href="/googletest/s?defs=Initialize&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Initialize</a>
<a class="l" name="156" href="#156">156</a><a class="xv" name="run_benchmarks"/><a href="/googletest/s?refs=run_benchmarks&amp;project=benchmark" class="xv intelliWindow-symbol" data-definition-place="def">run_benchmarks</a> = <a class="d intelliWindow-symbol" href="#_benchmark" data-definition-place="defined-in-file">_benchmark</a>.<a href="/googletest/s?defs=RunSpecifiedBenchmarks&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">RunSpecifiedBenchmarks</a>
<a class="l" name="157" href="#157">157</a>