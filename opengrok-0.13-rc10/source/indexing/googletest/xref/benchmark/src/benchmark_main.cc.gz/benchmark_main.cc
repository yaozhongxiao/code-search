<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">// Copyright 2018 Google Inc. All rights reserved.</span>
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span><span class="c">// Licensed under the Apache License, Version 2.0 (the "License");</span>
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span><span class="c">// you may not use this file except in compliance with the License.</span>
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span><span class="c">// You may obtain a copy of the License at</span>
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span><span class="c">//     <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a></span>
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span><span class="c">// Unless required by applicable law or agreed to in writing, software</span>
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span><span class="c">// distributed under the License is distributed on an "AS IS" BASIS,</span>
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span><span class="c">// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.</span>
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span><span class="c">// See the License for the specific language governing permissions and</span>
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span><span class="c">// limitations under the License.</span>
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=benchmark/">benchmark</a>/<a href="/googletest/s?path=benchmark/benchmark.h">benchmark.h</a>"</span>
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span><a href="/googletest/s?defs=BENCHMARK_MAIN&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">BENCHMARK_MAIN</a>()&#59;
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span>