<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># How to release
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>* Make sure you're on master and synced to HEAD
<a class="l" name="4" href="#4">4</a>* Ensure the project builds and tests run (sanity check only, obviously)
<a class="l" name="5" href="#5">5</a>    * `parallel -j0 exec ::: test/*_test` can help ensure everything at least
<a class="l" name="6" href="#6">6</a>      passes
<a class="l" name="7" href="#7">7</a>* Prepare release notes
<a class="l" name="8" href="#8">8</a>    * `git log $(git describe --abbrev=0 --tags)<a href="/googletest/s?path=..HEAD&amp;project=benchmark">..HEAD</a>` gives you the list of
<a class="l" name="9" href="#9">9</a>      commits between the last annotated tag and HEAD
<a class="hl" name="10" href="#10">10</a>    * Pick the most interesting.
<a class="l" name="11" href="#11">11</a>* Create a release through github's interface
<a class="l" name="12" href="#12">12</a>    * Note this will create a lightweight tag.
<a class="l" name="13" href="#13">13</a>    * Update this to an annotated tag:
<a class="l" name="14" href="#14">14</a>      * `git pull --tags`
<a class="l" name="15" href="#15">15</a>      * `git tag -a -f &lt;tag&gt; &lt;tag&gt;`
<a class="l" name="16" href="#16">16</a>      * `git push --force origin`
<a class="l" name="17" href="#17">17</a>