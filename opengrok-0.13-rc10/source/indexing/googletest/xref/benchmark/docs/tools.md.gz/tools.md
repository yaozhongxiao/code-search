<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># Benchmark Tools
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>## <a href="/googletest/s?path=compare.py&amp;project=benchmark">compare.py</a>
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>The `<a href="/googletest/s?path=compare.py&amp;project=benchmark">compare.py</a>` can be used to compare the result of benchmarks.
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>### Dependencies
<a class="l" name="8" href="#8">8</a>The utility relies on the [scipy](<a href="https://www.scipy.org">https://www.scipy.org</a>) package which can be installed using pip:
<a class="l" name="9" href="#9">9</a>```bash
<a class="hl" name="10" href="#10">10</a>pip3 install -r <a href="/googletest/s?path=requirements.txt&amp;project=benchmark">requirements.txt</a>
<a class="l" name="11" href="#11">11</a>```
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a>### Displaying aggregates only
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a>The switch `-a` / `--display_aggregates_only` can be used to control the
<a class="l" name="16" href="#16">16</a>displayment of the normal iterations vs the aggregates. When passed, it will
<a class="l" name="17" href="#17">17</a>be passthrough to the benchmark binaries to be run, and will be accounted for
<a class="l" name="18" href="#18">18</a>in the tool itself; only the aggregates will be displayed, but not normal runs.
<a class="l" name="19" href="#19">19</a>It only affects the display, the separate runs will still be used to calculate
<a class="hl" name="20" href="#20">20</a>the U test.
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a>### Modes of operation
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a>There are three modes of operation:
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a>1. Just compare two benchmarks
<a class="l" name="27" href="#27">27</a>The program is invoked like:
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a>``` bash
<a class="hl" name="30" href="#30">30</a>$ <a href="/googletest/s?path=compare.py&amp;project=benchmark">compare.py</a> benchmarks &lt;benchmark_baseline&gt; &lt;benchmark_contender&gt; [benchmark options]...
<a class="l" name="31" href="#31">31</a>```
<a class="l" name="32" href="#32">32</a>Where `&lt;benchmark_baseline&gt;` and `&lt;benchmark_contender&gt;` either specify a benchmark executable file, or a JSON output file. The type of the input file is automatically detected. If a benchmark executable is specified then the benchmark is run to obtain the results. Otherwise the results are simply loaded from the output file.
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a>`[benchmark options]` will be passed to the benchmarks invocations. They can be anything that binary accepts, be it either normal `--benchmark_*` parameters, or some custom parameters your binary takes.
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a>Example output:
<a class="l" name="37" href="#37">37</a>```
<a class="l" name="38" href="#38">38</a>$ ./<a href="/googletest/s?path=compare.py&amp;project=benchmark">compare.py</a> benchmarks ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a> ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a>
<a class="l" name="39" href="#39">39</a>RUNNING: ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a> --benchmark_out=<a href="/googletest/s?path=/tmp/tmprBT5nW&amp;project=benchmark">/tmp/tmprBT5nW</a>
<a class="hl" name="40" href="#40">40</a>Run on (8 X 4000 MHz CPU s)
<a class="l" name="41" href="#41">41</a>2017-11-07 21:16:44
<a class="l" name="42" href="#42">42</a>------------------------------------------------------
<a class="l" name="43" href="#43">43</a>Benchmark               Time           CPU Iterations
<a class="l" name="44" href="#44">44</a>------------------------------------------------------
<a class="l" name="45" href="#45">45</a>BM_memcpy/8            36 ns         36 ns   19101577   211.669MB/s
<a class="l" name="46" href="#46">46</a>BM_memcpy/64           76 ns         76 ns    9412571   800.199MB/s
<a class="l" name="47" href="#47">47</a>BM_memcpy/512          84 ns         84 ns    8249070   5.64771GB/s
<a class="l" name="48" href="#48">48</a>BM_memcpy/1024        116 ns        116 ns    6181763   8.19505GB/s
<a class="l" name="49" href="#49">49</a>BM_memcpy/8192        643 ns        643 ns    1062855   11.8636GB/s
<a class="hl" name="50" href="#50">50</a>BM_copy/8             222 ns        222 ns    3137987   34.3772MB/s
<a class="l" name="51" href="#51">51</a>BM_copy/64           1608 ns       1608 ns     432758   37.9501MB/s
<a class="l" name="52" href="#52">52</a>BM_copy/512         12589 ns      12589 ns      54806   38.7867MB/s
<a class="l" name="53" href="#53">53</a>BM_copy/1024        25169 ns      25169 ns      27713   38.8003MB/s
<a class="l" name="54" href="#54">54</a>BM_copy/8192       201165 ns     201112 ns       3486   38.8466MB/s
<a class="l" name="55" href="#55">55</a>RUNNING: ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a> --benchmark_out=<a href="/googletest/s?path=/tmp/tmpt1wwG&amp;project=benchmark">/tmp/tmpt1wwG</a>_
<a class="l" name="56" href="#56">56</a>Run on (8 X 4000 MHz CPU s)
<a class="l" name="57" href="#57">57</a>2017-11-07 21:16:53
<a class="l" name="58" href="#58">58</a>------------------------------------------------------
<a class="l" name="59" href="#59">59</a>Benchmark               Time           CPU Iterations
<a class="hl" name="60" href="#60">60</a>------------------------------------------------------
<a class="l" name="61" href="#61">61</a>BM_memcpy/8            36 ns         36 ns   19397903   211.255MB/s
<a class="l" name="62" href="#62">62</a>BM_memcpy/64           73 ns         73 ns    9691174   839.635MB/s
<a class="l" name="63" href="#63">63</a>BM_memcpy/512          85 ns         85 ns    8312329   5.60101GB/s
<a class="l" name="64" href="#64">64</a>BM_memcpy/1024        118 ns        118 ns    6438774   8.11608GB/s
<a class="l" name="65" href="#65">65</a>BM_memcpy/8192        656 ns        656 ns    1068644   11.6277GB/s
<a class="l" name="66" href="#66">66</a>BM_copy/8             223 ns        223 ns    3146977   34.2338MB/s
<a class="l" name="67" href="#67">67</a>BM_copy/64           1611 ns       1611 ns     435340   37.8751MB/s
<a class="l" name="68" href="#68">68</a>BM_copy/512         12622 ns      12622 ns      54818   38.6844MB/s
<a class="l" name="69" href="#69">69</a>BM_copy/1024        25257 ns      25239 ns      27779   38.6927MB/s
<a class="hl" name="70" href="#70">70</a>BM_copy/8192       205013 ns     205010 ns       3479    38.108MB/s
<a class="l" name="71" href="#71">71</a>Comparing ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a> to ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a>
<a class="l" name="72" href="#72">72</a>Benchmark                 Time             CPU      Time Old      Time New       CPU Old       CPU New
<a class="l" name="73" href="#73">73</a>------------------------------------------------------------------------------------------------------
<a class="l" name="74" href="#74">74</a>BM_memcpy/8            +0.0020         +0.0020            36            36            36            36
<a class="l" name="75" href="#75">75</a>BM_memcpy/64           -0.0468         -0.0470            76            73            76            73
<a class="l" name="76" href="#76">76</a>BM_memcpy/512          +0.0081         +0.0083            84            85            84            85
<a class="l" name="77" href="#77">77</a>BM_memcpy/1024         +0.0098         +0.0097           116           118           116           118
<a class="l" name="78" href="#78">78</a>BM_memcpy/8192         +0.0200         +0.0203           643           656           643           656
<a class="l" name="79" href="#79">79</a>BM_copy/8              +0.0046         +0.0042           222           223           222           223
<a class="hl" name="80" href="#80">80</a>BM_copy/64             +0.0020         +0.0020          1608          1611          1608          1611
<a class="l" name="81" href="#81">81</a>BM_copy/512            +0.0027         +0.0026         12589         12622         12589         12622
<a class="l" name="82" href="#82">82</a>BM_copy/1024           +0.0035         +0.0028         25169         25257         25169         25239
<a class="l" name="83" href="#83">83</a>BM_copy/8192           +0.0191         +0.0194        201165        205013        201112        205010
<a class="l" name="84" href="#84">84</a>```
<a class="l" name="85" href="#85">85</a>
<a class="l" name="86" href="#86">86</a>What it does is for the every benchmark from the first run it looks for the benchmark with exactly the same name in the second run, and then compares the results. If the names differ, the benchmark is omitted from the diff.
<a class="l" name="87" href="#87">87</a>As you can note, the values in `Time` and `CPU` columns are calculated as `(new - old) / |old|`.
<a class="l" name="88" href="#88">88</a>
<a class="l" name="89" href="#89">89</a>2. Compare two different filters of one benchmark
<a class="hl" name="90" href="#90">90</a>The program is invoked like:
<a class="l" name="91" href="#91">91</a>
<a class="l" name="92" href="#92">92</a>``` bash
<a class="l" name="93" href="#93">93</a>$ <a href="/googletest/s?path=compare.py&amp;project=benchmark">compare.py</a> filters &lt;benchmark&gt; &lt;filter_baseline&gt; &lt;filter_contender&gt; [benchmark options]...
<a class="l" name="94" href="#94">94</a>```
<a class="l" name="95" href="#95">95</a>Where `&lt;benchmark&gt;` either specify a benchmark executable file, or a JSON output file. The type of the input file is automatically detected. If a benchmark executable is specified then the benchmark is run to obtain the results. Otherwise the results are simply loaded from the output file.
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>Where `&lt;filter_baseline&gt;` and `&lt;filter_contender&gt;` are the same regex filters that you would pass to the `[--benchmark_filter=&lt;regex&gt;]` parameter of the benchmark binary.
<a class="l" name="98" href="#98">98</a>
<a class="l" name="99" href="#99">99</a>`[benchmark options]` will be passed to the benchmarks invocations. They can be anything that binary accepts, be it either normal `--benchmark_*` parameters, or some custom parameters your binary takes.
<a class="hl" name="100" href="#100">100</a>
<a class="l" name="101" href="#101">101</a>Example output:
<a class="l" name="102" href="#102">102</a>```
<a class="l" name="103" href="#103">103</a>$ ./<a href="/googletest/s?path=compare.py&amp;project=benchmark">compare.py</a> filters ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a> BM_memcpy BM_copy
<a class="l" name="104" href="#104">104</a>RUNNING: ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a> --benchmark_filter=BM_memcpy --benchmark_out=<a href="/googletest/s?path=/tmp/tmpBWKk0k&amp;project=benchmark">/tmp/tmpBWKk0k</a>
<a class="l" name="105" href="#105">105</a>Run on (8 X 4000 MHz CPU s)
<a class="l" name="106" href="#106">106</a>2017-11-07 21:37:28
<a class="l" name="107" href="#107">107</a>------------------------------------------------------
<a class="l" name="108" href="#108">108</a>Benchmark               Time           CPU Iterations
<a class="l" name="109" href="#109">109</a>------------------------------------------------------
<a class="hl" name="110" href="#110">110</a>BM_memcpy/8            36 ns         36 ns   17891491   211.215MB/s
<a class="l" name="111" href="#111">111</a>BM_memcpy/64           74 ns         74 ns    9400999   825.646MB/s
<a class="l" name="112" href="#112">112</a>BM_memcpy/512          87 ns         87 ns    8027453   5.46126GB/s
<a class="l" name="113" href="#113">113</a>BM_memcpy/1024        111 ns        111 ns    6116853    8.5648GB/s
<a class="l" name="114" href="#114">114</a>BM_memcpy/8192        657 ns        656 ns    1064679   11.6247GB/s
<a class="l" name="115" href="#115">115</a>RUNNING: ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a> --benchmark_filter=BM_copy --benchmark_out=<a href="/googletest/s?path=/tmp/tmpAvWcOM&amp;project=benchmark">/tmp/tmpAvWcOM</a>
<a class="l" name="116" href="#116">116</a>Run on (8 X 4000 MHz CPU s)
<a class="l" name="117" href="#117">117</a>2017-11-07 21:37:33
<a class="l" name="118" href="#118">118</a>----------------------------------------------------
<a class="l" name="119" href="#119">119</a>Benchmark             Time           CPU Iterations
<a class="hl" name="120" href="#120">120</a>----------------------------------------------------
<a class="l" name="121" href="#121">121</a>BM_copy/8           227 ns        227 ns    3038700   33.6264MB/s
<a class="l" name="122" href="#122">122</a>BM_copy/64         1640 ns       1640 ns     426893   37.2154MB/s
<a class="l" name="123" href="#123">123</a>BM_copy/512       12804 ns      12801 ns      55417   38.1444MB/s
<a class="l" name="124" href="#124">124</a>BM_copy/1024      25409 ns      25407 ns      27516   38.4365MB/s
<a class="l" name="125" href="#125">125</a>BM_copy/8192     202986 ns     202990 ns       3454   38.4871MB/s
<a class="l" name="126" href="#126">126</a>Comparing BM_memcpy to BM_copy (from ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a>)
<a class="l" name="127" href="#127">127</a>Benchmark                               Time             CPU      Time Old      Time New       CPU Old       CPU New
<a class="l" name="128" href="#128">128</a>--------------------------------------------------------------------------------------------------------------------
<a class="l" name="129" href="#129">129</a>[BM_memcpy vs. BM_copy]/8            +5.2829         +5.2812            36           227            36           227
<a class="hl" name="130" href="#130">130</a>[BM_memcpy vs. BM_copy]/64          +21.1719        +21.1856            74          1640            74          1640
<a class="l" name="131" href="#131">131</a>[BM_memcpy vs. BM_copy]/512        +145.6487       +145.6097            87         12804            87         12801
<a class="l" name="132" href="#132">132</a>[BM_memcpy vs. BM_copy]/1024       +227.1860       +227.1776           111         25409           111         25407
<a class="l" name="133" href="#133">133</a>[BM_memcpy vs. BM_copy]/8192       +308.1664       +308.2898           657        202986           656        202990
<a class="l" name="134" href="#134">134</a>```
<a class="l" name="135" href="#135">135</a>
<a class="l" name="136" href="#136">136</a>As you can see, it applies filter to the benchmarks, both when running the benchmark, and before doing the diff. And to make the diff work, the matches are replaced with some common string. Thus, you can compare two different benchmark families within one benchmark binary.
<a class="l" name="137" href="#137">137</a>As you can note, the values in `Time` and `CPU` columns are calculated as `(new - old) / |old|`.
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>3. Compare filter one from benchmark one to filter two from benchmark two:
<a class="hl" name="140" href="#140">140</a>The program is invoked like:
<a class="l" name="141" href="#141">141</a>
<a class="l" name="142" href="#142">142</a>``` bash
<a class="l" name="143" href="#143">143</a>$ <a href="/googletest/s?path=compare.py&amp;project=benchmark">compare.py</a> filters &lt;benchmark_baseline&gt; &lt;filter_baseline&gt; &lt;benchmark_contender&gt; &lt;filter_contender&gt; [benchmark options]...
<a class="l" name="144" href="#144">144</a>```
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>Where `&lt;benchmark_baseline&gt;` and `&lt;benchmark_contender&gt;` either specify a benchmark executable file, or a JSON output file. The type of the input file is automatically detected. If a benchmark executable is specified then the benchmark is run to obtain the results. Otherwise the results are simply loaded from the output file.
<a class="l" name="147" href="#147">147</a>
<a class="l" name="148" href="#148">148</a>Where `&lt;filter_baseline&gt;` and `&lt;filter_contender&gt;` are the same regex filters that you would pass to the `[--benchmark_filter=&lt;regex&gt;]` parameter of the benchmark binary.
<a class="l" name="149" href="#149">149</a>
<a class="hl" name="150" href="#150">150</a>`[benchmark options]` will be passed to the benchmarks invocations. They can be anything that binary accepts, be it either normal `--benchmark_*` parameters, or some custom parameters your binary takes.
<a class="l" name="151" href="#151">151</a>
<a class="l" name="152" href="#152">152</a>Example output:
<a class="l" name="153" href="#153">153</a>```
<a class="l" name="154" href="#154">154</a>$ ./<a href="/googletest/s?path=compare.py&amp;project=benchmark">compare.py</a> benchmarksfiltered ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a> BM_memcpy ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a> BM_copy
<a class="l" name="155" href="#155">155</a>RUNNING: ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a> --benchmark_filter=BM_memcpy --benchmark_out=<a href="/googletest/s?path=/tmp/tmp_FvbYg&amp;project=benchmark">/tmp/tmp_FvbYg</a>
<a class="l" name="156" href="#156">156</a>Run on (8 X 4000 MHz CPU s)
<a class="l" name="157" href="#157">157</a>2017-11-07 21:38:27
<a class="l" name="158" href="#158">158</a>------------------------------------------------------
<a class="l" name="159" href="#159">159</a>Benchmark               Time           CPU Iterations
<a class="hl" name="160" href="#160">160</a>------------------------------------------------------
<a class="l" name="161" href="#161">161</a>BM_memcpy/8            37 ns         37 ns   18953482   204.118MB/s
<a class="l" name="162" href="#162">162</a>BM_memcpy/64           74 ns         74 ns    9206578   828.245MB/s
<a class="l" name="163" href="#163">163</a>BM_memcpy/512          91 ns         91 ns    8086195   5.25476GB/s
<a class="l" name="164" href="#164">164</a>BM_memcpy/1024        120 ns        120 ns    5804513   7.95662GB/s
<a class="l" name="165" href="#165">165</a>BM_memcpy/8192        664 ns        664 ns    1028363   11.4948GB/s
<a class="l" name="166" href="#166">166</a>RUNNING: ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a> --benchmark_filter=BM_copy --benchmark_out=<a href="/googletest/s?path=/tmp/tmpDfL5iE&amp;project=benchmark">/tmp/tmpDfL5iE</a>
<a class="l" name="167" href="#167">167</a>Run on (8 X 4000 MHz CPU s)
<a class="l" name="168" href="#168">168</a>2017-11-07 21:38:32
<a class="l" name="169" href="#169">169</a>----------------------------------------------------
<a class="hl" name="170" href="#170">170</a>Benchmark             Time           CPU Iterations
<a class="l" name="171" href="#171">171</a>----------------------------------------------------
<a class="l" name="172" href="#172">172</a>BM_copy/8           230 ns        230 ns    2985909   33.1161MB/s
<a class="l" name="173" href="#173">173</a>BM_copy/64         1654 ns       1653 ns     419408   36.9137MB/s
<a class="l" name="174" href="#174">174</a>BM_copy/512       13122 ns      13120 ns      53403   37.2156MB/s
<a class="l" name="175" href="#175">175</a>BM_copy/1024      26679 ns      26666 ns      26575   36.6218MB/s
<a class="l" name="176" href="#176">176</a>BM_copy/8192     215068 ns     215053 ns       3221   36.3283MB/s
<a class="l" name="177" href="#177">177</a>Comparing BM_memcpy (from ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a>) to BM_copy (from ./<a href="/googletest/s?path=a.out&amp;project=benchmark">a.out</a>)
<a class="l" name="178" href="#178">178</a>Benchmark                               Time             CPU      Time Old      Time New       CPU Old       CPU New
<a class="l" name="179" href="#179">179</a>--------------------------------------------------------------------------------------------------------------------
<a class="hl" name="180" href="#180">180</a>[BM_memcpy vs. BM_copy]/8            +5.1649         +5.1637            37           230            37           230
<a class="l" name="181" href="#181">181</a>[BM_memcpy vs. BM_copy]/64          +21.4352        +21.4374            74          1654            74          1653
<a class="l" name="182" href="#182">182</a>[BM_memcpy vs. BM_copy]/512        +143.6022       +143.5865            91         13122            91         13120
<a class="l" name="183" href="#183">183</a>[BM_memcpy vs. BM_copy]/1024       +221.5903       +221.4790           120         26679           120         26666
<a class="l" name="184" href="#184">184</a>[BM_memcpy vs. BM_copy]/8192       +322.9059       +323.0096           664        215068           664        215053
<a class="l" name="185" href="#185">185</a>```
<a class="l" name="186" href="#186">186</a>This is a mix of the previous two modes, two (potentially different) benchmark binaries are run, and a different filter is applied to each one.
<a class="l" name="187" href="#187">187</a>As you can note, the values in `Time` and `CPU` columns are calculated as `(new - old) / |old|`.
<a class="l" name="188" href="#188">188</a>
<a class="l" name="189" href="#189">189</a>### U test
<a class="hl" name="190" href="#190">190</a>
<a class="l" name="191" href="#191">191</a>If there is a sufficient repetition count of the benchmarks, the tool can do
<a class="l" name="192" href="#192">192</a>a [U Test](<a href="https://en.wikipedia.org/wiki/Mann%E2%80%93Whitney_U_test">https://en.wikipedia.org/wiki/Mann%E2%80%93Whitney_U_test</a>), of the
<a class="l" name="193" href="#193">193</a>null hypothesis that it is equally likely that a randomly selected value from
<a class="l" name="194" href="#194">194</a>one sample will be less than or greater than a randomly selected value from a
<a class="l" name="195" href="#195">195</a>second sample.
<a class="l" name="196" href="#196">196</a>
<a class="l" name="197" href="#197">197</a>If the calculated p-value is below this value is lower than the significance
<a class="l" name="198" href="#198">198</a>level alpha, then the result is said to be statistically significant and the
<a class="l" name="199" href="#199">199</a>null hypothesis is rejected. Which in other words means that the two benchmarks
<a class="hl" name="200" href="#200">200</a>aren't identical.
<a class="l" name="201" href="#201">201</a>
<a class="l" name="202" href="#202">202</a>**WARNING**: requires **LARGE** (no less than 9) number of repetitions to be
<a class="l" name="203" href="#203">203</a>meaningful!
<a class="l" name="204" href="#204">204</a>