<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># How to contribute #
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>We'd love to accept your patches and contributions to this project.  There are
<a class="l" name="4" href="#4">4</a>a just a few small guidelines you need to follow.
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>## Contributor License Agreement ##
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>Contributions to any Google project must be accompanied by a Contributor
<a class="hl" name="10" href="#10">10</a>License Agreement.  This is not a copyright **assignment**, it simply gives
<a class="l" name="11" href="#11">11</a>Google permission to use and redistribute your contributions as part of the
<a class="l" name="12" href="#12">12</a>project.
<a class="l" name="13" href="#13">13</a>
<a class="l" name="14" href="#14">14</a>  * If you are an individual writing original source code and you're sure you
<a class="l" name="15" href="#15">15</a>    own the intellectual property, then you'll need to sign an [individual
<a class="l" name="16" href="#16">16</a>    CLA][].
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a>  * If you work for a company that wants to allow you to contribute your work,
<a class="l" name="19" href="#19">19</a>    then you'll need to sign a [corporate CLA][].
<a class="hl" name="20" href="#20">20</a>
<a class="l" name="21" href="#21">21</a>You generally only need to submit a CLA once, so if you've already submitted
<a class="l" name="22" href="#22">22</a>one (even if it was for a different project), you probably don't need to do it
<a class="l" name="23" href="#23">23</a>again.
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a>[individual CLA]: <a href="https://developers.google.com/open-source/cla/individual">https://developers.google.com/open-source/cla/individual</a>
<a class="l" name="26" href="#26">26</a>[corporate CLA]: <a href="https://developers.google.com/open-source/cla/corporate">https://developers.google.com/open-source/cla/corporate</a>
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a>Once your CLA is submitted (or if you already submitted one for
<a class="l" name="29" href="#29">29</a>another Google project), make a commit adding yourself to the
<a class="hl" name="30" href="#30">30</a>[AUTHORS][] and [CONTRIBUTORS][] files. This commit can be part
<a class="l" name="31" href="#31">31</a>of your first [pull request][].
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>[AUTHORS]: AUTHORS
<a class="l" name="34" href="#34">34</a>[CONTRIBUTORS]: CONTRIBUTORS
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>## Submitting a patch ##
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>  1. It's generally best to start by opening a new issue describing the bug or
<a class="hl" name="40" href="#40">40</a>     feature you're intending to fix.  Even if you think it's relatively minor,
<a class="l" name="41" href="#41">41</a>     it's helpful to know what people are working on.  Mention in the initial
<a class="l" name="42" href="#42">42</a>     issue that you are planning to work on that bug or feature so that it can
<a class="l" name="43" href="#43">43</a>     be assigned to you.
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>  1. Follow the normal process of [forking][] the project, and setup a new
<a class="l" name="46" href="#46">46</a>     branch to work in.  It's important that each group of changes be done in
<a class="l" name="47" href="#47">47</a>     separate branches in order to ensure that a pull request only includes the
<a class="l" name="48" href="#48">48</a>     commits related to that bug or feature.
<a class="l" name="49" href="#49">49</a>
<a class="hl" name="50" href="#50">50</a>  1. Do your best to have [well-formed commit messages][] for each change.
<a class="l" name="51" href="#51">51</a>     This provides consistency throughout the project, and ensures that commit
<a class="l" name="52" href="#52">52</a>     messages are able to be formatted properly by various git tools.
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>  1. Finally, push the commits to your fork and submit a [pull request][].
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>[forking]: <a href="https://help.github.com/articles/fork-a-repo">https://help.github.com/articles/fork-a-repo</a>
<a class="l" name="57" href="#57">57</a>[well-formed commit messages]: <a href="http://tbaggery.com/2008/04/19/a-note-about-git-commit-messages.html">http://tbaggery.com/2008/04/19/a-note-about-git-commit-messages.html</a>
<a class="l" name="58" href="#58">58</a>[pull request]: <a href="https://help.github.com/articles/creating-a-pull-request">https://help.github.com/articles/creating-a-pull-request</a>
<a class="l" name="59" href="#59">59</a>