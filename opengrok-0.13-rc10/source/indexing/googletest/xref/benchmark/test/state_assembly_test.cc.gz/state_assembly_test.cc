<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Function","xf",[["test_for_auto_loop",18],["test_while_loop",41]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span>#<b>include</b> &lt;<a href="/googletest/s?path=benchmark/">benchmark</a>/<a href="/googletest/s?path=benchmark/benchmark.h">benchmark.h</a>&gt;
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span>#<b>ifdef</b> <a href="/googletest/s?defs=__clang__&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__clang__</a>
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span>#<b>pragma</b> <a href="/googletest/s?defs=clang&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">clang</a> <a href="/googletest/s?defs=diagnostic&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">diagnostic</a> <a href="/googletest/s?defs=ignored&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ignored</a> <span class="s">"-Wreturn-type"</span>
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span>#<b>endif</b>
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span><span class="c">// clang-format off</span>
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span><b>extern</b> <span class="s">"C"</span> &#123;
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span>  <b>extern</b> <b>int</b> <a href="/googletest/s?defs=ExternInt&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ExternInt</a>&#59;
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=benchmark&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">benchmark</a>::<a href="/googletest/s?defs=State&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">State</a>&amp; <a href="/googletest/s?defs=GetState&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetState</a>()&#59;
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span>  <b>void</b> <a href="/googletest/s?defs=Fn&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Fn</a>()&#59;
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span><span class="c">// clang-format on</span>
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span><b>using</b> <a href="/googletest/s?defs=benchmark&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">benchmark</a>::<a href="/googletest/s?defs=State&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">State</a>&#59;
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span><span class="c">// CHECK-LABEL: test_for_auto_loop:</span>
<span id='scope_id_a20387b9' class='scope-head'><span class='scope-signature'>test_for_auto_loop()</span><a class="l" name="18" href="#18">18</a><a href="#" onclick='fold(this.parentNode.id)' id='scope_id_a20387b9_fold_icon'><span class='fold-icon'>&nbsp;</span></a><b>extern</b> <span class="s">"C"</span> <b>int</b> <a class="xf" name="test_for_auto_loop"/><a href="/googletest/s?refs=test_for_auto_loop&amp;project=benchmark" class="xf intelliWindow-symbol" data-definition-place="def">test_for_auto_loop</a>() &#123;</span>
<span id='scope_id_a20387b9_fold' class='scope-body'><a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=State&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">State</a>&amp; S = <a href="/googletest/s?defs=GetState&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetState</a>()&#59;
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span>  <b>int</b> x = <span class="n">42</span>&#59;
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK: 	[[CALL:call(q)*]]	_ZN9benchmark5State16StartKeepRunningEv</span>
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK-NEXT: testq %rbx, %rbx</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK-NEXT: je [[LOOP_END:.*]]</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>  <b>for</b> (<b>auto</b> _ : S) &#123;
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span>    <span class="c">// CHECK: .L[[LOOP_HEAD:[a-zA-Z0-9_]+]]:</span>
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span>    <span class="c">// CHECK-GNU-NEXT: subq $1, %rbx</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span>    <span class="c">// CHECK-CLANG-NEXT: {{(addq \$1, %rax|incq %rax|addq \$-1, %rbx)}}</span>
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span>    <span class="c">// CHECK-NEXT: jne .L[[LOOP_HEAD]]</span>
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span>    <a href="/googletest/s?defs=benchmark&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">benchmark</a>::<a href="/googletest/s?defs=DoNotOptimize&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">DoNotOptimize</a>(x)&#59;
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span>  &#125;
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK: [[LOOP_END]]:</span>
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK: [[CALL]]	_ZN9benchmark5State17FinishKeepRunningEv</span>
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK: movl $101, %eax</span>
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK: ret</span>
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>  <b>return</b> <span class="n">101</span>&#59;
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>&#125;
</span><a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span><span class="c">// CHECK-LABEL: test_while_loop:</span>
<span id='scope_id_5619e123' class='scope-head'><span class='scope-signature'>test_while_loop()</span><a class="l" name="41" href="#41">41</a><a href="#" onclick='fold(this.parentNode.id)' id='scope_id_5619e123_fold_icon'><span class='fold-icon'>&nbsp;</span></a><b>extern</b> <span class="s">"C"</span> <b>int</b> <a class="xf" name="test_while_loop"/><a href="/googletest/s?refs=test_while_loop&amp;project=benchmark" class="xf intelliWindow-symbol" data-definition-place="def">test_while_loop</a>() &#123;</span>
<span id='scope_id_5619e123_fold' class='scope-body'><a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=State&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">State</a>&amp; S = <a href="/googletest/s?defs=GetState&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetState</a>()&#59;
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>  <b>int</b> x = <span class="n">42</span>&#59;
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK: j{{(e|mp)}} .L[[LOOP_HEADER:[a-zA-Z0-9_]+]]</span>
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK-NEXT: .L[[LOOP_BODY:[a-zA-Z0-9_]+]]:</span>
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>  <b>while</b> (S.<a href="/googletest/s?defs=KeepRunning&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">KeepRunning</a>()) &#123;
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>    <span class="c">// CHECK-GNU-NEXT: subq $1, %[[IREG:[a-z]+]]</span>
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>    <span class="c">// CHECK-CLANG-NEXT: {{(addq \$-1,|decq)}} %[[IREG:[a-z]+]]</span>
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>    <span class="c">// CHECK: movq %[[IREG]], [[DEST:.*]]</span>
<a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span>    <a href="/googletest/s?defs=benchmark&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">benchmark</a>::<a href="/googletest/s?defs=DoNotOptimize&amp;project=benchmark" class="intelliWindow-symbol" data-definition-place="undefined-in-file">DoNotOptimize</a>(x)&#59;
<a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span>  &#125;
<a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK-DAG: movq [[DEST]], %[[IREG]]</span>
<a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK-DAG: testq %[[IREG]], %[[IREG]]</span>
<a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK-DAG: jne .L[[LOOP_BODY]]</span>
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK-DAG: .L[[LOOP_HEADER]]:</span>
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="58" href="#58">58</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK: cmpb $0</span>
<a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK-NEXT: jne .L[[LOOP_END:[a-zA-Z0-9_]+]]</span>
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK: [[CALL:call(q)*]] _ZN9benchmark5State16StartKeepRunningEv</span>
<a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK: .L[[LOOP_END]]:</span>
<a class="l" name="63" href="#63">63</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK: [[CALL]] _ZN9benchmark5State17FinishKeepRunningEv</span>
<a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK: movl $101, %eax</span>
<a class="l" name="66" href="#66">66</a><span class='fold-space'>&nbsp;</span>  <span class="c">// CHECK: ret</span>
<a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span>  <b>return</b> <span class="n">101</span>&#59;
<a class="l" name="68" href="#68">68</a><span class='fold-space'>&nbsp;</span>&#125;
</span><a class="l" name="69" href="#69">69</a><span class='fold-space'>&nbsp;</span>