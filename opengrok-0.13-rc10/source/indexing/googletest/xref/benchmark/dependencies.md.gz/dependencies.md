<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># Build tool dependency policy
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>To ensure the broadest compatibility when building the benchmark library, but
<a class="l" name="4" href="#4">4</a>still allow forward progress, we require any build tooling to be available for:
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a>* Debian stable AND
<a class="l" name="7" href="#7">7</a>* The last two Ubuntu LTS releases AND
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>Currently, this means using build tool versions that are available for Ubuntu
<a class="hl" name="10" href="#10">10</a>16.04 (Xenial), Ubuntu 18.04 (Bionic), and Debian stretch.
<a class="l" name="11" href="#11">11</a>
<a class="l" name="12" href="#12">12</a>_Note, [travis](<a href="/googletest/s?path=.travis.yml&amp;project=benchmark">.travis.yml</a>) runs under Ubuntu 14.04 (Trusty) for linux builds._
<a class="l" name="13" href="#13">13</a>
<a class="l" name="14" href="#14">14</a>## cmake
<a class="l" name="15" href="#15">15</a>The current supported version is cmake 3.5.1 as of 2018-06-06.
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a>_Note, this version is also available for Ubuntu 14.04, the previous Ubuntu LTS
<a class="l" name="18" href="#18">18</a>release, as `cmake3`._
<a class="l" name="19" href="#19">19</a>