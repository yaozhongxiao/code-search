<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># Benchmark
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>[![build-and-test](<a href="https://github.com/google/benchmark/workflows/build-and-test/badge.svg">https://github.com/google/benchmark/workflows/build-and-test/badge.svg</a>)](<a href="https://github.com/google/benchmark/actions?query=workflow%3Abuild-and-test">https://github.com/google/benchmark/actions?query=workflow%3Abuild-and-test</a>)
<a class="l" name="4" href="#4">4</a>[![pylint](<a href="https://github.com/google/benchmark/workflows/pylint/badge.svg">https://github.com/google/benchmark/workflows/pylint/badge.svg</a>)](<a href="https://github.com/google/benchmark/actions?query=workflow%3Apylint">https://github.com/google/benchmark/actions?query=workflow%3Apylint</a>)
<a class="l" name="5" href="#5">5</a>[![test-bindings](<a href="https://github.com/google/benchmark/workflows/test-bindings/badge.svg">https://github.com/google/benchmark/workflows/test-bindings/badge.svg</a>)](<a href="https://github.com/google/benchmark/actions?query=workflow%3Atest-bindings">https://github.com/google/benchmark/actions?query=workflow%3Atest-bindings</a>)
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>[![Build Status](<a href="https://travis-ci.org/google/benchmark.svg?branch=master">https://travis-ci.org/google/benchmark.svg?branch=master</a>)](<a href="https://travis-ci.org/google/benchmark">https://travis-ci.org/google/benchmark</a>)
<a class="l" name="8" href="#8">8</a>[![Build status](<a href="https://ci.appveyor.com/api/projects/status/u0qsyp7t1tk7cpxs/branch/master?svg=true">https://ci.appveyor.com/api/projects/status/u0qsyp7t1tk7cpxs/branch/master?svg=true</a>)](<a href="https://ci.appveyor.com/project/google/benchmark/branch/master">https://ci.appveyor.com/project/google/benchmark/branch/master</a>)
<a class="l" name="9" href="#9">9</a>[![Coverage Status](<a href="https://coveralls.io/repos/google/benchmark/badge.svg">https://coveralls.io/repos/google/benchmark/badge.svg</a>)](<a href="https://coveralls.io/r/google/benchmark">https://coveralls.io/r/google/benchmark</a>)
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a>
<a class="l" name="12" href="#12">12</a>A library to benchmark code snippets, similar to unit tests. Example:
<a class="l" name="13" href="#13">13</a>
<a class="l" name="14" href="#14">14</a>```c++
<a class="l" name="15" href="#15">15</a>#include &lt;<a href="/googletest/s?path=benchmark/benchmark.h&amp;project=benchmark">benchmark/benchmark.h</a>&gt;
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a>static void BM_SomeFunction(benchmark::State&amp; state) {
<a class="l" name="18" href="#18">18</a>  // Perform setup here
<a class="l" name="19" href="#19">19</a>  for (auto _ : state) {
<a class="hl" name="20" href="#20">20</a>    // This code gets timed
<a class="l" name="21" href="#21">21</a>    SomeFunction();
<a class="l" name="22" href="#22">22</a>  }
<a class="l" name="23" href="#23">23</a>}
<a class="l" name="24" href="#24">24</a>// Register the function as a benchmark
<a class="l" name="25" href="#25">25</a>BENCHMARK(BM_SomeFunction);
<a class="l" name="26" href="#26">26</a>// Run the benchmark
<a class="l" name="27" href="#27">27</a>BENCHMARK_MAIN();
<a class="l" name="28" href="#28">28</a>```
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a>To get started, see [Requirements](#requirements) and
<a class="l" name="31" href="#31">31</a>[Installation](#installation). See [Usage](#usage) for a full example and the
<a class="l" name="32" href="#32">32</a>[User Guide](#user-guide) for a more comprehensive feature overview.
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a>It may also help to read the [Google Test documentation](<a href="https://github.com/google/googletest/blob/master/googletest/docs/primer.md">https://github.com/google/googletest/blob/master/googletest/docs/primer.md</a>)
<a class="l" name="35" href="#35">35</a>as some of the structural aspects of the APIs are similar.
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>### Resources
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>[Discussion group](<a href="https://groups.google.com/d/forum/benchmark-discuss">https://groups.google.com/d/forum/benchmark-discuss</a>)
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>IRC channel: [freenode](<a href="https://freenode.net">https://freenode.net</a>) #googlebenchmark
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>[Additional Tooling Documentation](<a href="/googletest/s?path=docs/tools.md&amp;project=benchmark">docs/tools.md</a>)
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>[Assembly Testing Documentation](<a href="/googletest/s?path=docs/AssemblyTests.md&amp;project=benchmark">docs/AssemblyTests.md</a>)
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>## Requirements
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>The library can be used with C++03. However, it requires C++11 to build,
<a class="hl" name="50" href="#50">50</a>including compiler and standard library support.
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a>The following minimum versions are required to build the library:
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>* GCC 4.8
<a class="l" name="55" href="#55">55</a>* Clang 3.4
<a class="l" name="56" href="#56">56</a>* Visual Studio 14 2015
<a class="l" name="57" href="#57">57</a>* Intel 2015 Update 1
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>See [Platform-Specific Build Instructions](#platform-specific-build-instructions).
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a>## Installation
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>This describes the installation process using cmake. As pre-requisites, you'll
<a class="l" name="64" href="#64">64</a>need git and cmake installed.
<a class="l" name="65" href="#65">65</a>
<a class="l" name="66" href="#66">66</a>_See [<a href="/googletest/s?path=dependencies.md&amp;project=benchmark">dependencies.md</a>](<a href="/googletest/s?path=dependencies.md&amp;project=benchmark">dependencies.md</a>) for more details regarding supported
<a class="l" name="67" href="#67">67</a>versions of build tools._
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>```bash
<a class="hl" name="70" href="#70">70</a># Check out the library.
<a class="l" name="71" href="#71">71</a>$ git clone <a href="https://github.com/google/benchmark.git">https://github.com/google/benchmark.git</a>
<a class="l" name="72" href="#72">72</a># Benchmark requires Google Test as a dependency. Add the source tree as a subdirectory.
<a class="l" name="73" href="#73">73</a>$ git clone <a href="https://github.com/google/googletest.git">https://github.com/google/googletest.git</a> <a href="/googletest/s?path=benchmark/googletest&amp;project=benchmark">benchmark/googletest</a>
<a class="l" name="74" href="#74">74</a># Go to the library root directory
<a class="l" name="75" href="#75">75</a>$ cd benchmark
<a class="l" name="76" href="#76">76</a># Make a build directory to place the build output.
<a class="l" name="77" href="#77">77</a>$ cmake -E make_directory "build"
<a class="l" name="78" href="#78">78</a># Generate build system files with cmake.
<a class="l" name="79" href="#79">79</a>$ cmake -E chdir "build" cmake -DCMAKE_BUILD_TYPE=Release ../
<a class="hl" name="80" href="#80">80</a># or, starting with CMake 3.13, use a simpler form:
<a class="l" name="81" href="#81">81</a># cmake -DCMAKE_BUILD_TYPE=Release -S . -B "build"
<a class="l" name="82" href="#82">82</a># Build the library.
<a class="l" name="83" href="#83">83</a>$ cmake --build "build" --config Release
<a class="l" name="84" href="#84">84</a>```
<a class="l" name="85" href="#85">85</a>This builds the `benchmark` and `benchmark_main` libraries and tests.
<a class="l" name="86" href="#86">86</a>On a unix system, the build directory should now look something like this:
<a class="l" name="87" href="#87">87</a>
<a class="l" name="88" href="#88">88</a>```
<a class="l" name="89" href="#89">89</a>/benchmark
<a class="hl" name="90" href="#90">90</a>  /build
<a class="l" name="91" href="#91">91</a>    /src
<a class="l" name="92" href="#92">92</a>      /<a href="/googletest/s?path=libbenchmark.a&amp;project=benchmark">libbenchmark.a</a>
<a class="l" name="93" href="#93">93</a>      /<a href="/googletest/s?path=libbenchmark_main.a&amp;project=benchmark">libbenchmark_main.a</a>
<a class="l" name="94" href="#94">94</a>    /test
<a class="l" name="95" href="#95">95</a>      ...
<a class="l" name="96" href="#96">96</a>```
<a class="l" name="97" href="#97">97</a>
<a class="l" name="98" href="#98">98</a>Next, you can run the tests to check the build.
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>```bash
<a class="l" name="101" href="#101">101</a>$ cmake -E chdir "build" ctest --build-config Release
<a class="l" name="102" href="#102">102</a>```
<a class="l" name="103" href="#103">103</a>
<a class="l" name="104" href="#104">104</a>If you want to install the library globally, also run:
<a class="l" name="105" href="#105">105</a>
<a class="l" name="106" href="#106">106</a>```
<a class="l" name="107" href="#107">107</a>sudo cmake --build "build" --config Release --target install
<a class="l" name="108" href="#108">108</a>```
<a class="l" name="109" href="#109">109</a>
<a class="hl" name="110" href="#110">110</a>Note that Google Benchmark requires Google Test to build and run the tests. This
<a class="l" name="111" href="#111">111</a>dependency can be provided two ways:
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>* Checkout the Google Test sources into `<a href="/googletest/s?path=benchmark/googletest&amp;project=benchmark">benchmark/googletest</a>` as above.
<a class="l" name="114" href="#114">114</a>* Otherwise, if `-DBENCHMARK_DOWNLOAD_DEPENDENCIES=ON` is specified during
<a class="l" name="115" href="#115">115</a>  configuration, the library will automatically download and build any required
<a class="l" name="116" href="#116">116</a>  dependencies.
<a class="l" name="117" href="#117">117</a>
<a class="l" name="118" href="#118">118</a>If you do not wish to build and run the tests, add `-DBENCHMARK_ENABLE_GTEST_TESTS=OFF`
<a class="l" name="119" href="#119">119</a>to `CMAKE_ARGS`.
<a class="hl" name="120" href="#120">120</a>
<a class="l" name="121" href="#121">121</a>### Debug vs Release
<a class="l" name="122" href="#122">122</a>
<a class="l" name="123" href="#123">123</a>By default, benchmark builds as a debug library. You will see a warning in the
<a class="l" name="124" href="#124">124</a>output when this is the case. To build it as a release library instead, add
<a class="l" name="125" href="#125">125</a>`-DCMAKE_BUILD_TYPE=Release` when generating the build system files, as shown
<a class="l" name="126" href="#126">126</a>above. The use of `--config Release` in build commands is needed to properly
<a class="l" name="127" href="#127">127</a>support multi-configuration tools (like Visual Studio for example) and can be
<a class="l" name="128" href="#128">128</a>skipped for other build systems (like Makefile).
<a class="l" name="129" href="#129">129</a>
<a class="hl" name="130" href="#130">130</a>To enable link-time optimisation, also add `-DBENCHMARK_ENABLE_LTO=true` when
<a class="l" name="131" href="#131">131</a>generating the build system files.
<a class="l" name="132" href="#132">132</a>
<a class="l" name="133" href="#133">133</a>If you are using gcc, you might need to set `GCC_AR` and `GCC_RANLIB` cmake
<a class="l" name="134" href="#134">134</a>cache variables, if autodetection fails.
<a class="l" name="135" href="#135">135</a>
<a class="l" name="136" href="#136">136</a>If you are using clang, you may need to set `LLVMAR_EXECUTABLE`,
<a class="l" name="137" href="#137">137</a>`LLVMNM_EXECUTABLE` and `LLVMRANLIB_EXECUTABLE` cmake cache variables.
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>### Stable and Experimental Library Versions
<a class="hl" name="140" href="#140">140</a>
<a class="l" name="141" href="#141">141</a>The main branch contains the latest stable version of the benchmarking library;
<a class="l" name="142" href="#142">142</a>the API of which can be considered largely stable, with source breaking changes
<a class="l" name="143" href="#143">143</a>being made only upon the release of a new major version.
<a class="l" name="144" href="#144">144</a>
<a class="l" name="145" href="#145">145</a>Newer, experimental, features are implemented and tested on the
<a class="l" name="146" href="#146">146</a>[`v2` branch](<a href="https://github.com/google/benchmark/tree/v2">https://github.com/google/benchmark/tree/v2</a>). Users who wish
<a class="l" name="147" href="#147">147</a>to use, test, and provide feedback on the new features are encouraged to try
<a class="l" name="148" href="#148">148</a>this branch. However, this branch provides no stability guarantees and reserves
<a class="l" name="149" href="#149">149</a>the right to change and break the API at any time.
<a class="hl" name="150" href="#150">150</a>
<a class="l" name="151" href="#151">151</a>## Usage
<a class="l" name="152" href="#152">152</a>
<a class="l" name="153" href="#153">153</a>### Basic usage
<a class="l" name="154" href="#154">154</a>
<a class="l" name="155" href="#155">155</a>Define a function that executes the code to measure, register it as a benchmark
<a class="l" name="156" href="#156">156</a>function using the `BENCHMARK` macro, and ensure an appropriate `main` function
<a class="l" name="157" href="#157">157</a>is available:
<a class="l" name="158" href="#158">158</a>
<a class="l" name="159" href="#159">159</a>```c++
<a class="hl" name="160" href="#160">160</a>#include &lt;<a href="/googletest/s?path=benchmark/benchmark.h&amp;project=benchmark">benchmark/benchmark.h</a>&gt;
<a class="l" name="161" href="#161">161</a>
<a class="l" name="162" href="#162">162</a>static void BM_StringCreation(benchmark::State&amp; state) {
<a class="l" name="163" href="#163">163</a>  for (auto _ : state)
<a class="l" name="164" href="#164">164</a>    std::string empty_string;
<a class="l" name="165" href="#165">165</a>}
<a class="l" name="166" href="#166">166</a>// Register the function as a benchmark
<a class="l" name="167" href="#167">167</a>BENCHMARK(BM_StringCreation);
<a class="l" name="168" href="#168">168</a>
<a class="l" name="169" href="#169">169</a>// Define another benchmark
<a class="hl" name="170" href="#170">170</a>static void BM_StringCopy(benchmark::State&amp; state) {
<a class="l" name="171" href="#171">171</a>  std::string x = "hello";
<a class="l" name="172" href="#172">172</a>  for (auto _ : state)
<a class="l" name="173" href="#173">173</a>    std::string copy(x);
<a class="l" name="174" href="#174">174</a>}
<a class="l" name="175" href="#175">175</a>BENCHMARK(BM_StringCopy);
<a class="l" name="176" href="#176">176</a>
<a class="l" name="177" href="#177">177</a>BENCHMARK_MAIN();
<a class="l" name="178" href="#178">178</a>```
<a class="l" name="179" href="#179">179</a>
<a class="hl" name="180" href="#180">180</a>To run the benchmark, compile and link against the `benchmark` library
<a class="l" name="181" href="#181">181</a>(<a href="/googletest/s?path=libbenchmark.a&amp;project=benchmark">libbenchmark.a</a>/.so). If you followed the build steps above, this library will 
<a class="l" name="182" href="#182">182</a>be under the build directory you created.
<a class="l" name="183" href="#183">183</a>
<a class="l" name="184" href="#184">184</a>```bash
<a class="l" name="185" href="#185">185</a># Example on linux after running the build steps above. Assumes the
<a class="l" name="186" href="#186">186</a># `benchmark` and `build` directories are under the current directory.
<a class="l" name="187" href="#187">187</a>$ g++ <a href="/googletest/s?path=mybenchmark.cc&amp;project=benchmark">mybenchmark.cc</a> -std=c++11 -isystem <a href="/googletest/s?path=benchmark/include&amp;project=benchmark">benchmark/include</a> \
<a class="l" name="188" href="#188">188</a>  -Lbenchmark<a href="/googletest/s?path=/build/src&amp;project=benchmark">/build/src</a> -lbenchmark -lpthread -o mybenchmark
<a class="l" name="189" href="#189">189</a>```
<a class="hl" name="190" href="#190">190</a>
<a class="l" name="191" href="#191">191</a>Alternatively, link against the `benchmark_main` library and remove
<a class="l" name="192" href="#192">192</a>`BENCHMARK_MAIN();` above to get the same behavior.
<a class="l" name="193" href="#193">193</a>
<a class="l" name="194" href="#194">194</a>The compiled executable will run all benchmarks by default. Pass the `--help`
<a class="l" name="195" href="#195">195</a>flag for option information or see the guide below.
<a class="l" name="196" href="#196">196</a>
<a class="l" name="197" href="#197">197</a>### Usage with CMake
<a class="l" name="198" href="#198">198</a>
<a class="l" name="199" href="#199">199</a>If using CMake, it is recommended to link against the project-provided
<a class="hl" name="200" href="#200">200</a>`benchmark::benchmark` and `benchmark::benchmark_main` targets using
<a class="l" name="201" href="#201">201</a>`target_link_libraries`.
<a class="l" name="202" href="#202">202</a>It is possible to use ```find_package``` to import an installed version of the
<a class="l" name="203" href="#203">203</a>library.
<a class="l" name="204" href="#204">204</a>```cmake
<a class="l" name="205" href="#205">205</a>find_package(benchmark REQUIRED)
<a class="l" name="206" href="#206">206</a>```
<a class="l" name="207" href="#207">207</a>Alternatively, ```add_subdirectory``` will incorporate the library directly in
<a class="l" name="208" href="#208">208</a>to one's CMake project.
<a class="l" name="209" href="#209">209</a>```cmake
<a class="hl" name="210" href="#210">210</a>add_subdirectory(benchmark)
<a class="l" name="211" href="#211">211</a>```
<a class="l" name="212" href="#212">212</a>Either way, link to the library as follows.
<a class="l" name="213" href="#213">213</a>```cmake
<a class="l" name="214" href="#214">214</a>target_link_libraries(MyTarget benchmark::benchmark)
<a class="l" name="215" href="#215">215</a>```
<a class="l" name="216" href="#216">216</a>
<a class="l" name="217" href="#217">217</a>## Platform Specific Build Instructions
<a class="l" name="218" href="#218">218</a>
<a class="l" name="219" href="#219">219</a>### Building with GCC
<a class="hl" name="220" href="#220">220</a>
<a class="l" name="221" href="#221">221</a>When the library is built using GCC it is necessary to link with the pthread
<a class="l" name="222" href="#222">222</a>library due to how GCC implements `std::thread`. Failing to link to pthread will
<a class="l" name="223" href="#223">223</a>lead to runtime exceptions (unless you're using libc++), not linker errors. See
<a class="l" name="224" href="#224">224</a>[issue #67](<a href="https://github.com/google/benchmark/issues/67">https://github.com/google/benchmark/issues/67</a>) for more details. You
<a class="l" name="225" href="#225">225</a>can link to pthread by adding `-pthread` to your linker command. Note, you can
<a class="l" name="226" href="#226">226</a>also use `-lpthread`, but there are potential issues with ordering of command
<a class="l" name="227" href="#227">227</a>line parameters if you use that.
<a class="l" name="228" href="#228">228</a>
<a class="l" name="229" href="#229">229</a>### Building with Visual Studio 2015 or 2017
<a class="hl" name="230" href="#230">230</a>
<a class="l" name="231" href="#231">231</a>The `shlwapi` library (`-lshlwapi`) is required to support a call to `CPUInfo` which reads the registry. Either add `<a href="/googletest/s?path=shlwapi.lib&amp;project=benchmark">shlwapi.lib</a>` under `[ Configuration Properties &gt; Linker &gt; Input ]`, or use the following:
<a class="l" name="232" href="#232">232</a>
<a class="l" name="233" href="#233">233</a>```
<a class="l" name="234" href="#234">234</a>// Alternatively, can add libraries using linker options.
<a class="l" name="235" href="#235">235</a>#ifdef _WIN32
<a class="l" name="236" href="#236">236</a>#pragma comment ( lib, "<a href="/googletest/s?path=Shlwapi.lib&amp;project=benchmark">Shlwapi.lib</a>" )
<a class="l" name="237" href="#237">237</a>#ifdef _DEBUG
<a class="l" name="238" href="#238">238</a>#pragma comment ( lib, "<a href="/googletest/s?path=benchmarkd.lib&amp;project=benchmark">benchmarkd.lib</a>" )
<a class="l" name="239" href="#239">239</a>#else
<a class="hl" name="240" href="#240">240</a>#pragma comment ( lib, "<a href="/googletest/s?path=benchmark.lib&amp;project=benchmark">benchmark.lib</a>" )
<a class="l" name="241" href="#241">241</a>#endif
<a class="l" name="242" href="#242">242</a>#endif
<a class="l" name="243" href="#243">243</a>```
<a class="l" name="244" href="#244">244</a>
<a class="l" name="245" href="#245">245</a>Can also use the graphical version of CMake:
<a class="l" name="246" href="#246">246</a>* Open `CMake GUI`.
<a class="l" name="247" href="#247">247</a>* Under `Where to build the binaries`, same path as source plus `build`.
<a class="l" name="248" href="#248">248</a>* Under `CMAKE_INSTALL_PREFIX`, same path as source plus `install`.
<a class="l" name="249" href="#249">249</a>* Click `Configure`, `Generate`, `Open Project`.
<a class="hl" name="250" href="#250">250</a>* If build fails, try deleting entire directory and starting again, or unticking options to build less.
<a class="l" name="251" href="#251">251</a>
<a class="l" name="252" href="#252">252</a>### Building with Intel 2015 Update 1 or Intel System Studio Update 4
<a class="l" name="253" href="#253">253</a>
<a class="l" name="254" href="#254">254</a>See instructions for building with Visual Studio. Once built, right click on the solution and change the build to Intel.
<a class="l" name="255" href="#255">255</a>
<a class="l" name="256" href="#256">256</a>### Building on Solaris
<a class="l" name="257" href="#257">257</a>
<a class="l" name="258" href="#258">258</a>If you're running benchmarks on solaris, you'll want the kstat library linked in
<a class="l" name="259" href="#259">259</a>too (`-lkstat`).
<a class="hl" name="260" href="#260">260</a>
<a class="l" name="261" href="#261">261</a>## User Guide
<a class="l" name="262" href="#262">262</a>
<a class="l" name="263" href="#263">263</a>### Command Line
<a class="l" name="264" href="#264">264</a>
<a class="l" name="265" href="#265">265</a>[Output Formats](#output-formats)
<a class="l" name="266" href="#266">266</a>
<a class="l" name="267" href="#267">267</a>[Output Files](#output-files)
<a class="l" name="268" href="#268">268</a>
<a class="l" name="269" href="#269">269</a>[Running Benchmarks](#running-benchmarks)
<a class="hl" name="270" href="#270">270</a>
<a class="l" name="271" href="#271">271</a>[Running a Subset of Benchmarks](#running-a-subset-of-benchmarks)
<a class="l" name="272" href="#272">272</a>
<a class="l" name="273" href="#273">273</a>[Result Comparison](#result-comparison)
<a class="l" name="274" href="#274">274</a>
<a class="l" name="275" href="#275">275</a>### Library
<a class="l" name="276" href="#276">276</a>
<a class="l" name="277" href="#277">277</a>[Runtime and Reporting Considerations](#runtime-and-reporting-considerations)
<a class="l" name="278" href="#278">278</a>
<a class="l" name="279" href="#279">279</a>[Passing Arguments](#passing-arguments)
<a class="hl" name="280" href="#280">280</a>
<a class="l" name="281" href="#281">281</a>[Calculating Asymptotic Complexity](#asymptotic-complexity)
<a class="l" name="282" href="#282">282</a>
<a class="l" name="283" href="#283">283</a>[Templated Benchmarks](#templated-benchmarks)
<a class="l" name="284" href="#284">284</a>
<a class="l" name="285" href="#285">285</a>[Fixtures](#fixtures)
<a class="l" name="286" href="#286">286</a>
<a class="l" name="287" href="#287">287</a>[Custom Counters](#custom-counters)
<a class="l" name="288" href="#288">288</a>
<a class="l" name="289" href="#289">289</a>[Multithreaded Benchmarks](#multithreaded-benchmarks)
<a class="hl" name="290" href="#290">290</a>
<a class="l" name="291" href="#291">291</a>[CPU Timers](#cpu-timers)
<a class="l" name="292" href="#292">292</a>
<a class="l" name="293" href="#293">293</a>[Manual Timing](#manual-timing)
<a class="l" name="294" href="#294">294</a>
<a class="l" name="295" href="#295">295</a>[Setting the Time Unit](#setting-the-time-unit)
<a class="l" name="296" href="#296">296</a>
<a class="l" name="297" href="#297">297</a>[Preventing Optimization](#preventing-optimization)
<a class="l" name="298" href="#298">298</a>
<a class="l" name="299" href="#299">299</a>[Reporting Statistics](#reporting-statistics)
<a class="hl" name="300" href="#300">300</a>
<a class="l" name="301" href="#301">301</a>[Custom Statistics](#custom-statistics)
<a class="l" name="302" href="#302">302</a>
<a class="l" name="303" href="#303">303</a>[Using RegisterBenchmark](#using-register-benchmark)
<a class="l" name="304" href="#304">304</a>
<a class="l" name="305" href="#305">305</a>[Exiting with an Error](#exiting-with-an-error)
<a class="l" name="306" href="#306">306</a>
<a class="l" name="307" href="#307">307</a>[A Faster KeepRunning Loop](#a-faster-keep-running-loop)
<a class="l" name="308" href="#308">308</a>
<a class="l" name="309" href="#309">309</a>[Disabling CPU Frequency Scaling](#disabling-cpu-frequency-scaling)
<a class="hl" name="310" href="#310">310</a>
<a class="l" name="311" href="#311">311</a>
<a class="l" name="312" href="#312">312</a>&lt;a name="output-formats" /&gt;
<a class="l" name="313" href="#313">313</a>
<a class="l" name="314" href="#314">314</a>### Output Formats
<a class="l" name="315" href="#315">315</a>
<a class="l" name="316" href="#316">316</a>The library supports multiple output formats. Use the
<a class="l" name="317" href="#317">317</a>`--benchmark_format=&lt;console|json|csv&gt;` flag (or set the
<a class="l" name="318" href="#318">318</a>`BENCHMARK_FORMAT=&lt;console|json|csv&gt;` environment variable) to set
<a class="l" name="319" href="#319">319</a>the format type. `console` is the default format.
<a class="hl" name="320" href="#320">320</a>
<a class="l" name="321" href="#321">321</a>The Console format is intended to be a human readable format. By default
<a class="l" name="322" href="#322">322</a>the format generates color output. Context is output on stderr and the
<a class="l" name="323" href="#323">323</a>tabular data on stdout. Example tabular output looks like:
<a class="l" name="324" href="#324">324</a>
<a class="l" name="325" href="#325">325</a>```
<a class="l" name="326" href="#326">326</a>Benchmark                               Time(ns)    CPU(ns) Iterations
<a class="l" name="327" href="#327">327</a>----------------------------------------------------------------------
<a class="l" name="328" href="#328">328</a>BM_SetInsert/1024/1                        28928      29349      23853  133.097kB/s   33.2742k items/s
<a class="l" name="329" href="#329">329</a>BM_SetInsert/1024/8                        32065      32913      21375  949.487kB/s   237.372k items/s
<a class="hl" name="330" href="#330">330</a>BM_SetInsert/1024/10                       33157      33648      21431  1.13369MB/s   290.225k items/s
<a class="l" name="331" href="#331">331</a>```
<a class="l" name="332" href="#332">332</a>
<a class="l" name="333" href="#333">333</a>The JSON format outputs human readable json split into two top level attributes.
<a class="l" name="334" href="#334">334</a>The `context` attribute contains information about the run in general, including
<a class="l" name="335" href="#335">335</a>information about the CPU and the date.
<a class="l" name="336" href="#336">336</a>The `benchmarks` attribute contains a list of every benchmark run. Example json
<a class="l" name="337" href="#337">337</a>output looks like:
<a class="l" name="338" href="#338">338</a>
<a class="l" name="339" href="#339">339</a>```json
<a class="hl" name="340" href="#340">340</a>{
<a class="l" name="341" href="#341">341</a>  "context": {
<a class="l" name="342" href="#342">342</a>    "date": "2015/03/17-18:40:25",
<a class="l" name="343" href="#343">343</a>    "num_cpus": 40,
<a class="l" name="344" href="#344">344</a>    "mhz_per_cpu": 2801,
<a class="l" name="345" href="#345">345</a>    "cpu_scaling_enabled": false,
<a class="l" name="346" href="#346">346</a>    "build_type": "debug"
<a class="l" name="347" href="#347">347</a>  },
<a class="l" name="348" href="#348">348</a>  "benchmarks": [
<a class="l" name="349" href="#349">349</a>    {
<a class="hl" name="350" href="#350">350</a>      "name": "BM_SetInsert/1024/1",
<a class="l" name="351" href="#351">351</a>      "iterations": 94877,
<a class="l" name="352" href="#352">352</a>      "real_time": 29275,
<a class="l" name="353" href="#353">353</a>      "cpu_time": 29836,
<a class="l" name="354" href="#354">354</a>      "bytes_per_second": 134066,
<a class="l" name="355" href="#355">355</a>      "items_per_second": 33516
<a class="l" name="356" href="#356">356</a>    },
<a class="l" name="357" href="#357">357</a>    {
<a class="l" name="358" href="#358">358</a>      "name": "BM_SetInsert/1024/8",
<a class="l" name="359" href="#359">359</a>      "iterations": 21609,
<a class="hl" name="360" href="#360">360</a>      "real_time": 32317,
<a class="l" name="361" href="#361">361</a>      "cpu_time": 32429,
<a class="l" name="362" href="#362">362</a>      "bytes_per_second": 986770,
<a class="l" name="363" href="#363">363</a>      "items_per_second": 246693
<a class="l" name="364" href="#364">364</a>    },
<a class="l" name="365" href="#365">365</a>    {
<a class="l" name="366" href="#366">366</a>      "name": "BM_SetInsert/1024/10",
<a class="l" name="367" href="#367">367</a>      "iterations": 21393,
<a class="l" name="368" href="#368">368</a>      "real_time": 32724,
<a class="l" name="369" href="#369">369</a>      "cpu_time": 33355,
<a class="hl" name="370" href="#370">370</a>      "bytes_per_second": 1199226,
<a class="l" name="371" href="#371">371</a>      "items_per_second": 299807
<a class="l" name="372" href="#372">372</a>    }
<a class="l" name="373" href="#373">373</a>  ]
<a class="l" name="374" href="#374">374</a>}
<a class="l" name="375" href="#375">375</a>```
<a class="l" name="376" href="#376">376</a>
<a class="l" name="377" href="#377">377</a>The CSV format outputs comma-separated values. The `context` is output on stderr
<a class="l" name="378" href="#378">378</a>and the CSV itself on stdout. Example CSV output looks like:
<a class="l" name="379" href="#379">379</a>
<a class="hl" name="380" href="#380">380</a>```
<a class="l" name="381" href="#381">381</a>name,iterations,real_time,cpu_time,bytes_per_second,items_per_second,label
<a class="l" name="382" href="#382">382</a>"BM_SetInsert/1024/1",65465,17890.7,8407.45,475768,118942,
<a class="l" name="383" href="#383">383</a>"BM_SetInsert/1024/8",116606,18810.1,9766.64,3.27646e+06,819115,
<a class="l" name="384" href="#384">384</a>"BM_SetInsert/1024/10",106365,17238.4,8421.53,4.74973e+06,1.18743e+06,
<a class="l" name="385" href="#385">385</a>```
<a class="l" name="386" href="#386">386</a>
<a class="l" name="387" href="#387">387</a>&lt;a name="output-files" /&gt;
<a class="l" name="388" href="#388">388</a>
<a class="l" name="389" href="#389">389</a>### Output Files
<a class="hl" name="390" href="#390">390</a>
<a class="l" name="391" href="#391">391</a>Write benchmark results to a file with the `--benchmark_out=&lt;filename&gt;` option
<a class="l" name="392" href="#392">392</a>(or set `BENCHMARK_OUT`). Specify the output format with
<a class="l" name="393" href="#393">393</a>`--benchmark_out_format={json|console|csv}` (or set
<a class="l" name="394" href="#394">394</a>`BENCHMARK_OUT_FORMAT={json|console|csv}`). Note that specifying
<a class="l" name="395" href="#395">395</a>`--benchmark_out` does not suppress the console output.
<a class="l" name="396" href="#396">396</a>
<a class="l" name="397" href="#397">397</a>&lt;a name="running-benchmarks" /&gt;
<a class="l" name="398" href="#398">398</a>
<a class="l" name="399" href="#399">399</a>### Running Benchmarks
<a class="hl" name="400" href="#400">400</a>
<a class="l" name="401" href="#401">401</a>Benchmarks are executed by running the produced binaries. Benchmarks binaries,
<a class="l" name="402" href="#402">402</a>by default, accept options that may be specified either through their command
<a class="l" name="403" href="#403">403</a>line interface or by setting environment variables before execution. For every
<a class="l" name="404" href="#404">404</a>`--option_flag=&lt;value&gt;` CLI switch, a corresponding environment variable
<a class="l" name="405" href="#405">405</a>`OPTION_FLAG=&lt;value&gt;` exist and is used as default if set (CLI switches always
<a class="l" name="406" href="#406">406</a> prevails). A complete list of CLI options is available running benchmarks
<a class="l" name="407" href="#407">407</a> with the `--help` switch.
<a class="l" name="408" href="#408">408</a>
<a class="l" name="409" href="#409">409</a>&lt;a name="running-a-subset-of-benchmarks" /&gt;
<a class="hl" name="410" href="#410">410</a>
<a class="l" name="411" href="#411">411</a>### Running a Subset of Benchmarks
<a class="l" name="412" href="#412">412</a>
<a class="l" name="413" href="#413">413</a>The `--benchmark_filter=&lt;regex&gt;` option (or `BENCHMARK_FILTER=&lt;regex&gt;`
<a class="l" name="414" href="#414">414</a>environment variable) can be used to only run the benchmarks that match
<a class="l" name="415" href="#415">415</a>the specified `&lt;regex&gt;`. For example:
<a class="l" name="416" href="#416">416</a>
<a class="l" name="417" href="#417">417</a>```bash
<a class="l" name="418" href="#418">418</a>$ ./<a href="/googletest/s?path=run_benchmarks.x&amp;project=benchmark">run_benchmarks.x</a> --benchmark_filter=BM_memcpy/32
<a class="l" name="419" href="#419">419</a>Run on (1 X 2300 MHz CPU )
<a class="hl" name="420" href="#420">420</a>2016-06-25 19:34:24
<a class="l" name="421" href="#421">421</a>Benchmark              Time           CPU Iterations
<a class="l" name="422" href="#422">422</a>----------------------------------------------------
<a class="l" name="423" href="#423">423</a>BM_memcpy/32          11 ns         11 ns   79545455
<a class="l" name="424" href="#424">424</a>BM_memcpy/32k       2181 ns       2185 ns     324074
<a class="l" name="425" href="#425">425</a>BM_memcpy/32          12 ns         12 ns   54687500
<a class="l" name="426" href="#426">426</a>BM_memcpy/32k       1834 ns       1837 ns     357143
<a class="l" name="427" href="#427">427</a>```
<a class="l" name="428" href="#428">428</a>
<a class="l" name="429" href="#429">429</a>&lt;a name="result-comparison" /&gt;
<a class="hl" name="430" href="#430">430</a>
<a class="l" name="431" href="#431">431</a>### Result comparison
<a class="l" name="432" href="#432">432</a>
<a class="l" name="433" href="#433">433</a>It is possible to compare the benchmarking results.
<a class="l" name="434" href="#434">434</a>See [Additional Tooling Documentation](<a href="/googletest/s?path=docs/tools.md&amp;project=benchmark">docs/tools.md</a>)
<a class="l" name="435" href="#435">435</a>
<a class="l" name="436" href="#436">436</a>&lt;a name="runtime-and-reporting-considerations" /&gt;
<a class="l" name="437" href="#437">437</a>
<a class="l" name="438" href="#438">438</a>### Runtime and Reporting Considerations
<a class="l" name="439" href="#439">439</a>
<a class="hl" name="440" href="#440">440</a>When the benchmark binary is executed, each benchmark function is run serially.
<a class="l" name="441" href="#441">441</a>The number of iterations to run is determined dynamically by running the
<a class="l" name="442" href="#442">442</a>benchmark a few times and measuring the time taken and ensuring that the
<a class="l" name="443" href="#443">443</a>ultimate result will be statistically stable. As such, faster benchmark
<a class="l" name="444" href="#444">444</a>functions will be run for more iterations than slower benchmark functions, and
<a class="l" name="445" href="#445">445</a>the number of iterations is thus reported.
<a class="l" name="446" href="#446">446</a>
<a class="l" name="447" href="#447">447</a>In all cases, the number of iterations for which the benchmark is run is
<a class="l" name="448" href="#448">448</a>governed by the amount of time the benchmark takes. Concretely, the number of
<a class="l" name="449" href="#449">449</a>iterations is at least one, not more than 1e9, until CPU time is greater than
<a class="hl" name="450" href="#450">450</a>the minimum time, or the wallclock time is 5x minimum time. The minimum time is
<a class="l" name="451" href="#451">451</a>set per benchmark by calling `MinTime` on the registered benchmark object.
<a class="l" name="452" href="#452">452</a>
<a class="l" name="453" href="#453">453</a>Average timings are then reported over the iterations run. If multiple
<a class="l" name="454" href="#454">454</a>repetitions are requested using the `--benchmark_repetitions` command-line
<a class="l" name="455" href="#455">455</a>option, or at registration time, the benchmark function will be run several
<a class="l" name="456" href="#456">456</a>times and statistical results across these repetitions will also be reported.
<a class="l" name="457" href="#457">457</a>
<a class="l" name="458" href="#458">458</a>As well as the per-benchmark entries, a preamble in the report will include
<a class="l" name="459" href="#459">459</a>information about the machine on which the benchmarks are run.
<a class="hl" name="460" href="#460">460</a>
<a class="l" name="461" href="#461">461</a>&lt;a name="passing-arguments" /&gt;
<a class="l" name="462" href="#462">462</a>
<a class="l" name="463" href="#463">463</a>### Passing Arguments
<a class="l" name="464" href="#464">464</a>
<a class="l" name="465" href="#465">465</a>Sometimes a family of benchmarks can be implemented with just one routine that
<a class="l" name="466" href="#466">466</a>takes an extra argument to specify which one of the family of benchmarks to
<a class="l" name="467" href="#467">467</a>run. For example, the following code defines a family of benchmarks for
<a class="l" name="468" href="#468">468</a>measuring the speed of `memcpy()` calls of different lengths:
<a class="l" name="469" href="#469">469</a>
<a class="hl" name="470" href="#470">470</a>```c++
<a class="l" name="471" href="#471">471</a>static void BM_memcpy(benchmark::State&amp; state) {
<a class="l" name="472" href="#472">472</a>  char* src = new char[<a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0)];
<a class="l" name="473" href="#473">473</a>  char* dst = new char[<a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0)];
<a class="l" name="474" href="#474">474</a>  memset(src, 'x', <a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0));
<a class="l" name="475" href="#475">475</a>  for (auto _ : state)
<a class="l" name="476" href="#476">476</a>    memcpy(dst, src, <a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0));
<a class="l" name="477" href="#477">477</a>  <a href="/googletest/s?path=state.SetBytesProcessed&amp;project=benchmark">state.SetBytesProcessed</a>(int64_t(<a href="/googletest/s?path=state.iterations&amp;project=benchmark">state.iterations</a>()) *
<a class="l" name="478" href="#478">478</a>                          int64_t(<a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0)));
<a class="l" name="479" href="#479">479</a>  delete[] src;
<a class="hl" name="480" href="#480">480</a>  delete[] dst;
<a class="l" name="481" href="#481">481</a>}
<a class="l" name="482" href="#482">482</a>BENCHMARK(BM_memcpy)-&gt;Arg(8)-&gt;Arg(64)-&gt;Arg(512)-&gt;Arg(1&lt;&lt;10)-&gt;Arg(8&lt;&lt;10);
<a class="l" name="483" href="#483">483</a>```
<a class="l" name="484" href="#484">484</a>
<a class="l" name="485" href="#485">485</a>The preceding code is quite repetitive, and can be replaced with the following
<a class="l" name="486" href="#486">486</a>short-hand. The following invocation will pick a few appropriate arguments in
<a class="l" name="487" href="#487">487</a>the specified range and will generate a benchmark for each such argument.
<a class="l" name="488" href="#488">488</a>
<a class="l" name="489" href="#489">489</a>```c++
<a class="hl" name="490" href="#490">490</a>BENCHMARK(BM_memcpy)-&gt;Range(8, 8&lt;&lt;10);
<a class="l" name="491" href="#491">491</a>```
<a class="l" name="492" href="#492">492</a>
<a class="l" name="493" href="#493">493</a>By default the arguments in the range are generated in multiples of eight and
<a class="l" name="494" href="#494">494</a>the command above selects [ 8, 64, 512, 4k, 8k ]. In the following code the
<a class="l" name="495" href="#495">495</a>range multiplier is changed to multiples of two.
<a class="l" name="496" href="#496">496</a>
<a class="l" name="497" href="#497">497</a>```c++
<a class="l" name="498" href="#498">498</a>BENCHMARK(BM_memcpy)-&gt;RangeMultiplier(2)-&gt;Range(8, 8&lt;&lt;10);
<a class="l" name="499" href="#499">499</a>```
<a class="hl" name="500" href="#500">500</a>
<a class="l" name="501" href="#501">501</a>Now arguments generated are [ 8, 16, 32, 64, 128, 256, 512, 1024, 2k, 4k, 8k ].
<a class="l" name="502" href="#502">502</a>
<a class="l" name="503" href="#503">503</a>The preceding code shows a method of defining a sparse range.  The following
<a class="l" name="504" href="#504">504</a>example shows a method of defining a dense range. It is then used to benchmark
<a class="l" name="505" href="#505">505</a>the performance of `std::vector` initialization for uniformly increasing sizes.
<a class="l" name="506" href="#506">506</a>
<a class="l" name="507" href="#507">507</a>```c++
<a class="l" name="508" href="#508">508</a>static void BM_DenseRange(benchmark::State&amp; state) {
<a class="l" name="509" href="#509">509</a>  for(auto _ : state) {
<a class="hl" name="510" href="#510">510</a>    std::vector&lt;int&gt; v(<a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0), <a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0));
<a class="l" name="511" href="#511">511</a>    benchmark::DoNotOptimize(<a href="/googletest/s?path=v.data&amp;project=benchmark">v.data</a>());
<a class="l" name="512" href="#512">512</a>    benchmark::ClobberMemory();
<a class="l" name="513" href="#513">513</a>  }
<a class="l" name="514" href="#514">514</a>}
<a class="l" name="515" href="#515">515</a>BENCHMARK(BM_DenseRange)-&gt;DenseRange(0, 1024, 128);
<a class="l" name="516" href="#516">516</a>```
<a class="l" name="517" href="#517">517</a>
<a class="l" name="518" href="#518">518</a>Now arguments generated are [ 0, 128, 256, 384, 512, 640, 768, 896, 1024 ].
<a class="l" name="519" href="#519">519</a>
<a class="hl" name="520" href="#520">520</a>You might have a benchmark that depends on two or more inputs. For example, the
<a class="l" name="521" href="#521">521</a>following code defines a family of benchmarks for measuring the speed of set
<a class="l" name="522" href="#522">522</a>insertion.
<a class="l" name="523" href="#523">523</a>
<a class="l" name="524" href="#524">524</a>```c++
<a class="l" name="525" href="#525">525</a>static void BM_SetInsert(benchmark::State&amp; state) {
<a class="l" name="526" href="#526">526</a>  std::set&lt;int&gt; data;
<a class="l" name="527" href="#527">527</a>  for (auto _ : state) {
<a class="l" name="528" href="#528">528</a>    <a href="/googletest/s?path=state.PauseTiming&amp;project=benchmark">state.PauseTiming</a>();
<a class="l" name="529" href="#529">529</a>    data = ConstructRandomSet(<a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0));
<a class="hl" name="530" href="#530">530</a>    <a href="/googletest/s?path=state.ResumeTiming&amp;project=benchmark">state.ResumeTiming</a>();
<a class="l" name="531" href="#531">531</a>    for (int j = 0; j &lt; <a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(1); ++j)
<a class="l" name="532" href="#532">532</a>      <a href="/googletest/s?path=data.insert&amp;project=benchmark">data.insert</a>(RandomNumber());
<a class="l" name="533" href="#533">533</a>  }
<a class="l" name="534" href="#534">534</a>}
<a class="l" name="535" href="#535">535</a>BENCHMARK(BM_SetInsert)
<a class="l" name="536" href="#536">536</a>    -&gt;Args({1&lt;&lt;10, 128})
<a class="l" name="537" href="#537">537</a>    -&gt;Args({2&lt;&lt;10, 128})
<a class="l" name="538" href="#538">538</a>    -&gt;Args({4&lt;&lt;10, 128})
<a class="l" name="539" href="#539">539</a>    -&gt;Args({8&lt;&lt;10, 128})
<a class="hl" name="540" href="#540">540</a>    -&gt;Args({1&lt;&lt;10, 512})
<a class="l" name="541" href="#541">541</a>    -&gt;Args({2&lt;&lt;10, 512})
<a class="l" name="542" href="#542">542</a>    -&gt;Args({4&lt;&lt;10, 512})
<a class="l" name="543" href="#543">543</a>    -&gt;Args({8&lt;&lt;10, 512});
<a class="l" name="544" href="#544">544</a>```
<a class="l" name="545" href="#545">545</a>
<a class="l" name="546" href="#546">546</a>The preceding code is quite repetitive, and can be replaced with the following
<a class="l" name="547" href="#547">547</a>short-hand. The following macro will pick a few appropriate arguments in the
<a class="l" name="548" href="#548">548</a>product of the two specified ranges and will generate a benchmark for each such
<a class="l" name="549" href="#549">549</a>pair.
<a class="hl" name="550" href="#550">550</a>
<a class="l" name="551" href="#551">551</a>```c++
<a class="l" name="552" href="#552">552</a>BENCHMARK(BM_SetInsert)-&gt;Ranges({{1&lt;&lt;10, 8&lt;&lt;10}, {128, 512}});
<a class="l" name="553" href="#553">553</a>```
<a class="l" name="554" href="#554">554</a>
<a class="l" name="555" href="#555">555</a>Some benchmarks may require specific argument values that cannot be expressed
<a class="l" name="556" href="#556">556</a>with `Ranges`. In this case, `ArgsProduct` offers the ability to generate a
<a class="l" name="557" href="#557">557</a>benchmark input for each combination in the product of the supplied vectors.
<a class="l" name="558" href="#558">558</a>
<a class="l" name="559" href="#559">559</a>```c++
<a class="hl" name="560" href="#560">560</a>BENCHMARK(BM_SetInsert)
<a class="l" name="561" href="#561">561</a>    -&gt;ArgsProduct({{1&lt;&lt;10, 3&lt;&lt;10, 8&lt;&lt;10}, {20, 40, 60, 80}})
<a class="l" name="562" href="#562">562</a>// would generate the same benchmark arguments as
<a class="l" name="563" href="#563">563</a>BENCHMARK(BM_SetInsert)
<a class="l" name="564" href="#564">564</a>    -&gt;Args({1&lt;&lt;10, 20})
<a class="l" name="565" href="#565">565</a>    -&gt;Args({3&lt;&lt;10, 20})
<a class="l" name="566" href="#566">566</a>    -&gt;Args({8&lt;&lt;10, 20})
<a class="l" name="567" href="#567">567</a>    -&gt;Args({3&lt;&lt;10, 40})
<a class="l" name="568" href="#568">568</a>    -&gt;Args({8&lt;&lt;10, 40})
<a class="l" name="569" href="#569">569</a>    -&gt;Args({1&lt;&lt;10, 40})
<a class="hl" name="570" href="#570">570</a>    -&gt;Args({1&lt;&lt;10, 60})
<a class="l" name="571" href="#571">571</a>    -&gt;Args({3&lt;&lt;10, 60})
<a class="l" name="572" href="#572">572</a>    -&gt;Args({8&lt;&lt;10, 60})
<a class="l" name="573" href="#573">573</a>    -&gt;Args({1&lt;&lt;10, 80})
<a class="l" name="574" href="#574">574</a>    -&gt;Args({3&lt;&lt;10, 80})
<a class="l" name="575" href="#575">575</a>    -&gt;Args({8&lt;&lt;10, 80});
<a class="l" name="576" href="#576">576</a>```
<a class="l" name="577" href="#577">577</a>
<a class="l" name="578" href="#578">578</a>For more complex patterns of inputs, passing a custom function to `Apply` allows
<a class="l" name="579" href="#579">579</a>programmatic specification of an arbitrary set of arguments on which to run the
<a class="hl" name="580" href="#580">580</a>benchmark. The following example enumerates a dense range on one parameter,
<a class="l" name="581" href="#581">581</a>and a sparse range on the second.
<a class="l" name="582" href="#582">582</a>
<a class="l" name="583" href="#583">583</a>```c++
<a class="l" name="584" href="#584">584</a>static void CustomArguments(benchmark::internal::Benchmark* b) {
<a class="l" name="585" href="#585">585</a>  for (int i = 0; i &lt;= 10; ++i)
<a class="l" name="586" href="#586">586</a>    for (int j = 32; j &lt;= 1024*1024; j *= 8)
<a class="l" name="587" href="#587">587</a>      b-&gt;Args({i, j});
<a class="l" name="588" href="#588">588</a>}
<a class="l" name="589" href="#589">589</a>BENCHMARK(BM_SetInsert)-&gt;Apply(CustomArguments);
<a class="hl" name="590" href="#590">590</a>```
<a class="l" name="591" href="#591">591</a>
<a class="l" name="592" href="#592">592</a>#### Passing Arbitrary Arguments to a Benchmark
<a class="l" name="593" href="#593">593</a>
<a class="l" name="594" href="#594">594</a>In C++11 it is possible to define a benchmark that takes an arbitrary number
<a class="l" name="595" href="#595">595</a>of extra arguments. The `BENCHMARK_CAPTURE(func, test_case_name, <a href="/googletest/s?path=...args&amp;project=benchmark">...args</a>)`
<a class="l" name="596" href="#596">596</a>macro creates a benchmark that invokes `func`  with the `benchmark::State` as
<a class="l" name="597" href="#597">597</a>the first argument followed by the specified `args...`.
<a class="l" name="598" href="#598">598</a>The `test_case_name` is appended to the name of the benchmark and
<a class="l" name="599" href="#599">599</a>should describe the values passed.
<a class="hl" name="600" href="#600">600</a>
<a class="l" name="601" href="#601">601</a>```c++
<a class="l" name="602" href="#602">602</a>template &lt;class <a href="/googletest/s?path=...ExtraArgs&amp;project=benchmark">...ExtraArgs</a>&gt;
<a class="l" name="603" href="#603">603</a>void BM_takes_args(benchmark::State&amp; state, ExtraArgs&amp;&amp;... extra_args) {
<a class="l" name="604" href="#604">604</a>  [...]
<a class="l" name="605" href="#605">605</a>}
<a class="l" name="606" href="#606">606</a>// Registers a benchmark named "<a href="/googletest/s?path=BM_takes_args/int_string_test&amp;project=benchmark">BM_takes_args/int_string_test</a>" that passes
<a class="l" name="607" href="#607">607</a>// the specified values to `extra_args`.
<a class="l" name="608" href="#608">608</a>BENCHMARK_CAPTURE(BM_takes_args, int_string_test, 42, std::string("abc"));
<a class="l" name="609" href="#609">609</a>```
<a class="hl" name="610" href="#610">610</a>
<a class="l" name="611" href="#611">611</a>Note that elements of `<a href="/googletest/s?path=...args&amp;project=benchmark">...args</a>` may refer to global variables. Users should
<a class="l" name="612" href="#612">612</a>avoid modifying global state inside of a benchmark.
<a class="l" name="613" href="#613">613</a>
<a class="l" name="614" href="#614">614</a>&lt;a name="asymptotic-complexity" /&gt;
<a class="l" name="615" href="#615">615</a>
<a class="l" name="616" href="#616">616</a>### Calculating Asymptotic Complexity (Big O)
<a class="l" name="617" href="#617">617</a>
<a class="l" name="618" href="#618">618</a>Asymptotic complexity might be calculated for a family of benchmarks. The
<a class="l" name="619" href="#619">619</a>following code will calculate the coefficient for the high-order term in the
<a class="hl" name="620" href="#620">620</a>running time and the normalized root-mean square error of string comparison.
<a class="l" name="621" href="#621">621</a>
<a class="l" name="622" href="#622">622</a>```c++
<a class="l" name="623" href="#623">623</a>static void BM_StringCompare(benchmark::State&amp; state) {
<a class="l" name="624" href="#624">624</a>  std::string s1(<a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0), '-');
<a class="l" name="625" href="#625">625</a>  std::string s2(<a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0), '-');
<a class="l" name="626" href="#626">626</a>  for (auto _ : state) {
<a class="l" name="627" href="#627">627</a>    benchmark::DoNotOptimize(<a href="/googletest/s?path=s1.compare&amp;project=benchmark">s1.compare</a>(s2));
<a class="l" name="628" href="#628">628</a>  }
<a class="l" name="629" href="#629">629</a>  <a href="/googletest/s?path=state.SetComplexityN&amp;project=benchmark">state.SetComplexityN</a>(<a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0));
<a class="hl" name="630" href="#630">630</a>}
<a class="l" name="631" href="#631">631</a>BENCHMARK(BM_StringCompare)
<a class="l" name="632" href="#632">632</a>    -&gt;RangeMultiplier(2)-&gt;Range(1&lt;&lt;10, 1&lt;&lt;18)-&gt;Complexity(benchmark::oN);
<a class="l" name="633" href="#633">633</a>```
<a class="l" name="634" href="#634">634</a>
<a class="l" name="635" href="#635">635</a>As shown in the following invocation, asymptotic complexity might also be
<a class="l" name="636" href="#636">636</a>calculated automatically.
<a class="l" name="637" href="#637">637</a>
<a class="l" name="638" href="#638">638</a>```c++
<a class="l" name="639" href="#639">639</a>BENCHMARK(BM_StringCompare)
<a class="hl" name="640" href="#640">640</a>    -&gt;RangeMultiplier(2)-&gt;Range(1&lt;&lt;10, 1&lt;&lt;18)-&gt;Complexity();
<a class="l" name="641" href="#641">641</a>```
<a class="l" name="642" href="#642">642</a>
<a class="l" name="643" href="#643">643</a>The following code will specify asymptotic complexity with a lambda function,
<a class="l" name="644" href="#644">644</a>that might be used to customize high-order term calculation.
<a class="l" name="645" href="#645">645</a>
<a class="l" name="646" href="#646">646</a>```c++
<a class="l" name="647" href="#647">647</a>BENCHMARK(BM_StringCompare)-&gt;RangeMultiplier(2)
<a class="l" name="648" href="#648">648</a>    -&gt;Range(1&lt;&lt;10, 1&lt;&lt;18)-&gt;Complexity([](benchmark::IterationCount n)-&gt;double{return n; });
<a class="l" name="649" href="#649">649</a>```
<a class="hl" name="650" href="#650">650</a>
<a class="l" name="651" href="#651">651</a>&lt;a name="templated-benchmarks" /&gt;
<a class="l" name="652" href="#652">652</a>
<a class="l" name="653" href="#653">653</a>### Templated Benchmarks
<a class="l" name="654" href="#654">654</a>
<a class="l" name="655" href="#655">655</a>This example produces and consumes messages of size `sizeof(v)` `range_x`
<a class="l" name="656" href="#656">656</a>times. It also outputs throughput in the absence of multiprogramming.
<a class="l" name="657" href="#657">657</a>
<a class="l" name="658" href="#658">658</a>```c++
<a class="l" name="659" href="#659">659</a>template &lt;class Q&gt; void BM_Sequential(benchmark::State&amp; state) {
<a class="hl" name="660" href="#660">660</a>  Q q;
<a class="l" name="661" href="#661">661</a>  typename Q::value_type v;
<a class="l" name="662" href="#662">662</a>  for (auto _ : state) {
<a class="l" name="663" href="#663">663</a>    for (int i = <a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0); i--; )
<a class="l" name="664" href="#664">664</a>      <a href="/googletest/s?path=q.push&amp;project=benchmark">q.push</a>(v);
<a class="l" name="665" href="#665">665</a>    for (int e = <a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0); e--; )
<a class="l" name="666" href="#666">666</a>      <a href="/googletest/s?path=q.Wait&amp;project=benchmark">q.Wait</a>(&amp;v);
<a class="l" name="667" href="#667">667</a>  }
<a class="l" name="668" href="#668">668</a>  // actually messages, not bytes:
<a class="l" name="669" href="#669">669</a>  <a href="/googletest/s?path=state.SetBytesProcessed&amp;project=benchmark">state.SetBytesProcessed</a>(
<a class="hl" name="670" href="#670">670</a>      static_cast&lt;int64_t&gt;(<a href="/googletest/s?path=state.iterations&amp;project=benchmark">state.iterations</a>())*<a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0));
<a class="l" name="671" href="#671">671</a>}
<a class="l" name="672" href="#672">672</a>BENCHMARK_TEMPLATE(BM_Sequential, WaitQueue&lt;int&gt;)-&gt;Range(1&lt;&lt;0, 1&lt;&lt;10);
<a class="l" name="673" href="#673">673</a>```
<a class="l" name="674" href="#674">674</a>
<a class="l" name="675" href="#675">675</a>Three macros are provided for adding benchmark templates.
<a class="l" name="676" href="#676">676</a>
<a class="l" name="677" href="#677">677</a>```c++
<a class="l" name="678" href="#678">678</a>#ifdef BENCHMARK_HAS_CXX11
<a class="l" name="679" href="#679">679</a>#define BENCHMARK_TEMPLATE(func, ...) // Takes any number of parameters.
<a class="hl" name="680" href="#680">680</a>#else // C++ &lt; C++11
<a class="l" name="681" href="#681">681</a>#define BENCHMARK_TEMPLATE(func, arg1)
<a class="l" name="682" href="#682">682</a>#endif
<a class="l" name="683" href="#683">683</a>#define BENCHMARK_TEMPLATE1(func, arg1)
<a class="l" name="684" href="#684">684</a>#define BENCHMARK_TEMPLATE2(func, arg1, arg2)
<a class="l" name="685" href="#685">685</a>```
<a class="l" name="686" href="#686">686</a>
<a class="l" name="687" href="#687">687</a>&lt;a name="fixtures" /&gt;
<a class="l" name="688" href="#688">688</a>
<a class="l" name="689" href="#689">689</a>### Fixtures
<a class="hl" name="690" href="#690">690</a>
<a class="l" name="691" href="#691">691</a>Fixture tests are created by first defining a type that derives from
<a class="l" name="692" href="#692">692</a>`::benchmark::Fixture` and then <a href="/googletest/s?path=creating/registering&amp;project=benchmark">creating/registering</a> the tests using the
<a class="l" name="693" href="#693">693</a>following macros:
<a class="l" name="694" href="#694">694</a>
<a class="l" name="695" href="#695">695</a>* `BENCHMARK_F(ClassName, Method)`
<a class="l" name="696" href="#696">696</a>* `BENCHMARK_DEFINE_F(ClassName, Method)`
<a class="l" name="697" href="#697">697</a>* `BENCHMARK_REGISTER_F(ClassName, Method)`
<a class="l" name="698" href="#698">698</a>
<a class="l" name="699" href="#699">699</a>For Example:
<a class="hl" name="700" href="#700">700</a>
<a class="l" name="701" href="#701">701</a>```c++
<a class="l" name="702" href="#702">702</a>class MyFixture : public benchmark::Fixture {
<a class="l" name="703" href="#703">703</a>public:
<a class="l" name="704" href="#704">704</a>  void SetUp(const ::benchmark::State&amp; state) {
<a class="l" name="705" href="#705">705</a>  }
<a class="l" name="706" href="#706">706</a>
<a class="l" name="707" href="#707">707</a>  void TearDown(const ::benchmark::State&amp; state) {
<a class="l" name="708" href="#708">708</a>  }
<a class="l" name="709" href="#709">709</a>};
<a class="hl" name="710" href="#710">710</a>
<a class="l" name="711" href="#711">711</a>BENCHMARK_F(MyFixture, FooTest)(benchmark::State&amp; st) {
<a class="l" name="712" href="#712">712</a>   for (auto _ : st) {
<a class="l" name="713" href="#713">713</a>     ...
<a class="l" name="714" href="#714">714</a>  }
<a class="l" name="715" href="#715">715</a>}
<a class="l" name="716" href="#716">716</a>
<a class="l" name="717" href="#717">717</a>BENCHMARK_DEFINE_F(MyFixture, BarTest)(benchmark::State&amp; st) {
<a class="l" name="718" href="#718">718</a>   for (auto _ : st) {
<a class="l" name="719" href="#719">719</a>     ...
<a class="hl" name="720" href="#720">720</a>  }
<a class="l" name="721" href="#721">721</a>}
<a class="l" name="722" href="#722">722</a>/* BarTest is NOT registered */
<a class="l" name="723" href="#723">723</a>BENCHMARK_REGISTER_F(MyFixture, BarTest)-&gt;Threads(2);
<a class="l" name="724" href="#724">724</a>/* BarTest is now registered */
<a class="l" name="725" href="#725">725</a>```
<a class="l" name="726" href="#726">726</a>
<a class="l" name="727" href="#727">727</a>#### Templated Fixtures
<a class="l" name="728" href="#728">728</a>
<a class="l" name="729" href="#729">729</a>Also you can create templated fixture by using the following macros:
<a class="hl" name="730" href="#730">730</a>
<a class="l" name="731" href="#731">731</a>* `BENCHMARK_TEMPLATE_F(ClassName, Method, ...)`
<a class="l" name="732" href="#732">732</a>* `BENCHMARK_TEMPLATE_DEFINE_F(ClassName, Method, ...)`
<a class="l" name="733" href="#733">733</a>
<a class="l" name="734" href="#734">734</a>For example:
<a class="l" name="735" href="#735">735</a>
<a class="l" name="736" href="#736">736</a>```c++
<a class="l" name="737" href="#737">737</a>template&lt;typename T&gt;
<a class="l" name="738" href="#738">738</a>class MyFixture : public benchmark::Fixture {};
<a class="l" name="739" href="#739">739</a>
<a class="hl" name="740" href="#740">740</a>BENCHMARK_TEMPLATE_F(MyFixture, IntTest, int)(benchmark::State&amp; st) {
<a class="l" name="741" href="#741">741</a>   for (auto _ : st) {
<a class="l" name="742" href="#742">742</a>     ...
<a class="l" name="743" href="#743">743</a>  }
<a class="l" name="744" href="#744">744</a>}
<a class="l" name="745" href="#745">745</a>
<a class="l" name="746" href="#746">746</a>BENCHMARK_TEMPLATE_DEFINE_F(MyFixture, DoubleTest, double)(benchmark::State&amp; st) {
<a class="l" name="747" href="#747">747</a>   for (auto _ : st) {
<a class="l" name="748" href="#748">748</a>     ...
<a class="l" name="749" href="#749">749</a>  }
<a class="hl" name="750" href="#750">750</a>}
<a class="l" name="751" href="#751">751</a>
<a class="l" name="752" href="#752">752</a>BENCHMARK_REGISTER_F(MyFixture, DoubleTest)-&gt;Threads(2);
<a class="l" name="753" href="#753">753</a>```
<a class="l" name="754" href="#754">754</a>
<a class="l" name="755" href="#755">755</a>&lt;a name="custom-counters" /&gt;
<a class="l" name="756" href="#756">756</a>
<a class="l" name="757" href="#757">757</a>### Custom Counters
<a class="l" name="758" href="#758">758</a>
<a class="l" name="759" href="#759">759</a>You can add your own counters with user-defined names. The example below
<a class="hl" name="760" href="#760">760</a>will add columns "Foo", "Bar" and "Baz" in its output:
<a class="l" name="761" href="#761">761</a>
<a class="l" name="762" href="#762">762</a>```c++
<a class="l" name="763" href="#763">763</a>static void UserCountersExample1(benchmark::State&amp; state) {
<a class="l" name="764" href="#764">764</a>  double numFoos = 0, numBars = 0, numBazs = 0;
<a class="l" name="765" href="#765">765</a>  for (auto _ : state) {
<a class="l" name="766" href="#766">766</a>    // ... count Foo,Bar,Baz events
<a class="l" name="767" href="#767">767</a>  }
<a class="l" name="768" href="#768">768</a>  <a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>["Foo"] = numFoos;
<a class="l" name="769" href="#769">769</a>  <a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>["Bar"] = numBars;
<a class="hl" name="770" href="#770">770</a>  <a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>["Baz"] = numBazs;
<a class="l" name="771" href="#771">771</a>}
<a class="l" name="772" href="#772">772</a>```
<a class="l" name="773" href="#773">773</a>
<a class="l" name="774" href="#774">774</a>The `<a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>` object is a `std::map` with `std::string` keys
<a class="l" name="775" href="#775">775</a>and `Counter` values. The latter is a `double`-like class, via an implicit
<a class="l" name="776" href="#776">776</a>conversion to `double&amp;`. Thus you can use all of the standard arithmetic
<a class="l" name="777" href="#777">777</a>assignment operators (`=,+=,-=,*=,/=`) to change the value of each counter.
<a class="l" name="778" href="#778">778</a>
<a class="l" name="779" href="#779">779</a>In multithreaded benchmarks, each counter is set on the calling thread only.
<a class="hl" name="780" href="#780">780</a>When the benchmark finishes, the counters from each thread will be summed;
<a class="l" name="781" href="#781">781</a>the resulting sum is the value which will be shown for the benchmark.
<a class="l" name="782" href="#782">782</a>
<a class="l" name="783" href="#783">783</a>The `Counter` constructor accepts three parameters: the value as a `double`
<a class="l" name="784" href="#784">784</a>; a bit flag which allows you to show counters as rates, <a href="/googletest/s?path=and/or&amp;project=benchmark">and/or</a> as per-thread
<a class="l" name="785" href="#785">785</a>iteration, <a href="/googletest/s?path=and/or&amp;project=benchmark">and/or</a> as per-thread averages, <a href="/googletest/s?path=and/or&amp;project=benchmark">and/or</a> iteration invariants,
<a class="l" name="786" href="#786">786</a><a href="/googletest/s?path=and/or&amp;project=benchmark">and/or</a> finally inverting the result; and a flag specifying the 'unit' - <a href="/googletest/s?path=i.e.&amp;project=benchmark">i.e.</a>
<a class="l" name="787" href="#787">787</a>is 1k a 1000 (default, `benchmark::Counter::OneK::kIs1000`), or 1024
<a class="l" name="788" href="#788">788</a>(`benchmark::Counter::OneK::kIs1024`)?
<a class="l" name="789" href="#789">789</a>
<a class="hl" name="790" href="#790">790</a>```c++
<a class="l" name="791" href="#791">791</a>  // sets a simple counter
<a class="l" name="792" href="#792">792</a>  <a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>["Foo"] = numFoos;
<a class="l" name="793" href="#793">793</a>
<a class="l" name="794" href="#794">794</a>  // Set the counter as a rate. It will be presented divided
<a class="l" name="795" href="#795">795</a>  // by the duration of the benchmark.
<a class="l" name="796" href="#796">796</a>  // Meaning: per one second, how many 'foo's are processed?
<a class="l" name="797" href="#797">797</a>  <a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>["FooRate"] = Counter(numFoos, benchmark::Counter::kIsRate);
<a class="l" name="798" href="#798">798</a>
<a class="l" name="799" href="#799">799</a>  // Set the counter as a rate. It will be presented divided
<a class="hl" name="800" href="#800">800</a>  // by the duration of the benchmark, and the result inverted.
<a class="l" name="801" href="#801">801</a>  // Meaning: how many seconds it takes to process one 'foo'?
<a class="l" name="802" href="#802">802</a>  <a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>["FooInvRate"] = Counter(numFoos, benchmark::Counter::kIsRate | benchmark::Counter::kInvert);
<a class="l" name="803" href="#803">803</a>
<a class="l" name="804" href="#804">804</a>  // Set the counter as a thread-average quantity. It will
<a class="l" name="805" href="#805">805</a>  // be presented divided by the number of threads.
<a class="l" name="806" href="#806">806</a>  <a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>["FooAvg"] = Counter(numFoos, benchmark::Counter::kAvgThreads);
<a class="l" name="807" href="#807">807</a>
<a class="l" name="808" href="#808">808</a>  // There's also a combined flag:
<a class="l" name="809" href="#809">809</a>  <a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>["FooAvgRate"] = Counter(numFoos,benchmark::Counter::kAvgThreadsRate);
<a class="hl" name="810" href="#810">810</a>
<a class="l" name="811" href="#811">811</a>  // This says that we process with the rate of <a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0) bytes every iteration:
<a class="l" name="812" href="#812">812</a>  <a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>["BytesProcessed"] = Counter(<a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0), benchmark::Counter::kIsIterationInvariantRate, benchmark::Counter::OneK::kIs1024);
<a class="l" name="813" href="#813">813</a>```
<a class="l" name="814" href="#814">814</a>
<a class="l" name="815" href="#815">815</a>When you're compiling in C++11 mode or later you can use `insert()` with
<a class="l" name="816" href="#816">816</a>`std::initializer_list`:
<a class="l" name="817" href="#817">817</a>
<a class="l" name="818" href="#818">818</a>```c++
<a class="l" name="819" href="#819">819</a>  // With C++11, this can be done:
<a class="hl" name="820" href="#820">820</a>  <a href="/googletest/s?path=state.counters.insert&amp;project=benchmark">state.counters.insert</a>({{"Foo", numFoos}, {"Bar", numBars}, {"Baz", numBazs}});
<a class="l" name="821" href="#821">821</a>  // ... instead of:
<a class="l" name="822" href="#822">822</a>  <a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>["Foo"] = numFoos;
<a class="l" name="823" href="#823">823</a>  <a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>["Bar"] = numBars;
<a class="l" name="824" href="#824">824</a>  <a href="/googletest/s?path=state.counters&amp;project=benchmark">state.counters</a>["Baz"] = numBazs;
<a class="l" name="825" href="#825">825</a>```
<a class="l" name="826" href="#826">826</a>
<a class="l" name="827" href="#827">827</a>#### Counter Reporting
<a class="l" name="828" href="#828">828</a>
<a class="l" name="829" href="#829">829</a>When using the console reporter, by default, user counters are printed at
<a class="hl" name="830" href="#830">830</a>the end after the table, the same way as ``bytes_processed`` and
<a class="l" name="831" href="#831">831</a>``items_processed``. This is best for cases in which there are few counters,
<a class="l" name="832" href="#832">832</a>or where there are only a couple of lines per benchmark. Here's an example of
<a class="l" name="833" href="#833">833</a>the default output:
<a class="l" name="834" href="#834">834</a>
<a class="l" name="835" href="#835">835</a>```
<a class="l" name="836" href="#836">836</a>------------------------------------------------------------------------------
<a class="l" name="837" href="#837">837</a>Benchmark                        Time           CPU Iterations UserCounters...
<a class="l" name="838" href="#838">838</a>------------------------------------------------------------------------------
<a class="l" name="839" href="#839">839</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:8      2248 ns      10277 ns      68808 Bar=16 Bat=40 Baz=24 Foo=8
<a class="hl" name="840" href="#840">840</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:1      9797 ns       9788 ns      71523 Bar=2 Bat=5 Baz=3 Foo=1024m
<a class="l" name="841" href="#841">841</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:2      4924 ns       9842 ns      71036 Bar=4 Bat=10 Baz=6 Foo=2
<a class="l" name="842" href="#842">842</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:4      2589 ns      10284 ns      68012 Bar=8 Bat=20 Baz=12 Foo=4
<a class="l" name="843" href="#843">843</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:8      2212 ns      10287 ns      68040 Bar=16 Bat=40 Baz=24 Foo=8
<a class="l" name="844" href="#844">844</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:16     1782 ns      10278 ns      68144 Bar=32 Bat=80 Baz=48 Foo=16
<a class="l" name="845" href="#845">845</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:32     1291 ns      10296 ns      68256 Bar=64 Bat=160 Baz=96 Foo=32
<a class="l" name="846" href="#846">846</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:4      2615 ns      10307 ns      68040 Bar=8 Bat=20 Baz=12 Foo=4
<a class="l" name="847" href="#847">847</a>BM_Factorial                    26 ns         26 ns   26608979 40320
<a class="l" name="848" href="#848">848</a><a href="/googletest/s?path=BM_Factorial/real_time&amp;project=benchmark">BM_Factorial/real_time</a>          26 ns         26 ns   26587936 40320
<a class="l" name="849" href="#849">849</a>BM_CalculatePiRange/1           16 ns         16 ns   45704255 0
<a class="hl" name="850" href="#850">850</a>BM_CalculatePiRange/8           73 ns         73 ns    9520927 3.28374
<a class="l" name="851" href="#851">851</a>BM_CalculatePiRange/64         609 ns        609 ns    1140647 3.15746
<a class="l" name="852" href="#852">852</a>BM_CalculatePiRange/512       4900 ns       4901 ns     142696 3.14355
<a class="l" name="853" href="#853">853</a>```
<a class="l" name="854" href="#854">854</a>
<a class="l" name="855" href="#855">855</a>If this doesn't suit you, you can print each counter as a table column by
<a class="l" name="856" href="#856">856</a>passing the flag `--benchmark_counters_tabular=true` to the benchmark
<a class="l" name="857" href="#857">857</a>application. This is best for cases in which there are a lot of counters, or
<a class="l" name="858" href="#858">858</a>a lot of lines per individual benchmark. Note that this will trigger a
<a class="l" name="859" href="#859">859</a>reprinting of the table header any time the counter set changes between
<a class="hl" name="860" href="#860">860</a>individual benchmarks. Here's an example of corresponding output when
<a class="l" name="861" href="#861">861</a>`--benchmark_counters_tabular=true` is passed:
<a class="l" name="862" href="#862">862</a>
<a class="l" name="863" href="#863">863</a>```
<a class="l" name="864" href="#864">864</a>---------------------------------------------------------------------------------------
<a class="l" name="865" href="#865">865</a>Benchmark                        Time           CPU Iterations    Bar   Bat   Baz   Foo
<a class="l" name="866" href="#866">866</a>---------------------------------------------------------------------------------------
<a class="l" name="867" href="#867">867</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:8      2198 ns       9953 ns      70688     16    40    24     8
<a class="l" name="868" href="#868">868</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:1      9504 ns       9504 ns      73787      2     5     3     1
<a class="l" name="869" href="#869">869</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:2      4775 ns       9550 ns      72606      4    10     6     2
<a class="hl" name="870" href="#870">870</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:4      2508 ns       9951 ns      70332      8    20    12     4
<a class="l" name="871" href="#871">871</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:8      2055 ns       9933 ns      70344     16    40    24     8
<a class="l" name="872" href="#872">872</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:16     1610 ns       9946 ns      70720     32    80    48    16
<a class="l" name="873" href="#873">873</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:32     1192 ns       9948 ns      70496     64   160    96    32
<a class="l" name="874" href="#874">874</a><a href="/googletest/s?path=BM_UserCounter/threads&amp;project=benchmark">BM_UserCounter/threads</a>:4      2506 ns       9949 ns      70332      8    20    12     4
<a class="l" name="875" href="#875">875</a>--------------------------------------------------------------
<a class="l" name="876" href="#876">876</a>Benchmark                        Time           CPU Iterations
<a class="l" name="877" href="#877">877</a>--------------------------------------------------------------
<a class="l" name="878" href="#878">878</a>BM_Factorial                    26 ns         26 ns   26392245 40320
<a class="l" name="879" href="#879">879</a><a href="/googletest/s?path=BM_Factorial/real_time&amp;project=benchmark">BM_Factorial/real_time</a>          26 ns         26 ns   26494107 40320
<a class="hl" name="880" href="#880">880</a>BM_CalculatePiRange/1           15 ns         15 ns   45571597 0
<a class="l" name="881" href="#881">881</a>BM_CalculatePiRange/8           74 ns         74 ns    9450212 3.28374
<a class="l" name="882" href="#882">882</a>BM_CalculatePiRange/64         595 ns        595 ns    1173901 3.15746
<a class="l" name="883" href="#883">883</a>BM_CalculatePiRange/512       4752 ns       4752 ns     147380 3.14355
<a class="l" name="884" href="#884">884</a>BM_CalculatePiRange/4k       37970 ns      37972 ns      18453 3.14184
<a class="l" name="885" href="#885">885</a>BM_CalculatePiRange/32k     303733 ns     303744 ns       2305 3.14162
<a class="l" name="886" href="#886">886</a>BM_CalculatePiRange/256k   2434095 ns    2434186 ns        288 3.1416
<a class="l" name="887" href="#887">887</a>BM_CalculatePiRange/1024k  9721140 ns    9721413 ns         71 3.14159
<a class="l" name="888" href="#888">888</a><a href="/googletest/s?path=BM_CalculatePi/threads&amp;project=benchmark">BM_CalculatePi/threads</a>:8      2255 ns       9943 ns      70936
<a class="l" name="889" href="#889">889</a>```
<a class="hl" name="890" href="#890">890</a>
<a class="l" name="891" href="#891">891</a>Note above the additional header printed when the benchmark changes from
<a class="l" name="892" href="#892">892</a>``BM_UserCounter`` to ``BM_Factorial``. This is because ``BM_Factorial`` does
<a class="l" name="893" href="#893">893</a>not have the same counter set as ``BM_UserCounter``.
<a class="l" name="894" href="#894">894</a>
<a class="l" name="895" href="#895">895</a>&lt;a name="multithreaded-benchmarks"/&gt;
<a class="l" name="896" href="#896">896</a>
<a class="l" name="897" href="#897">897</a>### Multithreaded Benchmarks
<a class="l" name="898" href="#898">898</a>
<a class="l" name="899" href="#899">899</a>In a multithreaded test (benchmark invoked by multiple threads simultaneously),
<a class="hl" name="900" href="#900">900</a>it is guaranteed that none of the threads will start until all have reached
<a class="l" name="901" href="#901">901</a>the start of the benchmark loop, and all will have finished before any thread
<a class="l" name="902" href="#902">902</a>exits the benchmark loop. (This behavior is also provided by the `KeepRunning()`
<a class="l" name="903" href="#903">903</a>API) As such, any global setup or teardown can be wrapped in a check against the thread
<a class="l" name="904" href="#904">904</a>index:
<a class="l" name="905" href="#905">905</a>
<a class="l" name="906" href="#906">906</a>```c++
<a class="l" name="907" href="#907">907</a>static void BM_MultiThreaded(benchmark::State&amp; state) {
<a class="l" name="908" href="#908">908</a>  if (<a href="/googletest/s?path=state.thread_index&amp;project=benchmark">state.thread_index</a> == 0) {
<a class="l" name="909" href="#909">909</a>    // Setup code here.
<a class="hl" name="910" href="#910">910</a>  }
<a class="l" name="911" href="#911">911</a>  for (auto _ : state) {
<a class="l" name="912" href="#912">912</a>    // Run the test as normal.
<a class="l" name="913" href="#913">913</a>  }
<a class="l" name="914" href="#914">914</a>  if (<a href="/googletest/s?path=state.thread_index&amp;project=benchmark">state.thread_index</a> == 0) {
<a class="l" name="915" href="#915">915</a>    // Teardown code here.
<a class="l" name="916" href="#916">916</a>  }
<a class="l" name="917" href="#917">917</a>}
<a class="l" name="918" href="#918">918</a>BENCHMARK(BM_MultiThreaded)-&gt;Threads(2);
<a class="l" name="919" href="#919">919</a>```
<a class="hl" name="920" href="#920">920</a>
<a class="l" name="921" href="#921">921</a>If the benchmarked code itself uses threads and you want to compare it to
<a class="l" name="922" href="#922">922</a>single-threaded code, you may want to use real-time ("wallclock") measurements
<a class="l" name="923" href="#923">923</a>for latency comparisons:
<a class="l" name="924" href="#924">924</a>
<a class="l" name="925" href="#925">925</a>```c++
<a class="l" name="926" href="#926">926</a>BENCHMARK(BM_test)-&gt;Range(8, 8&lt;&lt;10)-&gt;UseRealTime();
<a class="l" name="927" href="#927">927</a>```
<a class="l" name="928" href="#928">928</a>
<a class="l" name="929" href="#929">929</a>Without `UseRealTime`, CPU time is used by default.
<a class="hl" name="930" href="#930">930</a>
<a class="l" name="931" href="#931">931</a>&lt;a name="cpu-timers" /&gt;
<a class="l" name="932" href="#932">932</a>
<a class="l" name="933" href="#933">933</a>### CPU Timers
<a class="l" name="934" href="#934">934</a>
<a class="l" name="935" href="#935">935</a>By default, the CPU timer only measures the time spent by the main thread.
<a class="l" name="936" href="#936">936</a>If the benchmark itself uses threads internally, this measurement may not
<a class="l" name="937" href="#937">937</a>be what you are looking for. Instead, there is a way to measure the total
<a class="l" name="938" href="#938">938</a>CPU usage of the process, by all the threads.
<a class="l" name="939" href="#939">939</a>
<a class="hl" name="940" href="#940">940</a>```c++
<a class="l" name="941" href="#941">941</a>void callee(int i);
<a class="l" name="942" href="#942">942</a>
<a class="l" name="943" href="#943">943</a>static void MyMain(int size) {
<a class="l" name="944" href="#944">944</a>#pragma omp parallel for
<a class="l" name="945" href="#945">945</a>  for(int i = 0; i &lt; size; i++)
<a class="l" name="946" href="#946">946</a>    callee(i);
<a class="l" name="947" href="#947">947</a>}
<a class="l" name="948" href="#948">948</a>
<a class="l" name="949" href="#949">949</a>static void BM_OpenMP(benchmark::State&amp; state) {
<a class="hl" name="950" href="#950">950</a>  for (auto _ : state)
<a class="l" name="951" href="#951">951</a>    MyMain(<a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0));
<a class="l" name="952" href="#952">952</a>}
<a class="l" name="953" href="#953">953</a>
<a class="l" name="954" href="#954">954</a>// Measure the time spent by the main thread, use it to decide for how long to
<a class="l" name="955" href="#955">955</a>// run the benchmark loop. Depending on the internal implementation detail may
<a class="l" name="956" href="#956">956</a>// measure to anywhere from near-zero (the overhead spent <a href="/googletest/s?path=before/after&amp;project=benchmark">before/after</a> work
<a class="l" name="957" href="#957">957</a>// handoff to worker thread[s]) to the whole single-thread time.
<a class="l" name="958" href="#958">958</a>BENCHMARK(BM_OpenMP)-&gt;Range(8, 8&lt;&lt;10);
<a class="l" name="959" href="#959">959</a>
<a class="hl" name="960" href="#960">960</a>// Measure the user-visible time, the wall clock (literally, the time that
<a class="l" name="961" href="#961">961</a>// has passed on the clock on the wall), use it to decide for how long to
<a class="l" name="962" href="#962">962</a>// run the benchmark loop. This will always be meaningful, an will match the
<a class="l" name="963" href="#963">963</a>// time spent by the main thread in single-threaded case, in general decreasing
<a class="l" name="964" href="#964">964</a>// with the number of internal threads doing the work.
<a class="l" name="965" href="#965">965</a>BENCHMARK(BM_OpenMP)-&gt;Range(8, 8&lt;&lt;10)-&gt;UseRealTime();
<a class="l" name="966" href="#966">966</a>
<a class="l" name="967" href="#967">967</a>// Measure the total CPU consumption, use it to decide for how long to
<a class="l" name="968" href="#968">968</a>// run the benchmark loop. This will always measure to no less than the
<a class="l" name="969" href="#969">969</a>// time spent by the main thread in single-threaded case.
<a class="hl" name="970" href="#970">970</a>BENCHMARK(BM_OpenMP)-&gt;Range(8, 8&lt;&lt;10)-&gt;MeasureProcessCPUTime();
<a class="l" name="971" href="#971">971</a>
<a class="l" name="972" href="#972">972</a>// A mixture of the last two. Measure the total CPU consumption, but use the
<a class="l" name="973" href="#973">973</a>// wall clock to decide for how long to run the benchmark loop.
<a class="l" name="974" href="#974">974</a>BENCHMARK(BM_OpenMP)-&gt;Range(8, 8&lt;&lt;10)-&gt;MeasureProcessCPUTime()-&gt;UseRealTime();
<a class="l" name="975" href="#975">975</a>```
<a class="l" name="976" href="#976">976</a>
<a class="l" name="977" href="#977">977</a>#### Controlling Timers
<a class="l" name="978" href="#978">978</a>
<a class="l" name="979" href="#979">979</a>Normally, the entire duration of the work loop (`for (auto _ : state) {}`)
<a class="hl" name="980" href="#980">980</a>is measured. But sometimes, it is necessary to do some work inside of
<a class="l" name="981" href="#981">981</a>that loop, every iteration, but without counting that time to the benchmark time.
<a class="l" name="982" href="#982">982</a>That is possible, although it is not recommended, since it has high overhead.
<a class="l" name="983" href="#983">983</a>
<a class="l" name="984" href="#984">984</a>```c++
<a class="l" name="985" href="#985">985</a>static void BM_SetInsert_With_Timer_Control(benchmark::State&amp; state) {
<a class="l" name="986" href="#986">986</a>  std::set&lt;int&gt; data;
<a class="l" name="987" href="#987">987</a>  for (auto _ : state) {
<a class="l" name="988" href="#988">988</a>    <a href="/googletest/s?path=state.PauseTiming&amp;project=benchmark">state.PauseTiming</a>(); // Stop timers. They will not count until they are resumed.
<a class="l" name="989" href="#989">989</a>    data = ConstructRandomSet(<a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0)); // Do something that should not be measured
<a class="hl" name="990" href="#990">990</a>    <a href="/googletest/s?path=state.ResumeTiming&amp;project=benchmark">state.ResumeTiming</a>(); // And resume timers. They are now counting again.
<a class="l" name="991" href="#991">991</a>    // The rest will be measured.
<a class="l" name="992" href="#992">992</a>    for (int j = 0; j &lt; <a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(1); ++j)
<a class="l" name="993" href="#993">993</a>      <a href="/googletest/s?path=data.insert&amp;project=benchmark">data.insert</a>(RandomNumber());
<a class="l" name="994" href="#994">994</a>  }
<a class="l" name="995" href="#995">995</a>}
<a class="l" name="996" href="#996">996</a>BENCHMARK(BM_SetInsert_With_Timer_Control)-&gt;Ranges({{1&lt;&lt;10, 8&lt;&lt;10}, {128, 512}});
<a class="l" name="997" href="#997">997</a>```
<a class="l" name="998" href="#998">998</a>
<a class="l" name="999" href="#999">999</a>&lt;a name="manual-timing" /&gt;
<a class="hl" name="1000" href="#1000">1000</a>
<a class="l" name="1001" href="#1001">1001</a>### Manual Timing
<a class="l" name="1002" href="#1002">1002</a>
<a class="l" name="1003" href="#1003">1003</a>For benchmarking something for which neither CPU time nor real-time are
<a class="l" name="1004" href="#1004">1004</a>correct or accurate enough, completely manual timing is supported using
<a class="l" name="1005" href="#1005">1005</a>the `UseManualTime` function.
<a class="l" name="1006" href="#1006">1006</a>
<a class="l" name="1007" href="#1007">1007</a>When `UseManualTime` is used, the benchmarked code must call
<a class="l" name="1008" href="#1008">1008</a>`SetIterationTime` once per iteration of the benchmark loop to
<a class="l" name="1009" href="#1009">1009</a>report the manually measured time.
<a class="hl" name="1010" href="#1010">1010</a>
<a class="l" name="1011" href="#1011">1011</a>An example use case for this is benchmarking GPU execution (<a href="/googletest/s?path=e.g.&amp;project=benchmark">e.g.</a> OpenCL
<a class="l" name="1012" href="#1012">1012</a>or CUDA kernels, OpenGL or Vulkan or Direct3D draw calls), which cannot
<a class="l" name="1013" href="#1013">1013</a>be accurately measured using CPU time or real-time. Instead, they can be
<a class="l" name="1014" href="#1014">1014</a>measured accurately using a dedicated API, and these measurement results
<a class="l" name="1015" href="#1015">1015</a>can be reported back with `SetIterationTime`.
<a class="l" name="1016" href="#1016">1016</a>
<a class="l" name="1017" href="#1017">1017</a>```c++
<a class="l" name="1018" href="#1018">1018</a>static void BM_ManualTiming(benchmark::State&amp; state) {
<a class="l" name="1019" href="#1019">1019</a>  int microseconds = <a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0);
<a class="hl" name="1020" href="#1020">1020</a>  std::chrono::duration&lt;double, std::micro&gt; sleep_duration {
<a class="l" name="1021" href="#1021">1021</a>    static_cast&lt;double&gt;(microseconds)
<a class="l" name="1022" href="#1022">1022</a>  };
<a class="l" name="1023" href="#1023">1023</a>
<a class="l" name="1024" href="#1024">1024</a>  for (auto _ : state) {
<a class="l" name="1025" href="#1025">1025</a>    auto start = std::chrono::high_resolution_clock::now();
<a class="l" name="1026" href="#1026">1026</a>    // Simulate some useful workload with a sleep
<a class="l" name="1027" href="#1027">1027</a>    std::this_thread::sleep_for(sleep_duration);
<a class="l" name="1028" href="#1028">1028</a>    auto end = std::chrono::high_resolution_clock::now();
<a class="l" name="1029" href="#1029">1029</a>
<a class="hl" name="1030" href="#1030">1030</a>    auto elapsed_seconds =
<a class="l" name="1031" href="#1031">1031</a>      std::chrono::duration_cast&lt;std::chrono::duration&lt;double&gt;&gt;(
<a class="l" name="1032" href="#1032">1032</a>        end - start);
<a class="l" name="1033" href="#1033">1033</a>
<a class="l" name="1034" href="#1034">1034</a>    <a href="/googletest/s?path=state.SetIterationTime&amp;project=benchmark">state.SetIterationTime</a>(<a href="/googletest/s?path=elapsed_seconds.count&amp;project=benchmark">elapsed_seconds.count</a>());
<a class="l" name="1035" href="#1035">1035</a>  }
<a class="l" name="1036" href="#1036">1036</a>}
<a class="l" name="1037" href="#1037">1037</a>BENCHMARK(BM_ManualTiming)-&gt;Range(1, 1&lt;&lt;17)-&gt;UseManualTime();
<a class="l" name="1038" href="#1038">1038</a>```
<a class="l" name="1039" href="#1039">1039</a>
<a class="hl" name="1040" href="#1040">1040</a>&lt;a name="setting-the-time-unit" /&gt;
<a class="l" name="1041" href="#1041">1041</a>
<a class="l" name="1042" href="#1042">1042</a>### Setting the Time Unit
<a class="l" name="1043" href="#1043">1043</a>
<a class="l" name="1044" href="#1044">1044</a>If a benchmark runs a few milliseconds it may be hard to visually compare the
<a class="l" name="1045" href="#1045">1045</a>measured times, since the output data is given in nanoseconds per default. In
<a class="l" name="1046" href="#1046">1046</a>order to manually set the time unit, you can specify it manually:
<a class="l" name="1047" href="#1047">1047</a>
<a class="l" name="1048" href="#1048">1048</a>```c++
<a class="l" name="1049" href="#1049">1049</a>BENCHMARK(BM_test)-&gt;Unit(benchmark::kMillisecond);
<a class="hl" name="1050" href="#1050">1050</a>```
<a class="l" name="1051" href="#1051">1051</a>
<a class="l" name="1052" href="#1052">1052</a>&lt;a name="preventing-optimization" /&gt;
<a class="l" name="1053" href="#1053">1053</a>
<a class="l" name="1054" href="#1054">1054</a>### Preventing Optimization
<a class="l" name="1055" href="#1055">1055</a>
<a class="l" name="1056" href="#1056">1056</a>To prevent a value or expression from being optimized away by the compiler
<a class="l" name="1057" href="#1057">1057</a>the `benchmark::DoNotOptimize(...)` and `benchmark::ClobberMemory()`
<a class="l" name="1058" href="#1058">1058</a>functions can be used.
<a class="l" name="1059" href="#1059">1059</a>
<a class="hl" name="1060" href="#1060">1060</a>```c++
<a class="l" name="1061" href="#1061">1061</a>static void BM_test(benchmark::State&amp; state) {
<a class="l" name="1062" href="#1062">1062</a>  for (auto _ : state) {
<a class="l" name="1063" href="#1063">1063</a>      int x = 0;
<a class="l" name="1064" href="#1064">1064</a>      for (int i=0; i &lt; 64; ++i) {
<a class="l" name="1065" href="#1065">1065</a>        benchmark::DoNotOptimize(x += i);
<a class="l" name="1066" href="#1066">1066</a>      }
<a class="l" name="1067" href="#1067">1067</a>  }
<a class="l" name="1068" href="#1068">1068</a>}
<a class="l" name="1069" href="#1069">1069</a>```
<a class="hl" name="1070" href="#1070">1070</a>
<a class="l" name="1071" href="#1071">1071</a>`DoNotOptimize(&lt;expr&gt;)` forces the  *result* of `&lt;expr&gt;` to be stored in either
<a class="l" name="1072" href="#1072">1072</a>memory or a register. For GNU based compilers it acts as <a href="/googletest/s?path=read/write&amp;project=benchmark">read/write</a> barrier
<a class="l" name="1073" href="#1073">1073</a>for global memory. More specifically it forces the compiler to flush pending
<a class="l" name="1074" href="#1074">1074</a>writes to memory and reload any other values as necessary.
<a class="l" name="1075" href="#1075">1075</a>
<a class="l" name="1076" href="#1076">1076</a>Note that `DoNotOptimize(&lt;expr&gt;)` does not prevent optimizations on `&lt;expr&gt;`
<a class="l" name="1077" href="#1077">1077</a>in any way. `&lt;expr&gt;` may even be removed entirely when the result is already
<a class="l" name="1078" href="#1078">1078</a>known. For example:
<a class="l" name="1079" href="#1079">1079</a>
<a class="hl" name="1080" href="#1080">1080</a>```c++
<a class="l" name="1081" href="#1081">1081</a>  /* Example 1: `&lt;expr&gt;` is removed entirely. */
<a class="l" name="1082" href="#1082">1082</a>  int foo(int x) { return x + 42; }
<a class="l" name="1083" href="#1083">1083</a>  while (...) DoNotOptimize(foo(0)); // Optimized to DoNotOptimize(42);
<a class="l" name="1084" href="#1084">1084</a>
<a class="l" name="1085" href="#1085">1085</a>  /*  Example 2: Result of '&lt;expr&gt;' is only reused */
<a class="l" name="1086" href="#1086">1086</a>  int bar(int) __attribute__((const));
<a class="l" name="1087" href="#1087">1087</a>  while (...) DoNotOptimize(bar(0)); // Optimized to:
<a class="l" name="1088" href="#1088">1088</a>  // int __result__ = bar(0);
<a class="l" name="1089" href="#1089">1089</a>  // while (...) DoNotOptimize(__result__);
<a class="hl" name="1090" href="#1090">1090</a>```
<a class="l" name="1091" href="#1091">1091</a>
<a class="l" name="1092" href="#1092">1092</a>The second tool for preventing optimizations is `ClobberMemory()`. In essence
<a class="l" name="1093" href="#1093">1093</a>`ClobberMemory()` forces the compiler to perform all pending writes to global
<a class="l" name="1094" href="#1094">1094</a>memory. Memory managed by block scope objects must be "escaped" using
<a class="l" name="1095" href="#1095">1095</a>`DoNotOptimize(...)` before it can be clobbered. In the below example
<a class="l" name="1096" href="#1096">1096</a>`ClobberMemory()` prevents the call to `<a href="/googletest/s?path=v.push_back&amp;project=benchmark">v.push_back</a>(42)` from being optimized
<a class="l" name="1097" href="#1097">1097</a>away.
<a class="l" name="1098" href="#1098">1098</a>
<a class="l" name="1099" href="#1099">1099</a>```c++
<a class="hl" name="1100" href="#1100">1100</a>static void BM_vector_push_back(benchmark::State&amp; state) {
<a class="l" name="1101" href="#1101">1101</a>  for (auto _ : state) {
<a class="l" name="1102" href="#1102">1102</a>    std::vector&lt;int&gt; v;
<a class="l" name="1103" href="#1103">1103</a>    <a href="/googletest/s?path=v.reserve&amp;project=benchmark">v.reserve</a>(1);
<a class="l" name="1104" href="#1104">1104</a>    benchmark::DoNotOptimize(<a href="/googletest/s?path=v.data&amp;project=benchmark">v.data</a>()); // Allow <a href="/googletest/s?path=v.data&amp;project=benchmark">v.data</a>() to be clobbered.
<a class="l" name="1105" href="#1105">1105</a>    <a href="/googletest/s?path=v.push_back&amp;project=benchmark">v.push_back</a>(42);
<a class="l" name="1106" href="#1106">1106</a>    benchmark::ClobberMemory(); // Force 42 to be written to memory.
<a class="l" name="1107" href="#1107">1107</a>  }
<a class="l" name="1108" href="#1108">1108</a>}
<a class="l" name="1109" href="#1109">1109</a>```
<a class="hl" name="1110" href="#1110">1110</a>
<a class="l" name="1111" href="#1111">1111</a>Note that `ClobberMemory()` is only available for GNU or MSVC based compilers.
<a class="l" name="1112" href="#1112">1112</a>
<a class="l" name="1113" href="#1113">1113</a>&lt;a name="reporting-statistics" /&gt;
<a class="l" name="1114" href="#1114">1114</a>
<a class="l" name="1115" href="#1115">1115</a>### Statistics: Reporting the Mean, Median and Standard Deviation of Repeated Benchmarks
<a class="l" name="1116" href="#1116">1116</a>
<a class="l" name="1117" href="#1117">1117</a>By default each benchmark is run once and that single result is reported.
<a class="l" name="1118" href="#1118">1118</a>However benchmarks are often noisy and a single result may not be representative
<a class="l" name="1119" href="#1119">1119</a>of the overall behavior. For this reason it's possible to repeatedly rerun the
<a class="hl" name="1120" href="#1120">1120</a>benchmark.
<a class="l" name="1121" href="#1121">1121</a>
<a class="l" name="1122" href="#1122">1122</a>The number of runs of each benchmark is specified globally by the
<a class="l" name="1123" href="#1123">1123</a>`--benchmark_repetitions` flag or on a per benchmark basis by calling
<a class="l" name="1124" href="#1124">1124</a>`Repetitions` on the registered benchmark object. When a benchmark is run more
<a class="l" name="1125" href="#1125">1125</a>than once the mean, median and standard deviation of the runs will be reported.
<a class="l" name="1126" href="#1126">1126</a>
<a class="l" name="1127" href="#1127">1127</a>Additionally the `--benchmark_report_aggregates_only={true|false}`,
<a class="l" name="1128" href="#1128">1128</a>`--benchmark_display_aggregates_only={true|false}` flags or
<a class="l" name="1129" href="#1129">1129</a>`ReportAggregatesOnly(bool)`, `DisplayAggregatesOnly(bool)` functions can be
<a class="hl" name="1130" href="#1130">1130</a>used to change how repeated tests are reported. By default the result of each
<a class="l" name="1131" href="#1131">1131</a>repeated run is reported. When `report aggregates only` option is `true`,
<a class="l" name="1132" href="#1132">1132</a>only the aggregates (<a href="/googletest/s?path=i.e.&amp;project=benchmark">i.e.</a> mean, median and standard deviation, maybe complexity
<a class="l" name="1133" href="#1133">1133</a>measurements if they were requested) of the runs is reported, to both the
<a class="l" name="1134" href="#1134">1134</a>reporters - standard output (console), and the file.
<a class="l" name="1135" href="#1135">1135</a>However when only the `display aggregates only` option is `true`,
<a class="l" name="1136" href="#1136">1136</a>only the aggregates are displayed in the standard output, while the file
<a class="l" name="1137" href="#1137">1137</a>output still contains everything.
<a class="l" name="1138" href="#1138">1138</a>Calling `ReportAggregatesOnly(bool)` / `DisplayAggregatesOnly(bool)` on a
<a class="l" name="1139" href="#1139">1139</a>registered benchmark object overrides the value of the appropriate flag for that
<a class="hl" name="1140" href="#1140">1140</a>benchmark.
<a class="l" name="1141" href="#1141">1141</a>
<a class="l" name="1142" href="#1142">1142</a>&lt;a name="custom-statistics" /&gt;
<a class="l" name="1143" href="#1143">1143</a>
<a class="l" name="1144" href="#1144">1144</a>### Custom Statistics
<a class="l" name="1145" href="#1145">1145</a>
<a class="l" name="1146" href="#1146">1146</a>While having mean, median and standard deviation is nice, this may not be
<a class="l" name="1147" href="#1147">1147</a>enough for everyone. For example you may want to know what the largest
<a class="l" name="1148" href="#1148">1148</a>observation is, <a href="/googletest/s?path=e.g.&amp;project=benchmark">e.g.</a> because you have some real-time constraints. This is easy.
<a class="l" name="1149" href="#1149">1149</a>The following code will specify a custom statistic to be calculated, defined
<a class="hl" name="1150" href="#1150">1150</a>by a lambda function.
<a class="l" name="1151" href="#1151">1151</a>
<a class="l" name="1152" href="#1152">1152</a>```c++
<a class="l" name="1153" href="#1153">1153</a>void BM_spin_empty(benchmark::State&amp; state) {
<a class="l" name="1154" href="#1154">1154</a>  for (auto _ : state) {
<a class="l" name="1155" href="#1155">1155</a>    for (int x = 0; x &lt; <a href="/googletest/s?path=state.range&amp;project=benchmark">state.range</a>(0); ++x) {
<a class="l" name="1156" href="#1156">1156</a>      benchmark::DoNotOptimize(x);
<a class="l" name="1157" href="#1157">1157</a>    }
<a class="l" name="1158" href="#1158">1158</a>  }
<a class="l" name="1159" href="#1159">1159</a>}
<a class="hl" name="1160" href="#1160">1160</a>
<a class="l" name="1161" href="#1161">1161</a>BENCHMARK(BM_spin_empty)
<a class="l" name="1162" href="#1162">1162</a>  -&gt;ComputeStatistics("max", [](const std::vector&lt;double&gt;&amp; v) -&gt; double {
<a class="l" name="1163" href="#1163">1163</a>    return *(std::max_element(std::begin(v), std::end(v)));
<a class="l" name="1164" href="#1164">1164</a>  })
<a class="l" name="1165" href="#1165">1165</a>  -&gt;Arg(512);
<a class="l" name="1166" href="#1166">1166</a>```
<a class="l" name="1167" href="#1167">1167</a>
<a class="l" name="1168" href="#1168">1168</a>&lt;a name="using-register-benchmark" /&gt;
<a class="l" name="1169" href="#1169">1169</a>
<a class="hl" name="1170" href="#1170">1170</a>### Using RegisterBenchmark(name, fn, args...)
<a class="l" name="1171" href="#1171">1171</a>
<a class="l" name="1172" href="#1172">1172</a>The `RegisterBenchmark(name, func, args...)` function provides an alternative
<a class="l" name="1173" href="#1173">1173</a>way to create and register benchmarks.
<a class="l" name="1174" href="#1174">1174</a>`RegisterBenchmark(name, func, args...)` creates, registers, and returns a
<a class="l" name="1175" href="#1175">1175</a>pointer to a new benchmark with the specified `name` that invokes
<a class="l" name="1176" href="#1176">1176</a>`func(st, args...)` where `st` is a `benchmark::State` object.
<a class="l" name="1177" href="#1177">1177</a>
<a class="l" name="1178" href="#1178">1178</a>Unlike the `BENCHMARK` registration macros, which can only be used at the global
<a class="l" name="1179" href="#1179">1179</a>scope, the `RegisterBenchmark` can be called anywhere. This allows for
<a class="hl" name="1180" href="#1180">1180</a>benchmark tests to be registered programmatically.
<a class="l" name="1181" href="#1181">1181</a>
<a class="l" name="1182" href="#1182">1182</a>Additionally `RegisterBenchmark` allows any callable object to be registered
<a class="l" name="1183" href="#1183">1183</a>as a benchmark. Including capturing lambdas and function objects.
<a class="l" name="1184" href="#1184">1184</a>
<a class="l" name="1185" href="#1185">1185</a>For Example:
<a class="l" name="1186" href="#1186">1186</a>```c++
<a class="l" name="1187" href="#1187">1187</a>auto BM_test = [](benchmark::State&amp; st, auto Inputs) { /* ... */ };
<a class="l" name="1188" href="#1188">1188</a>
<a class="l" name="1189" href="#1189">1189</a>int main(int argc, char** argv) {
<a class="hl" name="1190" href="#1190">1190</a>  for (auto&amp; test_input : { /* ... */ })
<a class="l" name="1191" href="#1191">1191</a>      benchmark::RegisterBenchmark(<a href="/googletest/s?path=test_input.name&amp;project=benchmark">test_input.name</a>(), BM_test, test_input);
<a class="l" name="1192" href="#1192">1192</a>  benchmark::Initialize(&amp;argc, argv);
<a class="l" name="1193" href="#1193">1193</a>  benchmark::RunSpecifiedBenchmarks();
<a class="l" name="1194" href="#1194">1194</a>}
<a class="l" name="1195" href="#1195">1195</a>```
<a class="l" name="1196" href="#1196">1196</a>
<a class="l" name="1197" href="#1197">1197</a>&lt;a name="exiting-with-an-error" /&gt;
<a class="l" name="1198" href="#1198">1198</a>
<a class="l" name="1199" href="#1199">1199</a>### Exiting with an Error
<a class="hl" name="1200" href="#1200">1200</a>
<a class="l" name="1201" href="#1201">1201</a>When errors caused by external influences, such as file I/O and network
<a class="l" name="1202" href="#1202">1202</a>communication, occur within a benchmark the
<a class="l" name="1203" href="#1203">1203</a>`State::SkipWithError(const char* msg)` function can be used to skip that run
<a class="l" name="1204" href="#1204">1204</a>of benchmark and report the error. Note that only future iterations of the
<a class="l" name="1205" href="#1205">1205</a>`KeepRunning()` are skipped. For the ranged-for version of the benchmark loop
<a class="l" name="1206" href="#1206">1206</a>Users must explicitly exit the loop, otherwise all iterations will be performed.
<a class="l" name="1207" href="#1207">1207</a>Users may explicitly return to exit the benchmark immediately.
<a class="l" name="1208" href="#1208">1208</a>
<a class="l" name="1209" href="#1209">1209</a>The `SkipWithError(...)` function may be used at any point within the benchmark,
<a class="hl" name="1210" href="#1210">1210</a>including before and after the benchmark loop. Moreover, if `SkipWithError(...)`
<a class="l" name="1211" href="#1211">1211</a>has been used, it is not required to reach the benchmark loop and one may return
<a class="l" name="1212" href="#1212">1212</a>from the benchmark function early.
<a class="l" name="1213" href="#1213">1213</a>
<a class="l" name="1214" href="#1214">1214</a>For example:
<a class="l" name="1215" href="#1215">1215</a>
<a class="l" name="1216" href="#1216">1216</a>```c++
<a class="l" name="1217" href="#1217">1217</a>static void BM_test(benchmark::State&amp; state) {
<a class="l" name="1218" href="#1218">1218</a>  auto resource = GetResource();
<a class="l" name="1219" href="#1219">1219</a>  if (!<a href="/googletest/s?path=resource.good&amp;project=benchmark">resource.good</a>()) {
<a class="hl" name="1220" href="#1220">1220</a>    <a href="/googletest/s?path=state.SkipWithError&amp;project=benchmark">state.SkipWithError</a>("Resource is not good!");
<a class="l" name="1221" href="#1221">1221</a>    // KeepRunning() loop will not be entered.
<a class="l" name="1222" href="#1222">1222</a>  }
<a class="l" name="1223" href="#1223">1223</a>  while (<a href="/googletest/s?path=state.KeepRunning&amp;project=benchmark">state.KeepRunning</a>()) {
<a class="l" name="1224" href="#1224">1224</a>    auto data = <a href="/googletest/s?path=resource.read_data&amp;project=benchmark">resource.read_data</a>();
<a class="l" name="1225" href="#1225">1225</a>    if (!<a href="/googletest/s?path=resource.good&amp;project=benchmark">resource.good</a>()) {
<a class="l" name="1226" href="#1226">1226</a>      <a href="/googletest/s?path=state.SkipWithError&amp;project=benchmark">state.SkipWithError</a>("Failed to read data!");
<a class="l" name="1227" href="#1227">1227</a>      break; // Needed to skip the rest of the iteration.
<a class="l" name="1228" href="#1228">1228</a>    }
<a class="l" name="1229" href="#1229">1229</a>    do_stuff(data);
<a class="hl" name="1230" href="#1230">1230</a>  }
<a class="l" name="1231" href="#1231">1231</a>}
<a class="l" name="1232" href="#1232">1232</a>
<a class="l" name="1233" href="#1233">1233</a>static void BM_test_ranged_fo(benchmark::State &amp; state) {
<a class="l" name="1234" href="#1234">1234</a>  auto resource = GetResource();
<a class="l" name="1235" href="#1235">1235</a>  if (!<a href="/googletest/s?path=resource.good&amp;project=benchmark">resource.good</a>()) {
<a class="l" name="1236" href="#1236">1236</a>    <a href="/googletest/s?path=state.SkipWithError&amp;project=benchmark">state.SkipWithError</a>("Resource is not good!");
<a class="l" name="1237" href="#1237">1237</a>    return; // Early return is allowed when SkipWithError() has been used.
<a class="l" name="1238" href="#1238">1238</a>  }
<a class="l" name="1239" href="#1239">1239</a>  for (auto _ : state) {
<a class="hl" name="1240" href="#1240">1240</a>    auto data = <a href="/googletest/s?path=resource.read_data&amp;project=benchmark">resource.read_data</a>();
<a class="l" name="1241" href="#1241">1241</a>    if (!<a href="/googletest/s?path=resource.good&amp;project=benchmark">resource.good</a>()) {
<a class="l" name="1242" href="#1242">1242</a>      <a href="/googletest/s?path=state.SkipWithError&amp;project=benchmark">state.SkipWithError</a>("Failed to read data!");
<a class="l" name="1243" href="#1243">1243</a>      break; // REQUIRED to prevent all further iterations.
<a class="l" name="1244" href="#1244">1244</a>    }
<a class="l" name="1245" href="#1245">1245</a>    do_stuff(data);
<a class="l" name="1246" href="#1246">1246</a>  }
<a class="l" name="1247" href="#1247">1247</a>}
<a class="l" name="1248" href="#1248">1248</a>```
<a class="l" name="1249" href="#1249">1249</a>&lt;a name="a-faster-keep-running-loop" /&gt;
<a class="hl" name="1250" href="#1250">1250</a>
<a class="l" name="1251" href="#1251">1251</a>### A Faster KeepRunning Loop
<a class="l" name="1252" href="#1252">1252</a>
<a class="l" name="1253" href="#1253">1253</a>In C++11 mode, a ranged-based for loop should be used in preference to
<a class="l" name="1254" href="#1254">1254</a>the `KeepRunning` loop for running the benchmarks. For example:
<a class="l" name="1255" href="#1255">1255</a>
<a class="l" name="1256" href="#1256">1256</a>```c++
<a class="l" name="1257" href="#1257">1257</a>static void BM_Fast(benchmark::State &amp;state) {
<a class="l" name="1258" href="#1258">1258</a>  for (auto _ : state) {
<a class="l" name="1259" href="#1259">1259</a>    FastOperation();
<a class="hl" name="1260" href="#1260">1260</a>  }
<a class="l" name="1261" href="#1261">1261</a>}
<a class="l" name="1262" href="#1262">1262</a>BENCHMARK(BM_Fast);
<a class="l" name="1263" href="#1263">1263</a>```
<a class="l" name="1264" href="#1264">1264</a>
<a class="l" name="1265" href="#1265">1265</a>The reason the ranged-for loop is faster than using `KeepRunning`, is
<a class="l" name="1266" href="#1266">1266</a>because `KeepRunning` requires a memory load and store of the iteration count
<a class="l" name="1267" href="#1267">1267</a>ever iteration, whereas the ranged-for variant is able to keep the iteration count
<a class="l" name="1268" href="#1268">1268</a>in a register.
<a class="l" name="1269" href="#1269">1269</a>
<a class="hl" name="1270" href="#1270">1270</a>For example, an empty inner loop of using the ranged-based for method looks like:
<a class="l" name="1271" href="#1271">1271</a>
<a class="l" name="1272" href="#1272">1272</a>```asm
<a class="l" name="1273" href="#1273">1273</a># Loop Init
<a class="l" name="1274" href="#1274">1274</a>  mov rbx, qword ptr [r14 + 104]
<a class="l" name="1275" href="#1275">1275</a>  call benchmark::State::StartKeepRunning()
<a class="l" name="1276" href="#1276">1276</a>  test rbx, rbx
<a class="l" name="1277" href="#1277">1277</a>  je .LoopEnd
<a class="l" name="1278" href="#1278">1278</a>.LoopHeader: # =&gt;This Inner Loop Header: Depth=1
<a class="l" name="1279" href="#1279">1279</a>  add rbx, -1
<a class="hl" name="1280" href="#1280">1280</a>  jne .LoopHeader
<a class="l" name="1281" href="#1281">1281</a>.LoopEnd:
<a class="l" name="1282" href="#1282">1282</a>```
<a class="l" name="1283" href="#1283">1283</a>
<a class="l" name="1284" href="#1284">1284</a>Compared to an empty `KeepRunning` loop, which looks like:
<a class="l" name="1285" href="#1285">1285</a>
<a class="l" name="1286" href="#1286">1286</a>```asm
<a class="l" name="1287" href="#1287">1287</a>.LoopHeader: # in Loop: Header=BB0_3 Depth=1
<a class="l" name="1288" href="#1288">1288</a>  cmp byte ptr [rbx], 1
<a class="l" name="1289" href="#1289">1289</a>  jne .LoopInit
<a class="hl" name="1290" href="#1290">1290</a>.LoopBody: # =&gt;This Inner Loop Header: Depth=1
<a class="l" name="1291" href="#1291">1291</a>  mov rax, qword ptr [rbx + 8]
<a class="l" name="1292" href="#1292">1292</a>  lea rcx, [rax + 1]
<a class="l" name="1293" href="#1293">1293</a>  mov qword ptr [rbx + 8], rcx
<a class="l" name="1294" href="#1294">1294</a>  cmp rax, qword ptr [rbx + 104]
<a class="l" name="1295" href="#1295">1295</a>  jb .LoopHeader
<a class="l" name="1296" href="#1296">1296</a>  jmp .LoopEnd
<a class="l" name="1297" href="#1297">1297</a>.LoopInit:
<a class="l" name="1298" href="#1298">1298</a>  mov rdi, rbx
<a class="l" name="1299" href="#1299">1299</a>  call benchmark::State::StartKeepRunning()
<a class="hl" name="1300" href="#1300">1300</a>  jmp .LoopBody
<a class="l" name="1301" href="#1301">1301</a>.LoopEnd:
<a class="l" name="1302" href="#1302">1302</a>```
<a class="l" name="1303" href="#1303">1303</a>
<a class="l" name="1304" href="#1304">1304</a>Unless C++03 compatibility is required, the ranged-for variant of writing
<a class="l" name="1305" href="#1305">1305</a>the benchmark loop should be preferred.
<a class="l" name="1306" href="#1306">1306</a>
<a class="l" name="1307" href="#1307">1307</a>&lt;a name="disabling-cpu-frequency-scaling" /&gt;
<a class="l" name="1308" href="#1308">1308</a>
<a class="l" name="1309" href="#1309">1309</a>### Disabling CPU Frequency Scaling
<a class="hl" name="1310" href="#1310">1310</a>
<a class="l" name="1311" href="#1311">1311</a>If you see this error:
<a class="l" name="1312" href="#1312">1312</a>
<a class="l" name="1313" href="#1313">1313</a>```
<a class="l" name="1314" href="#1314">1314</a>***WARNING*** CPU scaling is enabled, the benchmark real time measurements may be noisy and will incur extra overhead.
<a class="l" name="1315" href="#1315">1315</a>```
<a class="l" name="1316" href="#1316">1316</a>
<a class="l" name="1317" href="#1317">1317</a>you might want to disable the CPU frequency scaling while running the benchmark:
<a class="l" name="1318" href="#1318">1318</a>
<a class="l" name="1319" href="#1319">1319</a>```bash
<a class="hl" name="1320" href="#1320">1320</a>sudo cpupower frequency-set --governor performance
<a class="l" name="1321" href="#1321">1321</a>./mybench
<a class="l" name="1322" href="#1322">1322</a>sudo cpupower frequency-set --governor powersave
<a class="l" name="1323" href="#1323">1323</a>```
<a class="l" name="1324" href="#1324">1324</a>