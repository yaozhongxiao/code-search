<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>---
<a class="l" name="2" href="#2">2</a>name: Bug report
<a class="l" name="3" href="#3">3</a>about: Create a report to help us improve
<a class="l" name="4" href="#4">4</a>title: "[BUG]"
<a class="l" name="5" href="#5">5</a>labels: ''
<a class="l" name="6" href="#6">6</a>assignees: ''
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>---
<a class="l" name="9" href="#9">9</a>
<a class="hl" name="10" href="#10">10</a>**Describe the bug**
<a class="l" name="11" href="#11">11</a>A clear and concise description of what the bug is.
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a>**System**
<a class="l" name="14" href="#14">14</a>Which OS, compiler, and compiler version are you using:
<a class="l" name="15" href="#15">15</a>  - OS: 
<a class="l" name="16" href="#16">16</a>  - Compiler and version: 
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a>**To reproduce**
<a class="l" name="19" href="#19">19</a>Steps to reproduce the behavior:
<a class="hl" name="20" href="#20">20</a>1. sync to commit ...
<a class="l" name="21" href="#21">21</a>2. <a href="/googletest/s?path=cmake/bazel&amp;project=benchmark">cmake/bazel</a>...
<a class="l" name="22" href="#22">22</a>3. make ...
<a class="l" name="23" href="#23">23</a>4. See error
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a>**Expected behavior**
<a class="l" name="26" href="#26">26</a>A clear and concise description of what you expected to happen.
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a>**Screenshots**
<a class="l" name="29" href="#29">29</a>If applicable, add screenshots to help explain your problem.
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a>**Additional context**
<a class="l" name="32" href="#32">32</a>Add any other context about the problem here.
<a class="l" name="33" href="#33">33</a>