<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># GoogleTest
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>#### OSS Builds Status:
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>[![Build Status](<a href="https://api.travis-ci.org/google/googletest.svg?branch=master">https://api.travis-ci.org/google/googletest.svg?branch=master</a>)](<a href="https://travis-ci.org/google/googletest">https://travis-ci.org/google/googletest</a>)
<a class="l" name="6" href="#6">6</a>[![Build status](<a href="https://ci.appveyor.com/api/projects/status/4o38plt0xbo1ubc8/branch/master?svg=true">https://ci.appveyor.com/api/projects/status/4o38plt0xbo1ubc8/branch/master?svg=true</a>)](<a href="https://ci.appveyor.com/project/GoogleTestAppVeyor/googletest/branch/master">https://ci.appveyor.com/project/GoogleTestAppVeyor/googletest/branch/master</a>)
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>### Announcements:
<a class="l" name="9" href="#9">9</a>
<a class="hl" name="10" href="#10">10</a>#### Release <a href="/googletest/s?path=1.10.x&amp;project=googletest">1.10.x</a>
<a class="l" name="11" href="#11">11</a>
<a class="l" name="12" href="#12">12</a>[Release <a href="/googletest/s?path=1.10.x&amp;project=googletest">1.10.x</a>](<a href="https://github.com/google/googletest/releases/tag/release-1.10.0">https://github.com/google/googletest/releases/tag/release-1.10.0</a>)
<a class="l" name="13" href="#13">13</a>is now available.
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a>#### Coming Soon
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a>*   Post <a href="/googletest/s?path=1.10.x&amp;project=googletest">1.10.x</a> googletest will follow
<a class="l" name="18" href="#18">18</a>    [Abseil Live at Head philosophy](<a href="https://abseil.io/about/philosophy">https://abseil.io/about/philosophy</a>)
<a class="l" name="19" href="#19">19</a>*   We are also planning to take a dependency on
<a class="hl" name="20" href="#20">20</a>    [Abseil](<a href="https://github.com/abseil/abseil-cpp">https://github.com/abseil/abseil-cpp</a>).
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a>## Welcome to **GoogleTest**, Google's C++ test framework!
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a>This repository is a merger of the formerly separate GoogleTest and GoogleMock
<a class="l" name="25" href="#25">25</a>projects. These were so closely related that it makes sense to maintain and
<a class="l" name="26" href="#26">26</a>release them together.
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a>### Getting started:
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a>The information for **GoogleTest** is available in the
<a class="l" name="31" href="#31">31</a>[GoogleTest Primer](<a href="/googletest/s?path=googletest/docs/primer.md&amp;project=googletest">googletest/docs/primer.md</a>) documentation.
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>**GoogleMock** is an extension to GoogleTest for writing and using C++ mock
<a class="l" name="34" href="#34">34</a>classes. See the separate [GoogleMock documentation](<a href="/googletest/s?path=googlemock/README.md&amp;project=googletest">googlemock/README.md</a>).
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a>More detailed documentation for googletest is in its interior
<a class="l" name="37" href="#37">37</a>[<a href="/googletest/s?path=googletest/README.md&amp;project=googletest">googletest/README.md</a>](<a href="/googletest/s?path=googletest/README.md&amp;project=googletest">googletest/README.md</a>) file.
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>## Features
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>*   An [xUnit](<a href="https://en.wikipedia.org/wiki/XUnit">https://en.wikipedia.org/wiki/XUnit</a>) test framework.
<a class="l" name="42" href="#42">42</a>*   Test discovery.
<a class="l" name="43" href="#43">43</a>*   A rich set of assertions.
<a class="l" name="44" href="#44">44</a>*   User-defined assertions.
<a class="l" name="45" href="#45">45</a>*   Death tests.
<a class="l" name="46" href="#46">46</a>*   Fatal and non-fatal failures.
<a class="l" name="47" href="#47">47</a>*   Value-parameterized tests.
<a class="l" name="48" href="#48">48</a>*   Type-parameterized tests.
<a class="l" name="49" href="#49">49</a>*   Various options for running the tests.
<a class="hl" name="50" href="#50">50</a>*   XML test report generation.
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a>## Platforms
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>GoogleTest has been used on a variety of platforms:
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>*   Linux
<a class="l" name="57" href="#57">57</a>*   Mac OS X
<a class="l" name="58" href="#58">58</a>*   Windows
<a class="l" name="59" href="#59">59</a>*   Cygwin
<a class="hl" name="60" href="#60">60</a>*   MinGW
<a class="l" name="61" href="#61">61</a>*   Windows Mobile
<a class="l" name="62" href="#62">62</a>*   Symbian
<a class="l" name="63" href="#63">63</a>*   PlatformIO
<a class="l" name="64" href="#64">64</a>
<a class="l" name="65" href="#65">65</a>## Who Is Using GoogleTest?
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>In addition to many internal projects at Google, GoogleTest is also used by the
<a class="l" name="68" href="#68">68</a>following notable projects:
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>*   The [Chromium projects](<a href="http://www.chromium.org/">http://www.chromium.org/</a>) (behind the Chrome browser
<a class="l" name="71" href="#71">71</a>    and Chrome OS).
<a class="l" name="72" href="#72">72</a>*   The [LLVM](<a href="http://llvm.org/">http://llvm.org/</a>) compiler.
<a class="l" name="73" href="#73">73</a>*   [Protocol Buffers](<a href="https://github.com/google/protobuf">https://github.com/google/protobuf</a>), Google's data
<a class="l" name="74" href="#74">74</a>    interchange format.
<a class="l" name="75" href="#75">75</a>*   The [OpenCV](<a href="http://opencv.org/">http://opencv.org/</a>) computer vision library.
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>## Related Open Source Projects
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>[GTest Runner](<a href="https://github.com/nholthaus/gtest-runner">https://github.com/nholthaus/gtest-runner</a>) is a Qt5 based
<a class="hl" name="80" href="#80">80</a>automated test-runner and Graphical User Interface with powerful features for
<a class="l" name="81" href="#81">81</a>Windows and Linux platforms.
<a class="l" name="82" href="#82">82</a>
<a class="l" name="83" href="#83">83</a>[GoogleTest UI](<a href="https://github.com/ospector/gtest-gbar">https://github.com/ospector/gtest-gbar</a>) is a test runner that
<a class="l" name="84" href="#84">84</a>runs your test binary, allows you to track its progress via a progress bar, and
<a class="l" name="85" href="#85">85</a>displays a list of test failures. Clicking on one shows failure text. Google
<a class="l" name="86" href="#86">86</a>Test UI is written in C#.
<a class="l" name="87" href="#87">87</a>
<a class="l" name="88" href="#88">88</a>[GTest TAP Listener](<a href="https://github.com/kinow/gtest-tap-listener">https://github.com/kinow/gtest-tap-listener</a>) is an event
<a class="l" name="89" href="#89">89</a>listener for GoogleTest that implements the
<a class="hl" name="90" href="#90">90</a>[TAP protocol](<a href="https://en.wikipedia.org/wiki/Test_Anything_Protocol">https://en.wikipedia.org/wiki/Test_Anything_Protocol</a>) for test
<a class="l" name="91" href="#91">91</a>result output. If your test runner understands TAP, you may find it useful.
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>[gtest-parallel](<a href="https://github.com/google/gtest-parallel">https://github.com/google/gtest-parallel</a>) is a test runner that
<a class="l" name="94" href="#94">94</a>runs tests from your binary in parallel to provide significant speed-up.
<a class="l" name="95" href="#95">95</a>
<a class="l" name="96" href="#96">96</a>[GoogleTest Adapter](<a href="https://marketplace.visualstudio.com/items?itemName=DavidSchuldenfrei.gtest-adapter">https://marketplace.visualstudio.com/items?itemName=DavidSchuldenfrei.gtest-adapter</a>)
<a class="l" name="97" href="#97">97</a>is a VS Code extension allowing to view GoogleTest in a tree view, and <a href="/googletest/s?path=run/debug&amp;project=googletest">run/debug</a>
<a class="l" name="98" href="#98">98</a>your tests.
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>[C++ TestMate](<a href="https://github.com/matepek/vscode-catch2-test-adapter">https://github.com/matepek/vscode-catch2-test-adapter</a>) is a VS
<a class="l" name="101" href="#101">101</a>Code extension allowing to view GoogleTest in a tree view, and <a href="/googletest/s?path=run/debug&amp;project=googletest">run/debug</a> your
<a class="l" name="102" href="#102">102</a>tests.
<a class="l" name="103" href="#103">103</a>
<a class="l" name="104" href="#104">104</a>[Cornichon](<a href="https://pypi.org/project/cornichon/">https://pypi.org/project/cornichon/</a>) is a small Gherkin DSL parser
<a class="l" name="105" href="#105">105</a>that generates stub code for GoogleTest.
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>## Requirements
<a class="l" name="108" href="#108">108</a>
<a class="l" name="109" href="#109">109</a>GoogleTest is designed to have fairly minimal requirements to build and use with
<a class="hl" name="110" href="#110">110</a>your projects, but there are some. If you notice any problems on your platform,
<a class="l" name="111" href="#111">111</a>please file an issue on the
<a class="l" name="112" href="#112">112</a>[GoogleTest GitHub Issue Tracker](<a href="https://github.com/google/googletest/issues">https://github.com/google/googletest/issues</a>).
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>Patches for fixing them are welcome!
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>### Build Requirements
<a class="l" name="117" href="#117">117</a>
<a class="l" name="118" href="#118">118</a>These are the base requirements to build and use GoogleTest from a source
<a class="l" name="119" href="#119">119</a>package:
<a class="hl" name="120" href="#120">120</a>
<a class="l" name="121" href="#121">121</a>*   [Bazel](<a href="https://bazel.build/">https://bazel.build/</a>) or [CMake](<a href="https://cmake.org/">https://cmake.org/</a>). NOTE: Bazel is
<a class="l" name="122" href="#122">122</a>    the build system that GoogleTest is using internally and tests against.
<a class="l" name="123" href="#123">123</a>    CMake is community-supported.
<a class="l" name="124" href="#124">124</a>
<a class="l" name="125" href="#125">125</a>*   A C++11-standard-compliant compiler
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>## Contributing change
<a class="l" name="128" href="#128">128</a>
<a class="l" name="129" href="#129">129</a>Please read the [`<a href="/googletest/s?path=CONTRIBUTING.md&amp;project=googletest">CONTRIBUTING.md</a>`](<a href="/googletest/s?path=CONTRIBUTING.md&amp;project=googletest">CONTRIBUTING.md</a>) for details on how to
<a class="hl" name="130" href="#130">130</a>contribute to this project.
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>Happy testing!
<a class="l" name="133" href="#133">133</a>