<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># How to become a contributor and submit your own code
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>## Contributor License Agreements
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>We'd love to accept your patches! Before we can take them, we have to jump a
<a class="l" name="6" href="#6">6</a>couple of legal hurdles.
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>Please fill out either the individual or corporate Contributor License Agreement
<a class="l" name="9" href="#9">9</a>(CLA).
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a>*   If you are an individual writing original source code and you're sure you
<a class="l" name="12" href="#12">12</a>    own the intellectual property, then you'll need to sign an
<a class="l" name="13" href="#13">13</a>    [individual CLA](<a href="https://developers.google.com/open-source/cla/individual">https://developers.google.com/open-source/cla/individual</a>).
<a class="l" name="14" href="#14">14</a>*   If you work for a company that wants to allow you to contribute your work,
<a class="l" name="15" href="#15">15</a>    then you'll need to sign a
<a class="l" name="16" href="#16">16</a>    [corporate CLA](<a href="https://developers.google.com/open-source/cla/corporate">https://developers.google.com/open-source/cla/corporate</a>).
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a>Follow either of the two links above to access the appropriate CLA and
<a class="l" name="19" href="#19">19</a>instructions for how to sign and return it. Once we receive it, we'll be able to
<a class="hl" name="20" href="#20">20</a>accept your pull requests.
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a>## Are you a Googler?
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a>If you are a Googler, please make an attempt to submit an internal change rather
<a class="l" name="25" href="#25">25</a>than a GitHub Pull Request. If you are not able to submit an internal change a
<a class="l" name="26" href="#26">26</a>PR is acceptable as an alternative.
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a>## Contributing A Patch
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a>1.  Submit an issue describing your proposed change to the
<a class="l" name="31" href="#31">31</a>    [issue tracker](<a href="https://github.com/google/googletest/issues">https://github.com/google/googletest/issues</a>).
<a class="l" name="32" href="#32">32</a>2.  Please don't mix more than one logical change per submittal, because it
<a class="l" name="33" href="#33">33</a>    makes the history hard to follow. If you want to make a change that doesn't
<a class="l" name="34" href="#34">34</a>    have a corresponding issue in the issue tracker, please create one.
<a class="l" name="35" href="#35">35</a>3.  Also, coordinate with team members that are listed on the issue in question.
<a class="l" name="36" href="#36">36</a>    This ensures that work isn't being duplicated and communicating your plan
<a class="l" name="37" href="#37">37</a>    early also generally leads to better patches.
<a class="l" name="38" href="#38">38</a>4.  If your proposed change is accepted, and you haven't already done so, sign a
<a class="l" name="39" href="#39">39</a>    Contributor License Agreement (see details above).
<a class="hl" name="40" href="#40">40</a>5.  Fork the desired repo, develop and test your code changes.
<a class="l" name="41" href="#41">41</a>6.  Ensure that your code adheres to the existing style in the sample to which
<a class="l" name="42" href="#42">42</a>    you are contributing.
<a class="l" name="43" href="#43">43</a>7.  Ensure that your code has an appropriate set of unit tests which all pass.
<a class="l" name="44" href="#44">44</a>8.  Submit a pull request.
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>## The Google Test and Google Mock Communities
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>The Google Test community exists primarily through the
<a class="l" name="49" href="#49">49</a>[discussion group](<a href="http://groups.google.com/group/googletestframework">http://groups.google.com/group/googletestframework</a>) and the
<a class="hl" name="50" href="#50">50</a>GitHub repository. Likewise, the Google Mock community exists primarily through
<a class="l" name="51" href="#51">51</a>their own [discussion group](<a href="http://groups.google.com/group/googlemock">http://groups.google.com/group/googlemock</a>). You are
<a class="l" name="52" href="#52">52</a>definitely encouraged to contribute to the discussion and you can also help us
<a class="l" name="53" href="#53">53</a>to keep the effectiveness of the group high by following and promoting the
<a class="l" name="54" href="#54">54</a>guidelines listed here.
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>### Please Be Friendly
<a class="l" name="57" href="#57">57</a>
<a class="l" name="58" href="#58">58</a>Showing courtesy and respect to others is a vital part of the Google culture,
<a class="l" name="59" href="#59">59</a>and we strongly encourage everyone participating in Google Test development to
<a class="hl" name="60" href="#60">60</a>join us in accepting nothing less. Of course, being courteous is not the same as
<a class="l" name="61" href="#61">61</a>failing to constructively disagree with each other, but it does mean that we
<a class="l" name="62" href="#62">62</a>should be respectful of each other when enumerating the 42 technical reasons
<a class="l" name="63" href="#63">63</a>that a particular proposal may not be the best choice. There's never a reason to
<a class="l" name="64" href="#64">64</a>be antagonistic or dismissive toward anyone who is sincerely trying to
<a class="l" name="65" href="#65">65</a>contribute to a discussion.
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>Sure, C++ testing is serious business and all that, but it's also a lot of fun.
<a class="l" name="68" href="#68">68</a>Let's keep it that way. Let's strive to be one of the friendliest communities in
<a class="l" name="69" href="#69">69</a>all of open source.
<a class="hl" name="70" href="#70">70</a>
<a class="l" name="71" href="#71">71</a>As always, discuss Google Test in the official GoogleTest discussion group. You
<a class="l" name="72" href="#72">72</a>don't have to actually submit code in order to sign up. Your participation
<a class="l" name="73" href="#73">73</a>itself is a valuable contribution.
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>## Style
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>To keep the source consistent, readable, diffable and easy to merge, we use a
<a class="l" name="78" href="#78">78</a>fairly rigid coding style, as defined by the
<a class="l" name="79" href="#79">79</a>[google-styleguide](<a href="https://github.com/google/styleguide">https://github.com/google/styleguide</a>) project. All patches
<a class="hl" name="80" href="#80">80</a>will be expected to conform to the style outlined
<a class="l" name="81" href="#81">81</a>[here](<a href="https://google.github.io/styleguide/cppguide.html">https://google.github.io/styleguide/cppguide.html</a>). Use
<a class="l" name="82" href="#82">82</a>[.clang-format](<a href="https://github.com/google/googletest/blob/master/.clang-format">https://github.com/google/googletest/blob/master/.clang-format</a>)
<a class="l" name="83" href="#83">83</a>to check your formatting.
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>## Requirements for Contributors
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>If you plan to contribute a patch, you need to build Google Test, Google Mock,
<a class="l" name="88" href="#88">88</a>and their own tests from a git checkout, which has further requirements:
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>*   [Python](<a href="https://www.python.org/">https://www.python.org/</a>) v2.3 or newer (for running some of the
<a class="l" name="91" href="#91">91</a>    tests and re-generating certain source files from templates)
<a class="l" name="92" href="#92">92</a>*   [CMake](<a href="https://cmake.org/">https://cmake.org/</a>) v2.6.4 or newer
<a class="l" name="93" href="#93">93</a>
<a class="l" name="94" href="#94">94</a>## Developing Google Test and Google Mock
<a class="l" name="95" href="#95">95</a>
<a class="l" name="96" href="#96">96</a>This section discusses how to make your own changes to the Google Test project.
<a class="l" name="97" href="#97">97</a>
<a class="l" name="98" href="#98">98</a>### Testing Google Test and Google Mock Themselves
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>To make sure your changes work as intended and don't break existing
<a class="l" name="101" href="#101">101</a>functionality, you'll want to compile and run Google Test and GoogleMock's own
<a class="l" name="102" href="#102">102</a>tests. For that you can use CMake:
<a class="l" name="103" href="#103">103</a>
<a class="l" name="104" href="#104">104</a>    mkdir mybuild
<a class="l" name="105" href="#105">105</a>    cd mybuild
<a class="l" name="106" href="#106">106</a>    cmake -Dgtest_build_tests=ON -Dgmock_build_tests=ON ${GTEST_REPO_DIR}
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>To choose between building only Google Test or Google Mock, you may modify your
<a class="l" name="109" href="#109">109</a>cmake command to be one of each
<a class="hl" name="110" href="#110">110</a>
<a class="l" name="111" href="#111">111</a>    cmake -Dgtest_build_tests=ON ${GTEST_DIR} # sets up Google Test tests
<a class="l" name="112" href="#112">112</a>    cmake -Dgmock_build_tests=ON ${GMOCK_DIR} # sets up Google Mock tests
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>Make sure you have Python installed, as some of Google Test's tests are written
<a class="l" name="115" href="#115">115</a>in Python. If the cmake command complains about not being able to find Python
<a class="l" name="116" href="#116">116</a>(`Could NOT find PythonInterp (missing: PYTHON_EXECUTABLE)`), try telling it
<a class="l" name="117" href="#117">117</a>explicitly where your Python executable can be found:
<a class="l" name="118" href="#118">118</a>
<a class="l" name="119" href="#119">119</a>    cmake -DPYTHON_EXECUTABLE=<a href="/googletest/s?path=path/to/python&amp;project=googletest">path/to/python</a> ...
<a class="hl" name="120" href="#120">120</a>
<a class="l" name="121" href="#121">121</a>Next, you can build Google Test and / or Google Mock and all desired tests. On
<a class="l" name="122" href="#122">122</a>\*nix, this is usually done by
<a class="l" name="123" href="#123">123</a>
<a class="l" name="124" href="#124">124</a>    make
<a class="l" name="125" href="#125">125</a>
<a class="l" name="126" href="#126">126</a>To run the tests, do
<a class="l" name="127" href="#127">127</a>
<a class="l" name="128" href="#128">128</a>    make test
<a class="l" name="129" href="#129">129</a>
<a class="hl" name="130" href="#130">130</a>All tests should pass.
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>### Regenerating Source Files
<a class="l" name="133" href="#133">133</a>
<a class="l" name="134" href="#134">134</a>Some of Google Test's source files are generated from templates (not in the C++
<a class="l" name="135" href="#135">135</a>sense) using a script. For example, the file
<a class="l" name="136" href="#136">136</a>*<a href="/googletest/s?path=googlemock/include/gmock/gmock-generated-actions.h.pump&amp;project=googletest">googlemock/include/gmock/gmock-generated-actions.h.pump</a>* is used to generate
<a class="l" name="137" href="#137">137</a>*<a href="/googletest/s?path=gmock-generated-actions.h&amp;project=googletest">gmock-generated-actions.h</a>* in the same directory.
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>You don't need to worry about regenerating the source files unless you need to
<a class="hl" name="140" href="#140">140</a>modify them. You would then modify the corresponding `.pump` files and run the
<a class="l" name="141" href="#141">141</a>'[<a href="/googletest/s?path=pump.py&amp;project=googletest">pump.py</a>](<a href="/googletest/s?path=googlemock/scripts/pump.py&amp;project=googletest">googlemock/scripts/pump.py</a>)' generator script. See the
<a class="l" name="142" href="#142">142</a>[Pump Manual](<a href="/googletest/s?path=googlemock/docs/pump_manual.md&amp;project=googletest">googlemock/docs/pump_manual.md</a>).
<a class="l" name="143" href="#143">143</a>