<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">// Copyright 2009, Google Inc.</span>
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span><span class="c">// All rights reserved.</span>
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span><span class="c">// Redistribution and use in source and binary forms, with or without</span>
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span><span class="c">// modification, are permitted provided that the following conditions are</span>
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span><span class="c">// met:</span>
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span><span class="c">//     * Redistributions of source code must retain the above copyright</span>
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span><span class="c">// notice, this list of conditions and the following disclaimer.</span>
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span><span class="c">//     * Redistributions in binary form must reproduce the above</span>
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span><span class="c">// copyright notice, this list of conditions and the following disclaimer</span>
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span><span class="c">// in the documentation <a href="/googletest/s?path=and/">and</a>/<a href="/googletest/s?path=and/or">or</a> other materials provided with the</span>
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span><span class="c">// distribution.</span>
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span><span class="c">//     * Neither the name of Google Inc. nor the names of its</span>
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span><span class="c">// contributors may be used to endorse or promote products derived from</span>
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span><span class="c">// this software without specific prior written permission.</span>
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span><span class="c">// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span><span class="c">// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR</span>
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span><span class="c">// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT</span>
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span><span class="c">// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span><span class="c">// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span><span class="c">// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span><span class="c">// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><span class="c">// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT</span>
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span><span class="c">// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><span class="c">// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</span>
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span><span class="c">// Tests for Google C++ Mocking Framework (Google Mock)</span>
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span><span class="c">// Some users use a build system that Google Mock doesn't support directly,</span>
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span><span class="c">// yet they still want to build and run Google Mock's own tests.  This file</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span><span class="c">// includes most such tests, making it easier for these users to maintain</span>
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span><span class="c">// their build scripts (they just need to build this file, even though the</span>
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span><span class="c">// below list of actual *_<a href="/googletest/s?path=test.cc&amp;project=googletest">test.cc</a> files might change).</span>
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=test/">test</a>/<a href="/googletest/s?path=test/gmock-actions_test.cc">gmock-actions_test.cc</a>"</span>
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=test/">test</a>/<a href="/googletest/s?path=test/gmock-cardinalities_test.cc">gmock-cardinalities_test.cc</a>"</span>
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=test/">test</a>/<a href="/googletest/s?path=test/gmock-generated-actions_test.cc">gmock-generated-actions_test.cc</a>"</span>
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=test/">test</a>/<a href="/googletest/s?path=test/gmock-internal-utils_test.cc">gmock-internal-utils_test.cc</a>"</span>
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=test/">test</a>/<a href="/googletest/s?path=test/gmock-matchers_test.cc">gmock-matchers_test.cc</a>"</span>
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=test/">test</a>/<a href="/googletest/s?path=test/gmock-more-actions_test.cc">gmock-more-actions_test.cc</a>"</span>
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=test/">test</a>/<a href="/googletest/s?path=test/gmock-nice-strict_test.cc">gmock-nice-strict_test.cc</a>"</span>
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=test/">test</a>/<a href="/googletest/s?path=test/gmock-port_test.cc">gmock-port_test.cc</a>"</span>
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=test/">test</a>/<a href="/googletest/s?path=test/gmock-spec-builders_test.cc">gmock-spec-builders_test.cc</a>"</span>
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=test/">test</a>/<a href="/googletest/s?path=test/gmock_test.cc">gmock_test.cc</a>"</span>
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>