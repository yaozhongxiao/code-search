<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["GTEST_TESTS_UTIL_DIR",41],["GTEST_TESTS_UTIL_DIR",43],["PREMATURE_EXIT_FILE_ENV_VAR",100],["SCRIPT_DIR",36],["SetEnvVar",99],["Subprocess",96],["TestCase",97],["environ",98],["gtest_tests_util_dir",39]]],["Namespace","xn",[["gtest_test_utils",47],["os",32],["sys",33]]],["Function","xf",[["GetExitStatus",72],["GetSourceDir",50],["GetTestExecutablePath",56],["Main",105]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c"># Copyright 2006, Google Inc.</span>
<a class="l" name="2" href="#2">2</a><span class="c"># All rights reserved.</span>
<a class="l" name="3" href="#3">3</a><span class="c">#</span>
<a class="l" name="4" href="#4">4</a><span class="c"># Redistribution and use in source and binary forms, with or without</span>
<a class="l" name="5" href="#5">5</a><span class="c"># modification, are permitted provided that the following conditions are</span>
<a class="l" name="6" href="#6">6</a><span class="c"># met:</span>
<a class="l" name="7" href="#7">7</a><span class="c">#</span>
<a class="l" name="8" href="#8">8</a><span class="c">#     * Redistributions of source code must retain the above copyright</span>
<a class="l" name="9" href="#9">9</a><span class="c"># notice, this list of conditions and the following disclaimer.</span>
<a class="hl" name="10" href="#10">10</a><span class="c">#     * Redistributions in binary form must reproduce the above</span>
<a class="l" name="11" href="#11">11</a><span class="c"># copyright notice, this list of conditions and the following disclaimer</span>
<a class="l" name="12" href="#12">12</a><span class="c"># in the documentation <a href="/googletest/s?path=and/">and</a>/<a href="/googletest/s?path=and/or">or</a> other materials provided with the</span>
<a class="l" name="13" href="#13">13</a><span class="c"># distribution.</span>
<a class="l" name="14" href="#14">14</a><span class="c">#     * Neither the name of Google Inc. nor the names of its</span>
<a class="l" name="15" href="#15">15</a><span class="c"># contributors may be used to endorse or promote products derived from</span>
<a class="l" name="16" href="#16">16</a><span class="c"># this software without specific prior written permission.</span>
<a class="l" name="17" href="#17">17</a><span class="c">#</span>
<a class="l" name="18" href="#18">18</a><span class="c"># THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS</span>
<a class="l" name="19" href="#19">19</a><span class="c"># "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT</span>
<a class="hl" name="20" href="#20">20</a><span class="c"># LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR</span>
<a class="l" name="21" href="#21">21</a><span class="c"># A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT</span>
<a class="l" name="22" href="#22">22</a><span class="c"># OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,</span>
<a class="l" name="23" href="#23">23</a><span class="c"># SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT</span>
<a class="l" name="24" href="#24">24</a><span class="c"># LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,</span>
<a class="l" name="25" href="#25">25</a><span class="c"># DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY</span>
<a class="l" name="26" href="#26">26</a><span class="c"># THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT</span>
<a class="l" name="27" href="#27">27</a><span class="c"># (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE</span>
<a class="l" name="28" href="#28">28</a><span class="c"># OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</span>
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a><span class="s">"""Unit test utilities for Google C++ Mocking Framework."""</span>
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a><b>import</b> <a class="xn" name="os"/><a href="/googletest/s?refs=os&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">os</a>
<a class="l" name="33" href="#33">33</a><b>import</b> <a class="xn" name="sys"/><a href="/googletest/s?refs=sys&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">sys</a>
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a><span class="c"># Determines path to gtest_test_utils and imports it.</span>
<a class="l" name="36" href="#36">36</a><a class="xv" name="SCRIPT_DIR"/><a href="/googletest/s?refs=SCRIPT_DIR&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">SCRIPT_DIR</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=dirname&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">dirname</a>(<a href="/googletest/s?defs=__file__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__file__</a>) <b>or</b> <span class="s">'.'</span>
<a class="l" name="37" href="#37">37</a>
<a class="l" name="38" href="#38">38</a><span class="c"># isdir resolves symbolic links.</span>
<a class="l" name="39" href="#39">39</a><a class="xv" name="gtest_tests_util_dir"/><a href="/googletest/s?refs=gtest_tests_util_dir&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">gtest_tests_util_dir</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a class="d intelliWindow-symbol" href="#SCRIPT_DIR" data-definition-place="defined-in-file">SCRIPT_DIR</a>, <span class="s">'../../<a href="/googletest/s?path=/googletest/">googletest</a>/<a href="/googletest/s?path=/googletest/test">test</a>'</span>)
<a class="hl" name="40" href="#40">40</a><b>if</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=isdir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">isdir</a>(<a class="d intelliWindow-symbol" href="#gtest_tests_util_dir" data-definition-place="defined-in-file">gtest_tests_util_dir</a>):
<a class="l" name="41" href="#41">41</a>  <a class="xv" name="GTEST_TESTS_UTIL_DIR"/><a href="/googletest/s?refs=GTEST_TESTS_UTIL_DIR&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_TESTS_UTIL_DIR</a> = <a class="d intelliWindow-symbol" href="#gtest_tests_util_dir" data-definition-place="defined-in-file">gtest_tests_util_dir</a>
<a class="l" name="42" href="#42">42</a><b>else</b>:
<a class="l" name="43" href="#43">43</a>  <a class="xv" name="GTEST_TESTS_UTIL_DIR"/><a href="/googletest/s?refs=GTEST_TESTS_UTIL_DIR&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_TESTS_UTIL_DIR</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a class="d intelliWindow-symbol" href="#SCRIPT_DIR" data-definition-place="defined-in-file">SCRIPT_DIR</a>, <span class="s">'../../<a href="/googletest/s?path=/googletest/">googletest</a>/<a href="/googletest/s?path=/googletest/test">test</a>'</span>)
<a class="l" name="44" href="#44">44</a><a class="d intelliWindow-symbol" href="#sys" data-definition-place="defined-in-file">sys</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=append&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">append</a>(<a href="/googletest/s?defs=GTEST_TESTS_UTIL_DIR&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GTEST_TESTS_UTIL_DIR</a>)
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a><span class="c"># pylint: disable=C6204</span>
<a class="l" name="47" href="#47">47</a><b>import</b> <a class="xn" name="gtest_test_utils"/><a href="/googletest/s?refs=gtest_test_utils&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">gtest_test_utils</a>
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>
<a class="hl" name="50" href="#50">50</a><b>def</b> <a class="xf" name="GetSourceDir"/><a href="/googletest/s?refs=GetSourceDir&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">GetSourceDir</a>():
<a class="l" name="51" href="#51">51</a>  <span class="s">"""Returns the absolute path of the directory where the .py files are."""</span>
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>  <b>return</b> <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a class="d intelliWindow-symbol" href="#GetSourceDir" data-definition-place="defined-in-file">GetSourceDir</a>()
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a><b>def</b> <a class="xf" name="GetTestExecutablePath"/><a href="/googletest/s?refs=GetTestExecutablePath&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">GetTestExecutablePath</a>(<a href="/googletest/s?defs=executable_name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">executable_name</a>):
<a class="l" name="57" href="#57">57</a>  <span class="s">"""Returns the absolute path of the test binary given its name.
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>  The function will print a message and abort the program if the resulting file
<a class="hl" name="60" href="#60">60</a>  doesn't exist.
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>  Args:
<a class="l" name="63" href="#63">63</a>    executable_name: name of the test binary that the test script runs.
<a class="l" name="64" href="#64">64</a>
<a class="l" name="65" href="#65">65</a>  Returns:
<a class="l" name="66" href="#66">66</a>    The absolute path of the test binary.
<a class="l" name="67" href="#67">67</a>  """</span>
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>  <b>return</b> <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a class="d intelliWindow-symbol" href="#GetTestExecutablePath" data-definition-place="defined-in-file">GetTestExecutablePath</a>(<a href="/googletest/s?defs=executable_name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">executable_name</a>)
<a class="hl" name="70" href="#70">70</a>
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a><b>def</b> <a class="xf" name="GetExitStatus"/><a href="/googletest/s?refs=GetExitStatus&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">GetExitStatus</a>(<a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>):
<a class="l" name="73" href="#73">73</a>  <span class="s">"""Returns the argument to exit(), or -1 if exit() wasn't called.
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>  Args:
<a class="l" name="76" href="#76">76</a>    exit_code: the result value of os.system(command).
<a class="l" name="77" href="#77">77</a>  """</span>
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>  <b>if</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">name</a> == <span class="s">'nt'</span>:
<a class="hl" name="80" href="#80">80</a>    <span class="c"># On Windows, os.WEXITSTATUS() doesn't work and os.system() returns</span>
<a class="l" name="81" href="#81">81</a>    <span class="c"># the argument to exit() directly.</span>
<a class="l" name="82" href="#82">82</a>    <b>return</b> <a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>
<a class="l" name="83" href="#83">83</a>  <b>else</b>:
<a class="l" name="84" href="#84">84</a>    <span class="c"># On Unix, os.WEXITSTATUS() must be used to extract the exit status</span>
<a class="l" name="85" href="#85">85</a>    <span class="c"># from the result of os.system().</span>
<a class="l" name="86" href="#86">86</a>    <b>if</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=WIFEXITED&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">WIFEXITED</a>(<a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>):
<a class="l" name="87" href="#87">87</a>      <b>return</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=WEXITSTATUS&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">WEXITSTATUS</a>(<a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>)
<a class="l" name="88" href="#88">88</a>    <b>else</b>:
<a class="l" name="89" href="#89">89</a>      <b>return</b> -<span class="n">1</span>
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>
<a class="l" name="92" href="#92">92</a><span class="c"># Suppresses the "Invalid const name" lint complaint</span>
<a class="l" name="93" href="#93">93</a><span class="c"># pylint: disable-msg=C6409</span>
<a class="l" name="94" href="#94">94</a>
<a class="l" name="95" href="#95">95</a><span class="c"># Exposes utilities from gtest_test_utils.</span>
<a class="l" name="96" href="#96">96</a><a class="xv" name="Subprocess"/><a href="/googletest/s?refs=Subprocess&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">Subprocess</a> = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a class="xv" name="Subprocess"/><a href="/googletest/s?refs=Subprocess&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">Subprocess</a>
<a class="l" name="97" href="#97">97</a><a class="xv" name="TestCase"/><a href="/googletest/s?refs=TestCase&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">TestCase</a> = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a class="xv" name="TestCase"/><a href="/googletest/s?refs=TestCase&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">TestCase</a>
<a class="l" name="98" href="#98">98</a><a class="xv" name="environ"/><a href="/googletest/s?refs=environ&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">environ</a> = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a class="xv" name="environ"/><a href="/googletest/s?refs=environ&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">environ</a>
<a class="l" name="99" href="#99">99</a><a class="xv" name="SetEnvVar"/><a href="/googletest/s?refs=SetEnvVar&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">SetEnvVar</a> = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a class="xv" name="SetEnvVar"/><a href="/googletest/s?refs=SetEnvVar&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">SetEnvVar</a>
<a class="hl" name="100" href="#100">100</a><a class="xv" name="PREMATURE_EXIT_FILE_ENV_VAR"/><a href="/googletest/s?refs=PREMATURE_EXIT_FILE_ENV_VAR&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">PREMATURE_EXIT_FILE_ENV_VAR</a> = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a class="xv" name="PREMATURE_EXIT_FILE_ENV_VAR"/><a href="/googletest/s?refs=PREMATURE_EXIT_FILE_ENV_VAR&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">PREMATURE_EXIT_FILE_ENV_VAR</a>
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a><span class="c"># pylint: enable-msg=C6409</span>
<a class="l" name="103" href="#103">103</a>
<a class="l" name="104" href="#104">104</a>
<a class="l" name="105" href="#105">105</a><b>def</b> <a class="xf" name="Main"/><a href="/googletest/s?refs=Main&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">Main</a>():
<a class="l" name="106" href="#106">106</a>  <span class="s">"""Runs the unit test."""</span>
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>  <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a class="d intelliWindow-symbol" href="#Main" data-definition-place="defined-in-file">Main</a>()
<a class="l" name="109" href="#109">109</a>