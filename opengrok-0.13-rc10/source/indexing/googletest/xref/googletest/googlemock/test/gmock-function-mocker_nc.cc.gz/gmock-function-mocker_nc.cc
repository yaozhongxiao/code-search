<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Struct","xs",[["Base",8]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=gmock/">gmock</a>/<a href="/googletest/s?path=gmock/gmock.h">gmock.h</a>"</span>
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span>#<b>include</b> &lt;<a href="/googletest/s?path=memory">memory</a>&gt;
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span>#<b>include</b> &lt;<a href="/googletest/s?path=string">string</a>&gt;
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span>#<b>if</b> <b>defined</b>(<a href="/googletest/s?defs=TEST_MOCK_METHOD_INVALID_CONST_SPEC&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TEST_MOCK_METHOD_INVALID_CONST_SPEC</a>)
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span><b>struct</b> <a class="xs" name="Base"/><a href="/googletest/s?refs=Base&amp;project=googletest" class="xs intelliWindow-symbol" data-definition-place="def">Base</a> &#123;
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=MOCK_METHOD&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MOCK_METHOD</a>(<b>int</b>, F, (), (<a href="/googletest/s?defs=onst&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">onst</a>))&#59;
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span>&#125;&#59;
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span>#<b>else</b>
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span><span class="c">// Sanity check - this should compile.</span>
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span>#<b>endif</b>
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span>