<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["TEST_SPECS",31]]],["Class","xc",[["GMockMethodNCTest",20]]],["Namespace","xn",[["fake_target_util",14],["googletest",15],["os",3],["sys",4]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="s">"""Negative compilation tests for Google Mock macro MOCK_METHOD."""</span>
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><b>import</b> <a class="xn" name="os"/><a href="/googletest/s?refs=os&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">os</a>
<a class="l" name="4" href="#4">4</a><b>import</b> <a class="xn" name="sys"/><a href="/googletest/s?refs=sys&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">sys</a>
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a><a href="/googletest/s?defs=IS_LINUX&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IS_LINUX</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">name</a> == <span class="s">"posix"</span> <b>and</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=uname&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">uname</a>()[<span class="n">0</span>] == <span class="s">"Linux"</span>
<a class="l" name="7" href="#7">7</a><b>if</b> <b>not</b> <a href="/googletest/s?defs=IS_LINUX&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IS_LINUX</a>:
<a class="l" name="8" href="#8">8</a>  <a class="d intelliWindow-symbol" href="#sys" data-definition-place="defined-in-file">sys</a>.<a href="/googletest/s?defs=stderr&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">stderr</a>.<a href="/googletest/s?defs=write&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">write</a>(
<a class="l" name="9" href="#9">9</a>      <span class="s">"WARNING: Negative compilation tests are not supported on this platform"</span>)
<a class="hl" name="10" href="#10">10</a>  <a class="d intelliWindow-symbol" href="#sys" data-definition-place="defined-in-file">sys</a>.<a href="/googletest/s?defs=exit&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit</a>(<span class="n">0</span>)
<a class="l" name="11" href="#11">11</a>
<a class="l" name="12" href="#12">12</a><span class="c"># Suppresses the 'Import not at the top of the file' lint complaint.</span>
<a class="l" name="13" href="#13">13</a><span class="c"># pylint: disable-msg=C6204</span>
<a class="l" name="14" href="#14">14</a><b>from</b> <a href="/googletest/s?defs=google3&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">google3</a>.<a href="/googletest/s?defs=testing&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">testing</a>.<a href="/googletest/s?defs=pybase&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">pybase</a> <b>import</b> <a class="xn" name="fake_target_util"/><a href="/googletest/s?refs=fake_target_util&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">fake_target_util</a>
<a class="l" name="15" href="#15">15</a><b>from</b> <a href="/googletest/s?defs=google3&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">google3</a>.<a href="/googletest/s?defs=testing&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">testing</a>.<a href="/googletest/s?defs=pybase&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">pybase</a> <b>import</b> <a class="xn" name="googletest"/><a href="/googletest/s?refs=googletest&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">googletest</a>
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a><span class="c"># pylint: enable-msg=C6204</span>
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a><b>class</b> <a class="xc" name="GMockMethodNCTest"/><a href="/googletest/s?refs=GMockMethodNCTest&amp;project=googletest" class="xc intelliWindow-symbol" data-definition-place="def">GMockMethodNCTest</a>(<a class="d intelliWindow-symbol" href="#googletest" data-definition-place="defined-in-file">googletest</a>.<a href="/googletest/s?defs=TestCase&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TestCase</a>):
<a class="l" name="21" href="#21">21</a>  <span class="s">"""Negative compilation tests for MOCK_METHOD."""</span>
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a>  <span class="c"># The class body is intentionally empty.  The actual test*() methods</span>
<a class="l" name="24" href="#24">24</a>  <span class="c"># will be defined at run time by a call to</span>
<a class="l" name="25" href="#25">25</a>  <span class="c"># DefineNegativeCompilationTests() later.</span>
<a class="l" name="26" href="#26">26</a>  <b>pass</b>
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a><span class="c"># Defines a list of test specs, where each element is a tuple</span>
<a class="hl" name="30" href="#30">30</a><span class="c"># (test name, list of regexes for matching the compiler errors).</span>
<a class="l" name="31" href="#31">31</a><a class="xv" name="TEST_SPECS"/><a href="/googletest/s?refs=TEST_SPECS&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">TEST_SPECS</a> = [
<a class="l" name="32" href="#32">32</a>    (<span class="s">"MOCK_METHOD_INVALID_CONST_SPEC"</span>,
<a class="l" name="33" href="#33">33</a>     [r<span class="s">"onst cannot be recognized as a valid specification modifier"</span>]),
<a class="l" name="34" href="#34">34</a>]
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a><span class="c"># Define a test method in GMockNCTest for each element in TEST_SPECS.</span>
<a class="l" name="37" href="#37">37</a><a class="d intelliWindow-symbol" href="#fake_target_util" data-definition-place="defined-in-file">fake_target_util</a>.<a href="/googletest/s?defs=DefineNegativeCompilationTests&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">DefineNegativeCompilationTests</a>(
<a class="l" name="38" href="#38">38</a>    <a class="d intelliWindow-symbol" href="#GMockMethodNCTest" data-definition-place="defined-in-file">GMockMethodNCTest</a>,
<a class="l" name="39" href="#39">39</a>    <span class="s">"<a href="/googletest/s?path=google3/">google3</a>/<a href="/googletest/s?path=google3/third_party/">third_party</a>/<a href="/googletest/s?path=google3/third_party/googletest/">googletest</a>/<a href="/googletest/s?path=google3/third_party/googletest/googlemock/">googlemock</a>/<a href="/googletest/s?path=google3/third_party/googletest/googlemock/test/">test</a>/<a href="/googletest/s?path=google3/third_party/googletest/googlemock/test/gmock-function-mocker_nc">gmock-function-mocker_nc</a>"</span>,
<a class="hl" name="40" href="#40">40</a>    <span class="s">"gmock-function-mocker_nc.o"</span>, <a class="d intelliWindow-symbol" href="#TEST_SPECS" data-definition-place="defined-in-file">TEST_SPECS</a>)
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a><b>if</b> <a href="/googletest/s?defs=__name__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__name__</a> == <span class="s">"__main__"</span>:
<a class="l" name="43" href="#43">43</a>  <a class="d intelliWindow-symbol" href="#googletest" data-definition-place="defined-in-file">googletest</a>.<a href="/googletest/s?defs=main&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">main</a>()
<a class="l" name="44" href="#44">44</a>