<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># Googletest Mocking (gMock) Framework
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>### Overview
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>Google's framework for writing and using C++ mock classes. It can help you
<a class="l" name="6" href="#6">6</a>derive better designs of your system and write better tests.
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>It is inspired by:
<a class="l" name="9" href="#9">9</a>
<a class="hl" name="10" href="#10">10</a>*   [jMock](<a href="http://www.jmock.org/">http://www.jmock.org/</a>)
<a class="l" name="11" href="#11">11</a>*   [EasyMock](<a href="http://www.easymock.org/">http://www.easymock.org/</a>)
<a class="l" name="12" href="#12">12</a>*   [Hamcrest](<a href="http://code.google.com/p/hamcrest/">http://code.google.com/p/hamcrest/</a>)
<a class="l" name="13" href="#13">13</a>
<a class="l" name="14" href="#14">14</a>It is designed with C++'s specifics in mind.
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a>gMock:
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a>-   Provides a declarative syntax for defining mocks.
<a class="l" name="19" href="#19">19</a>-   Can define partial (hybrid) mocks, which are a cross of real and mock
<a class="hl" name="20" href="#20">20</a>    objects.
<a class="l" name="21" href="#21">21</a>-   Handles functions of arbitrary types and overloaded functions.
<a class="l" name="22" href="#22">22</a>-   Comes with a rich set of matchers for validating function arguments.
<a class="l" name="23" href="#23">23</a>-   Uses an intuitive syntax for controlling the behavior of a mock.
<a class="l" name="24" href="#24">24</a>-   Does automatic verification of expectations (no record-and-replay needed).
<a class="l" name="25" href="#25">25</a>-   Allows arbitrary (partial) ordering constraints on function calls to be
<a class="l" name="26" href="#26">26</a>    expressed.
<a class="l" name="27" href="#27">27</a>-   Lets a user extend it by defining new matchers and actions.
<a class="l" name="28" href="#28">28</a>-   Does not use exceptions.
<a class="l" name="29" href="#29">29</a>-   Is easy to learn and use.
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a>Details and examples can be found here:
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>*   [gMock for Dummies](<a href="/googletest/s?path=docs/for_dummies.md&amp;project=googletest">docs/for_dummies.md</a>)
<a class="l" name="34" href="#34">34</a>*   [Legacy gMock FAQ](<a href="/googletest/s?path=docs/gmock_faq.md&amp;project=googletest">docs/gmock_faq.md</a>)
<a class="l" name="35" href="#35">35</a>*   [gMock Cookbook](<a href="/googletest/s?path=docs/cook_book.md&amp;project=googletest">docs/cook_book.md</a>)
<a class="l" name="36" href="#36">36</a>*   [gMock Cheat Sheet](<a href="/googletest/s?path=docs/cheat_sheet.md&amp;project=googletest">docs/cheat_sheet.md</a>)
<a class="l" name="37" href="#37">37</a>
<a class="l" name="38" href="#38">38</a>Please note that code under <a href="/googletest/s?path=scripts/generator&amp;project=googletest">scripts/generator</a>/ is from the
<a class="l" name="39" href="#39">39</a>[cppclean project](<a href="http://code.google.com/p/cppclean/">http://code.google.com/p/cppclean/</a>) and under the Apache
<a class="hl" name="40" href="#40">40</a>License, which is different from GoogleMock's license.
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>GoogleMock is a part of
<a class="l" name="43" href="#43">43</a>[GoogleTest C++ testing framework](<a href="http://github.com/google/googletest/">http://github.com/google/googletest/</a>) and a
<a class="l" name="44" href="#44">44</a>subject to the same requirements.
<a class="l" name="45" href="#45">45</a>