<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Macro","xm",[["GMOCK_INCLUDE_GMOCK_GMOCK_H_",38]]],["Namespace","xn",[["testing",68]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">// Copyright 2007, Google Inc.</span>
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span><span class="c">// All rights reserved.</span>
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span><span class="c">// Redistribution and use in source and binary forms, with or without</span>
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span><span class="c">// modification, are permitted provided that the following conditions are</span>
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span><span class="c">// met:</span>
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span><span class="c">//     * Redistributions of source code must retain the above copyright</span>
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span><span class="c">// notice, this list of conditions and the following disclaimer.</span>
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span><span class="c">//     * Redistributions in binary form must reproduce the above</span>
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span><span class="c">// copyright notice, this list of conditions and the following disclaimer</span>
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span><span class="c">// in the documentation <a href="/googletest/s?path=and/">and</a>/<a href="/googletest/s?path=and/or">or</a> other materials provided with the</span>
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span><span class="c">// distribution.</span>
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span><span class="c">//     * Neither the name of Google Inc. nor the names of its</span>
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span><span class="c">// contributors may be used to endorse or promote products derived from</span>
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span><span class="c">// this software without specific prior written permission.</span>
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span><span class="c">// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span><span class="c">// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR</span>
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span><span class="c">// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT</span>
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span><span class="c">// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span><span class="c">// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span><span class="c">// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span><span class="c">// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><span class="c">// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT</span>
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span><span class="c">// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><span class="c">// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</span>
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span><span class="c">// Google Mock - a framework for writing C++ mock classes.</span>
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span><span class="c">// This is the main header file a user should include.</span>
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span><span class="c">// GOOGLETEST_CM0002 DO NOT DELETE</span>
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>#<b>ifndef</b> <a class="d intelliWindow-symbol" href="#GMOCK_INCLUDE_GMOCK_GMOCK_H_" data-definition-place="defined-in-file">GMOCK_INCLUDE_GMOCK_GMOCK_H_</a>
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="GMOCK_INCLUDE_GMOCK_GMOCK_H_"/><a href="/googletest/s?refs=GMOCK_INCLUDE_GMOCK_GMOCK_H_&amp;project=googletest" class="xm intelliWindow-symbol" data-definition-place="def">GMOCK_INCLUDE_GMOCK_GMOCK_H_</a>
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span><span class="c">// This file implements the following syntax:</span>
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span><span class="c">//   ON_CALL(mock_object, Method(...))</span>
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span><span class="c">//     .With(...) ?</span>
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span><span class="c">//     .WillByDefault(...);</span>
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span><span class="c">// where With() is optional and WillByDefault() must appear exactly</span>
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span><span class="c">// once.</span>
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span><span class="c">//   EXPECT_CALL(mock_object, Method(...))</span>
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span><span class="c">//     .With(...) ?</span>
<a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span><span class="c">//     .Times(...) ?</span>
<a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span><span class="c">//     .InSequence(...) *</span>
<a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span><span class="c">//     .WillOnce(...) *</span>
<a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span><span class="c">//     .WillRepeatedly(...) ?</span>
<a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span><span class="c">//     .RetiresOnSaturation() ? ;</span>
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span><span class="c">// where all clauses are optional and WillOnce() can be repeated.</span>
<a class="l" name="58" href="#58">58</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=gmock/">gmock</a>/<a href="/googletest/s?path=gmock/gmock-actions.h">gmock-actions.h</a>"</span>
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=gmock/">gmock</a>/<a href="/googletest/s?path=gmock/gmock-cardinalities.h">gmock-cardinalities.h</a>"</span>
<a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=gmock/">gmock</a>/<a href="/googletest/s?path=gmock/gmock-function-mocker.h">gmock-function-mocker.h</a>"</span>
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=gmock/">gmock</a>/<a href="/googletest/s?path=gmock/gmock-generated-actions.h">gmock-generated-actions.h</a>"</span>
<a class="l" name="63" href="#63">63</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=gmock/">gmock</a>/<a href="/googletest/s?path=gmock/gmock-matchers.h">gmock-matchers.h</a>"</span>
<a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=gmock/">gmock</a>/<a href="/googletest/s?path=gmock/gmock-more-matchers.h">gmock-more-matchers.h</a>"</span>
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=gmock/">gmock</a>/<a href="/googletest/s?path=gmock/gmock-nice-strict.h">gmock-nice-strict.h</a>"</span>
<a class="l" name="66" href="#66">66</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=gmock/">gmock</a>/<a href="/googletest/s?path=gmock/internal/">internal</a>/<a href="/googletest/s?path=gmock/internal/gmock-internal-utils.h">gmock-internal-utils.h</a>"</span>
<a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="68" href="#68">68</a><span class='fold-space'>&nbsp;</span><a href="/googletest/s?defs=namespace&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">namespace</a> <a class="xn" name="testing"/><a href="/googletest/s?refs=testing&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">testing</a> &#123;
<a class="l" name="69" href="#69">69</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="70" href="#70">70</a><span class='fold-space'>&nbsp;</span><span class="c">// Declares Google Mock flags that we want a user to use programmatically.</span>
<a class="l" name="71" href="#71">71</a><span class='fold-space'>&nbsp;</span><a href="/googletest/s?defs=GMOCK_DECLARE_bool_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GMOCK_DECLARE_bool_</a>(<a href="/googletest/s?defs=catch_leaked_mocks&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">catch_leaked_mocks</a>)&#59;
<a class="l" name="72" href="#72">72</a><span class='fold-space'>&nbsp;</span><a href="/googletest/s?defs=GMOCK_DECLARE_string_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GMOCK_DECLARE_string_</a>(<a href="/googletest/s?defs=verbose&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">verbose</a>)&#59;
<a class="l" name="73" href="#73">73</a><span class='fold-space'>&nbsp;</span><a href="/googletest/s?defs=GMOCK_DECLARE_int32_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GMOCK_DECLARE_int32_</a>(<a href="/googletest/s?defs=default_mock_behavior&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">default_mock_behavior</a>)&#59;
<a class="l" name="74" href="#74">74</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="75" href="#75">75</a><span class='fold-space'>&nbsp;</span><span class="c">// Initializes Google Mock.  This must be called before running the</span>
<a class="l" name="76" href="#76">76</a><span class='fold-space'>&nbsp;</span><span class="c">// tests.  In particular, it parses the command line for the flags</span>
<a class="l" name="77" href="#77">77</a><span class='fold-space'>&nbsp;</span><span class="c">// that Google Mock recognizes.  Whenever a Google Mock flag is seen,</span>
<a class="l" name="78" href="#78">78</a><span class='fold-space'>&nbsp;</span><span class="c">// it is removed from argv, and *argc is decremented.</span>
<a class="l" name="79" href="#79">79</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="hl" name="80" href="#80">80</a><span class='fold-space'>&nbsp;</span><span class="c">// No value is returned.  Instead, the Google Mock flag variables are</span>
<a class="l" name="81" href="#81">81</a><span class='fold-space'>&nbsp;</span><span class="c">// updated.</span>
<a class="l" name="82" href="#82">82</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="83" href="#83">83</a><span class='fold-space'>&nbsp;</span><span class="c">// Since Google Test is needed for Google Mock to work, this function</span>
<a class="l" name="84" href="#84">84</a><span class='fold-space'>&nbsp;</span><span class="c">// also initializes Google Test and parses its flags, if that hasn't</span>
<a class="l" name="85" href="#85">85</a><span class='fold-space'>&nbsp;</span><span class="c">// been done.</span>
<a class="l" name="86" href="#86">86</a><span class='fold-space'>&nbsp;</span><a href="/googletest/s?defs=GTEST_API_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GTEST_API_</a> <b>void</b> <a href="/googletest/s?defs=InitGoogleMock&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">InitGoogleMock</a>(<b>int</b>* <a href="/googletest/s?defs=argc&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argc</a>, <b>char</b>** <a href="/googletest/s?defs=argv&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>)&#59;
<a class="l" name="87" href="#87">87</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="88" href="#88">88</a><span class='fold-space'>&nbsp;</span><span class="c">// This overloaded version can be used in Windows programs compiled in</span>
<a class="l" name="89" href="#89">89</a><span class='fold-space'>&nbsp;</span><span class="c">// UNICODE mode.</span>
<a class="hl" name="90" href="#90">90</a><span class='fold-space'>&nbsp;</span><a href="/googletest/s?defs=GTEST_API_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GTEST_API_</a> <b>void</b> <a href="/googletest/s?defs=InitGoogleMock&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">InitGoogleMock</a>(<b>int</b>* <a href="/googletest/s?defs=argc&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argc</a>, <a href="/googletest/s?defs=wchar_t&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">wchar_t</a>** <a href="/googletest/s?defs=argv&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>)&#59;
<a class="l" name="91" href="#91">91</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="92" href="#92">92</a><span class='fold-space'>&nbsp;</span><span class="c">// This overloaded version can be used on <a href="/googletest/s?path=Arduino/">Arduino</a>/<a href="/googletest/s?path=Arduino/embedded">embedded</a> platforms where</span>
<a class="l" name="93" href="#93">93</a><span class='fold-space'>&nbsp;</span><span class="c">// there is no <a href="/googletest/s?path=argc/">argc</a>/<a href="/googletest/s?path=argc/argv">argv</a>.</span>
<a class="l" name="94" href="#94">94</a><span class='fold-space'>&nbsp;</span><a href="/googletest/s?defs=GTEST_API_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GTEST_API_</a> <b>void</b> <a href="/googletest/s?defs=InitGoogleMock&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">InitGoogleMock</a>()&#59;
<a class="l" name="95" href="#95">95</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="96" href="#96">96</a><span class='fold-space'>&nbsp;</span>&#125;  <span class="c">// namespace testing</span>
<a class="l" name="97" href="#97">97</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="98" href="#98">98</a><span class='fold-space'>&nbsp;</span>#<b>endif</b>  <span class="c">// GMOCK_INCLUDE_GMOCK_GMOCK_H_</span>
<a class="l" name="99" href="#99">99</a><span class='fold-space'>&nbsp;</span>