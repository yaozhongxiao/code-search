<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># Customization Points
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>The custom directory is an injection point for custom user configurations.
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>## Header `<a href="/googletest/s?path=gmock-port.h&amp;project=googletest">gmock-port.h</a>`
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>The following macros can be defined:
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>### Flag related macros:
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a>*   `GMOCK_DECLARE_bool_(name)`
<a class="l" name="12" href="#12">12</a>*   `GMOCK_DECLARE_int32_(name)`
<a class="l" name="13" href="#13">13</a>*   `GMOCK_DECLARE_string_(name)`
<a class="l" name="14" href="#14">14</a>*   `GMOCK_DEFINE_bool_(name, default_val, doc)`
<a class="l" name="15" href="#15">15</a>*   `GMOCK_DEFINE_int32_(name, default_val, doc)`
<a class="l" name="16" href="#16">16</a>*   `GMOCK_DEFINE_string_(name, default_val, doc)`
<a class="l" name="17" href="#17">17</a>