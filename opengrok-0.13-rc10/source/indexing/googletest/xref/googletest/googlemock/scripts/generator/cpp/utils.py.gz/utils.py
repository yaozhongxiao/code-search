<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["DEBUG",23]]],["Namespace","xn",[["sys",20]]],["Function","xf",[["ReadFile",26]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/googletest/s?path=/usr/">usr</a>/<a href="/googletest/s?path=/usr/bin/">bin</a>/<a href="/googletest/s?path=/usr/bin/env">env</a> python</span>
<a class="l" name="2" href="#2">2</a><span class="c">#</span>
<a class="l" name="3" href="#3">3</a><span class="c"># Copyright 2007 Neal Norwitz</span>
<a class="l" name="4" href="#4">4</a><span class="c"># Portions Copyright 2007 Google Inc.</span>
<a class="l" name="5" href="#5">5</a><span class="c">#</span>
<a class="l" name="6" href="#6">6</a><span class="c"># Licensed under the Apache License, Version 2.0 (the "License");</span>
<a class="l" name="7" href="#7">7</a><span class="c"># you may not use this file except in compliance with the License.</span>
<a class="l" name="8" href="#8">8</a><span class="c"># You may obtain a copy of the License at</span>
<a class="l" name="9" href="#9">9</a><span class="c">#</span>
<a class="hl" name="10" href="#10">10</a><span class="c">#      <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a></span>
<a class="l" name="11" href="#11">11</a><span class="c">#</span>
<a class="l" name="12" href="#12">12</a><span class="c"># Unless required by applicable law or agreed to in writing, software</span>
<a class="l" name="13" href="#13">13</a><span class="c"># distributed under the License is distributed on an "AS IS" BASIS,</span>
<a class="l" name="14" href="#14">14</a><span class="c"># WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.</span>
<a class="l" name="15" href="#15">15</a><span class="c"># See the License for the specific language governing permissions and</span>
<a class="l" name="16" href="#16">16</a><span class="c"># limitations under the License.</span>
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a><span class="s">"""Generic utilities for C++ parsing."""</span>
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a><b>import</b> <a class="xn" name="sys"/><a href="/googletest/s?refs=sys&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">sys</a>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c"># Set to True to see the <a href="/googletest/s?path=start/">start</a>/<a href="/googletest/s?path=start/end">end</a> token indices.</span>
<a class="l" name="23" href="#23">23</a><a class="xv" name="DEBUG"/><a href="/googletest/s?refs=DEBUG&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">DEBUG</a> = <a href="/googletest/s?defs=True&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">True</a>
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><b>def</b> <a class="xf" name="ReadFile"/><a href="/googletest/s?refs=ReadFile&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">ReadFile</a>(<a href="/googletest/s?defs=filename&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">filename</a>, <a href="/googletest/s?defs=print_error&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">print_error</a>=<a href="/googletest/s?defs=True&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">True</a>):
<a class="l" name="27" href="#27">27</a>    <span class="s">"""Returns the contents of a file."""</span>
<a class="l" name="28" href="#28">28</a>    <b>try</b>:
<a class="l" name="29" href="#29">29</a>        <a href="/googletest/s?defs=fp&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fp</a> = <a href="/googletest/s?defs=open&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">open</a>(<a href="/googletest/s?defs=filename&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">filename</a>)
<a class="hl" name="30" href="#30">30</a>        <b>try</b>:
<a class="l" name="31" href="#31">31</a>            <b>return</b> <a href="/googletest/s?defs=fp&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fp</a>.<a href="/googletest/s?defs=read&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">read</a>()
<a class="l" name="32" href="#32">32</a>        <b>finally</b>:
<a class="l" name="33" href="#33">33</a>            <a href="/googletest/s?defs=fp&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fp</a>.<a href="/googletest/s?defs=close&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">close</a>()
<a class="l" name="34" href="#34">34</a>    <b>except</b> <a href="/googletest/s?defs=IOError&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOError</a>:
<a class="l" name="35" href="#35">35</a>        <b>if</b> <a href="/googletest/s?defs=print_error&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">print_error</a>:
<a class="l" name="36" href="#36">36</a>            <b>print</b>(<span class="s">'Error reading %s: %s'</span> % (<a href="/googletest/s?defs=filename&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">filename</a>, <a class="d intelliWindow-symbol" href="#sys" data-definition-place="defined-in-file">sys</a>.<a href="/googletest/s?defs=exc_info&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exc_info</a>()[<span class="n">1</span>]))
<a class="l" name="37" href="#37">37</a>        <b>return</b> <b>None</b>
<a class="l" name="38" href="#38">38</a>