<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["GenerateMethodsTest",44],["GenerateMocksTest",348],["TestCase",31]]],["Namespace","xn",[["ast",27],["gmock_class",28],["os",20],["sys",21],["unittest",22]]],["Function","xf",[["testArgsOfTemplateTypes",275],["testArrayArgWithoutNames",337],["testCStyleCommentsInParameterListAreNotRemoved",261],["testClassWithStorageSpecifierMacro",389],["testConstDefaultParameter",214],["testConstRefDefaultParameter",225],["testDefaultParameters",174],["testDoubleSlashCommentsInParameterListAreRemoved",248],["testEnumClassType",510],["testEnumType",491],["testExplicitVoid",151],["testExplicitlyDefaultedConstructorsAndDestructor",97],["testExplicitlyDeletedConstructorsAndDestructor",113],["testMultipleDefaultParameters",185],["testMultipleSingleLineDefaultParameters",203],["testParenthesizedCommaInArg",475],["testPointerArgWithoutNames",317],["testReferenceArgWithoutNames",327],["testRemovesCommentsWhenDefaultsArePresent",236],["testReturnTypeWithManyTemplateArgs",295],["testReturnTypeWithOneTemplateArg",285],["testSimpleConstMethod",140],["testSimpleConstructorsAndDestructor",67],["testSimpleMethodInTemplatedClass",305],["testSimpleOverrideMethod",129],["testStdFunction",529],["testStrangeNewlineInParameter",162],["testTemplateInATemplateTypedef",440],["testTemplateInATemplateTypedefWithComma",457],["testTemplatedClass",422],["testTemplatedForwardDeclaration",405],["testVirtualDestructor",84]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/googletest/s?path=/usr/">usr</a>/<a href="/googletest/s?path=/usr/bin/">bin</a>/<a href="/googletest/s?path=/usr/bin/env">env</a> python</span>
<a class="l" name="2" href="#2">2</a><span class="c">#</span>
<a class="l" name="3" href="#3">3</a><span class="c"># Copyright 2009 Neal Norwitz All Rights Reserved.</span>
<a class="l" name="4" href="#4">4</a><span class="c"># Portions Copyright 2009 Google Inc. All Rights Reserved.</span>
<a class="l" name="5" href="#5">5</a><span class="c">#</span>
<a class="l" name="6" href="#6">6</a><span class="c"># Licensed under the Apache License, Version 2.0 (the "License");</span>
<a class="l" name="7" href="#7">7</a><span class="c"># you may not use this file except in compliance with the License.</span>
<a class="l" name="8" href="#8">8</a><span class="c"># You may obtain a copy of the License at</span>
<a class="l" name="9" href="#9">9</a><span class="c">#</span>
<a class="hl" name="10" href="#10">10</a><span class="c">#      <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a></span>
<a class="l" name="11" href="#11">11</a><span class="c">#</span>
<a class="l" name="12" href="#12">12</a><span class="c"># Unless required by applicable law or agreed to in writing, software</span>
<a class="l" name="13" href="#13">13</a><span class="c"># distributed under the License is distributed on an "AS IS" BASIS,</span>
<a class="l" name="14" href="#14">14</a><span class="c"># WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.</span>
<a class="l" name="15" href="#15">15</a><span class="c"># See the License for the specific language governing permissions and</span>
<a class="l" name="16" href="#16">16</a><span class="c"># limitations under the License.</span>
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a><span class="s">"""Tests for gmock.scripts.generator.cpp.gmock_class."""</span>
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a><b>import</b> <a class="xn" name="os"/><a href="/googletest/s?refs=os&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">os</a>
<a class="l" name="21" href="#21">21</a><b>import</b> <a class="xn" name="sys"/><a href="/googletest/s?refs=sys&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">sys</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a class="xn" name="unittest"/><a href="/googletest/s?refs=unittest&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">unittest</a>
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><span class="c"># Allow the cpp imports below to work when run as a standalone script.</span>
<a class="l" name="25" href="#25">25</a><a class="d intelliWindow-symbol" href="#sys" data-definition-place="defined-in-file">sys</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=append&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">append</a>(<a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=dirname&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">dirname</a>(<a href="/googletest/s?defs=__file__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__file__</a>), <span class="s">'..'</span>))
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a><b>from</b> <a href="/googletest/s?defs=cpp&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cpp</a> <b>import</b> <a class="xn" name="ast"/><a href="/googletest/s?refs=ast&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">ast</a>
<a class="l" name="28" href="#28">28</a><b>from</b> <a href="/googletest/s?defs=cpp&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cpp</a> <b>import</b> <a class="xn" name="gmock_class"/><a href="/googletest/s?refs=gmock_class&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">gmock_class</a>
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a><b>class</b> <a class="xc" name="TestCase"/><a href="/googletest/s?refs=TestCase&amp;project=googletest" class="xc intelliWindow-symbol" data-definition-place="def">TestCase</a>(<a class="d intelliWindow-symbol" href="#unittest" data-definition-place="defined-in-file">unittest</a>.<a class="xc" name="TestCase"/><a href="/googletest/s?refs=TestCase&amp;project=googletest" class="xc intelliWindow-symbol" data-definition-place="def">TestCase</a>):
<a class="l" name="32" href="#32">32</a>  <span class="s">"""Helper class that adds assert methods."""</span>
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a>  @<a href="/googletest/s?defs=staticmethod&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">staticmethod</a>
<a class="l" name="35" href="#35">35</a>  <b>def</b> <a class="xmb" name="StripLeadingWhitespace"/><a href="/googletest/s?refs=StripLeadingWhitespace&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">StripLeadingWhitespace</a>(<a href="/googletest/s?defs=lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a>):
<a class="l" name="36" href="#36">36</a>    <span class="s">"""Strip leading whitespace in each line in 'lines'."""</span>
<a class="l" name="37" href="#37">37</a>    <b>return</b> <span class="s">'\n'</span>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>([s.<a href="/googletest/s?defs=lstrip&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lstrip</a>() <b>for</b> s <b>in</b> <a href="/googletest/s?defs=lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a>.<a href="/googletest/s?defs=split&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">split</a>(<span class="s">'\n'</span>)])
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>  <b>def</b> <a class="xmb" name="assertEqualIgnoreLeadingWhitespace"/><a href="/googletest/s?refs=assertEqualIgnoreLeadingWhitespace&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">assertEqualIgnoreLeadingWhitespace</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>, <a href="/googletest/s?defs=expected_lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_lines</a>, <a href="/googletest/s?defs=lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a>):
<a class="hl" name="40" href="#40">40</a>    <span class="s">"""Specialized assert that ignores the indent level."""</span>
<a class="l" name="41" href="#41">41</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertEqual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertEqual</a>(<a href="/googletest/s?defs=expected_lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_lines</a>, <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#StripLeadingWhitespace" data-definition-place="defined-in-file">StripLeadingWhitespace</a>(<a href="/googletest/s?defs=lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a>))
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>
<a class="l" name="44" href="#44">44</a><b>class</b> <a class="xc" name="GenerateMethodsTest"/><a href="/googletest/s?refs=GenerateMethodsTest&amp;project=googletest" class="xc intelliWindow-symbol" data-definition-place="def">GenerateMethodsTest</a>(<a class="d intelliWindow-symbol" href="#TestCase" data-definition-place="defined-in-file">TestCase</a>):
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>  @<a href="/googletest/s?defs=staticmethod&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">staticmethod</a>
<a class="l" name="47" href="#47">47</a>  <b>def</b> <a class="xmb" name="GenerateMethodSource"/><a href="/googletest/s?refs=GenerateMethodSource&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">GenerateMethodSource</a>(<a href="/googletest/s?defs=cpp_source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cpp_source</a>):
<a class="l" name="48" href="#48">48</a>    <span class="s">"""Convert C++ source to Google Mock output source lines."""</span>
<a class="l" name="49" href="#49">49</a>    <a href="/googletest/s?defs=method_source_lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">method_source_lines</a> = []
<a class="hl" name="50" href="#50">50</a>    <span class="c"># &lt;test&gt; is a pseudo-filename, it is not read or written.</span>
<a class="l" name="51" href="#51">51</a>    <a href="/googletest/s?defs=builder&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">builder</a> = <a class="d intelliWindow-symbol" href="#ast" data-definition-place="defined-in-file">ast</a>.<a href="/googletest/s?defs=BuilderFromSource&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">BuilderFromSource</a>(<a href="/googletest/s?defs=cpp_source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cpp_source</a>, <span class="s">'&lt;test&gt;'</span>)
<a class="l" name="52" href="#52">52</a>    <a href="/googletest/s?defs=ast_list&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ast_list</a> = <a href="/googletest/s?defs=list&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">list</a>(<a href="/googletest/s?defs=builder&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">builder</a>.<a href="/googletest/s?defs=Generate&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Generate</a>())
<a class="l" name="53" href="#53">53</a>    <a class="d intelliWindow-symbol" href="#gmock_class" data-definition-place="defined-in-file">gmock_class</a>.<a href="/googletest/s?defs=_GenerateMethods&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">_GenerateMethods</a>(<a href="/googletest/s?defs=method_source_lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">method_source_lines</a>, <a href="/googletest/s?defs=cpp_source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cpp_source</a>, <a href="/googletest/s?defs=ast_list&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ast_list</a>[<span class="n">0</span>])
<a class="l" name="54" href="#54">54</a>    <b>return</b> <span class="s">'\n'</span>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a href="/googletest/s?defs=method_source_lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">method_source_lines</a>)
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>  <b>def</b> <a class="xmb" name="testSimpleMethod"/><a href="/googletest/s?refs=testSimpleMethod&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testSimpleMethod</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="57" href="#57">57</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="58" href="#58">58</a>class Foo {
<a class="l" name="59" href="#59">59</a> public:
<a class="hl" name="60" href="#60">60</a>  virtual int Bar();
<a class="l" name="61" href="#61">61</a>};
<a class="l" name="62" href="#62">62</a>"""</span>
<a class="l" name="63" href="#63">63</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="64" href="#64">64</a>        <span class="s">'MOCK_METHOD(int, Bar, (), (override));'</span>,
<a class="l" name="65" href="#65">65</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>  <b>def</b> <a class="xf" name="testSimpleConstructorsAndDestructor"/><a href="/googletest/s?refs=testSimpleConstructorsAndDestructor&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testSimpleConstructorsAndDestructor</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="68" href="#68">68</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="69" href="#69">69</a>class Foo {
<a class="hl" name="70" href="#70">70</a> public:
<a class="l" name="71" href="#71">71</a>  Foo();
<a class="l" name="72" href="#72">72</a>  Foo(int x);
<a class="l" name="73" href="#73">73</a>  Foo(const Foo&amp; f);
<a class="l" name="74" href="#74">74</a>  Foo(Foo&amp;&amp; f);
<a class="l" name="75" href="#75">75</a>  ~Foo();
<a class="l" name="76" href="#76">76</a>  virtual int Bar() = 0;
<a class="l" name="77" href="#77">77</a>};
<a class="l" name="78" href="#78">78</a>"""</span>
<a class="l" name="79" href="#79">79</a>    <span class="c"># The constructors and destructor should be ignored.</span>
<a class="hl" name="80" href="#80">80</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="81" href="#81">81</a>        <span class="s">'MOCK_METHOD(int, Bar, (), (override));'</span>,
<a class="l" name="82" href="#82">82</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>  <b>def</b> <a class="xf" name="testVirtualDestructor"/><a href="/googletest/s?refs=testVirtualDestructor&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testVirtualDestructor</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="85" href="#85">85</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="86" href="#86">86</a>class Foo {
<a class="l" name="87" href="#87">87</a> public:
<a class="l" name="88" href="#88">88</a>  virtual ~Foo();
<a class="l" name="89" href="#89">89</a>  virtual int Bar() = 0;
<a class="hl" name="90" href="#90">90</a>};
<a class="l" name="91" href="#91">91</a>"""</span>
<a class="l" name="92" href="#92">92</a>    <span class="c"># The destructor should be ignored.</span>
<a class="l" name="93" href="#93">93</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="94" href="#94">94</a>        <span class="s">'MOCK_METHOD(int, Bar, (), (override));'</span>,
<a class="l" name="95" href="#95">95</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>  <b>def</b> <a class="xf" name="testExplicitlyDefaultedConstructorsAndDestructor"/><a href="/googletest/s?refs=testExplicitlyDefaultedConstructorsAndDestructor&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testExplicitlyDefaultedConstructorsAndDestructor</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="98" href="#98">98</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="99" href="#99">99</a>class Foo {
<a class="hl" name="100" href="#100">100</a> public:
<a class="l" name="101" href="#101">101</a>  Foo() = default;
<a class="l" name="102" href="#102">102</a>  Foo(const Foo&amp; f) = default;
<a class="l" name="103" href="#103">103</a>  Foo(Foo&amp;&amp; f) = default;
<a class="l" name="104" href="#104">104</a>  ~Foo() = default;
<a class="l" name="105" href="#105">105</a>  virtual int Bar() = 0;
<a class="l" name="106" href="#106">106</a>};
<a class="l" name="107" href="#107">107</a>"""</span>
<a class="l" name="108" href="#108">108</a>    <span class="c"># The constructors and destructor should be ignored.</span>
<a class="l" name="109" href="#109">109</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="hl" name="110" href="#110">110</a>        <span class="s">'MOCK_METHOD(int, Bar, (), (override));'</span>,
<a class="l" name="111" href="#111">111</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>  <b>def</b> <a class="xf" name="testExplicitlyDeletedConstructorsAndDestructor"/><a href="/googletest/s?refs=testExplicitlyDeletedConstructorsAndDestructor&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testExplicitlyDeletedConstructorsAndDestructor</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="114" href="#114">114</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="115" href="#115">115</a>class Foo {
<a class="l" name="116" href="#116">116</a> public:
<a class="l" name="117" href="#117">117</a>  Foo() = delete;
<a class="l" name="118" href="#118">118</a>  Foo(const Foo&amp; f) = delete;
<a class="l" name="119" href="#119">119</a>  Foo(Foo&amp;&amp; f) = delete;
<a class="hl" name="120" href="#120">120</a>  ~Foo() = delete;
<a class="l" name="121" href="#121">121</a>  virtual int Bar() = 0;
<a class="l" name="122" href="#122">122</a>};
<a class="l" name="123" href="#123">123</a>"""</span>
<a class="l" name="124" href="#124">124</a>    <span class="c"># The constructors and destructor should be ignored.</span>
<a class="l" name="125" href="#125">125</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="126" href="#126">126</a>        <span class="s">'MOCK_METHOD(int, Bar, (), (override));'</span>,
<a class="l" name="127" href="#127">127</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="128" href="#128">128</a>
<a class="l" name="129" href="#129">129</a>  <b>def</b> <a class="xf" name="testSimpleOverrideMethod"/><a href="/googletest/s?refs=testSimpleOverrideMethod&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testSimpleOverrideMethod</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="hl" name="130" href="#130">130</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="131" href="#131">131</a>class Foo {
<a class="l" name="132" href="#132">132</a> public:
<a class="l" name="133" href="#133">133</a>  int Bar() override;
<a class="l" name="134" href="#134">134</a>};
<a class="l" name="135" href="#135">135</a>"""</span>
<a class="l" name="136" href="#136">136</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="137" href="#137">137</a>        <span class="s">'MOCK_METHOD(int, Bar, (), (override));'</span>,
<a class="l" name="138" href="#138">138</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="139" href="#139">139</a>
<a class="hl" name="140" href="#140">140</a>  <b>def</b> <a class="xf" name="testSimpleConstMethod"/><a href="/googletest/s?refs=testSimpleConstMethod&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testSimpleConstMethod</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="141" href="#141">141</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="142" href="#142">142</a>class Foo {
<a class="l" name="143" href="#143">143</a> public:
<a class="l" name="144" href="#144">144</a>  virtual void Bar(bool flag) const;
<a class="l" name="145" href="#145">145</a>};
<a class="l" name="146" href="#146">146</a>"""</span>
<a class="l" name="147" href="#147">147</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="148" href="#148">148</a>        <span class="s">'MOCK_METHOD(void, Bar, (bool flag), (const, override));'</span>,
<a class="l" name="149" href="#149">149</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="hl" name="150" href="#150">150</a>
<a class="l" name="151" href="#151">151</a>  <b>def</b> <a class="xf" name="testExplicitVoid"/><a href="/googletest/s?refs=testExplicitVoid&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testExplicitVoid</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="152" href="#152">152</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="153" href="#153">153</a>class Foo {
<a class="l" name="154" href="#154">154</a> public:
<a class="l" name="155" href="#155">155</a>  virtual int Bar(void);
<a class="l" name="156" href="#156">156</a>};
<a class="l" name="157" href="#157">157</a>"""</span>
<a class="l" name="158" href="#158">158</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="159" href="#159">159</a>        <span class="s">'MOCK_METHOD(int, Bar, (void), (override));'</span>,
<a class="hl" name="160" href="#160">160</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="161" href="#161">161</a>
<a class="l" name="162" href="#162">162</a>  <b>def</b> <a class="xf" name="testStrangeNewlineInParameter"/><a href="/googletest/s?refs=testStrangeNewlineInParameter&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testStrangeNewlineInParameter</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="163" href="#163">163</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="164" href="#164">164</a>class Foo {
<a class="l" name="165" href="#165">165</a> public:
<a class="l" name="166" href="#166">166</a>  virtual void Bar(int
<a class="l" name="167" href="#167">167</a>a) = 0;
<a class="l" name="168" href="#168">168</a>};
<a class="l" name="169" href="#169">169</a>"""</span>
<a class="hl" name="170" href="#170">170</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="171" href="#171">171</a>        <span class="s">'MOCK_METHOD(void, Bar, (int a), (override));'</span>,
<a class="l" name="172" href="#172">172</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="173" href="#173">173</a>
<a class="l" name="174" href="#174">174</a>  <b>def</b> <a class="xf" name="testDefaultParameters"/><a href="/googletest/s?refs=testDefaultParameters&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testDefaultParameters</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="175" href="#175">175</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="176" href="#176">176</a>class Foo {
<a class="l" name="177" href="#177">177</a> public:
<a class="l" name="178" href="#178">178</a>  virtual void Bar(int a, char c = 'x') = 0;
<a class="l" name="179" href="#179">179</a>};
<a class="hl" name="180" href="#180">180</a>"""</span>
<a class="l" name="181" href="#181">181</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="182" href="#182">182</a>        <span class="s">'MOCK_METHOD(void, Bar, (int a, char c), (override));'</span>,
<a class="l" name="183" href="#183">183</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="184" href="#184">184</a>
<a class="l" name="185" href="#185">185</a>  <b>def</b> <a class="xf" name="testMultipleDefaultParameters"/><a href="/googletest/s?refs=testMultipleDefaultParameters&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testMultipleDefaultParameters</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="186" href="#186">186</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="187" href="#187">187</a>class Foo {
<a class="l" name="188" href="#188">188</a> public:
<a class="l" name="189" href="#189">189</a>  virtual void Bar(
<a class="hl" name="190" href="#190">190</a>        int a = 42,
<a class="l" name="191" href="#191">191</a>        char c = 'x',
<a class="l" name="192" href="#192">192</a>        const int* const p = nullptr,
<a class="l" name="193" href="#193">193</a>        const std::string&amp; s = "42",
<a class="l" name="194" href="#194">194</a>        char tab[] = {'4','2'},
<a class="l" name="195" href="#195">195</a>        int const *&amp; rp = aDefaultPointer) = 0;
<a class="l" name="196" href="#196">196</a>};
<a class="l" name="197" href="#197">197</a>"""</span>
<a class="l" name="198" href="#198">198</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="199" href="#199">199</a>        <span class="s">'MOCK_METHOD(void, Bar, '</span>
<a class="hl" name="200" href="#200">200</a>        <span class="s">'(int a, char c, const int* const p, const std::string&amp; s, char tab[], int const *&amp; rp), '</span>
<a class="l" name="201" href="#201">201</a>        <span class="s">'(override));'</span>, <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="202" href="#202">202</a>
<a class="l" name="203" href="#203">203</a>  <b>def</b> <a class="xf" name="testMultipleSingleLineDefaultParameters"/><a href="/googletest/s?refs=testMultipleSingleLineDefaultParameters&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testMultipleSingleLineDefaultParameters</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="204" href="#204">204</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="205" href="#205">205</a>class Foo {
<a class="l" name="206" href="#206">206</a> public:
<a class="l" name="207" href="#207">207</a>  virtual void Bar(int a = 42, int b = 43, int c = 44) = 0;
<a class="l" name="208" href="#208">208</a>};
<a class="l" name="209" href="#209">209</a>"""</span>
<a class="hl" name="210" href="#210">210</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="211" href="#211">211</a>        <span class="s">'MOCK_METHOD(void, Bar, (int a, int b, int c), (override));'</span>,
<a class="l" name="212" href="#212">212</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="213" href="#213">213</a>
<a class="l" name="214" href="#214">214</a>  <b>def</b> <a class="xf" name="testConstDefaultParameter"/><a href="/googletest/s?refs=testConstDefaultParameter&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testConstDefaultParameter</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="215" href="#215">215</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="216" href="#216">216</a>class Test {
<a class="l" name="217" href="#217">217</a> public:
<a class="l" name="218" href="#218">218</a>  virtual bool Bar(const int test_arg = 42) = 0;
<a class="l" name="219" href="#219">219</a>};
<a class="hl" name="220" href="#220">220</a>"""</span>
<a class="l" name="221" href="#221">221</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="222" href="#222">222</a>        <span class="s">'MOCK_METHOD(bool, Bar, (const int test_arg), (override));'</span>,
<a class="l" name="223" href="#223">223</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="224" href="#224">224</a>
<a class="l" name="225" href="#225">225</a>  <b>def</b> <a class="xf" name="testConstRefDefaultParameter"/><a href="/googletest/s?refs=testConstRefDefaultParameter&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testConstRefDefaultParameter</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="226" href="#226">226</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="227" href="#227">227</a>class Test {
<a class="l" name="228" href="#228">228</a> public:
<a class="l" name="229" href="#229">229</a>  virtual bool Bar(const std::string&amp; test_arg = "42" ) = 0;
<a class="hl" name="230" href="#230">230</a>};
<a class="l" name="231" href="#231">231</a>"""</span>
<a class="l" name="232" href="#232">232</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="233" href="#233">233</a>        <span class="s">'MOCK_METHOD(bool, Bar, (const std::string&amp; test_arg), (override));'</span>,
<a class="l" name="234" href="#234">234</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="235" href="#235">235</a>
<a class="l" name="236" href="#236">236</a>  <b>def</b> <a class="xf" name="testRemovesCommentsWhenDefaultsArePresent"/><a href="/googletest/s?refs=testRemovesCommentsWhenDefaultsArePresent&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testRemovesCommentsWhenDefaultsArePresent</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="237" href="#237">237</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="238" href="#238">238</a>class Foo {
<a class="l" name="239" href="#239">239</a> public:
<a class="hl" name="240" href="#240">240</a>  virtual void Bar(int a = 42 /* a comment */,
<a class="l" name="241" href="#241">241</a>                   char /* other comment */ c= 'x') = 0;
<a class="l" name="242" href="#242">242</a>};
<a class="l" name="243" href="#243">243</a>"""</span>
<a class="l" name="244" href="#244">244</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="245" href="#245">245</a>        <span class="s">'MOCK_METHOD(void, Bar, (int a, char c), (override));'</span>,
<a class="l" name="246" href="#246">246</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="247" href="#247">247</a>
<a class="l" name="248" href="#248">248</a>  <b>def</b> <a class="xf" name="testDoubleSlashCommentsInParameterListAreRemoved"/><a href="/googletest/s?refs=testDoubleSlashCommentsInParameterListAreRemoved&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testDoubleSlashCommentsInParameterListAreRemoved</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="249" href="#249">249</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="hl" name="250" href="#250">250</a>class Foo {
<a class="l" name="251" href="#251">251</a> public:
<a class="l" name="252" href="#252">252</a>  virtual void Bar(int a,  // inline comments should be elided.
<a class="l" name="253" href="#253">253</a>                   int b   // inline comments should be elided.
<a class="l" name="254" href="#254">254</a>                   ) const = 0;
<a class="l" name="255" href="#255">255</a>};
<a class="l" name="256" href="#256">256</a>"""</span>
<a class="l" name="257" href="#257">257</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="258" href="#258">258</a>        <span class="s">'MOCK_METHOD(void, Bar, (int a, int b), (const, override));'</span>,
<a class="l" name="259" href="#259">259</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="hl" name="260" href="#260">260</a>
<a class="l" name="261" href="#261">261</a>  <b>def</b> <a class="xf" name="testCStyleCommentsInParameterListAreNotRemoved"/><a href="/googletest/s?refs=testCStyleCommentsInParameterListAreNotRemoved&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testCStyleCommentsInParameterListAreNotRemoved</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="262" href="#262">262</a>    <span class="c"># NOTE(nnorwitz): I'm not sure if it's the best behavior to keep these</span>
<a class="l" name="263" href="#263">263</a>    <span class="c"># comments.  Also note that C style comments after the last parameter</span>
<a class="l" name="264" href="#264">264</a>    <span class="c"># are still elided.</span>
<a class="l" name="265" href="#265">265</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="266" href="#266">266</a>class Foo {
<a class="l" name="267" href="#267">267</a> public:
<a class="l" name="268" href="#268">268</a>  virtual const string&amp; Bar(int /* keeper */, int b);
<a class="l" name="269" href="#269">269</a>};
<a class="hl" name="270" href="#270">270</a>"""</span>
<a class="l" name="271" href="#271">271</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="272" href="#272">272</a>        <span class="s">'MOCK_METHOD(const string&amp;, Bar, (int, int b), (override));'</span>,
<a class="l" name="273" href="#273">273</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="274" href="#274">274</a>
<a class="l" name="275" href="#275">275</a>  <b>def</b> <a class="xf" name="testArgsOfTemplateTypes"/><a href="/googletest/s?refs=testArgsOfTemplateTypes&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testArgsOfTemplateTypes</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="276" href="#276">276</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="277" href="#277">277</a>class Foo {
<a class="l" name="278" href="#278">278</a> public:
<a class="l" name="279" href="#279">279</a>  virtual int Bar(const vector&lt;int&gt;&amp; v, map&lt;int, string&gt;* output);
<a class="hl" name="280" href="#280">280</a>};"""</span>
<a class="l" name="281" href="#281">281</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="282" href="#282">282</a>        <span class="s">'MOCK_METHOD(int, Bar, (const vector&lt;int&gt;&amp; v, (map&lt;int, string&gt;* output)), (override));'</span>,
<a class="l" name="283" href="#283">283</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="284" href="#284">284</a>
<a class="l" name="285" href="#285">285</a>  <b>def</b> <a class="xf" name="testReturnTypeWithOneTemplateArg"/><a href="/googletest/s?refs=testReturnTypeWithOneTemplateArg&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testReturnTypeWithOneTemplateArg</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="286" href="#286">286</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="287" href="#287">287</a>class Foo {
<a class="l" name="288" href="#288">288</a> public:
<a class="l" name="289" href="#289">289</a>  virtual vector&lt;int&gt;* Bar(int n);
<a class="hl" name="290" href="#290">290</a>};"""</span>
<a class="l" name="291" href="#291">291</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="292" href="#292">292</a>        <span class="s">'MOCK_METHOD(vector&lt;int&gt;*, Bar, (int n), (override));'</span>,
<a class="l" name="293" href="#293">293</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="294" href="#294">294</a>
<a class="l" name="295" href="#295">295</a>  <b>def</b> <a class="xf" name="testReturnTypeWithManyTemplateArgs"/><a href="/googletest/s?refs=testReturnTypeWithManyTemplateArgs&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testReturnTypeWithManyTemplateArgs</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="296" href="#296">296</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="297" href="#297">297</a>class Foo {
<a class="l" name="298" href="#298">298</a> public:
<a class="l" name="299" href="#299">299</a>  virtual map&lt;int, string&gt; Bar();
<a class="hl" name="300" href="#300">300</a>};"""</span>
<a class="l" name="301" href="#301">301</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="302" href="#302">302</a>        <span class="s">'MOCK_METHOD((map&lt;int, string&gt;), Bar, (), (override));'</span>,
<a class="l" name="303" href="#303">303</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="304" href="#304">304</a>
<a class="l" name="305" href="#305">305</a>  <b>def</b> <a class="xf" name="testSimpleMethodInTemplatedClass"/><a href="/googletest/s?refs=testSimpleMethodInTemplatedClass&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testSimpleMethodInTemplatedClass</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="306" href="#306">306</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="307" href="#307">307</a>template&lt;class T&gt;
<a class="l" name="308" href="#308">308</a>class Foo {
<a class="l" name="309" href="#309">309</a> public:
<a class="hl" name="310" href="#310">310</a>  virtual int Bar();
<a class="l" name="311" href="#311">311</a>};
<a class="l" name="312" href="#312">312</a>"""</span>
<a class="l" name="313" href="#313">313</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="314" href="#314">314</a>        <span class="s">'MOCK_METHOD(int, Bar, (), (override));'</span>,
<a class="l" name="315" href="#315">315</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="316" href="#316">316</a>
<a class="l" name="317" href="#317">317</a>  <b>def</b> <a class="xf" name="testPointerArgWithoutNames"/><a href="/googletest/s?refs=testPointerArgWithoutNames&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testPointerArgWithoutNames</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="318" href="#318">318</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="319" href="#319">319</a>class Foo {
<a class="hl" name="320" href="#320">320</a>  virtual int Bar(C*);
<a class="l" name="321" href="#321">321</a>};
<a class="l" name="322" href="#322">322</a>"""</span>
<a class="l" name="323" href="#323">323</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="324" href="#324">324</a>        <span class="s">'MOCK_METHOD(int, Bar, (C*), (override));'</span>,
<a class="l" name="325" href="#325">325</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="326" href="#326">326</a>
<a class="l" name="327" href="#327">327</a>  <b>def</b> <a class="xf" name="testReferenceArgWithoutNames"/><a href="/googletest/s?refs=testReferenceArgWithoutNames&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testReferenceArgWithoutNames</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="328" href="#328">328</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="329" href="#329">329</a>class Foo {
<a class="hl" name="330" href="#330">330</a>  virtual int Bar(C&amp;);
<a class="l" name="331" href="#331">331</a>};
<a class="l" name="332" href="#332">332</a>"""</span>
<a class="l" name="333" href="#333">333</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="334" href="#334">334</a>        <span class="s">'MOCK_METHOD(int, Bar, (C&amp;), (override));'</span>,
<a class="l" name="335" href="#335">335</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="336" href="#336">336</a>
<a class="l" name="337" href="#337">337</a>  <b>def</b> <a class="xf" name="testArrayArgWithoutNames"/><a href="/googletest/s?refs=testArrayArgWithoutNames&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testArrayArgWithoutNames</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="338" href="#338">338</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="339" href="#339">339</a>class Foo {
<a class="hl" name="340" href="#340">340</a>  virtual int Bar(C[]);
<a class="l" name="341" href="#341">341</a>};
<a class="l" name="342" href="#342">342</a>"""</span>
<a class="l" name="343" href="#343">343</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(
<a class="l" name="344" href="#344">344</a>        <span class="s">'MOCK_METHOD(int, Bar, (C[]), (override));'</span>,
<a class="l" name="345" href="#345">345</a>        <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMethodSource" data-definition-place="defined-in-file">GenerateMethodSource</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="346" href="#346">346</a>
<a class="l" name="347" href="#347">347</a>
<a class="l" name="348" href="#348">348</a><b>class</b> <a class="xc" name="GenerateMocksTest"/><a href="/googletest/s?refs=GenerateMocksTest&amp;project=googletest" class="xc intelliWindow-symbol" data-definition-place="def">GenerateMocksTest</a>(<a class="d intelliWindow-symbol" href="#TestCase" data-definition-place="defined-in-file">TestCase</a>):
<a class="l" name="349" href="#349">349</a>
<a class="hl" name="350" href="#350">350</a>  @<a href="/googletest/s?defs=staticmethod&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">staticmethod</a>
<a class="l" name="351" href="#351">351</a>  <b>def</b> <a class="xmb" name="GenerateMocks"/><a href="/googletest/s?refs=GenerateMocks&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">GenerateMocks</a>(<a href="/googletest/s?defs=cpp_source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cpp_source</a>):
<a class="l" name="352" href="#352">352</a>    <span class="s">"""Convert C++ source to complete Google Mock output source."""</span>
<a class="l" name="353" href="#353">353</a>    <span class="c"># &lt;test&gt; is a pseudo-filename, it is not read or written.</span>
<a class="l" name="354" href="#354">354</a>    <a href="/googletest/s?defs=filename&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">filename</a> = <span class="s">'&lt;test&gt;'</span>
<a class="l" name="355" href="#355">355</a>    <a href="/googletest/s?defs=builder&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">builder</a> = <a class="d intelliWindow-symbol" href="#ast" data-definition-place="defined-in-file">ast</a>.<a href="/googletest/s?defs=BuilderFromSource&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">BuilderFromSource</a>(<a href="/googletest/s?defs=cpp_source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cpp_source</a>, <a href="/googletest/s?defs=filename&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">filename</a>)
<a class="l" name="356" href="#356">356</a>    <a href="/googletest/s?defs=ast_list&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ast_list</a> = <a href="/googletest/s?defs=list&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">list</a>(<a href="/googletest/s?defs=builder&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">builder</a>.<a href="/googletest/s?defs=Generate&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Generate</a>())
<a class="l" name="357" href="#357">357</a>    <a href="/googletest/s?defs=lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a> = <a class="d intelliWindow-symbol" href="#gmock_class" data-definition-place="defined-in-file">gmock_class</a>.<a href="/googletest/s?defs=_GenerateMocks&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">_GenerateMocks</a>(<a href="/googletest/s?defs=filename&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">filename</a>, <a href="/googletest/s?defs=cpp_source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cpp_source</a>, <a href="/googletest/s?defs=ast_list&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ast_list</a>, <b>None</b>)
<a class="l" name="358" href="#358">358</a>    <b>return</b> <span class="s">'\n'</span>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a href="/googletest/s?defs=lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a>)
<a class="l" name="359" href="#359">359</a>
<a class="hl" name="360" href="#360">360</a>  <b>def</b> <a class="xmb" name="testNamespaces"/><a href="/googletest/s?refs=testNamespaces&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testNamespaces</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="361" href="#361">361</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="362" href="#362">362</a>namespace Foo {
<a class="l" name="363" href="#363">363</a>namespace Bar { class Forward; }
<a class="l" name="364" href="#364">364</a>namespace Baz::Qux {
<a class="l" name="365" href="#365">365</a>
<a class="l" name="366" href="#366">366</a>class Test {
<a class="l" name="367" href="#367">367</a> public:
<a class="l" name="368" href="#368">368</a>  virtual void Foo();
<a class="l" name="369" href="#369">369</a>};
<a class="hl" name="370" href="#370">370</a>
<a class="l" name="371" href="#371">371</a>}  // namespace Baz::Qux
<a class="l" name="372" href="#372">372</a>}  // namespace Foo
<a class="l" name="373" href="#373">373</a>"""</span>
<a class="l" name="374" href="#374">374</a>    <a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a> = <span class="s">"""\
<a class="l" name="375" href="#375">375</a>namespace Foo {
<a class="l" name="376" href="#376">376</a>namespace Baz::Qux {
<a class="l" name="377" href="#377">377</a>
<a class="l" name="378" href="#378">378</a>class MockTest : public Test {
<a class="l" name="379" href="#379">379</a>public:
<a class="hl" name="380" href="#380">380</a>MOCK_METHOD(void, Foo, (), (override));
<a class="l" name="381" href="#381">381</a>};
<a class="l" name="382" href="#382">382</a>
<a class="l" name="383" href="#383">383</a>}  // namespace Baz::Qux
<a class="l" name="384" href="#384">384</a>}  // namespace Foo
<a class="l" name="385" href="#385">385</a>"""</span>
<a class="l" name="386" href="#386">386</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(<a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>,
<a class="l" name="387" href="#387">387</a>                                            <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMocks" data-definition-place="defined-in-file">GenerateMocks</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="388" href="#388">388</a>
<a class="l" name="389" href="#389">389</a>  <b>def</b> <a class="xf" name="testClassWithStorageSpecifierMacro"/><a href="/googletest/s?refs=testClassWithStorageSpecifierMacro&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testClassWithStorageSpecifierMacro</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="hl" name="390" href="#390">390</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="391" href="#391">391</a>class STORAGE_SPECIFIER Test {
<a class="l" name="392" href="#392">392</a> public:
<a class="l" name="393" href="#393">393</a>  virtual void Foo();
<a class="l" name="394" href="#394">394</a>};
<a class="l" name="395" href="#395">395</a>"""</span>
<a class="l" name="396" href="#396">396</a>    <a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a> = <span class="s">"""\
<a class="l" name="397" href="#397">397</a>class MockTest : public Test {
<a class="l" name="398" href="#398">398</a>public:
<a class="l" name="399" href="#399">399</a>MOCK_METHOD(void, Foo, (), (override));
<a class="hl" name="400" href="#400">400</a>};
<a class="l" name="401" href="#401">401</a>"""</span>
<a class="l" name="402" href="#402">402</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(<a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>,
<a class="l" name="403" href="#403">403</a>                                            <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMocks" data-definition-place="defined-in-file">GenerateMocks</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="404" href="#404">404</a>
<a class="l" name="405" href="#405">405</a>  <b>def</b> <a class="xf" name="testTemplatedForwardDeclaration"/><a href="/googletest/s?refs=testTemplatedForwardDeclaration&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testTemplatedForwardDeclaration</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="406" href="#406">406</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="407" href="#407">407</a>template &lt;class T&gt; class Forward;  // Forward declaration should be ignored.
<a class="l" name="408" href="#408">408</a>class Test {
<a class="l" name="409" href="#409">409</a> public:
<a class="hl" name="410" href="#410">410</a>  virtual void Foo();
<a class="l" name="411" href="#411">411</a>};
<a class="l" name="412" href="#412">412</a>"""</span>
<a class="l" name="413" href="#413">413</a>    <a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a> = <span class="s">"""\
<a class="l" name="414" href="#414">414</a>class MockTest : public Test {
<a class="l" name="415" href="#415">415</a>public:
<a class="l" name="416" href="#416">416</a>MOCK_METHOD(void, Foo, (), (override));
<a class="l" name="417" href="#417">417</a>};
<a class="l" name="418" href="#418">418</a>"""</span>
<a class="l" name="419" href="#419">419</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(<a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>,
<a class="hl" name="420" href="#420">420</a>                                            <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMocks" data-definition-place="defined-in-file">GenerateMocks</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="421" href="#421">421</a>
<a class="l" name="422" href="#422">422</a>  <b>def</b> <a class="xf" name="testTemplatedClass"/><a href="/googletest/s?refs=testTemplatedClass&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testTemplatedClass</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="423" href="#423">423</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="424" href="#424">424</a>template &lt;typename S, typename T&gt;
<a class="l" name="425" href="#425">425</a>class Test {
<a class="l" name="426" href="#426">426</a> public:
<a class="l" name="427" href="#427">427</a>  virtual void Foo();
<a class="l" name="428" href="#428">428</a>};
<a class="l" name="429" href="#429">429</a>"""</span>
<a class="hl" name="430" href="#430">430</a>    <a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a> = <span class="s">"""\
<a class="l" name="431" href="#431">431</a>template &lt;typename T0, typename T1&gt;
<a class="l" name="432" href="#432">432</a>class MockTest : public Test&lt;T0, T1&gt; {
<a class="l" name="433" href="#433">433</a>public:
<a class="l" name="434" href="#434">434</a>MOCK_METHOD(void, Foo, (), (override));
<a class="l" name="435" href="#435">435</a>};
<a class="l" name="436" href="#436">436</a>"""</span>
<a class="l" name="437" href="#437">437</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(<a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>,
<a class="l" name="438" href="#438">438</a>                                            <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMocks" data-definition-place="defined-in-file">GenerateMocks</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="439" href="#439">439</a>
<a class="hl" name="440" href="#440">440</a>  <b>def</b> <a class="xf" name="testTemplateInATemplateTypedef"/><a href="/googletest/s?refs=testTemplateInATemplateTypedef&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testTemplateInATemplateTypedef</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="441" href="#441">441</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="442" href="#442">442</a>class Test {
<a class="l" name="443" href="#443">443</a> public:
<a class="l" name="444" href="#444">444</a>  typedef std::vector&lt;std::list&lt;int&gt;&gt; FooType;
<a class="l" name="445" href="#445">445</a>  virtual void Bar(const FooType&amp; test_arg);
<a class="l" name="446" href="#446">446</a>};
<a class="l" name="447" href="#447">447</a>"""</span>
<a class="l" name="448" href="#448">448</a>    <a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a> = <span class="s">"""\
<a class="l" name="449" href="#449">449</a>class MockTest : public Test {
<a class="hl" name="450" href="#450">450</a>public:
<a class="l" name="451" href="#451">451</a>MOCK_METHOD(void, Bar, (const FooType&amp; test_arg), (override));
<a class="l" name="452" href="#452">452</a>};
<a class="l" name="453" href="#453">453</a>"""</span>
<a class="l" name="454" href="#454">454</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(<a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>,
<a class="l" name="455" href="#455">455</a>                                            <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMocks" data-definition-place="defined-in-file">GenerateMocks</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="456" href="#456">456</a>
<a class="l" name="457" href="#457">457</a>  <b>def</b> <a class="xf" name="testTemplateInATemplateTypedefWithComma"/><a href="/googletest/s?refs=testTemplateInATemplateTypedefWithComma&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testTemplateInATemplateTypedefWithComma</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="458" href="#458">458</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="459" href="#459">459</a>class Test {
<a class="hl" name="460" href="#460">460</a> public:
<a class="l" name="461" href="#461">461</a>  typedef std::function&lt;void(
<a class="l" name="462" href="#462">462</a>      const vector&lt;std::list&lt;int&gt;&gt;&amp;, int&gt; FooType;
<a class="l" name="463" href="#463">463</a>  virtual void Bar(const FooType&amp; test_arg);
<a class="l" name="464" href="#464">464</a>};
<a class="l" name="465" href="#465">465</a>"""</span>
<a class="l" name="466" href="#466">466</a>    <a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a> = <span class="s">"""\
<a class="l" name="467" href="#467">467</a>class MockTest : public Test {
<a class="l" name="468" href="#468">468</a>public:
<a class="l" name="469" href="#469">469</a>MOCK_METHOD(void, Bar, (const FooType&amp; test_arg), (override));
<a class="hl" name="470" href="#470">470</a>};
<a class="l" name="471" href="#471">471</a>"""</span>
<a class="l" name="472" href="#472">472</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(<a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>,
<a class="l" name="473" href="#473">473</a>                                            <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMocks" data-definition-place="defined-in-file">GenerateMocks</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="474" href="#474">474</a>
<a class="l" name="475" href="#475">475</a>  <b>def</b> <a class="xf" name="testParenthesizedCommaInArg"/><a href="/googletest/s?refs=testParenthesizedCommaInArg&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testParenthesizedCommaInArg</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="476" href="#476">476</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="477" href="#477">477</a>class Test {
<a class="l" name="478" href="#478">478</a> public:
<a class="l" name="479" href="#479">479</a>   virtual void Bar(std::function&lt;void(int, int)&gt; f);
<a class="hl" name="480" href="#480">480</a>};
<a class="l" name="481" href="#481">481</a>"""</span>
<a class="l" name="482" href="#482">482</a>    <a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a> = <span class="s">"""\
<a class="l" name="483" href="#483">483</a>class MockTest : public Test {
<a class="l" name="484" href="#484">484</a>public:
<a class="l" name="485" href="#485">485</a>MOCK_METHOD(void, Bar, (std::function&lt;void(int, int)&gt; f), (override));
<a class="l" name="486" href="#486">486</a>};
<a class="l" name="487" href="#487">487</a>"""</span>
<a class="l" name="488" href="#488">488</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(<a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>,
<a class="l" name="489" href="#489">489</a>                                            <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMocks" data-definition-place="defined-in-file">GenerateMocks</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="hl" name="490" href="#490">490</a>
<a class="l" name="491" href="#491">491</a>  <b>def</b> <a class="xf" name="testEnumType"/><a href="/googletest/s?refs=testEnumType&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testEnumType</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="492" href="#492">492</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="493" href="#493">493</a>class Test {
<a class="l" name="494" href="#494">494</a> public:
<a class="l" name="495" href="#495">495</a>  enum Bar {
<a class="l" name="496" href="#496">496</a>    BAZ, QUX, QUUX, QUUUX
<a class="l" name="497" href="#497">497</a>  };
<a class="l" name="498" href="#498">498</a>  virtual void Foo();
<a class="l" name="499" href="#499">499</a>};
<a class="hl" name="500" href="#500">500</a>"""</span>
<a class="l" name="501" href="#501">501</a>    <a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a> = <span class="s">"""\
<a class="l" name="502" href="#502">502</a>class MockTest : public Test {
<a class="l" name="503" href="#503">503</a>public:
<a class="l" name="504" href="#504">504</a>MOCK_METHOD(void, Foo, (), (override));
<a class="l" name="505" href="#505">505</a>};
<a class="l" name="506" href="#506">506</a>"""</span>
<a class="l" name="507" href="#507">507</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(<a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>,
<a class="l" name="508" href="#508">508</a>                                            <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMocks" data-definition-place="defined-in-file">GenerateMocks</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="509" href="#509">509</a>
<a class="hl" name="510" href="#510">510</a>  <b>def</b> <a class="xf" name="testEnumClassType"/><a href="/googletest/s?refs=testEnumClassType&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testEnumClassType</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="511" href="#511">511</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="512" href="#512">512</a>class Test {
<a class="l" name="513" href="#513">513</a> public:
<a class="l" name="514" href="#514">514</a>  enum class Bar {
<a class="l" name="515" href="#515">515</a>    BAZ, QUX, QUUX, QUUUX
<a class="l" name="516" href="#516">516</a>  };
<a class="l" name="517" href="#517">517</a>  virtual void Foo();
<a class="l" name="518" href="#518">518</a>};
<a class="l" name="519" href="#519">519</a>"""</span>
<a class="hl" name="520" href="#520">520</a>    <a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a> = <span class="s">"""\
<a class="l" name="521" href="#521">521</a>class MockTest : public Test {
<a class="l" name="522" href="#522">522</a>public:
<a class="l" name="523" href="#523">523</a>MOCK_METHOD(void, Foo, (), (override));
<a class="l" name="524" href="#524">524</a>};
<a class="l" name="525" href="#525">525</a>"""</span>
<a class="l" name="526" href="#526">526</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(<a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>,
<a class="l" name="527" href="#527">527</a>                                            <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMocks" data-definition-place="defined-in-file">GenerateMocks</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="528" href="#528">528</a>
<a class="l" name="529" href="#529">529</a>  <b>def</b> <a class="xf" name="testStdFunction"/><a href="/googletest/s?refs=testStdFunction&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">testStdFunction</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="hl" name="530" href="#530">530</a>    <a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a> = <span class="s">"""
<a class="l" name="531" href="#531">531</a>class Test {
<a class="l" name="532" href="#532">532</a> public:
<a class="l" name="533" href="#533">533</a>  Test(std::function&lt;int(std::string)&gt; foo) : foo_(foo) {}
<a class="l" name="534" href="#534">534</a>
<a class="l" name="535" href="#535">535</a>  virtual std::function&lt;int(std::string)&gt; foo();
<a class="l" name="536" href="#536">536</a>
<a class="l" name="537" href="#537">537</a> private:
<a class="l" name="538" href="#538">538</a>  std::function&lt;int(std::string)&gt; foo_;
<a class="l" name="539" href="#539">539</a>};
<a class="hl" name="540" href="#540">540</a>"""</span>
<a class="l" name="541" href="#541">541</a>    <a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a> = <span class="s">"""\
<a class="l" name="542" href="#542">542</a>class MockTest : public Test {
<a class="l" name="543" href="#543">543</a>public:
<a class="l" name="544" href="#544">544</a>MOCK_METHOD(std::function&lt;int (std::string)&gt;, foo, (), (override));
<a class="l" name="545" href="#545">545</a>};
<a class="l" name="546" href="#546">546</a>"""</span>
<a class="l" name="547" href="#547">547</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#assertEqualIgnoreLeadingWhitespace" data-definition-place="defined-in-file">assertEqualIgnoreLeadingWhitespace</a>(<a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>,
<a class="l" name="548" href="#548">548</a>                                            <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#GenerateMocks" data-definition-place="defined-in-file">GenerateMocks</a>(<a href="/googletest/s?defs=source&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">source</a>))
<a class="l" name="549" href="#549">549</a>
<a class="hl" name="550" href="#550">550</a>
<a class="l" name="551" href="#551">551</a><b>if</b> <a href="/googletest/s?defs=__name__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__name__</a> == <span class="s">'__main__'</span>:
<a class="l" name="552" href="#552">552</a>  <a class="d intelliWindow-symbol" href="#unittest" data-definition-place="defined-in-file">unittest</a>.<a href="/googletest/s?defs=main&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">main</a>()
<a class="l" name="553" href="#553">553</a>