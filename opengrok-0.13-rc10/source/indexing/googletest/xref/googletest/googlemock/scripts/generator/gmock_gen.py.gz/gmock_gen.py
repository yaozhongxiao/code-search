<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Namespace","xn",[["gmock_class",27],["os",20],["sys",21]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/googletest/s?path=/usr/">usr</a>/<a href="/googletest/s?path=/usr/bin/">bin</a>/<a href="/googletest/s?path=/usr/bin/env">env</a> python</span>
<a class="l" name="2" href="#2">2</a><span class="c">#</span>
<a class="l" name="3" href="#3">3</a><span class="c"># Copyright 2008 Google Inc. All Rights Reserved.</span>
<a class="l" name="4" href="#4">4</a><span class="c">#</span>
<a class="l" name="5" href="#5">5</a><span class="c"># Licensed under the Apache License, Version 2.0 (the "License");</span>
<a class="l" name="6" href="#6">6</a><span class="c"># you may not use this file except in compliance with the License.</span>
<a class="l" name="7" href="#7">7</a><span class="c"># You may obtain a copy of the License at</span>
<a class="l" name="8" href="#8">8</a><span class="c">#</span>
<a class="l" name="9" href="#9">9</a><span class="c">#      <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a></span>
<a class="hl" name="10" href="#10">10</a><span class="c">#</span>
<a class="l" name="11" href="#11">11</a><span class="c"># Unless required by applicable law or agreed to in writing, software</span>
<a class="l" name="12" href="#12">12</a><span class="c"># distributed under the License is distributed on an "AS IS" BASIS,</span>
<a class="l" name="13" href="#13">13</a><span class="c"># WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.</span>
<a class="l" name="14" href="#14">14</a><span class="c"># See the License for the specific language governing permissions and</span>
<a class="l" name="15" href="#15">15</a><span class="c"># limitations under the License.</span>
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a><span class="s">"""Driver for starting up Google Mock class generator."""</span>
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a><b>import</b> <a class="xn" name="os"/><a href="/googletest/s?refs=os&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">os</a>
<a class="l" name="21" href="#21">21</a><b>import</b> <a class="xn" name="sys"/><a href="/googletest/s?refs=sys&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">sys</a>
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a><b>if</b> <a href="/googletest/s?defs=__name__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__name__</a> == <span class="s">'__main__'</span>:
<a class="l" name="24" href="#24">24</a>  <span class="c"># Add the directory of this script to the path so we can import gmock_class.</span>
<a class="l" name="25" href="#25">25</a>  <a class="d intelliWindow-symbol" href="#sys" data-definition-place="defined-in-file">sys</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=append&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">append</a>(<a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=dirname&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">dirname</a>(<a href="/googletest/s?defs=__file__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__file__</a>))
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a>  <b>from</b> <a href="/googletest/s?defs=cpp&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cpp</a> <b>import</b> <a class="xn" name="gmock_class"/><a href="/googletest/s?refs=gmock_class&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">gmock_class</a>
<a class="l" name="28" href="#28">28</a>  <span class="c"># Fix the docstring in case they require the usage.</span>
<a class="l" name="29" href="#29">29</a>  <a class="d intelliWindow-symbol" href="#gmock_class" data-definition-place="defined-in-file">gmock_class</a>.<a href="/googletest/s?defs=__doc__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__doc__</a> = <a class="d intelliWindow-symbol" href="#gmock_class" data-definition-place="defined-in-file">gmock_class</a>.<a href="/googletest/s?defs=__doc__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__doc__</a>.<a href="/googletest/s?defs=replace&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">replace</a>(<span class="s">'<a href="/googletest/s?path=gmock_class.py&amp;project=googletest">gmock_class.py</a>'</span>, <a href="/googletest/s?defs=__file__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__file__</a>)
<a class="hl" name="30" href="#30">30</a>  <a class="d intelliWindow-symbol" href="#gmock_class" data-definition-place="defined-in-file">gmock_class</a>.<a href="/googletest/s?defs=main&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">main</a>()
<a class="l" name="31" href="#31">31</a>