<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># gMock Cheat Sheet
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>&lt;!-- GOOGLETEST_CM0019 DO NOT DELETE --&gt;
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>&lt;!-- GOOGLETEST_CM0035 DO NOT DELETE --&gt;
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>&lt;!-- GOOGLETEST_CM0033 DO NOT DELETE --&gt;
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>## Defining a Mock Class
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a>### Mocking a Normal Class {#MockClass}
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a>Given
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a>```cpp
<a class="l" name="16" href="#16">16</a>class Foo {
<a class="l" name="17" href="#17">17</a>  ...
<a class="l" name="18" href="#18">18</a>  virtual ~Foo();
<a class="l" name="19" href="#19">19</a>  virtual int GetSize() const = 0;
<a class="hl" name="20" href="#20">20</a>  virtual string Describe(const char* name) = 0;
<a class="l" name="21" href="#21">21</a>  virtual string Describe(int type) = 0;
<a class="l" name="22" href="#22">22</a>  virtual bool Process(Bar elem, int count) = 0;
<a class="l" name="23" href="#23">23</a>};
<a class="l" name="24" href="#24">24</a>```
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a>(note that `~Foo()` **must** be virtual) we can define its mock as
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a>```cpp
<a class="l" name="29" href="#29">29</a>#include "<a href="/googletest/s?path=gmock/gmock.h&amp;project=googletest">gmock/gmock.h</a>"
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a>class MockFoo : public Foo {
<a class="l" name="32" href="#32">32</a>  ...
<a class="l" name="33" href="#33">33</a>  MOCK_METHOD(int, GetSize, (), (const, override));
<a class="l" name="34" href="#34">34</a>  MOCK_METHOD(string, Describe, (const char* name), (override));
<a class="l" name="35" href="#35">35</a>  MOCK_METHOD(string, Describe, (int type), (override));
<a class="l" name="36" href="#36">36</a>  MOCK_METHOD(bool, Process, (Bar elem, int count), (override));
<a class="l" name="37" href="#37">37</a>};
<a class="l" name="38" href="#38">38</a>```
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a>To create a "nice" mock, which ignores all uninteresting calls, a "naggy" mock,
<a class="l" name="41" href="#41">41</a>which warns on all uninteresting calls, or a "strict" mock, which treats them as
<a class="l" name="42" href="#42">42</a>failures:
<a class="l" name="43" href="#43">43</a>
<a class="l" name="44" href="#44">44</a>```cpp
<a class="l" name="45" href="#45">45</a>using ::testing::NiceMock;
<a class="l" name="46" href="#46">46</a>using ::testing::NaggyMock;
<a class="l" name="47" href="#47">47</a>using ::testing::StrictMock;
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>NiceMock&lt;MockFoo&gt; nice_foo;      // The type is a subclass of MockFoo.
<a class="hl" name="50" href="#50">50</a>NaggyMock&lt;MockFoo&gt; naggy_foo;    // The type is a subclass of MockFoo.
<a class="l" name="51" href="#51">51</a>StrictMock&lt;MockFoo&gt; strict_foo;  // The type is a subclass of MockFoo.
<a class="l" name="52" href="#52">52</a>```
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>**Note:** A mock object is currently naggy by default. We may make it nice by
<a class="l" name="55" href="#55">55</a>default in the future.
<a class="l" name="56" href="#56">56</a>
<a class="l" name="57" href="#57">57</a>### Mocking a Class Template {#MockTemplate}
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>Class templates can be mocked just like any class.
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a>To mock
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>```cpp
<a class="l" name="64" href="#64">64</a>template &lt;typename Elem&gt;
<a class="l" name="65" href="#65">65</a>class StackInterface {
<a class="l" name="66" href="#66">66</a>  ...
<a class="l" name="67" href="#67">67</a>  virtual ~StackInterface();
<a class="l" name="68" href="#68">68</a>  virtual int GetSize() const = 0;
<a class="l" name="69" href="#69">69</a>  virtual void Push(const Elem&amp; x) = 0;
<a class="hl" name="70" href="#70">70</a>};
<a class="l" name="71" href="#71">71</a>```
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>(note that all member functions that are mocked, including `~StackInterface()`
<a class="l" name="74" href="#74">74</a>**must** be virtual).
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a>```cpp
<a class="l" name="77" href="#77">77</a>template &lt;typename Elem&gt;
<a class="l" name="78" href="#78">78</a>class MockStack : public StackInterface&lt;Elem&gt; {
<a class="l" name="79" href="#79">79</a>  ...
<a class="hl" name="80" href="#80">80</a>  MOCK_METHOD(int, GetSize, (), (const, override));
<a class="l" name="81" href="#81">81</a>  MOCK_METHOD(void, Push, (const Elem&amp; x), (override));
<a class="l" name="82" href="#82">82</a>};
<a class="l" name="83" href="#83">83</a>```
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>### Specifying Calling Conventions for Mock Functions
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>If your mock function doesn't use the default calling convention, you can
<a class="l" name="88" href="#88">88</a>specify it by adding `Calltype(convention)` to `MOCK_METHOD`'s 4th parameter.
<a class="l" name="89" href="#89">89</a>For example,
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>```cpp
<a class="l" name="92" href="#92">92</a>  MOCK_METHOD(bool, Foo, (int n), (Calltype(STDMETHODCALLTYPE)));
<a class="l" name="93" href="#93">93</a>  MOCK_METHOD(int, Bar, (double x, double y),
<a class="l" name="94" href="#94">94</a>              (const, Calltype(STDMETHODCALLTYPE)));
<a class="l" name="95" href="#95">95</a>```
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>where `STDMETHODCALLTYPE` is defined by `&lt;<a href="/googletest/s?path=objbase.h&amp;project=googletest">objbase.h</a>&gt;` on Windows.
<a class="l" name="98" href="#98">98</a>
<a class="l" name="99" href="#99">99</a>## Using Mocks in Tests {#UsingMocks}
<a class="hl" name="100" href="#100">100</a>
<a class="l" name="101" href="#101">101</a>The typical work flow is:
<a class="l" name="102" href="#102">102</a>
<a class="l" name="103" href="#103">103</a>1.  Import the gMock names you need to use. All gMock symbols are in the
<a class="l" name="104" href="#104">104</a>    `testing` namespace unless they are macros or otherwise noted.
<a class="l" name="105" href="#105">105</a>2.  Create the mock objects.
<a class="l" name="106" href="#106">106</a>3.  Optionally, set the default actions of the mock objects.
<a class="l" name="107" href="#107">107</a>4.  Set your expectations on the mock objects (How will they be called? What
<a class="l" name="108" href="#108">108</a>    will they do?).
<a class="l" name="109" href="#109">109</a>5.  Exercise code that uses the mock objects; if necessary, check the result
<a class="hl" name="110" href="#110">110</a>    using googletest assertions.
<a class="l" name="111" href="#111">111</a>6.  When a mock object is destructed, gMock automatically verifies that all
<a class="l" name="112" href="#112">112</a>    expectations on it have been satisfied.
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>Here's an example:
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>```cpp
<a class="l" name="117" href="#117">117</a>using ::testing::Return;                          // #1
<a class="l" name="118" href="#118">118</a>
<a class="l" name="119" href="#119">119</a>TEST(BarTest, DoesThis) {
<a class="hl" name="120" href="#120">120</a>  MockFoo foo;                                    // #2
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>  ON_CALL(foo, GetSize())                         // #3
<a class="l" name="123" href="#123">123</a>      .WillByDefault(Return(1));
<a class="l" name="124" href="#124">124</a>  // ... other default actions ...
<a class="l" name="125" href="#125">125</a>
<a class="l" name="126" href="#126">126</a>  EXPECT_CALL(foo, Describe(5))                   // #4
<a class="l" name="127" href="#127">127</a>      .Times(3)
<a class="l" name="128" href="#128">128</a>      .WillRepeatedly(Return("Category 5"));
<a class="l" name="129" href="#129">129</a>  // ... other expectations ...
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a>  EXPECT_EQ("good", MyProductionFunction(&amp;foo));  // #5
<a class="l" name="132" href="#132">132</a>}                                                 // #6
<a class="l" name="133" href="#133">133</a>```
<a class="l" name="134" href="#134">134</a>
<a class="l" name="135" href="#135">135</a>## Setting Default Actions {#OnCall}
<a class="l" name="136" href="#136">136</a>
<a class="l" name="137" href="#137">137</a>gMock has a **built-in default action** for any function that returns `void`,
<a class="l" name="138" href="#138">138</a>`bool`, a numeric value, or a pointer. In C++11, it will additionally returns
<a class="l" name="139" href="#139">139</a>the default-constructed value, if one exists for the given type.
<a class="hl" name="140" href="#140">140</a>
<a class="l" name="141" href="#141">141</a>To customize the default action for functions with return type *`T`*:
<a class="l" name="142" href="#142">142</a>
<a class="l" name="143" href="#143">143</a>```cpp
<a class="l" name="144" href="#144">144</a>using ::testing::DefaultValue;
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>// Sets the default value to be returned. T must be CopyConstructible.
<a class="l" name="147" href="#147">147</a>DefaultValue&lt;T&gt;::Set(value);
<a class="l" name="148" href="#148">148</a>// Sets a factory. Will be invoked on demand. T must be MoveConstructible.
<a class="l" name="149" href="#149">149</a>//  T MakeT();
<a class="hl" name="150" href="#150">150</a>DefaultValue&lt;T&gt;::SetFactory(&amp;MakeT);
<a class="l" name="151" href="#151">151</a>// ... use the mocks ...
<a class="l" name="152" href="#152">152</a>// Resets the default value.
<a class="l" name="153" href="#153">153</a>DefaultValue&lt;T&gt;::Clear();
<a class="l" name="154" href="#154">154</a>```
<a class="l" name="155" href="#155">155</a>
<a class="l" name="156" href="#156">156</a>Example usage:
<a class="l" name="157" href="#157">157</a>
<a class="l" name="158" href="#158">158</a>```cpp
<a class="l" name="159" href="#159">159</a>  // Sets the default action for return type std::unique_ptr&lt;Buzz&gt; to
<a class="hl" name="160" href="#160">160</a>  // creating a new Buzz every time.
<a class="l" name="161" href="#161">161</a>  DefaultValue&lt;std::unique_ptr&lt;Buzz&gt;&gt;::SetFactory(
<a class="l" name="162" href="#162">162</a>      [] { return MakeUnique&lt;Buzz&gt;(AccessLevel::kInternal); });
<a class="l" name="163" href="#163">163</a>
<a class="l" name="164" href="#164">164</a>  // When this fires, the default action of MakeBuzz() will run, which
<a class="l" name="165" href="#165">165</a>  // will return a new Buzz object.
<a class="l" name="166" href="#166">166</a>  EXPECT_CALL(mock_buzzer_, MakeBuzz("hello")).Times(AnyNumber());
<a class="l" name="167" href="#167">167</a>
<a class="l" name="168" href="#168">168</a>  auto buzz1 = <a href="/googletest/s?path=mock_buzzer_.MakeBuzz&amp;project=googletest">mock_buzzer_.MakeBuzz</a>("hello");
<a class="l" name="169" href="#169">169</a>  auto buzz2 = <a href="/googletest/s?path=mock_buzzer_.MakeBuzz&amp;project=googletest">mock_buzzer_.MakeBuzz</a>("hello");
<a class="hl" name="170" href="#170">170</a>  EXPECT_NE(nullptr, buzz1);
<a class="l" name="171" href="#171">171</a>  EXPECT_NE(nullptr, buzz2);
<a class="l" name="172" href="#172">172</a>  EXPECT_NE(buzz1, buzz2);
<a class="l" name="173" href="#173">173</a>
<a class="l" name="174" href="#174">174</a>  // Resets the default action for return type std::unique_ptr&lt;Buzz&gt;,
<a class="l" name="175" href="#175">175</a>  // to avoid interfere with other tests.
<a class="l" name="176" href="#176">176</a>  DefaultValue&lt;std::unique_ptr&lt;Buzz&gt;&gt;::Clear();
<a class="l" name="177" href="#177">177</a>```
<a class="l" name="178" href="#178">178</a>
<a class="l" name="179" href="#179">179</a>To customize the default action for a particular method of a specific mock
<a class="hl" name="180" href="#180">180</a>object, use `ON_CALL()`. `ON_CALL()` has a similar syntax to `EXPECT_CALL()`,
<a class="l" name="181" href="#181">181</a>but it is used for setting default behaviors (when you do not require that the
<a class="l" name="182" href="#182">182</a>mock method is called). See [here](<a href="/googletest/s?path=cook_book.md&amp;project=googletest">cook_book.md</a>#UseOnCall) for a more detailed
<a class="l" name="183" href="#183">183</a>discussion.
<a class="l" name="184" href="#184">184</a>
<a class="l" name="185" href="#185">185</a>```cpp
<a class="l" name="186" href="#186">186</a>ON_CALL(mock-object, method(matchers))
<a class="l" name="187" href="#187">187</a>    .With(multi-argument-matcher)   ?
<a class="l" name="188" href="#188">188</a>    .WillByDefault(action);
<a class="l" name="189" href="#189">189</a>```
<a class="hl" name="190" href="#190">190</a>
<a class="l" name="191" href="#191">191</a>## Setting Expectations {#ExpectCall}
<a class="l" name="192" href="#192">192</a>
<a class="l" name="193" href="#193">193</a>`EXPECT_CALL()` sets **expectations** on a mock method (How will it be called?
<a class="l" name="194" href="#194">194</a>What will it do?):
<a class="l" name="195" href="#195">195</a>
<a class="l" name="196" href="#196">196</a>```cpp
<a class="l" name="197" href="#197">197</a>EXPECT_CALL(mock-object, method (matchers)?)
<a class="l" name="198" href="#198">198</a>     .With(multi-argument-matcher)  ?
<a class="l" name="199" href="#199">199</a>     .Times(cardinality)            ?
<a class="hl" name="200" href="#200">200</a>     .InSequence(sequences)         *
<a class="l" name="201" href="#201">201</a>     .After(expectations)           *
<a class="l" name="202" href="#202">202</a>     .WillOnce(action)              *
<a class="l" name="203" href="#203">203</a>     .WillRepeatedly(action)        ?
<a class="l" name="204" href="#204">204</a>     .RetiresOnSaturation();        ?
<a class="l" name="205" href="#205">205</a>```
<a class="l" name="206" href="#206">206</a>
<a class="l" name="207" href="#207">207</a>For each item above, `?` means it can be used at most once, while `*` means it
<a class="l" name="208" href="#208">208</a>can be used any number of times.
<a class="l" name="209" href="#209">209</a>
<a class="hl" name="210" href="#210">210</a>In order to pass, `EXPECT_CALL` must be used before the calls are actually made.
<a class="l" name="211" href="#211">211</a>
<a class="l" name="212" href="#212">212</a>The `(matchers)` is a comma-separated list of matchers that correspond to each
<a class="l" name="213" href="#213">213</a>of the arguments of `method`, and sets the expectation only for calls of
<a class="l" name="214" href="#214">214</a>`method` that matches all of the matchers.
<a class="l" name="215" href="#215">215</a>
<a class="l" name="216" href="#216">216</a>If `(matchers)` is omitted, the expectation is the same as if the matchers were
<a class="l" name="217" href="#217">217</a>set to anything matchers (for example, `(_, _, _, _)` for a four-arg method).
<a class="l" name="218" href="#218">218</a>
<a class="l" name="219" href="#219">219</a>If `Times()` is omitted, the cardinality is assumed to be:
<a class="hl" name="220" href="#220">220</a>
<a class="l" name="221" href="#221">221</a>*   `Times(1)` when there is neither `WillOnce()` nor `WillRepeatedly()`;
<a class="l" name="222" href="#222">222</a>*   `Times(n)` when there are `n` `WillOnce()`s but no `WillRepeatedly()`, where
<a class="l" name="223" href="#223">223</a>    `n` &gt;= 1; or
<a class="l" name="224" href="#224">224</a>*   `Times(AtLeast(n))` when there are `n` `WillOnce()`s and a
<a class="l" name="225" href="#225">225</a>    `WillRepeatedly()`, where `n` &gt;= 0.
<a class="l" name="226" href="#226">226</a>
<a class="l" name="227" href="#227">227</a>A method with no `EXPECT_CALL()` is free to be invoked *any number of times*,
<a class="l" name="228" href="#228">228</a>and the default action will be taken each time.
<a class="l" name="229" href="#229">229</a>
<a class="hl" name="230" href="#230">230</a>## Matchers {#MatcherList}
<a class="l" name="231" href="#231">231</a>
<a class="l" name="232" href="#232">232</a>&lt;!-- GOOGLETEST_CM0020 DO NOT DELETE --&gt;
<a class="l" name="233" href="#233">233</a>
<a class="l" name="234" href="#234">234</a>A **matcher** matches a *single* argument. You can use it inside `ON_CALL()` or
<a class="l" name="235" href="#235">235</a>`EXPECT_CALL()`, or use it to validate a value directly using two macros:
<a class="l" name="236" href="#236">236</a>
<a class="l" name="237" href="#237">237</a>&lt;!-- mdformat off(github rendering does not support multiline tables) --&gt;
<a class="l" name="238" href="#238">238</a>| Macro                                | Description                           |
<a class="l" name="239" href="#239">239</a>| :----------------------------------- | :------------------------------------ |
<a class="hl" name="240" href="#240">240</a>| `EXPECT_THAT(actual_value, matcher)` | Asserts that `actual_value` matches `matcher`. |
<a class="l" name="241" href="#241">241</a>| `ASSERT_THAT(actual_value, matcher)` | The same as `EXPECT_THAT(actual_value, matcher)`, except that it generates a **fatal** failure. |
<a class="l" name="242" href="#242">242</a>&lt;!-- mdformat on --&gt;
<a class="l" name="243" href="#243">243</a>
<a class="l" name="244" href="#244">244</a>**Note:** Although equality matching via `EXPECT_THAT(actual_value,
<a class="l" name="245" href="#245">245</a>expected_value)` is supported, prefer to make the comparison explicit via
<a class="l" name="246" href="#246">246</a>`EXPECT_THAT(actual_value, Eq(expected_value))` or `EXPECT_EQ(actual_value,
<a class="l" name="247" href="#247">247</a>expected_value)`.
<a class="l" name="248" href="#248">248</a>
<a class="l" name="249" href="#249">249</a>Built-in matchers (where `argument` is the function argument, <a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="hl" name="250" href="#250">250</a>`actual_value` in the example above, or when used in the context of
<a class="l" name="251" href="#251">251</a>`EXPECT_CALL(mock_object, method(matchers))`, the arguments of `method`) are
<a class="l" name="252" href="#252">252</a>divided into several categories:
<a class="l" name="253" href="#253">253</a>
<a class="l" name="254" href="#254">254</a>### Wildcard
<a class="l" name="255" href="#255">255</a>
<a class="l" name="256" href="#256">256</a>Matcher                     | Description
<a class="l" name="257" href="#257">257</a>:-------------------------- | :-----------------------------------------------
<a class="l" name="258" href="#258">258</a>`_`                         | `argument` can be any value of the correct type.
<a class="l" name="259" href="#259">259</a>`A&lt;type&gt;()` or `An&lt;type&gt;()` | `argument` can be any value of type `type`.
<a class="hl" name="260" href="#260">260</a>
<a class="l" name="261" href="#261">261</a>### Generic Comparison
<a class="l" name="262" href="#262">262</a>
<a class="l" name="263" href="#263">263</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="264" href="#264">264</a>| Matcher                | Description                                         |
<a class="l" name="265" href="#265">265</a>| :--------------------- | :-------------------------------------------------- |
<a class="l" name="266" href="#266">266</a>| `Eq(value)` or `value` | `argument == value`                                 |
<a class="l" name="267" href="#267">267</a>| `Ge(value)`            | `argument &gt;= value`                                 |
<a class="l" name="268" href="#268">268</a>| `Gt(value)`            | `argument &gt; value`                                  |
<a class="l" name="269" href="#269">269</a>| `Le(value)`            | `argument &lt;= value`                                 |
<a class="hl" name="270" href="#270">270</a>| `Lt(value)`            | `argument &lt; value`                                  |
<a class="l" name="271" href="#271">271</a>| `Ne(value)`            | `argument != value`                                 |
<a class="l" name="272" href="#272">272</a>| `IsFalse()`            | `argument` evaluates to `false` in a Boolean context. |
<a class="l" name="273" href="#273">273</a>| `IsTrue()`             | `argument` evaluates to `true` in a Boolean context. |
<a class="l" name="274" href="#274">274</a>| `IsNull()`             | `argument` is a `NULL` pointer (raw or smart).      |
<a class="l" name="275" href="#275">275</a>| `NotNull()`            | `argument` is a non-null pointer (raw or smart).    |
<a class="l" name="276" href="#276">276</a>| `Optional(m)`          | `argument` is `optional&lt;&gt;` that contains a value matching `m`. (For testing whether an `optional&lt;&gt;` is set, check for equality with `nullopt`. You may need to use `Eq(nullopt)` if the inner type doesn't have `==`.)|
<a class="l" name="277" href="#277">277</a>| `VariantWith&lt;T&gt;(m)`    | `argument` is `variant&lt;&gt;` that holds the alternative of type T with a value matching `m`. |
<a class="l" name="278" href="#278">278</a>| `Ref(variable)`        | `argument` is a reference to `variable`.            |
<a class="l" name="279" href="#279">279</a>| `TypedEq&lt;type&gt;(value)` | `argument` has type `type` and is equal to `value`. You may need to use this instead of `Eq(value)` when the mock function is overloaded. |
<a class="hl" name="280" href="#280">280</a>&lt;!-- mdformat on --&gt;
<a class="l" name="281" href="#281">281</a>
<a class="l" name="282" href="#282">282</a>Except `Ref()`, these matchers make a *copy* of `value` in case it's modified or
<a class="l" name="283" href="#283">283</a>destructed later. If the compiler complains that `value` doesn't have a public
<a class="l" name="284" href="#284">284</a>copy constructor, try wrap it in `std::ref()`, <a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="l" name="285" href="#285">285</a>`Eq(std::ref(non_copyable_value))`. If you do that, make sure
<a class="l" name="286" href="#286">286</a>`non_copyable_value` is not changed afterwards, or the meaning of your matcher
<a class="l" name="287" href="#287">287</a>will be changed.
<a class="l" name="288" href="#288">288</a>
<a class="l" name="289" href="#289">289</a>`IsTrue` and `IsFalse` are useful when you need to use a matcher, or for types
<a class="hl" name="290" href="#290">290</a>that can be explicitly converted to Boolean, but are not implicitly converted to
<a class="l" name="291" href="#291">291</a>Boolean. In other cases, you can use the basic
<a class="l" name="292" href="#292">292</a>[`EXPECT_TRUE` and `EXPECT_FALSE`](../..<a href="/googletest/s?path=/googletest/docs/primer&amp;project=googletest">/googletest/docs/primer</a>#basic-assertions)
<a class="l" name="293" href="#293">293</a>assertions.
<a class="l" name="294" href="#294">294</a>
<a class="l" name="295" href="#295">295</a>### Floating-Point Matchers {#FpMatchers}
<a class="l" name="296" href="#296">296</a>
<a class="l" name="297" href="#297">297</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="298" href="#298">298</a>| Matcher                          | Description                        |
<a class="l" name="299" href="#299">299</a>| :------------------------------- | :--------------------------------- |
<a class="hl" name="300" href="#300">300</a>| `DoubleEq(a_double)`             | `argument` is a `double` value approximately equal to `a_double`, treating two NaNs as unequal. |
<a class="l" name="301" href="#301">301</a>| `FloatEq(a_float)`               | `argument` is a `float` value approximately equal to `a_float`, treating two NaNs as unequal. |
<a class="l" name="302" href="#302">302</a>| `NanSensitiveDoubleEq(a_double)` | `argument` is a `double` value approximately equal to `a_double`, treating two NaNs as equal. |
<a class="l" name="303" href="#303">303</a>| `NanSensitiveFloatEq(a_float)`   | `argument` is a `float` value approximately equal to `a_float`, treating two NaNs as equal. |
<a class="l" name="304" href="#304">304</a>| `IsNan()`   | `argument` is any floating-point type with a NaN value. |
<a class="l" name="305" href="#305">305</a>&lt;!-- mdformat on --&gt;
<a class="l" name="306" href="#306">306</a>
<a class="l" name="307" href="#307">307</a>The above matchers use ULP-based comparison (the same as used in googletest).
<a class="l" name="308" href="#308">308</a>They automatically pick a reasonable error bound based on the absolute value of
<a class="l" name="309" href="#309">309</a>the expected value. `DoubleEq()` and `FloatEq()` conform to the IEEE standard,
<a class="hl" name="310" href="#310">310</a>which requires comparing two NaNs for equality to return false. The
<a class="l" name="311" href="#311">311</a>`NanSensitive*` version instead treats two NaNs as equal, which is often what a
<a class="l" name="312" href="#312">312</a>user wants.
<a class="l" name="313" href="#313">313</a>
<a class="l" name="314" href="#314">314</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="315" href="#315">315</a>| Matcher                                           | Description              |
<a class="l" name="316" href="#316">316</a>| :------------------------------------------------ | :----------------------- |
<a class="l" name="317" href="#317">317</a>| `DoubleNear(a_double, max_abs_error)`             | `argument` is a `double` value close to `a_double` (absolute error &lt;= `max_abs_error`), treating two NaNs as unequal. |
<a class="l" name="318" href="#318">318</a>| `FloatNear(a_float, max_abs_error)`               | `argument` is a `float` value close to `a_float` (absolute error &lt;= `max_abs_error`), treating two NaNs as unequal. |
<a class="l" name="319" href="#319">319</a>| `NanSensitiveDoubleNear(a_double, max_abs_error)` | `argument` is a `double` value close to `a_double` (absolute error &lt;= `max_abs_error`), treating two NaNs as equal. |
<a class="hl" name="320" href="#320">320</a>| `NanSensitiveFloatNear(a_float, max_abs_error)`   | `argument` is a `float` value close to `a_float` (absolute error &lt;= `max_abs_error`), treating two NaNs as equal. |
<a class="l" name="321" href="#321">321</a>&lt;!-- mdformat on --&gt;
<a class="l" name="322" href="#322">322</a>
<a class="l" name="323" href="#323">323</a>### String Matchers
<a class="l" name="324" href="#324">324</a>
<a class="l" name="325" href="#325">325</a>The `argument` can be either a C string or a C++ string object:
<a class="l" name="326" href="#326">326</a>
<a class="l" name="327" href="#327">327</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="328" href="#328">328</a>| Matcher                 | Description                                        |
<a class="l" name="329" href="#329">329</a>| :---------------------- | :------------------------------------------------- |
<a class="hl" name="330" href="#330">330</a>| `ContainsRegex(string)` | `argument` matches the given regular expression.   |
<a class="l" name="331" href="#331">331</a>| `EndsWith(suffix)`      | `argument` ends with string `suffix`.              |
<a class="l" name="332" href="#332">332</a>| `HasSubstr(string)`     | `argument` contains `string` as a sub-string.      |
<a class="l" name="333" href="#333">333</a>| `MatchesRegex(string)`  | `argument` matches the given regular expression with the match starting at the first character and ending at the last character. |
<a class="l" name="334" href="#334">334</a>| `StartsWith(prefix)`    | `argument` starts with string `prefix`.            |
<a class="l" name="335" href="#335">335</a>| `StrCaseEq(string)`     | `argument` is equal to `string`, ignoring case.    |
<a class="l" name="336" href="#336">336</a>| `StrCaseNe(string)`     | `argument` is not equal to `string`, ignoring case. |
<a class="l" name="337" href="#337">337</a>| `StrEq(string)`         | `argument` is equal to `string`.                   |
<a class="l" name="338" href="#338">338</a>| `StrNe(string)`         | `argument` is not equal to `string`.               |
<a class="l" name="339" href="#339">339</a>&lt;!-- mdformat on --&gt;
<a class="hl" name="340" href="#340">340</a>
<a class="l" name="341" href="#341">341</a>`ContainsRegex()` and `MatchesRegex()` take ownership of the `RE` object. They
<a class="l" name="342" href="#342">342</a>use the regular expression syntax defined
<a class="l" name="343" href="#343">343</a>[here](../..<a href="/googletest/s?path=/googletest/docs/advanced.md&amp;project=googletest">/googletest/docs/advanced.md</a>#regular-expression-syntax). All of
<a class="l" name="344" href="#344">344</a>these matchers, except `ContainsRegex()` and `MatchesRegex()` work for wide
<a class="l" name="345" href="#345">345</a>strings as well.
<a class="l" name="346" href="#346">346</a>
<a class="l" name="347" href="#347">347</a>### Container Matchers
<a class="l" name="348" href="#348">348</a>
<a class="l" name="349" href="#349">349</a>Most STL-style containers support `==`, so you can use `Eq(expected_container)`
<a class="hl" name="350" href="#350">350</a>or simply `expected_container` to match a container exactly. If you want to
<a class="l" name="351" href="#351">351</a>write the elements in-line, match them more flexibly, or get more informative
<a class="l" name="352" href="#352">352</a>messages, you can use:
<a class="l" name="353" href="#353">353</a>
<a class="l" name="354" href="#354">354</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="355" href="#355">355</a>| Matcher                                   | Description                      |
<a class="l" name="356" href="#356">356</a>| :---------------------------------------- | :------------------------------- |
<a class="l" name="357" href="#357">357</a>| `BeginEndDistanceIs(m)` | `argument` is a container whose `begin()` and `end()` iterators are separated by a number of increments matching `m`. <a href="/googletest/s?path=E.g.&amp;project=googletest">E.g.</a> `BeginEndDistanceIs(2)` or `BeginEndDistanceIs(Lt(2))`. For containers that define a `size()` method, `SizeIs(m)` may be more efficient. |
<a class="l" name="358" href="#358">358</a>| `ContainerEq(container)` | The same as `Eq(container)` except that the failure message also includes which elements are in one container but not the other. |
<a class="l" name="359" href="#359">359</a>| `Contains(e)` | `argument` contains an element that matches `e`, which can be either a value or a matcher. |
<a class="hl" name="360" href="#360">360</a>| `Each(e)` | `argument` is a container where *every* element matches `e`, which can be either a value or a matcher. |
<a class="l" name="361" href="#361">361</a>| `ElementsAre(e0, e1, ..., en)` | `argument` has `n + 1` elements, where the *i*-th element matches `ei`, which can be a value or a matcher. |
<a class="l" name="362" href="#362">362</a>| `ElementsAreArray({e0, e1, ..., en})`, `ElementsAreArray(a_container)`, `ElementsAreArray(begin, end)`, `ElementsAreArray(array)`, or `ElementsAreArray(array, count)` | The same as `ElementsAre()` except that the expected element <a href="/googletest/s?path=values/matchers&amp;project=googletest">values/matchers</a> come from an initializer list, STL-style container, iterator range, or C-style array. |
<a class="l" name="363" href="#363">363</a>| `IsEmpty()` | `argument` is an empty container (`<a href="/googletest/s?path=container.empty&amp;project=googletest">container.empty</a>()`). |
<a class="l" name="364" href="#364">364</a>| `IsSubsetOf({e0, e1, ..., en})`, `IsSubsetOf(a_container)`, `IsSubsetOf(begin, end)`, `IsSubsetOf(array)`, or `IsSubsetOf(array, count)` | `argument` matches `UnorderedElementsAre(x0, x1, ..., xk)` for some subset `{x0, x1, ..., xk}` of the expected matchers. |
<a class="l" name="365" href="#365">365</a>| `IsSupersetOf({e0, e1, ..., en})`, `IsSupersetOf(a_container)`, `IsSupersetOf(begin, end)`, `IsSupersetOf(array)`, or `IsSupersetOf(array, count)` | Some subset of `argument` matches `UnorderedElementsAre(`expected matchers`)`. |
<a class="l" name="366" href="#366">366</a>| `Pointwise(m, container)`, `Pointwise(m, {e0, e1, ..., en})` | `argument` contains the same number of elements as in `container`, and for all i, (the i-th element in `argument`, the i-th element in `container`) match `m`, which is a matcher on 2-tuples. <a href="/googletest/s?path=E.g.&amp;project=googletest">E.g.</a> `Pointwise(Le(), upper_bounds)` verifies that each element in `argument` doesn't exceed the corresponding element in `upper_bounds`. See more detail below. |
<a class="l" name="367" href="#367">367</a>| `SizeIs(m)` | `argument` is a container whose size matches `m`. <a href="/googletest/s?path=E.g.&amp;project=googletest">E.g.</a> `SizeIs(2)` or `SizeIs(Lt(2))`. |
<a class="l" name="368" href="#368">368</a>| `UnorderedElementsAre(e0, e1, ..., en)` | `argument` has `n + 1` elements, and under *some* permutation of the elements, each element matches an `ei` (for a different `i`), which can be a value or a matcher. |
<a class="l" name="369" href="#369">369</a>| `UnorderedElementsAreArray({e0, e1, ..., en})`, `UnorderedElementsAreArray(a_container)`, `UnorderedElementsAreArray(begin, end)`, `UnorderedElementsAreArray(array)`, or `UnorderedElementsAreArray(array, count)` | The same as `UnorderedElementsAre()` except that the expected element <a href="/googletest/s?path=values/matchers&amp;project=googletest">values/matchers</a> come from an initializer list, STL-style container, iterator range, or C-style array. |
<a class="hl" name="370" href="#370">370</a>| `UnorderedPointwise(m, container)`, `UnorderedPointwise(m, {e0, e1, ..., en})` | Like `Pointwise(m, container)`, but ignores the order of elements. |
<a class="l" name="371" href="#371">371</a>| `WhenSorted(m)` | When `argument` is sorted using the `&lt;` operator, it matches container matcher `m`. <a href="/googletest/s?path=E.g.&amp;project=googletest">E.g.</a> `WhenSorted(ElementsAre(1, 2, 3))` verifies that `argument` contains elements 1, 2, and 3, ignoring order. |
<a class="l" name="372" href="#372">372</a>| `WhenSortedBy(comparator, m)` | The same as `WhenSorted(m)`, except that the given comparator instead of `&lt;` is used to sort `argument`. <a href="/googletest/s?path=E.g.&amp;project=googletest">E.g.</a> `WhenSortedBy(std::greater(), ElementsAre(3, 2, 1))`. |
<a class="l" name="373" href="#373">373</a>&lt;!-- mdformat on --&gt;
<a class="l" name="374" href="#374">374</a>
<a class="l" name="375" href="#375">375</a>**Notes:**
<a class="l" name="376" href="#376">376</a>
<a class="l" name="377" href="#377">377</a>*   These matchers can also match:
<a class="l" name="378" href="#378">378</a>    1.  a native array passed by reference (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> in `Foo(const int (&amp;a)[5])`),
<a class="l" name="379" href="#379">379</a>        and
<a class="hl" name="380" href="#380">380</a>    2.  an array passed as a pointer and a count (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> in `Bar(const T* buffer,
<a class="l" name="381" href="#381">381</a>        int len)` -- see [Multi-argument Matchers](#MultiArgMatchers)).
<a class="l" name="382" href="#382">382</a>*   The array being matched may be multi-dimensional (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> its elements can be
<a class="l" name="383" href="#383">383</a>    arrays).
<a class="l" name="384" href="#384">384</a>*   `m` in `Pointwise(m, ...)` should be a matcher for `::std::tuple&lt;T, U&gt;`
<a class="l" name="385" href="#385">385</a>    where `T` and `U` are the element type of the actual container and the
<a class="l" name="386" href="#386">386</a>    expected container, respectively. For example, to compare two `Foo`
<a class="l" name="387" href="#387">387</a>    containers where `Foo` doesn't support `operator==`, one might write:
<a class="l" name="388" href="#388">388</a>
<a class="l" name="389" href="#389">389</a>    ```cpp
<a class="hl" name="390" href="#390">390</a>    using ::std::get;
<a class="l" name="391" href="#391">391</a>    MATCHER(FooEq, "") {
<a class="l" name="392" href="#392">392</a>      return std::get&lt;0&gt;(arg).Equals(std::get&lt;1&gt;(arg));
<a class="l" name="393" href="#393">393</a>    }
<a class="l" name="394" href="#394">394</a>    ...
<a class="l" name="395" href="#395">395</a>    EXPECT_THAT(actual_foos, Pointwise(FooEq(), expected_foos));
<a class="l" name="396" href="#396">396</a>    ```
<a class="l" name="397" href="#397">397</a>
<a class="l" name="398" href="#398">398</a>### Member Matchers
<a class="l" name="399" href="#399">399</a>
<a class="hl" name="400" href="#400">400</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="401" href="#401">401</a>| Matcher                         | Description                                |
<a class="l" name="402" href="#402">402</a>| :------------------------------ | :----------------------------------------- |
<a class="l" name="403" href="#403">403</a>| `Field(&amp;class::field, m)`       | `<a href="/googletest/s?path=argument.field&amp;project=googletest">argument.field</a>` (or `argument-&gt;field` when `argument` is a plain pointer) matches matcher `m`, where `argument` is an object of type _class_. |
<a class="l" name="404" href="#404">404</a>| `Key(e)`                        | `<a href="/googletest/s?path=argument.first&amp;project=googletest">argument.first</a>` matches `e`, which can be either a value or a matcher. <a href="/googletest/s?path=E.g.&amp;project=googletest">E.g.</a> `Contains(Key(Le(5)))` can verify that a `map` contains a key `&lt;= 5`. |
<a class="l" name="405" href="#405">405</a>| `Pair(m1, m2)`                  | `argument` is an `std::pair` whose `first` field matches `m1` and `second` field matches `m2`. |
<a class="l" name="406" href="#406">406</a>| `FieldsAre(m...)`                   | `argument` is a compatible object where each field matches piecewise with `m...`. A compatible object is any that supports the `std::tuple_size&lt;Obj&gt;`+`get&lt;I&gt;(obj)` protocol. In C++17 and up this also supports types compatible with structured bindings, like aggregates. |
<a class="l" name="407" href="#407">407</a>| `Property(&amp;class::property, m)` | `<a href="/googletest/s?path=argument.property&amp;project=googletest">argument.property</a>()` (or `argument-&gt;property()` when `argument` is a plain pointer) matches matcher `m`, where `argument` is an object of type _class_. |
<a class="l" name="408" href="#408">408</a>&lt;!-- mdformat on --&gt;
<a class="l" name="409" href="#409">409</a>
<a class="hl" name="410" href="#410">410</a>### Matching the Result of a Function, Functor, or Callback
<a class="l" name="411" href="#411">411</a>
<a class="l" name="412" href="#412">412</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="413" href="#413">413</a>| Matcher          | Description                                       |
<a class="l" name="414" href="#414">414</a>| :--------------- | :------------------------------------------------ |
<a class="l" name="415" href="#415">415</a>| `ResultOf(f, m)` | `f(argument)` matches matcher `m`, where `f` is a function or functor. |
<a class="l" name="416" href="#416">416</a>&lt;!-- mdformat on --&gt;
<a class="l" name="417" href="#417">417</a>
<a class="l" name="418" href="#418">418</a>### Pointer Matchers
<a class="l" name="419" href="#419">419</a>
<a class="hl" name="420" href="#420">420</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="421" href="#421">421</a>| Matcher                   | Description                                     |
<a class="l" name="422" href="#422">422</a>| :------------------------ | :---------------------------------------------- |
<a class="l" name="423" href="#423">423</a>| `Pointee(m)`              | `argument` (either a smart pointer or a raw pointer) points to a value that matches matcher `m`. |
<a class="l" name="424" href="#424">424</a>| `WhenDynamicCastTo&lt;T&gt;(m)` | when `argument` is passed through `dynamic_cast&lt;T&gt;()`, it matches matcher `m`. |
<a class="l" name="425" href="#425">425</a>&lt;!-- mdformat on --&gt;
<a class="l" name="426" href="#426">426</a>
<a class="l" name="427" href="#427">427</a>&lt;!-- GOOGLETEST_CM0026 DO NOT DELETE --&gt;
<a class="l" name="428" href="#428">428</a>
<a class="l" name="429" href="#429">429</a>&lt;!-- GOOGLETEST_CM0027 DO NOT DELETE --&gt;
<a class="hl" name="430" href="#430">430</a>
<a class="l" name="431" href="#431">431</a>### Multi-argument Matchers {#MultiArgMatchers}
<a class="l" name="432" href="#432">432</a>
<a class="l" name="433" href="#433">433</a>Technically, all matchers match a *single* value. A "multi-argument" matcher is
<a class="l" name="434" href="#434">434</a>just one that matches a *tuple*. The following matchers can be used to match a
<a class="l" name="435" href="#435">435</a>tuple `(x, y)`:
<a class="l" name="436" href="#436">436</a>
<a class="l" name="437" href="#437">437</a>Matcher | Description
<a class="l" name="438" href="#438">438</a>:------ | :----------
<a class="l" name="439" href="#439">439</a>`Eq()`  | `x == y`
<a class="hl" name="440" href="#440">440</a>`Ge()`  | `x &gt;= y`
<a class="l" name="441" href="#441">441</a>`Gt()`  | `x &gt; y`
<a class="l" name="442" href="#442">442</a>`Le()`  | `x &lt;= y`
<a class="l" name="443" href="#443">443</a>`Lt()`  | `x &lt; y`
<a class="l" name="444" href="#444">444</a>`Ne()`  | `x != y`
<a class="l" name="445" href="#445">445</a>
<a class="l" name="446" href="#446">446</a>You can use the following selectors to pick a subset of the arguments (or
<a class="l" name="447" href="#447">447</a>reorder them) to participate in the matching:
<a class="l" name="448" href="#448">448</a>
<a class="l" name="449" href="#449">449</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="hl" name="450" href="#450">450</a>| Matcher                    | Description                                     |
<a class="l" name="451" href="#451">451</a>| :------------------------- | :---------------------------------------------- |
<a class="l" name="452" href="#452">452</a>| `AllArgs(m)`               | Equivalent to `m`. Useful as syntactic sugar in `.With(AllArgs(m))`. |
<a class="l" name="453" href="#453">453</a>| `Args&lt;N1, N2, ..., Nk&gt;(m)` | The tuple of the `k` selected (using 0-based indices) arguments matches `m`, <a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `Args&lt;1, 2&gt;(Eq())`. |
<a class="l" name="454" href="#454">454</a>&lt;!-- mdformat on --&gt;
<a class="l" name="455" href="#455">455</a>
<a class="l" name="456" href="#456">456</a>### Composite Matchers
<a class="l" name="457" href="#457">457</a>
<a class="l" name="458" href="#458">458</a>You can make a matcher from one or more other matchers:
<a class="l" name="459" href="#459">459</a>
<a class="hl" name="460" href="#460">460</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="461" href="#461">461</a>| Matcher                          | Description                             |
<a class="l" name="462" href="#462">462</a>| :------------------------------- | :-------------------------------------- |
<a class="l" name="463" href="#463">463</a>| `AllOf(m1, m2, ..., mn)` | `argument` matches all of the matchers `m1` to `mn`. |
<a class="l" name="464" href="#464">464</a>| `AllOfArray({m0, m1, ..., mn})`, `AllOfArray(a_container)`, `AllOfArray(begin, end)`, `AllOfArray(array)`, or `AllOfArray(array, count)` | The same as `AllOf()` except that the matchers come from an initializer list, STL-style container, iterator range, or C-style array. |
<a class="l" name="465" href="#465">465</a>| `AnyOf(m1, m2, ..., mn)` | `argument` matches at least one of the matchers `m1` to `mn`. |
<a class="l" name="466" href="#466">466</a>| `AnyOfArray({m0, m1, ..., mn})`, `AnyOfArray(a_container)`, `AnyOfArray(begin, end)`, `AnyOfArray(array)`, or `AnyOfArray(array, count)` | The same as `AnyOf()` except that the matchers come from an initializer list, STL-style container, iterator range, or C-style array. |
<a class="l" name="467" href="#467">467</a>| `Not(m)` | `argument` doesn't match matcher `m`. |
<a class="l" name="468" href="#468">468</a>&lt;!-- mdformat on --&gt;
<a class="l" name="469" href="#469">469</a>
<a class="hl" name="470" href="#470">470</a>&lt;!-- GOOGLETEST_CM0028 DO NOT DELETE --&gt;
<a class="l" name="471" href="#471">471</a>
<a class="l" name="472" href="#472">472</a>### Adapters for Matchers
<a class="l" name="473" href="#473">473</a>
<a class="l" name="474" href="#474">474</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="475" href="#475">475</a>| Matcher                 | Description                           |
<a class="l" name="476" href="#476">476</a>| :---------------------- | :------------------------------------ |
<a class="l" name="477" href="#477">477</a>| `MatcherCast&lt;T&gt;(m)`     | casts matcher `m` to type `Matcher&lt;T&gt;`. |
<a class="l" name="478" href="#478">478</a>| `SafeMatcherCast&lt;T&gt;(m)` | [safely casts](<a href="/googletest/s?path=cook_book.md&amp;project=googletest">cook_book.md</a>#casting-matchers) matcher `m` to type `Matcher&lt;T&gt;`. |
<a class="l" name="479" href="#479">479</a>| `Truly(predicate)`      | `predicate(argument)` returns something considered by C++ to be true, where `predicate` is a function or functor. |
<a class="hl" name="480" href="#480">480</a>&lt;!-- mdformat on --&gt;
<a class="l" name="481" href="#481">481</a>
<a class="l" name="482" href="#482">482</a>`AddressSatisfies(callback)` and `Truly(callback)` take ownership of `callback`,
<a class="l" name="483" href="#483">483</a>which must be a permanent callback.
<a class="l" name="484" href="#484">484</a>
<a class="l" name="485" href="#485">485</a>### Using Matchers as Predicates {#MatchersAsPredicatesCheat}
<a class="l" name="486" href="#486">486</a>
<a class="l" name="487" href="#487">487</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="488" href="#488">488</a>| Matcher                       | Description                                 |
<a class="l" name="489" href="#489">489</a>| :---------------------------- | :------------------------------------------ |
<a class="hl" name="490" href="#490">490</a>| `Matches(m)(value)` | evaluates to `true` if `value` matches `m`. You can use `Matches(m)` alone as a unary functor. |
<a class="l" name="491" href="#491">491</a>| `ExplainMatchResult(m, value, result_listener)` | evaluates to `true` if `value` matches `m`, explaining the result to `result_listener`. |
<a class="l" name="492" href="#492">492</a>| `Value(value, m)` | evaluates to `true` if `value` matches `m`. |
<a class="l" name="493" href="#493">493</a>&lt;!-- mdformat on --&gt;
<a class="l" name="494" href="#494">494</a>
<a class="l" name="495" href="#495">495</a>### Defining Matchers
<a class="l" name="496" href="#496">496</a>
<a class="l" name="497" href="#497">497</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="498" href="#498">498</a>| Matcher                              | Description                           |
<a class="l" name="499" href="#499">499</a>| :----------------------------------- | :------------------------------------ |
<a class="hl" name="500" href="#500">500</a>| `MATCHER(IsEven, "") { return (arg % 2) == 0; }` | Defines a matcher `IsEven()` to match an even number. |
<a class="l" name="501" href="#501">501</a>| `MATCHER_P(IsDivisibleBy, n, "") { *result_listener &lt;&lt; "where the remainder is " &lt;&lt; (arg % n); return (arg % n) == 0; }` | Defines a matcher `IsDivisibleBy(n)` to match a number divisible by `n`. |
<a class="l" name="502" href="#502">502</a>| `MATCHER_P2(IsBetween, a, b, absl::StrCat(negation ? "isn't" : "is", " between ", PrintToString(a), " and ", PrintToString(b))) { return a &lt;= arg &amp;&amp; arg &lt;= b; }` | Defines a matcher `IsBetween(a, b)` to match a value in the range [`a`, `b`]. |
<a class="l" name="503" href="#503">503</a>&lt;!-- mdformat on --&gt;
<a class="l" name="504" href="#504">504</a>
<a class="l" name="505" href="#505">505</a>**Notes:**
<a class="l" name="506" href="#506">506</a>
<a class="l" name="507" href="#507">507</a>1.  The `MATCHER*` macros cannot be used inside a function or class.
<a class="l" name="508" href="#508">508</a>2.  The matcher body must be *purely functional* (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> it cannot have any side
<a class="l" name="509" href="#509">509</a>    effect, and the result must not depend on anything other than the value
<a class="hl" name="510" href="#510">510</a>    being matched and the matcher parameters).
<a class="l" name="511" href="#511">511</a>3.  You can use `PrintToString(x)` to convert a value `x` of any type to a
<a class="l" name="512" href="#512">512</a>    string.
<a class="l" name="513" href="#513">513</a>
<a class="l" name="514" href="#514">514</a>## Actions {#ActionList}
<a class="l" name="515" href="#515">515</a>
<a class="l" name="516" href="#516">516</a>**Actions** specify what a mock function should do when invoked.
<a class="l" name="517" href="#517">517</a>
<a class="l" name="518" href="#518">518</a>### Returning a Value
<a class="l" name="519" href="#519">519</a>
<a class="hl" name="520" href="#520">520</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="521" href="#521">521</a>|                                   |                                               |
<a class="l" name="522" href="#522">522</a>| :-------------------------------- | :-------------------------------------------- |
<a class="l" name="523" href="#523">523</a>| `Return()`                        | Return from a `void` mock function.           |
<a class="l" name="524" href="#524">524</a>| `Return(value)`                   | Return `value`. If the type of `value` is     different to the mock function's return type, `value` is converted to the latter type &lt;i&gt;at the time the expectation is set&lt;/i&gt;, not when the action is executed. |
<a class="l" name="525" href="#525">525</a>| `ReturnArg&lt;N&gt;()`                  | Return the `N`-th (0-based) argument.         |
<a class="l" name="526" href="#526">526</a>| `ReturnNew&lt;T&gt;(a1, ..., ak)`       | Return `new T(a1, ..., ak)`; a different      object is created each time. |
<a class="l" name="527" href="#527">527</a>| `ReturnNull()`                    | Return a null pointer.                        |
<a class="l" name="528" href="#528">528</a>| `ReturnPointee(ptr)`              | Return the value pointed to by `ptr`.         |
<a class="l" name="529" href="#529">529</a>| `ReturnRef(variable)`             | Return a reference to `variable`.             |
<a class="hl" name="530" href="#530">530</a>| `ReturnRefOfCopy(value)`          | Return a reference to a copy of `value`; the  copy lives as long as the action. |
<a class="l" name="531" href="#531">531</a>| `ReturnRoundRobin({a1, ..., ak})` | Each call will return the next `ai` in the list, starting at the beginning when the end of the list is reached. |
<a class="l" name="532" href="#532">532</a>&lt;!-- mdformat on --&gt;
<a class="l" name="533" href="#533">533</a>
<a class="l" name="534" href="#534">534</a>### Side Effects
<a class="l" name="535" href="#535">535</a>
<a class="l" name="536" href="#536">536</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="537" href="#537">537</a>|                                    |                                         |
<a class="l" name="538" href="#538">538</a>| :--------------------------------- | :-------------------------------------- |
<a class="l" name="539" href="#539">539</a>| `Assign(&amp;variable, value)` | Assign `value` to variable. |
<a class="hl" name="540" href="#540">540</a>| `DeleteArg&lt;N&gt;()` | Delete the `N`-th (0-based) argument, which must be a pointer. |
<a class="l" name="541" href="#541">541</a>| `SaveArg&lt;N&gt;(pointer)` | Save the `N`-th (0-based) argument to `*pointer`. |
<a class="l" name="542" href="#542">542</a>| `SaveArgPointee&lt;N&gt;(pointer)` | Save the value pointed to by the `N`-th (0-based) argument to `*pointer`. |
<a class="l" name="543" href="#543">543</a>| `SetArgReferee&lt;N&gt;(value)` | Assign `value` to the variable referenced by the `N`-th (0-based) argument. |
<a class="l" name="544" href="#544">544</a>| `SetArgPointee&lt;N&gt;(value)` | Assign `value` to the variable pointed by the `N`-th (0-based) argument. |
<a class="l" name="545" href="#545">545</a>| `SetArgumentPointee&lt;N&gt;(value)` | Same as `SetArgPointee&lt;N&gt;(value)`. Deprecated. Will be removed in v1.7.0. |
<a class="l" name="546" href="#546">546</a>| `SetArrayArgument&lt;N&gt;(first, last)` | Copies the elements in source range [`first`, `last`) to the array pointed to by the `N`-th (0-based) argument, which can be either a pointer or an iterator. The action does not take ownership of the elements in the source range. |
<a class="l" name="547" href="#547">547</a>| `SetErrnoAndReturn(error, value)` | Set `errno` to `error` and return `value`. |
<a class="l" name="548" href="#548">548</a>| `Throw(exception)` | Throws the given exception, which can be any copyable value. Available since v1.1.0. |
<a class="l" name="549" href="#549">549</a>&lt;!-- mdformat on --&gt;
<a class="hl" name="550" href="#550">550</a>
<a class="l" name="551" href="#551">551</a>### Using a Function, Functor, or Lambda as an Action
<a class="l" name="552" href="#552">552</a>
<a class="l" name="553" href="#553">553</a>In the following, by "callable" we mean a free function, `std::function`,
<a class="l" name="554" href="#554">554</a>functor, or lambda.
<a class="l" name="555" href="#555">555</a>
<a class="l" name="556" href="#556">556</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="557" href="#557">557</a>|                                     |                                        |
<a class="l" name="558" href="#558">558</a>| :---------------------------------- | :------------------------------------- |
<a class="l" name="559" href="#559">559</a>| `f` | Invoke f with the arguments passed to the mock function, where f is a callable. |
<a class="hl" name="560" href="#560">560</a>| `Invoke(f)` | Invoke `f` with the arguments passed to the mock function, where `f` can be a <a href="/googletest/s?path=global/static&amp;project=googletest">global/static</a> function or a functor. |
<a class="l" name="561" href="#561">561</a>| `Invoke(object_pointer, &amp;class::method)` | Invoke the method on the object with the arguments passed to the mock function. |
<a class="l" name="562" href="#562">562</a>| `InvokeWithoutArgs(f)` | Invoke `f`, which can be a <a href="/googletest/s?path=global/static&amp;project=googletest">global/static</a> function or a functor. `f` must take no arguments. |
<a class="l" name="563" href="#563">563</a>| `InvokeWithoutArgs(object_pointer, &amp;class::method)` | Invoke the method on the object, which takes no arguments. |
<a class="l" name="564" href="#564">564</a>| `InvokeArgument&lt;N&gt;(arg1, arg2, ..., argk)` | Invoke the mock function's `N`-th (0-based) argument, which must be a function or a functor, with the `k` arguments. |
<a class="l" name="565" href="#565">565</a>&lt;!-- mdformat on --&gt;
<a class="l" name="566" href="#566">566</a>
<a class="l" name="567" href="#567">567</a>The return value of the invoked function is used as the return value of the
<a class="l" name="568" href="#568">568</a>action.
<a class="l" name="569" href="#569">569</a>
<a class="hl" name="570" href="#570">570</a>When defining a callable to be used with `Invoke*()`, you can declare any unused
<a class="l" name="571" href="#571">571</a>parameters as `Unused`:
<a class="l" name="572" href="#572">572</a>
<a class="l" name="573" href="#573">573</a>```cpp
<a class="l" name="574" href="#574">574</a>using ::testing::Invoke;
<a class="l" name="575" href="#575">575</a>double Distance(Unused, double x, double y) { return sqrt(x*x + y*y); }
<a class="l" name="576" href="#576">576</a>...
<a class="l" name="577" href="#577">577</a>EXPECT_CALL(mock, Foo("Hi", _, _)).WillOnce(Invoke(Distance));
<a class="l" name="578" href="#578">578</a>```
<a class="l" name="579" href="#579">579</a>
<a class="hl" name="580" href="#580">580</a>`Invoke(callback)` and `InvokeWithoutArgs(callback)` take ownership of
<a class="l" name="581" href="#581">581</a>`callback`, which must be permanent. The type of `callback` must be a base
<a class="l" name="582" href="#582">582</a>callback type instead of a derived one, <a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="l" name="583" href="#583">583</a>
<a class="l" name="584" href="#584">584</a>```cpp
<a class="l" name="585" href="#585">585</a>  BlockingClosure* done = new BlockingClosure;
<a class="l" name="586" href="#586">586</a>  ... Invoke(done) ...;  // This won't compile!
<a class="l" name="587" href="#587">587</a>
<a class="l" name="588" href="#588">588</a>  Closure* done2 = new BlockingClosure;
<a class="l" name="589" href="#589">589</a>  ... Invoke(done2) ...;  // This works.
<a class="hl" name="590" href="#590">590</a>```
<a class="l" name="591" href="#591">591</a>
<a class="l" name="592" href="#592">592</a>In `InvokeArgument&lt;N&gt;(...)`, if an argument needs to be passed by reference,
<a class="l" name="593" href="#593">593</a>wrap it inside `std::ref()`. For example,
<a class="l" name="594" href="#594">594</a>
<a class="l" name="595" href="#595">595</a>```cpp
<a class="l" name="596" href="#596">596</a>using ::testing::InvokeArgument;
<a class="l" name="597" href="#597">597</a>...
<a class="l" name="598" href="#598">598</a>InvokeArgument&lt;2&gt;(5, string("Hi"), std::ref(foo))
<a class="l" name="599" href="#599">599</a>```
<a class="hl" name="600" href="#600">600</a>
<a class="l" name="601" href="#601">601</a>calls the mock function's #2 argument, passing to it `5` and `string("Hi")` by
<a class="l" name="602" href="#602">602</a>value, and `foo` by reference.
<a class="l" name="603" href="#603">603</a>
<a class="l" name="604" href="#604">604</a>### Default Action
<a class="l" name="605" href="#605">605</a>
<a class="l" name="606" href="#606">606</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="607" href="#607">607</a>| Matcher       | Description                                            |
<a class="l" name="608" href="#608">608</a>| :------------ | :----------------------------------------------------- |
<a class="l" name="609" href="#609">609</a>| `DoDefault()` | Do the default action (specified by `ON_CALL()` or the built-in one). |
<a class="hl" name="610" href="#610">610</a>&lt;!-- mdformat on --&gt;
<a class="l" name="611" href="#611">611</a>
<a class="l" name="612" href="#612">612</a>**Note:** due to technical reasons, `DoDefault()` cannot be used inside a
<a class="l" name="613" href="#613">613</a>composite action - trying to do so will result in a run-time error.
<a class="l" name="614" href="#614">614</a>
<a class="l" name="615" href="#615">615</a>&lt;!-- GOOGLETEST_CM0032 DO NOT DELETE --&gt;
<a class="l" name="616" href="#616">616</a>
<a class="l" name="617" href="#617">617</a>### Composite Actions
<a class="l" name="618" href="#618">618</a>
<a class="l" name="619" href="#619">619</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="hl" name="620" href="#620">620</a>|                                |                                             |
<a class="l" name="621" href="#621">621</a>| :----------------------------- | :------------------------------------------ |
<a class="l" name="622" href="#622">622</a>| `DoAll(a1, a2, ..., an)`       | Do all actions `a1` to `an` and return the result of `an` in each invocation. The first `n - 1` sub-actions must return void and will receive a  readonly view of the arguments. |
<a class="l" name="623" href="#623">623</a>| `IgnoreResult(a)`              | Perform action `a` and ignore its result. `a` must not return void. |
<a class="l" name="624" href="#624">624</a>| `WithArg&lt;N&gt;(a)`                | Pass the `N`-th (0-based) argument of the mock function to action `a` and perform it. |
<a class="l" name="625" href="#625">625</a>| `WithArgs&lt;N1, N2, ..., Nk&gt;(a)` | Pass the selected (0-based) arguments of the mock function to action `a` and perform it. |
<a class="l" name="626" href="#626">626</a>| `WithoutArgs(a)`               | Perform action `a` without any arguments. |
<a class="l" name="627" href="#627">627</a>&lt;!-- mdformat on --&gt;
<a class="l" name="628" href="#628">628</a>
<a class="l" name="629" href="#629">629</a>### Defining Actions
<a class="hl" name="630" href="#630">630</a>
<a class="l" name="631" href="#631">631</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="632" href="#632">632</a>|                                    |                                         |
<a class="l" name="633" href="#633">633</a>| :--------------------------------- | :-------------------------------------- |
<a class="l" name="634" href="#634">634</a>| `ACTION(Sum) { return arg0 + arg1; }` | Defines an action `Sum()` to return the sum of the mock function's argument #0 and #1. |
<a class="l" name="635" href="#635">635</a>| `ACTION_P(Plus, n) { return arg0 + n; }` | Defines an action `Plus(n)` to return the sum of the mock function's argument #0 and `n`. |
<a class="l" name="636" href="#636">636</a>| `ACTION_Pk(Foo, p1, ..., pk) { statements; }` | Defines a parameterized action `Foo(p1, ..., pk)` to execute the given `statements`. |
<a class="l" name="637" href="#637">637</a>&lt;!-- mdformat on --&gt;
<a class="l" name="638" href="#638">638</a>
<a class="l" name="639" href="#639">639</a>The `ACTION*` macros cannot be used inside a function or class.
<a class="hl" name="640" href="#640">640</a>
<a class="l" name="641" href="#641">641</a>## Cardinalities {#CardinalityList}
<a class="l" name="642" href="#642">642</a>
<a class="l" name="643" href="#643">643</a>These are used in `Times()` to specify how many times a mock function will be
<a class="l" name="644" href="#644">644</a>called:
<a class="l" name="645" href="#645">645</a>
<a class="l" name="646" href="#646">646</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="l" name="647" href="#647">647</a>|                   |                                                        |
<a class="l" name="648" href="#648">648</a>| :---------------- | :----------------------------------------------------- |
<a class="l" name="649" href="#649">649</a>| `AnyNumber()`     | The function can be called any number of times.        |
<a class="hl" name="650" href="#650">650</a>| `AtLeast(n)`      | The call is expected at least `n` times.               |
<a class="l" name="651" href="#651">651</a>| `AtMost(n)`       | The call is expected at most `n` times.                |
<a class="l" name="652" href="#652">652</a>| `Between(m, n)`   | The call is expected between `m` and `n` (inclusive) times. |
<a class="l" name="653" href="#653">653</a>| `Exactly(n) or n` | The call is expected exactly `n` times. In particular, the call should never happen when `n` is 0. |
<a class="l" name="654" href="#654">654</a>&lt;!-- mdformat on --&gt;
<a class="l" name="655" href="#655">655</a>
<a class="l" name="656" href="#656">656</a>## Expectation Order
<a class="l" name="657" href="#657">657</a>
<a class="l" name="658" href="#658">658</a>By default, the expectations can be matched in *any* order. If some or all
<a class="l" name="659" href="#659">659</a>expectations must be matched in a given order, there are two ways to specify it.
<a class="hl" name="660" href="#660">660</a>They can be used either independently or together.
<a class="l" name="661" href="#661">661</a>
<a class="l" name="662" href="#662">662</a>### The After Clause {#AfterClause}
<a class="l" name="663" href="#663">663</a>
<a class="l" name="664" href="#664">664</a>```cpp
<a class="l" name="665" href="#665">665</a>using ::testing::Expectation;
<a class="l" name="666" href="#666">666</a>...
<a class="l" name="667" href="#667">667</a>Expectation init_x = EXPECT_CALL(foo, InitX());
<a class="l" name="668" href="#668">668</a>Expectation init_y = EXPECT_CALL(foo, InitY());
<a class="l" name="669" href="#669">669</a>EXPECT_CALL(foo, Bar())
<a class="hl" name="670" href="#670">670</a>     .After(init_x, init_y);
<a class="l" name="671" href="#671">671</a>```
<a class="l" name="672" href="#672">672</a>
<a class="l" name="673" href="#673">673</a>says that `Bar()` can be called only after both `InitX()` and `InitY()` have
<a class="l" name="674" href="#674">674</a>been called.
<a class="l" name="675" href="#675">675</a>
<a class="l" name="676" href="#676">676</a>If you don't know how many pre-requisites an expectation has when you write it,
<a class="l" name="677" href="#677">677</a>you can use an `ExpectationSet` to collect them:
<a class="l" name="678" href="#678">678</a>
<a class="l" name="679" href="#679">679</a>```cpp
<a class="hl" name="680" href="#680">680</a>using ::testing::ExpectationSet;
<a class="l" name="681" href="#681">681</a>...
<a class="l" name="682" href="#682">682</a>ExpectationSet all_inits;
<a class="l" name="683" href="#683">683</a>for (int i = 0; i &lt; element_count; i++) {
<a class="l" name="684" href="#684">684</a>  all_inits += EXPECT_CALL(foo, InitElement(i));
<a class="l" name="685" href="#685">685</a>}
<a class="l" name="686" href="#686">686</a>EXPECT_CALL(foo, Bar())
<a class="l" name="687" href="#687">687</a>     .After(all_inits);
<a class="l" name="688" href="#688">688</a>```
<a class="l" name="689" href="#689">689</a>
<a class="hl" name="690" href="#690">690</a>says that `Bar()` can be called only after all elements have been initialized
<a class="l" name="691" href="#691">691</a>(but we don't care about which elements get initialized before the others).
<a class="l" name="692" href="#692">692</a>
<a class="l" name="693" href="#693">693</a>Modifying an `ExpectationSet` after using it in an `.After()` doesn't affect the
<a class="l" name="694" href="#694">694</a>meaning of the `.After()`.
<a class="l" name="695" href="#695">695</a>
<a class="l" name="696" href="#696">696</a>### Sequences {#UsingSequences}
<a class="l" name="697" href="#697">697</a>
<a class="l" name="698" href="#698">698</a>When you have a long chain of sequential expectations, it's easier to specify
<a class="l" name="699" href="#699">699</a>the order using **sequences**, which don't require you to given each expectation
<a class="hl" name="700" href="#700">700</a>in the chain a different name. *All expected calls* in the same sequence must
<a class="l" name="701" href="#701">701</a>occur in the order they are specified.
<a class="l" name="702" href="#702">702</a>
<a class="l" name="703" href="#703">703</a>```cpp
<a class="l" name="704" href="#704">704</a>using ::testing::Return;
<a class="l" name="705" href="#705">705</a>using ::testing::Sequence;
<a class="l" name="706" href="#706">706</a>Sequence s1, s2;
<a class="l" name="707" href="#707">707</a>...
<a class="l" name="708" href="#708">708</a>EXPECT_CALL(foo, Reset())
<a class="l" name="709" href="#709">709</a>    .InSequence(s1, s2)
<a class="hl" name="710" href="#710">710</a>    .WillOnce(Return(true));
<a class="l" name="711" href="#711">711</a>EXPECT_CALL(foo, GetSize())
<a class="l" name="712" href="#712">712</a>    .InSequence(s1)
<a class="l" name="713" href="#713">713</a>    .WillOnce(Return(1));
<a class="l" name="714" href="#714">714</a>EXPECT_CALL(foo, Describe(A&lt;const char*&gt;()))
<a class="l" name="715" href="#715">715</a>    .InSequence(s2)
<a class="l" name="716" href="#716">716</a>    .WillOnce(Return("dummy"));
<a class="l" name="717" href="#717">717</a>```
<a class="l" name="718" href="#718">718</a>
<a class="l" name="719" href="#719">719</a>says that `Reset()` must be called before *both* `GetSize()` *and* `Describe()`,
<a class="hl" name="720" href="#720">720</a>and the latter two can occur in any order.
<a class="l" name="721" href="#721">721</a>
<a class="l" name="722" href="#722">722</a>To put many expectations in a sequence conveniently:
<a class="l" name="723" href="#723">723</a>
<a class="l" name="724" href="#724">724</a>```cpp
<a class="l" name="725" href="#725">725</a>using ::testing::InSequence;
<a class="l" name="726" href="#726">726</a>{
<a class="l" name="727" href="#727">727</a>  InSequence seq;
<a class="l" name="728" href="#728">728</a>
<a class="l" name="729" href="#729">729</a>  EXPECT_CALL(...)...;
<a class="hl" name="730" href="#730">730</a>  EXPECT_CALL(...)...;
<a class="l" name="731" href="#731">731</a>  ...
<a class="l" name="732" href="#732">732</a>  EXPECT_CALL(...)...;
<a class="l" name="733" href="#733">733</a>}
<a class="l" name="734" href="#734">734</a>```
<a class="l" name="735" href="#735">735</a>
<a class="l" name="736" href="#736">736</a>says that all expected calls in the scope of `seq` must occur in strict order.
<a class="l" name="737" href="#737">737</a>The name `seq` is irrelevant.
<a class="l" name="738" href="#738">738</a>
<a class="l" name="739" href="#739">739</a>## Verifying and Resetting a Mock
<a class="hl" name="740" href="#740">740</a>
<a class="l" name="741" href="#741">741</a>gMock will verify the expectations on a mock object when it is destructed, or
<a class="l" name="742" href="#742">742</a>you can do it earlier:
<a class="l" name="743" href="#743">743</a>
<a class="l" name="744" href="#744">744</a>```cpp
<a class="l" name="745" href="#745">745</a>using ::testing::Mock;
<a class="l" name="746" href="#746">746</a>...
<a class="l" name="747" href="#747">747</a>// Verifies and removes the expectations on mock_obj;
<a class="l" name="748" href="#748">748</a>// returns true if and only if successful.
<a class="l" name="749" href="#749">749</a>Mock::VerifyAndClearExpectations(&amp;mock_obj);
<a class="hl" name="750" href="#750">750</a>...
<a class="l" name="751" href="#751">751</a>// Verifies and removes the expectations on mock_obj;
<a class="l" name="752" href="#752">752</a>// also removes the default actions set by ON_CALL();
<a class="l" name="753" href="#753">753</a>// returns true if and only if successful.
<a class="l" name="754" href="#754">754</a>Mock::VerifyAndClear(&amp;mock_obj);
<a class="l" name="755" href="#755">755</a>```
<a class="l" name="756" href="#756">756</a>
<a class="l" name="757" href="#757">757</a>You can also tell gMock that a mock object can be leaked and doesn't need to be
<a class="l" name="758" href="#758">758</a>verified:
<a class="l" name="759" href="#759">759</a>
<a class="hl" name="760" href="#760">760</a>```cpp
<a class="l" name="761" href="#761">761</a>Mock::AllowLeak(&amp;mock_obj);
<a class="l" name="762" href="#762">762</a>```
<a class="l" name="763" href="#763">763</a>
<a class="l" name="764" href="#764">764</a>## Mock Classes
<a class="l" name="765" href="#765">765</a>
<a class="l" name="766" href="#766">766</a>gMock defines a convenient mock class template
<a class="l" name="767" href="#767">767</a>
<a class="l" name="768" href="#768">768</a>```cpp
<a class="l" name="769" href="#769">769</a>class MockFunction&lt;R(A1, ..., An)&gt; {
<a class="hl" name="770" href="#770">770</a> public:
<a class="l" name="771" href="#771">771</a>  MOCK_METHOD(R, Call, (A1, ..., An));
<a class="l" name="772" href="#772">772</a>};
<a class="l" name="773" href="#773">773</a>```
<a class="l" name="774" href="#774">774</a>
<a class="l" name="775" href="#775">775</a>See this [recipe](<a href="/googletest/s?path=cook_book.md&amp;project=googletest">cook_book.md</a>#using-check-points) for one application of it.
<a class="l" name="776" href="#776">776</a>
<a class="l" name="777" href="#777">777</a>## Flags
<a class="l" name="778" href="#778">778</a>
<a class="l" name="779" href="#779">779</a>&lt;!-- mdformat off(no multiline tables) --&gt;
<a class="hl" name="780" href="#780">780</a>| Flag                           | Description                               |
<a class="l" name="781" href="#781">781</a>| :----------------------------- | :---------------------------------------- |
<a class="l" name="782" href="#782">782</a>| `--gmock_catch_leaked_mocks=0` | Don't report leaked mock objects as failures. |
<a class="l" name="783" href="#783">783</a>| `--gmock_verbose=LEVEL` | Sets the default verbosity level (`info`, `warning`, or `error`) of Google Mock messages. |
<a class="l" name="784" href="#784">784</a>&lt;!-- mdformat on --&gt;
<a class="l" name="785" href="#785">785</a>