<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>## Legacy gMock FAQ {#GMockFaq}
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>&lt;!-- GOOGLETEST_CM0021 DO NOT DELETE --&gt;
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>&lt;!-- GOOGLETEST_CM0035 DO NOT DELETE --&gt;
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>### When I call a method on my mock object, the method for the real object is invoked instead. What's the problem?
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>In order for a method to be mocked, it must be *virtual*, unless you use the
<a class="hl" name="10" href="#10">10</a>[high-perf dependency injection technique](<a href="/googletest/s?path=cook_book.md&amp;project=googletest">cook_book.md</a>#MockingNonVirtualMethods).
<a class="l" name="11" href="#11">11</a>
<a class="l" name="12" href="#12">12</a>### Can I mock a variadic function?
<a class="l" name="13" href="#13">13</a>
<a class="l" name="14" href="#14">14</a>You cannot mock a variadic function (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> a function taking ellipsis (`...`)
<a class="l" name="15" href="#15">15</a>arguments) directly in gMock.
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a>The problem is that in general, there is *no way* for a mock object to know how
<a class="l" name="18" href="#18">18</a>many arguments are passed to the variadic method, and what the arguments' types
<a class="l" name="19" href="#19">19</a>are. Only the *author of the base class* knows the protocol, and we cannot look
<a class="hl" name="20" href="#20">20</a>into his or her head.
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a>Therefore, to mock such a function, the *user* must teach the mock object how to
<a class="l" name="23" href="#23">23</a>figure out the number of arguments and their types. One way to do it is to
<a class="l" name="24" href="#24">24</a>provide overloaded versions of the function.
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a>Ellipsis arguments are inherited from C and not really a C++ feature. They are
<a class="l" name="27" href="#27">27</a>unsafe to use and don't work with arguments that have constructors or
<a class="l" name="28" href="#28">28</a>destructors. Therefore we recommend to avoid them in C++ as much as possible.
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a>### MSVC gives me warning C4301 or C4373 when I define a mock method with a const parameter. Why?
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a>If you compile this using Microsoft Visual C++ 2005 SP1:
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a>```cpp
<a class="l" name="35" href="#35">35</a>class Foo {
<a class="l" name="36" href="#36">36</a>  ...
<a class="l" name="37" href="#37">37</a>  virtual void Bar(const int i) = 0;
<a class="l" name="38" href="#38">38</a>};
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a>class MockFoo : public Foo {
<a class="l" name="41" href="#41">41</a>  ...
<a class="l" name="42" href="#42">42</a>  MOCK_METHOD(void, Bar, (const int i), (override));
<a class="l" name="43" href="#43">43</a>};
<a class="l" name="44" href="#44">44</a>```
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>You may get the following warning:
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>```shell
<a class="l" name="49" href="#49">49</a>warning C4301: 'MockFoo::Bar': overriding virtual function only differs from 'Foo::Bar' by <a href="/googletest/s?path=const/volatile&amp;project=googletest">const/volatile</a> qualifier
<a class="hl" name="50" href="#50">50</a>```
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a>This is a MSVC bug. The same code compiles fine with gcc, for example. If you
<a class="l" name="53" href="#53">53</a>use Visual C++ 2008 SP1, you would get the warning:
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>```shell
<a class="l" name="56" href="#56">56</a>warning C4373: 'MockFoo::Bar': virtual function overrides 'Foo::Bar', previous versions of the compiler did not override when parameters only differed by <a href="/googletest/s?path=const/volatile&amp;project=googletest">const/volatile</a> qualifiers
<a class="l" name="57" href="#57">57</a>```
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>In C++, if you *declare* a function with a `const` parameter, the `const`
<a class="hl" name="60" href="#60">60</a>modifier is ignored. Therefore, the `Foo` base class above is equivalent to:
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>```cpp
<a class="l" name="63" href="#63">63</a>class Foo {
<a class="l" name="64" href="#64">64</a>  ...
<a class="l" name="65" href="#65">65</a>  virtual void Bar(int i) = 0;  // int or const int?  Makes no difference.
<a class="l" name="66" href="#66">66</a>};
<a class="l" name="67" href="#67">67</a>```
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>In fact, you can *declare* `Bar()` with an `int` parameter, and define it with a
<a class="hl" name="70" href="#70">70</a>`const int` parameter. The compiler will still match them up.
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a>Since making a parameter `const` is meaningless in the method declaration, we
<a class="l" name="73" href="#73">73</a>recommend to remove it in both `Foo` and `MockFoo`. That should workaround the
<a class="l" name="74" href="#74">74</a>VC bug.
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a>Note that we are talking about the *top-level* `const` modifier here. If the
<a class="l" name="77" href="#77">77</a>function parameter is passed by pointer or reference, declaring the pointee or
<a class="l" name="78" href="#78">78</a>referee as `const` is still meaningful. For example, the following two
<a class="l" name="79" href="#79">79</a>declarations are *not* equivalent:
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a>```cpp
<a class="l" name="82" href="#82">82</a>void Bar(int* p);         // Neither p nor *p is const.
<a class="l" name="83" href="#83">83</a>void Bar(const int* p);  // p is not const, but *p is.
<a class="l" name="84" href="#84">84</a>```
<a class="l" name="85" href="#85">85</a>
<a class="l" name="86" href="#86">86</a>&lt;!-- GOOGLETEST_CM0030 DO NOT DELETE --&gt;
<a class="l" name="87" href="#87">87</a>
<a class="l" name="88" href="#88">88</a>### I can't figure out why gMock thinks my expectations are not satisfied. What should I do?
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>You might want to run your test with `--gmock_verbose=info`. This flag lets
<a class="l" name="91" href="#91">91</a>gMock print a trace of every mock function call it receives. By studying the
<a class="l" name="92" href="#92">92</a>trace, you'll gain insights on why the expectations you set are not met.
<a class="l" name="93" href="#93">93</a>
<a class="l" name="94" href="#94">94</a>If you see the message "The mock function has no default action set, and its
<a class="l" name="95" href="#95">95</a>return type has no default value set.", then try
<a class="l" name="96" href="#96">96</a>[adding a default action](<a href="/googletest/s?path=for_dummies.md&amp;project=googletest">for_dummies.md</a>#DefaultValue). Due to a known issue,
<a class="l" name="97" href="#97">97</a>unexpected calls on mocks without default actions don't print out a detailed
<a class="l" name="98" href="#98">98</a>comparison between the actual arguments and the expected arguments.
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>### My program crashed and `ScopedMockLog` spit out tons of messages. Is it a gMock bug?
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>gMock and `ScopedMockLog` are likely doing the right thing here.
<a class="l" name="103" href="#103">103</a>
<a class="l" name="104" href="#104">104</a>When a test crashes, the failure signal handler will try to log a lot of
<a class="l" name="105" href="#105">105</a>information (the stack trace, and the address map, for example). The messages
<a class="l" name="106" href="#106">106</a>are compounded if you have many threads with depth stacks. When `ScopedMockLog`
<a class="l" name="107" href="#107">107</a>intercepts these messages and finds that they don't match any expectations, it
<a class="l" name="108" href="#108">108</a>prints an error for each of them.
<a class="l" name="109" href="#109">109</a>
<a class="hl" name="110" href="#110">110</a>You can learn to ignore the errors, or you can rewrite your expectations to make
<a class="l" name="111" href="#111">111</a>your test more robust, for example, by adding something like:
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>```cpp
<a class="l" name="114" href="#114">114</a>using ::testing::AnyNumber;
<a class="l" name="115" href="#115">115</a>using ::testing::Not;
<a class="l" name="116" href="#116">116</a>...
<a class="l" name="117" href="#117">117</a>  // Ignores any log not done by us.
<a class="l" name="118" href="#118">118</a>  EXPECT_CALL(log, Log(_, Not(EndsWith("/<a href="/googletest/s?path=my_file.cc&amp;project=googletest">my_file.cc</a>")), _))
<a class="l" name="119" href="#119">119</a>      .Times(AnyNumber());
<a class="hl" name="120" href="#120">120</a>```
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>### How can I assert that a function is NEVER called?
<a class="l" name="123" href="#123">123</a>
<a class="l" name="124" href="#124">124</a>```cpp
<a class="l" name="125" href="#125">125</a>using ::testing::_;
<a class="l" name="126" href="#126">126</a>...
<a class="l" name="127" href="#127">127</a>  EXPECT_CALL(foo, Bar(_))
<a class="l" name="128" href="#128">128</a>      .Times(0);
<a class="l" name="129" href="#129">129</a>```
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a>&lt;!-- GOOGLETEST_CM0031 DO NOT DELETE --&gt;
<a class="l" name="132" href="#132">132</a>
<a class="l" name="133" href="#133">133</a>### I have a failed test where gMock tells me TWICE that a particular expectation is not satisfied. Isn't this redundant?
<a class="l" name="134" href="#134">134</a>
<a class="l" name="135" href="#135">135</a>When gMock detects a failure, it prints relevant information (the mock function
<a class="l" name="136" href="#136">136</a>arguments, the state of relevant expectations, and etc) to help the user debug.
<a class="l" name="137" href="#137">137</a>If another failure is detected, gMock will do the same, including printing the
<a class="l" name="138" href="#138">138</a>state of relevant expectations.
<a class="l" name="139" href="#139">139</a>
<a class="hl" name="140" href="#140">140</a>Sometimes an expectation's state didn't change between two failures, and you'll
<a class="l" name="141" href="#141">141</a>see the same description of the state twice. They are however *not* redundant,
<a class="l" name="142" href="#142">142</a>as they refer to *different points in time*. The fact they are the same *is*
<a class="l" name="143" href="#143">143</a>interesting information.
<a class="l" name="144" href="#144">144</a>
<a class="l" name="145" href="#145">145</a>### I get a heapcheck failure when using a mock object, but using a real object is fine. What can be wrong?
<a class="l" name="146" href="#146">146</a>
<a class="l" name="147" href="#147">147</a>Does the class (hopefully a pure interface) you are mocking have a virtual
<a class="l" name="148" href="#148">148</a>destructor?
<a class="l" name="149" href="#149">149</a>
<a class="hl" name="150" href="#150">150</a>Whenever you derive from a base class, make sure its destructor is virtual.
<a class="l" name="151" href="#151">151</a>Otherwise Bad Things will happen. Consider the following code:
<a class="l" name="152" href="#152">152</a>
<a class="l" name="153" href="#153">153</a>```cpp
<a class="l" name="154" href="#154">154</a>class Base {
<a class="l" name="155" href="#155">155</a> public:
<a class="l" name="156" href="#156">156</a>  // Not virtual, but should be.
<a class="l" name="157" href="#157">157</a>  ~Base() { ... }
<a class="l" name="158" href="#158">158</a>  ...
<a class="l" name="159" href="#159">159</a>};
<a class="hl" name="160" href="#160">160</a>
<a class="l" name="161" href="#161">161</a>class Derived : public Base {
<a class="l" name="162" href="#162">162</a> public:
<a class="l" name="163" href="#163">163</a>  ...
<a class="l" name="164" href="#164">164</a> private:
<a class="l" name="165" href="#165">165</a>  std::string value_;
<a class="l" name="166" href="#166">166</a>};
<a class="l" name="167" href="#167">167</a>
<a class="l" name="168" href="#168">168</a>...
<a class="l" name="169" href="#169">169</a>  Base* p = new Derived;
<a class="hl" name="170" href="#170">170</a>  ...
<a class="l" name="171" href="#171">171</a>  delete p;  // Surprise! ~Base() will be called, but ~Derived() will not
<a class="l" name="172" href="#172">172</a>                 // - value_ is leaked.
<a class="l" name="173" href="#173">173</a>```
<a class="l" name="174" href="#174">174</a>
<a class="l" name="175" href="#175">175</a>By changing `~Base()` to virtual, `~Derived()` will be correctly called when
<a class="l" name="176" href="#176">176</a>`delete p` is executed, and the heap checker will be happy.
<a class="l" name="177" href="#177">177</a>
<a class="l" name="178" href="#178">178</a>### The "newer expectations override older ones" rule makes writing expectations awkward. Why does gMock do that?
<a class="l" name="179" href="#179">179</a>
<a class="hl" name="180" href="#180">180</a>When people complain about this, often they are referring to code like:
<a class="l" name="181" href="#181">181</a>
<a class="l" name="182" href="#182">182</a>```cpp
<a class="l" name="183" href="#183">183</a>using ::testing::Return;
<a class="l" name="184" href="#184">184</a>...
<a class="l" name="185" href="#185">185</a>  // <a href="/googletest/s?path=foo.Bar&amp;project=googletest">foo.Bar</a>() should be called twice, return 1 the first time, and return
<a class="l" name="186" href="#186">186</a>  // 2 the second time.  However, I have to write the expectations in the
<a class="l" name="187" href="#187">187</a>  // reverse order.  This sucks big time!!!
<a class="l" name="188" href="#188">188</a>  EXPECT_CALL(foo, Bar())
<a class="l" name="189" href="#189">189</a>      .WillOnce(Return(2))
<a class="hl" name="190" href="#190">190</a>      .RetiresOnSaturation();
<a class="l" name="191" href="#191">191</a>  EXPECT_CALL(foo, Bar())
<a class="l" name="192" href="#192">192</a>      .WillOnce(Return(1))
<a class="l" name="193" href="#193">193</a>      .RetiresOnSaturation();
<a class="l" name="194" href="#194">194</a>```
<a class="l" name="195" href="#195">195</a>
<a class="l" name="196" href="#196">196</a>The problem, is that they didn't pick the **best** way to express the test's
<a class="l" name="197" href="#197">197</a>intent.
<a class="l" name="198" href="#198">198</a>
<a class="l" name="199" href="#199">199</a>By default, expectations don't have to be matched in *any* particular order. If
<a class="hl" name="200" href="#200">200</a>you want them to match in a certain order, you need to be explicit. This is
<a class="l" name="201" href="#201">201</a>gMock's (and jMock's) fundamental philosophy: it's easy to accidentally
<a class="l" name="202" href="#202">202</a>over-specify your tests, and we want to make it harder to do so.
<a class="l" name="203" href="#203">203</a>
<a class="l" name="204" href="#204">204</a>There are two better ways to write the test spec. You could either put the
<a class="l" name="205" href="#205">205</a>expectations in sequence:
<a class="l" name="206" href="#206">206</a>
<a class="l" name="207" href="#207">207</a>```cpp
<a class="l" name="208" href="#208">208</a>using ::testing::Return;
<a class="l" name="209" href="#209">209</a>...
<a class="hl" name="210" href="#210">210</a>  // <a href="/googletest/s?path=foo.Bar&amp;project=googletest">foo.Bar</a>() should be called twice, return 1 the first time, and return
<a class="l" name="211" href="#211">211</a>  // 2 the second time.  Using a sequence, we can write the expectations
<a class="l" name="212" href="#212">212</a>  // in their natural order.
<a class="l" name="213" href="#213">213</a>  {
<a class="l" name="214" href="#214">214</a>    InSequence s;
<a class="l" name="215" href="#215">215</a>    EXPECT_CALL(foo, Bar())
<a class="l" name="216" href="#216">216</a>        .WillOnce(Return(1))
<a class="l" name="217" href="#217">217</a>        .RetiresOnSaturation();
<a class="l" name="218" href="#218">218</a>    EXPECT_CALL(foo, Bar())
<a class="l" name="219" href="#219">219</a>        .WillOnce(Return(2))
<a class="hl" name="220" href="#220">220</a>        .RetiresOnSaturation();
<a class="l" name="221" href="#221">221</a>  }
<a class="l" name="222" href="#222">222</a>```
<a class="l" name="223" href="#223">223</a>
<a class="l" name="224" href="#224">224</a>or you can put the sequence of actions in the same expectation:
<a class="l" name="225" href="#225">225</a>
<a class="l" name="226" href="#226">226</a>```cpp
<a class="l" name="227" href="#227">227</a>using ::testing::Return;
<a class="l" name="228" href="#228">228</a>...
<a class="l" name="229" href="#229">229</a>  // <a href="/googletest/s?path=foo.Bar&amp;project=googletest">foo.Bar</a>() should be called twice, return 1 the first time, and return
<a class="hl" name="230" href="#230">230</a>  // 2 the second time.
<a class="l" name="231" href="#231">231</a>  EXPECT_CALL(foo, Bar())
<a class="l" name="232" href="#232">232</a>      .WillOnce(Return(1))
<a class="l" name="233" href="#233">233</a>      .WillOnce(Return(2))
<a class="l" name="234" href="#234">234</a>      .RetiresOnSaturation();
<a class="l" name="235" href="#235">235</a>```
<a class="l" name="236" href="#236">236</a>
<a class="l" name="237" href="#237">237</a>Back to the original questions: why does gMock search the expectations (and
<a class="l" name="238" href="#238">238</a>`ON_CALL`s) from back to front? Because this allows a user to set up a mock's
<a class="l" name="239" href="#239">239</a>behavior for the common case early (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> in the mock's constructor or the test
<a class="hl" name="240" href="#240">240</a>fixture's set-up phase) and customize it with more specific rules later. If
<a class="l" name="241" href="#241">241</a>gMock searches from front to back, this very useful pattern won't be possible.
<a class="l" name="242" href="#242">242</a>
<a class="l" name="243" href="#243">243</a>### gMock prints a warning when a function without EXPECT_CALL is called, even if I have set its behavior using ON_CALL. Would it be reasonable not to show the warning in this case?
<a class="l" name="244" href="#244">244</a>
<a class="l" name="245" href="#245">245</a>When choosing between being neat and being safe, we lean toward the latter. So
<a class="l" name="246" href="#246">246</a>the answer is that we think it's better to show the warning.
<a class="l" name="247" href="#247">247</a>
<a class="l" name="248" href="#248">248</a>Often people write `ON_CALL`s in the mock object's constructor or `SetUp()`, as
<a class="l" name="249" href="#249">249</a>the default behavior rarely changes from test to test. Then in the test body
<a class="hl" name="250" href="#250">250</a>they set the expectations, which are often different for each test. Having an
<a class="l" name="251" href="#251">251</a>`ON_CALL` in the set-up part of a test doesn't mean that the calls are expected.
<a class="l" name="252" href="#252">252</a>If there's no `EXPECT_CALL` and the method is called, it's possibly an error. If
<a class="l" name="253" href="#253">253</a>we quietly let the call go through without notifying the user, bugs may creep in
<a class="l" name="254" href="#254">254</a>unnoticed.
<a class="l" name="255" href="#255">255</a>
<a class="l" name="256" href="#256">256</a>If, however, you are sure that the calls are OK, you can write
<a class="l" name="257" href="#257">257</a>
<a class="l" name="258" href="#258">258</a>```cpp
<a class="l" name="259" href="#259">259</a>using ::testing::_;
<a class="hl" name="260" href="#260">260</a>...
<a class="l" name="261" href="#261">261</a>  EXPECT_CALL(foo, Bar(_))
<a class="l" name="262" href="#262">262</a>      .WillRepeatedly(...);
<a class="l" name="263" href="#263">263</a>```
<a class="l" name="264" href="#264">264</a>
<a class="l" name="265" href="#265">265</a>instead of
<a class="l" name="266" href="#266">266</a>
<a class="l" name="267" href="#267">267</a>```cpp
<a class="l" name="268" href="#268">268</a>using ::testing::_;
<a class="l" name="269" href="#269">269</a>...
<a class="hl" name="270" href="#270">270</a>  ON_CALL(foo, Bar(_))
<a class="l" name="271" href="#271">271</a>      .WillByDefault(...);
<a class="l" name="272" href="#272">272</a>```
<a class="l" name="273" href="#273">273</a>
<a class="l" name="274" href="#274">274</a>This tells gMock that you do expect the calls and no warning should be printed.
<a class="l" name="275" href="#275">275</a>
<a class="l" name="276" href="#276">276</a>Also, you can control the verbosity by specifying `--gmock_verbose=error`. Other
<a class="l" name="277" href="#277">277</a>values are `info` and `warning`. If you find the output too noisy when
<a class="l" name="278" href="#278">278</a>debugging, just choose a less verbose level.
<a class="l" name="279" href="#279">279</a>
<a class="hl" name="280" href="#280">280</a>### How can I delete the mock function's argument in an action?
<a class="l" name="281" href="#281">281</a>
<a class="l" name="282" href="#282">282</a>If your mock function takes a pointer argument and you want to delete that
<a class="l" name="283" href="#283">283</a>argument, you can use testing::DeleteArg&lt;N&gt;() to delete the N'th (zero-indexed)
<a class="l" name="284" href="#284">284</a>argument:
<a class="l" name="285" href="#285">285</a>
<a class="l" name="286" href="#286">286</a>```cpp
<a class="l" name="287" href="#287">287</a>using ::testing::_;
<a class="l" name="288" href="#288">288</a>  ...
<a class="l" name="289" href="#289">289</a>  MOCK_METHOD(void, Bar, (X* x, const Y&amp; y));
<a class="hl" name="290" href="#290">290</a>  ...
<a class="l" name="291" href="#291">291</a>  EXPECT_CALL(mock_foo_, Bar(_, _))
<a class="l" name="292" href="#292">292</a>      .WillOnce(testing::DeleteArg&lt;0&gt;()));
<a class="l" name="293" href="#293">293</a>```
<a class="l" name="294" href="#294">294</a>
<a class="l" name="295" href="#295">295</a>### How can I perform an arbitrary action on a mock function's argument?
<a class="l" name="296" href="#296">296</a>
<a class="l" name="297" href="#297">297</a>If you find yourself needing to perform some action that's not supported by
<a class="l" name="298" href="#298">298</a>gMock directly, remember that you can define your own actions using
<a class="l" name="299" href="#299">299</a>[`MakeAction()`](#NewMonoActions) or
<a class="hl" name="300" href="#300">300</a>[`MakePolymorphicAction()`](#NewPolyActions), or you can write a stub function
<a class="l" name="301" href="#301">301</a>and invoke it using [`Invoke()`](#FunctionsAsActions).
<a class="l" name="302" href="#302">302</a>
<a class="l" name="303" href="#303">303</a>```cpp
<a class="l" name="304" href="#304">304</a>using ::testing::_;
<a class="l" name="305" href="#305">305</a>using ::testing::Invoke;
<a class="l" name="306" href="#306">306</a>  ...
<a class="l" name="307" href="#307">307</a>  MOCK_METHOD(void, Bar, (X* p));
<a class="l" name="308" href="#308">308</a>  ...
<a class="l" name="309" href="#309">309</a>  EXPECT_CALL(mock_foo_, Bar(_))
<a class="hl" name="310" href="#310">310</a>      .WillOnce(Invoke(MyAction(...)));
<a class="l" name="311" href="#311">311</a>```
<a class="l" name="312" href="#312">312</a>
<a class="l" name="313" href="#313">313</a>### My code calls a <a href="/googletest/s?path=static/global&amp;project=googletest">static/global</a> function. Can I mock it?
<a class="l" name="314" href="#314">314</a>
<a class="l" name="315" href="#315">315</a>You can, but you need to make some changes.
<a class="l" name="316" href="#316">316</a>
<a class="l" name="317" href="#317">317</a>In general, if you find yourself needing to mock a static function, it's a sign
<a class="l" name="318" href="#318">318</a>that your modules are too tightly coupled (and less flexible, less reusable,
<a class="l" name="319" href="#319">319</a>less testable, etc). You are probably better off defining a small interface and
<a class="hl" name="320" href="#320">320</a>call the function through that interface, which then can be easily mocked. It's
<a class="l" name="321" href="#321">321</a>a bit of work initially, but usually pays for itself quickly.
<a class="l" name="322" href="#322">322</a>
<a class="l" name="323" href="#323">323</a>This Google Testing Blog
<a class="l" name="324" href="#324">324</a>[post](<a href="https://testing.googleblog.com/2008/06/defeat-static-cling.html">https://testing.googleblog.com/2008/06/defeat-static-cling.html</a>) says it
<a class="l" name="325" href="#325">325</a>excellently. Check it out.
<a class="l" name="326" href="#326">326</a>
<a class="l" name="327" href="#327">327</a>### My mock object needs to do complex stuff. It's a lot of pain to specify the actions. gMock sucks!
<a class="l" name="328" href="#328">328</a>
<a class="l" name="329" href="#329">329</a>I know it's not a question, but you get an answer for free any way. :-)
<a class="hl" name="330" href="#330">330</a>
<a class="l" name="331" href="#331">331</a>With gMock, you can create mocks in C++ easily. And people might be tempted to
<a class="l" name="332" href="#332">332</a>use them everywhere. Sometimes they work great, and sometimes you may find them,
<a class="l" name="333" href="#333">333</a>well, a pain to use. So, what's wrong in the latter case?
<a class="l" name="334" href="#334">334</a>
<a class="l" name="335" href="#335">335</a>When you write a test without using mocks, you exercise the code and assert that
<a class="l" name="336" href="#336">336</a>it returns the correct value or that the system is in an expected state. This is
<a class="l" name="337" href="#337">337</a>sometimes called "state-based testing".
<a class="l" name="338" href="#338">338</a>
<a class="l" name="339" href="#339">339</a>Mocks are great for what some call "interaction-based" testing: instead of
<a class="hl" name="340" href="#340">340</a>checking the system state at the very end, mock objects verify that they are
<a class="l" name="341" href="#341">341</a>invoked the right way and report an error as soon as it arises, giving you a
<a class="l" name="342" href="#342">342</a>handle on the precise context in which the error was triggered. This is often
<a class="l" name="343" href="#343">343</a>more effective and economical to do than state-based testing.
<a class="l" name="344" href="#344">344</a>
<a class="l" name="345" href="#345">345</a>If you are doing state-based testing and using a test double just to simulate
<a class="l" name="346" href="#346">346</a>the real object, you are probably better off using a fake. Using a mock in this
<a class="l" name="347" href="#347">347</a>case causes pain, as it's not a strong point for mocks to perform complex
<a class="l" name="348" href="#348">348</a>actions. If you experience this and think that mocks suck, you are just not
<a class="l" name="349" href="#349">349</a>using the right tool for your problem. Or, you might be trying to solve the
<a class="hl" name="350" href="#350">350</a>wrong problem. :-)
<a class="l" name="351" href="#351">351</a>
<a class="l" name="352" href="#352">352</a>### I got a warning "Uninteresting function call encountered - default action taken.." Should I panic?
<a class="l" name="353" href="#353">353</a>
<a class="l" name="354" href="#354">354</a>By all means, NO! It's just an FYI. :-)
<a class="l" name="355" href="#355">355</a>
<a class="l" name="356" href="#356">356</a>What it means is that you have a mock function, you haven't set any expectations
<a class="l" name="357" href="#357">357</a>on it (by gMock's rule this means that you are not interested in calls to this
<a class="l" name="358" href="#358">358</a>function and therefore it can be called any number of times), and it is called.
<a class="l" name="359" href="#359">359</a>That's OK - you didn't say it's not OK to call the function!
<a class="hl" name="360" href="#360">360</a>
<a class="l" name="361" href="#361">361</a>What if you actually meant to disallow this function to be called, but forgot to
<a class="l" name="362" href="#362">362</a>write `EXPECT_CALL(foo, Bar()).Times(0)`? While one can argue that it's the
<a class="l" name="363" href="#363">363</a>user's fault, gMock tries to be nice and prints you a note.
<a class="l" name="364" href="#364">364</a>
<a class="l" name="365" href="#365">365</a>So, when you see the message and believe that there shouldn't be any
<a class="l" name="366" href="#366">366</a>uninteresting calls, you should investigate what's going on. To make your life
<a class="l" name="367" href="#367">367</a>easier, gMock dumps the stack trace when an uninteresting call is encountered.
<a class="l" name="368" href="#368">368</a>From that you can figure out which mock function it is, and how it is called.
<a class="l" name="369" href="#369">369</a>
<a class="hl" name="370" href="#370">370</a>### I want to define a custom action. Should I use Invoke() or implement the ActionInterface interface?
<a class="l" name="371" href="#371">371</a>
<a class="l" name="372" href="#372">372</a>Either way is fine - you want to choose the one that's more convenient for your
<a class="l" name="373" href="#373">373</a>circumstance.
<a class="l" name="374" href="#374">374</a>
<a class="l" name="375" href="#375">375</a>Usually, if your action is for a particular function type, defining it using
<a class="l" name="376" href="#376">376</a>`Invoke()` should be easier; if your action can be used in functions of
<a class="l" name="377" href="#377">377</a>different types (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> if you are defining `Return(*value*)`),
<a class="l" name="378" href="#378">378</a>`MakePolymorphicAction()` is easiest. Sometimes you want precise control on what
<a class="l" name="379" href="#379">379</a>types of functions the action can be used in, and implementing `ActionInterface`
<a class="hl" name="380" href="#380">380</a>is the way to go here. See the implementation of `Return()` in
<a class="l" name="381" href="#381">381</a>`<a href="/googletest/s?path=testing/base/public/gmock-actions.h&amp;project=googletest">testing/base/public/gmock-actions.h</a>` for an example.
<a class="l" name="382" href="#382">382</a>
<a class="l" name="383" href="#383">383</a>### I use SetArgPointee() in WillOnce(), but gcc complains about "conflicting return type specified". What does it mean?
<a class="l" name="384" href="#384">384</a>
<a class="l" name="385" href="#385">385</a>You got this error as gMock has no idea what value it should return when the
<a class="l" name="386" href="#386">386</a>mock method is called. `SetArgPointee()` says what the side effect is, but
<a class="l" name="387" href="#387">387</a>doesn't say what the return value should be. You need `DoAll()` to chain a
<a class="l" name="388" href="#388">388</a>`SetArgPointee()` with a `Return()` that provides a value appropriate to the API
<a class="l" name="389" href="#389">389</a>being mocked.
<a class="hl" name="390" href="#390">390</a>
<a class="l" name="391" href="#391">391</a>See this [recipe](<a href="/googletest/s?path=cook_book.md&amp;project=googletest">cook_book.md</a>#mocking-side-effects) for more details and an
<a class="l" name="392" href="#392">392</a>example.
<a class="l" name="393" href="#393">393</a>
<a class="l" name="394" href="#394">394</a>### I have a huge mock class, and Microsoft Visual C++ runs out of memory when compiling it. What can I do?
<a class="l" name="395" href="#395">395</a>
<a class="l" name="396" href="#396">396</a>We've noticed that when the `/clr` compiler flag is used, Visual C++ uses 5~6
<a class="l" name="397" href="#397">397</a>times as much memory when compiling a mock class. We suggest to avoid `/clr`
<a class="l" name="398" href="#398">398</a>when compiling native C++ mocks.
<a class="l" name="399" href="#399">399</a>