<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># gMock Cookbook
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>&lt;!-- GOOGLETEST_CM0012 DO NOT DELETE --&gt;
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>You can find recipes for using gMock here. If you haven't yet, please read
<a class="l" name="6" href="#6">6</a>[the dummy guide](<a href="/googletest/s?path=for_dummies.md&amp;project=googletest">for_dummies.md</a>) first to make sure you understand the basics.
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>**Note:** gMock lives in the `testing` name space. For readability, it is
<a class="l" name="9" href="#9">9</a>recommended to write `using ::testing::Foo;` once in your file before using the
<a class="hl" name="10" href="#10">10</a>name `Foo` defined by gMock. We omit such `using` statements in this section for
<a class="l" name="11" href="#11">11</a>brevity, but you should do it in your own code.
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a>&lt;!-- GOOGLETEST_CM0035 DO NOT DELETE --&gt;
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a>## Creating Mock Classes
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a>Mock classes are defined as normal classes, using the `MOCK_METHOD` macro to
<a class="l" name="18" href="#18">18</a>generate mocked methods. The macro gets 3 or 4 parameters:
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a>```cpp
<a class="l" name="21" href="#21">21</a>class MyMock {
<a class="l" name="22" href="#22">22</a> public:
<a class="l" name="23" href="#23">23</a>  MOCK_METHOD(ReturnType, MethodName, (Args...));
<a class="l" name="24" href="#24">24</a>  MOCK_METHOD(ReturnType, MethodName, (Args...), (Specs...));
<a class="l" name="25" href="#25">25</a>};
<a class="l" name="26" href="#26">26</a>```
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a>The first 3 parameters are simply the method declaration, split into 3 parts.
<a class="l" name="29" href="#29">29</a>The 4th parameter accepts a closed list of qualifiers, which affect the
<a class="hl" name="30" href="#30">30</a>generated method:
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a>*   **`const`** - Makes the mocked method a `const` method. Required if
<a class="l" name="33" href="#33">33</a>    overriding a `const` method.
<a class="l" name="34" href="#34">34</a>*   **`override`** - Marks the method with `override`. Recommended if overriding
<a class="l" name="35" href="#35">35</a>    a `virtual` method.
<a class="l" name="36" href="#36">36</a>*   **`noexcept`** - Marks the method with `noexcept`. Required if overriding a
<a class="l" name="37" href="#37">37</a>    `noexcept` method.
<a class="l" name="38" href="#38">38</a>*   **`Calltype(...)`** - Sets the call type for the method (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> to
<a class="l" name="39" href="#39">39</a>    `STDMETHODCALLTYPE`), useful in Windows.
<a class="hl" name="40" href="#40">40</a>*   **`ref(...)`** - Marks the method with the reference qualification
<a class="l" name="41" href="#41">41</a>    specified. Required if overriding a method that has reference
<a class="l" name="42" href="#42">42</a>    qualifications. Eg `ref(&amp;)` or `ref(&amp;&amp;)`.
<a class="l" name="43" href="#43">43</a>
<a class="l" name="44" href="#44">44</a>### Dealing with unprotected commas
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>Unprotected commas, <a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> commas which are not surrounded by parentheses, prevent
<a class="l" name="47" href="#47">47</a>`MOCK_METHOD` from parsing its arguments correctly:
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>```cpp {.bad}
<a class="hl" name="50" href="#50">50</a>class MockFoo {
<a class="l" name="51" href="#51">51</a> public:
<a class="l" name="52" href="#52">52</a>  MOCK_METHOD(std::pair&lt;bool, int&gt;, GetPair, ());  // Won't compile!
<a class="l" name="53" href="#53">53</a>  MOCK_METHOD(bool, CheckMap, (std::map&lt;int, double&gt;, bool));  // Won't compile!
<a class="l" name="54" href="#54">54</a>};
<a class="l" name="55" href="#55">55</a>```
<a class="l" name="56" href="#56">56</a>
<a class="l" name="57" href="#57">57</a>Solution 1 - wrap with parentheses:
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>```cpp {.good}
<a class="hl" name="60" href="#60">60</a>class MockFoo {
<a class="l" name="61" href="#61">61</a> public:
<a class="l" name="62" href="#62">62</a>  MOCK_METHOD((std::pair&lt;bool, int&gt;), GetPair, ());
<a class="l" name="63" href="#63">63</a>  MOCK_METHOD(bool, CheckMap, ((std::map&lt;int, double&gt;), bool));
<a class="l" name="64" href="#64">64</a>};
<a class="l" name="65" href="#65">65</a>```
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>Note that wrapping a return or argument type with parentheses is, in general,
<a class="l" name="68" href="#68">68</a>invalid C++. `MOCK_METHOD` removes the parentheses.
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>Solution 2 - define an alias:
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a>```cpp {.good}
<a class="l" name="73" href="#73">73</a>class MockFoo {
<a class="l" name="74" href="#74">74</a> public:
<a class="l" name="75" href="#75">75</a>  using BoolAndInt = std::pair&lt;bool, int&gt;;
<a class="l" name="76" href="#76">76</a>  MOCK_METHOD(BoolAndInt, GetPair, ());
<a class="l" name="77" href="#77">77</a>  using MapIntDouble = std::map&lt;int, double&gt;;
<a class="l" name="78" href="#78">78</a>  MOCK_METHOD(bool, CheckMap, (MapIntDouble, bool));
<a class="l" name="79" href="#79">79</a>};
<a class="hl" name="80" href="#80">80</a>```
<a class="l" name="81" href="#81">81</a>
<a class="l" name="82" href="#82">82</a>### Mocking Private or Protected Methods
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>You must always put a mock method definition (`MOCK_METHOD`) in a `public:`
<a class="l" name="85" href="#85">85</a>section of the mock class, regardless of the method being mocked being `public`,
<a class="l" name="86" href="#86">86</a>`protected`, or `private` in the base class. This allows `ON_CALL` and
<a class="l" name="87" href="#87">87</a>`EXPECT_CALL` to reference the mock function from outside of the mock class.
<a class="l" name="88" href="#88">88</a>(Yes, C++ allows a subclass to change the access level of a virtual function in
<a class="l" name="89" href="#89">89</a>the base class.) Example:
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>```cpp
<a class="l" name="92" href="#92">92</a>class Foo {
<a class="l" name="93" href="#93">93</a> public:
<a class="l" name="94" href="#94">94</a>  ...
<a class="l" name="95" href="#95">95</a>  virtual bool Transform(Gadget* g) = 0;
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a> protected:
<a class="l" name="98" href="#98">98</a>  virtual void Resume();
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a> private:
<a class="l" name="101" href="#101">101</a>  virtual int GetTimeOut();
<a class="l" name="102" href="#102">102</a>};
<a class="l" name="103" href="#103">103</a>
<a class="l" name="104" href="#104">104</a>class MockFoo : public Foo {
<a class="l" name="105" href="#105">105</a> public:
<a class="l" name="106" href="#106">106</a>  ...
<a class="l" name="107" href="#107">107</a>  MOCK_METHOD(bool, Transform, (Gadget* g), (override));
<a class="l" name="108" href="#108">108</a>
<a class="l" name="109" href="#109">109</a>  // The following must be in the public section, even though the
<a class="hl" name="110" href="#110">110</a>  // methods are protected or private in the base class.
<a class="l" name="111" href="#111">111</a>  MOCK_METHOD(void, Resume, (), (override));
<a class="l" name="112" href="#112">112</a>  MOCK_METHOD(int, GetTimeOut, (), (override));
<a class="l" name="113" href="#113">113</a>};
<a class="l" name="114" href="#114">114</a>```
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>### Mocking Overloaded Methods
<a class="l" name="117" href="#117">117</a>
<a class="l" name="118" href="#118">118</a>You can mock overloaded functions as usual. No special attention is required:
<a class="l" name="119" href="#119">119</a>
<a class="hl" name="120" href="#120">120</a>```cpp
<a class="l" name="121" href="#121">121</a>class Foo {
<a class="l" name="122" href="#122">122</a>  ...
<a class="l" name="123" href="#123">123</a>
<a class="l" name="124" href="#124">124</a>  // Must be virtual as we'll inherit from Foo.
<a class="l" name="125" href="#125">125</a>  virtual ~Foo();
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>  // Overloaded on the types <a href="/googletest/s?path=and/or&amp;project=googletest">and/or</a> numbers of arguments.
<a class="l" name="128" href="#128">128</a>  virtual int Add(Element x);
<a class="l" name="129" href="#129">129</a>  virtual int Add(int times, Element x);
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a>  // Overloaded on the const-ness of this object.
<a class="l" name="132" href="#132">132</a>  virtual Bar&amp; GetBar();
<a class="l" name="133" href="#133">133</a>  virtual const Bar&amp; GetBar() const;
<a class="l" name="134" href="#134">134</a>};
<a class="l" name="135" href="#135">135</a>
<a class="l" name="136" href="#136">136</a>class MockFoo : public Foo {
<a class="l" name="137" href="#137">137</a>  ...
<a class="l" name="138" href="#138">138</a>  MOCK_METHOD(int, Add, (Element x), (override));
<a class="l" name="139" href="#139">139</a>  MOCK_METHOD(int, Add, (int times, Element x), (override));
<a class="hl" name="140" href="#140">140</a>
<a class="l" name="141" href="#141">141</a>  MOCK_METHOD(Bar&amp;, GetBar, (), (override));
<a class="l" name="142" href="#142">142</a>  MOCK_METHOD(const Bar&amp;, GetBar, (), (const, override));
<a class="l" name="143" href="#143">143</a>};
<a class="l" name="144" href="#144">144</a>```
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>**Note:** if you don't mock all versions of the overloaded method, the compiler
<a class="l" name="147" href="#147">147</a>will give you a warning about some methods in the base class being hidden. To
<a class="l" name="148" href="#148">148</a>fix that, use `using` to bring them in scope:
<a class="l" name="149" href="#149">149</a>
<a class="hl" name="150" href="#150">150</a>```cpp
<a class="l" name="151" href="#151">151</a>class MockFoo : public Foo {
<a class="l" name="152" href="#152">152</a>  ...
<a class="l" name="153" href="#153">153</a>  using Foo::Add;
<a class="l" name="154" href="#154">154</a>  MOCK_METHOD(int, Add, (Element x), (override));
<a class="l" name="155" href="#155">155</a>  // We don't want to mock int Add(int times, Element x);
<a class="l" name="156" href="#156">156</a>  ...
<a class="l" name="157" href="#157">157</a>};
<a class="l" name="158" href="#158">158</a>```
<a class="l" name="159" href="#159">159</a>
<a class="hl" name="160" href="#160">160</a>### Mocking Class Templates
<a class="l" name="161" href="#161">161</a>
<a class="l" name="162" href="#162">162</a>You can mock class templates just like any class.
<a class="l" name="163" href="#163">163</a>
<a class="l" name="164" href="#164">164</a>```cpp
<a class="l" name="165" href="#165">165</a>template &lt;typename Elem&gt;
<a class="l" name="166" href="#166">166</a>class StackInterface {
<a class="l" name="167" href="#167">167</a>  ...
<a class="l" name="168" href="#168">168</a>  // Must be virtual as we'll inherit from StackInterface.
<a class="l" name="169" href="#169">169</a>  virtual ~StackInterface();
<a class="hl" name="170" href="#170">170</a>
<a class="l" name="171" href="#171">171</a>  virtual int GetSize() const = 0;
<a class="l" name="172" href="#172">172</a>  virtual void Push(const Elem&amp; x) = 0;
<a class="l" name="173" href="#173">173</a>};
<a class="l" name="174" href="#174">174</a>
<a class="l" name="175" href="#175">175</a>template &lt;typename Elem&gt;
<a class="l" name="176" href="#176">176</a>class MockStack : public StackInterface&lt;Elem&gt; {
<a class="l" name="177" href="#177">177</a>  ...
<a class="l" name="178" href="#178">178</a>  MOCK_METHOD(int, GetSize, (), (override));
<a class="l" name="179" href="#179">179</a>  MOCK_METHOD(void, Push, (const Elem&amp; x), (override));
<a class="hl" name="180" href="#180">180</a>};
<a class="l" name="181" href="#181">181</a>```
<a class="l" name="182" href="#182">182</a>
<a class="l" name="183" href="#183">183</a>### Mocking Non-virtual Methods {#MockingNonVirtualMethods}
<a class="l" name="184" href="#184">184</a>
<a class="l" name="185" href="#185">185</a>gMock can mock non-virtual functions to be used in Hi-perf dependency
<a class="l" name="186" href="#186">186</a>injection.&lt;!-- GOOGLETEST_CM0017 DO NOT DELETE --&gt;
<a class="l" name="187" href="#187">187</a>
<a class="l" name="188" href="#188">188</a>In this case, instead of sharing a common base class with the real class, your
<a class="l" name="189" href="#189">189</a>mock class will be *unrelated* to the real class, but contain methods with the
<a class="hl" name="190" href="#190">190</a>same signatures. The syntax for mocking non-virtual methods is the *same* as
<a class="l" name="191" href="#191">191</a>mocking virtual methods (just don't add `override`):
<a class="l" name="192" href="#192">192</a>
<a class="l" name="193" href="#193">193</a>```cpp
<a class="l" name="194" href="#194">194</a>// A simple packet stream class.  None of its members is virtual.
<a class="l" name="195" href="#195">195</a>class ConcretePacketStream {
<a class="l" name="196" href="#196">196</a> public:
<a class="l" name="197" href="#197">197</a>  void AppendPacket(Packet* new_packet);
<a class="l" name="198" href="#198">198</a>  const Packet* GetPacket(size_t packet_number) const;
<a class="l" name="199" href="#199">199</a>  size_t NumberOfPackets() const;
<a class="hl" name="200" href="#200">200</a>  ...
<a class="l" name="201" href="#201">201</a>};
<a class="l" name="202" href="#202">202</a>
<a class="l" name="203" href="#203">203</a>// A mock packet stream class.  It inherits from no other, but defines
<a class="l" name="204" href="#204">204</a>// GetPacket() and NumberOfPackets().
<a class="l" name="205" href="#205">205</a>class MockPacketStream {
<a class="l" name="206" href="#206">206</a> public:
<a class="l" name="207" href="#207">207</a>  MOCK_METHOD(const Packet*, GetPacket, (size_t packet_number), (const));
<a class="l" name="208" href="#208">208</a>  MOCK_METHOD(size_t, NumberOfPackets, (), (const));
<a class="l" name="209" href="#209">209</a>  ...
<a class="hl" name="210" href="#210">210</a>};
<a class="l" name="211" href="#211">211</a>```
<a class="l" name="212" href="#212">212</a>
<a class="l" name="213" href="#213">213</a>Note that the mock class doesn't define `AppendPacket()`, unlike the real class.
<a class="l" name="214" href="#214">214</a>That's fine as long as the test doesn't need to call it.
<a class="l" name="215" href="#215">215</a>
<a class="l" name="216" href="#216">216</a>Next, you need a way to say that you want to use `ConcretePacketStream` in
<a class="l" name="217" href="#217">217</a>production code, and use `MockPacketStream` in tests. Since the functions are
<a class="l" name="218" href="#218">218</a>not virtual and the two classes are unrelated, you must specify your choice at
<a class="l" name="219" href="#219">219</a>*compile time* (as opposed to run time).
<a class="hl" name="220" href="#220">220</a>
<a class="l" name="221" href="#221">221</a>One way to do it is to templatize your code that needs to use a packet stream.
<a class="l" name="222" href="#222">222</a>More specifically, you will give your code a template type argument for the type
<a class="l" name="223" href="#223">223</a>of the packet stream. In production, you will instantiate your template with
<a class="l" name="224" href="#224">224</a>`ConcretePacketStream` as the type argument. In tests, you will instantiate the
<a class="l" name="225" href="#225">225</a>same template with `MockPacketStream`. For example, you may write:
<a class="l" name="226" href="#226">226</a>
<a class="l" name="227" href="#227">227</a>```cpp
<a class="l" name="228" href="#228">228</a>template &lt;class PacketStream&gt;
<a class="l" name="229" href="#229">229</a>void CreateConnection(PacketStream* stream) { ... }
<a class="hl" name="230" href="#230">230</a>
<a class="l" name="231" href="#231">231</a>template &lt;class PacketStream&gt;
<a class="l" name="232" href="#232">232</a>class PacketReader {
<a class="l" name="233" href="#233">233</a> public:
<a class="l" name="234" href="#234">234</a>  void ReadPackets(PacketStream* stream, size_t packet_num);
<a class="l" name="235" href="#235">235</a>};
<a class="l" name="236" href="#236">236</a>```
<a class="l" name="237" href="#237">237</a>
<a class="l" name="238" href="#238">238</a>Then you can use `CreateConnection&lt;ConcretePacketStream&gt;()` and
<a class="l" name="239" href="#239">239</a>`PacketReader&lt;ConcretePacketStream&gt;` in production code, and use
<a class="hl" name="240" href="#240">240</a>`CreateConnection&lt;MockPacketStream&gt;()` and `PacketReader&lt;MockPacketStream&gt;` in
<a class="l" name="241" href="#241">241</a>tests.
<a class="l" name="242" href="#242">242</a>
<a class="l" name="243" href="#243">243</a>```cpp
<a class="l" name="244" href="#244">244</a>  MockPacketStream mock_stream;
<a class="l" name="245" href="#245">245</a>  EXPECT_CALL(mock_stream, ...)...;
<a class="l" name="246" href="#246">246</a>  .. set more expectations on mock_stream ...
<a class="l" name="247" href="#247">247</a>  PacketReader&lt;MockPacketStream&gt; reader(&amp;mock_stream);
<a class="l" name="248" href="#248">248</a>  ... exercise reader ...
<a class="l" name="249" href="#249">249</a>```
<a class="hl" name="250" href="#250">250</a>
<a class="l" name="251" href="#251">251</a>### Mocking Free Functions
<a class="l" name="252" href="#252">252</a>
<a class="l" name="253" href="#253">253</a>It's possible to use gMock to mock a free function (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> a C-style function or a
<a class="l" name="254" href="#254">254</a>static method). You just need to rewrite your code to use an interface (abstract
<a class="l" name="255" href="#255">255</a>class).
<a class="l" name="256" href="#256">256</a>
<a class="l" name="257" href="#257">257</a>Instead of calling a free function (say, `OpenFile`) directly, introduce an
<a class="l" name="258" href="#258">258</a>interface for it and have a concrete subclass that calls the free function:
<a class="l" name="259" href="#259">259</a>
<a class="hl" name="260" href="#260">260</a>```cpp
<a class="l" name="261" href="#261">261</a>class FileInterface {
<a class="l" name="262" href="#262">262</a> public:
<a class="l" name="263" href="#263">263</a>  ...
<a class="l" name="264" href="#264">264</a>  virtual bool Open(const char* path, const char* mode) = 0;
<a class="l" name="265" href="#265">265</a>};
<a class="l" name="266" href="#266">266</a>
<a class="l" name="267" href="#267">267</a>class File : public FileInterface {
<a class="l" name="268" href="#268">268</a> public:
<a class="l" name="269" href="#269">269</a>  ...
<a class="hl" name="270" href="#270">270</a>  virtual bool Open(const char* path, const char* mode) {
<a class="l" name="271" href="#271">271</a>     return OpenFile(path, mode);
<a class="l" name="272" href="#272">272</a>  }
<a class="l" name="273" href="#273">273</a>};
<a class="l" name="274" href="#274">274</a>```
<a class="l" name="275" href="#275">275</a>
<a class="l" name="276" href="#276">276</a>Your code should talk to `FileInterface` to open a file. Now it's easy to mock
<a class="l" name="277" href="#277">277</a>out the function.
<a class="l" name="278" href="#278">278</a>
<a class="l" name="279" href="#279">279</a>This may seem like a lot of hassle, but in practice you often have multiple
<a class="hl" name="280" href="#280">280</a>related functions that you can put in the same interface, so the per-function
<a class="l" name="281" href="#281">281</a>syntactic overhead will be much lower.
<a class="l" name="282" href="#282">282</a>
<a class="l" name="283" href="#283">283</a>If you are concerned about the performance overhead incurred by virtual
<a class="l" name="284" href="#284">284</a>functions, and profiling confirms your concern, you can combine this with the
<a class="l" name="285" href="#285">285</a>recipe for [mocking non-virtual methods](#MockingNonVirtualMethods).
<a class="l" name="286" href="#286">286</a>
<a class="l" name="287" href="#287">287</a>### Old-Style `MOCK_METHODn` Macros
<a class="l" name="288" href="#288">288</a>
<a class="l" name="289" href="#289">289</a>Before the generic `MOCK_METHOD` macro
<a class="hl" name="290" href="#290">290</a>[was introduced in 2018](<a href="https://github.com/google/googletest/commit/c5f08bf91944ce1b19bcf414fa1760e69d20afc2">https://github.com/google/googletest/commit/c5f08bf91944ce1b19bcf414fa1760e69d20afc2</a>),
<a class="l" name="291" href="#291">291</a>mocks where created using a family of macros collectively called `MOCK_METHODn`.
<a class="l" name="292" href="#292">292</a>These macros are still supported, though migration to the new `MOCK_METHOD` is
<a class="l" name="293" href="#293">293</a>recommended.
<a class="l" name="294" href="#294">294</a>
<a class="l" name="295" href="#295">295</a>The macros in the `MOCK_METHODn` family differ from `MOCK_METHOD`:
<a class="l" name="296" href="#296">296</a>
<a class="l" name="297" href="#297">297</a>*   The general structure is `MOCK_METHODn(MethodName, ReturnType(Args))`,
<a class="l" name="298" href="#298">298</a>    instead of `MOCK_METHOD(ReturnType, MethodName, (Args))`.
<a class="l" name="299" href="#299">299</a>*   The number `n` must equal the number of arguments.
<a class="hl" name="300" href="#300">300</a>*   When mocking a const method, one must use `MOCK_CONST_METHODn`.
<a class="l" name="301" href="#301">301</a>*   When mocking a class template, the macro name must be suffixed with `_T`.
<a class="l" name="302" href="#302">302</a>*   In order to specify the call type, the macro name must be suffixed with
<a class="l" name="303" href="#303">303</a>    `_WITH_CALLTYPE`, and the call type is the first macro argument.
<a class="l" name="304" href="#304">304</a>
<a class="l" name="305" href="#305">305</a>Old macros and their new equivalents:
<a class="l" name="306" href="#306">306</a>
<a class="l" name="307" href="#307">307</a>&lt;a name="table99"&gt;&lt;/a&gt;
<a class="l" name="308" href="#308">308</a>&lt;table border="1" cellspacing="0" cellpadding="1"&gt;
<a class="l" name="309" href="#309">309</a>&lt;tr&gt; &lt;th colspan=2&gt; Simple &lt;/th&gt;&lt;/tr&gt;
<a class="hl" name="310" href="#310">310</a>&lt;tr&gt; &lt;td&gt; Old &lt;/td&gt; &lt;td&gt; `MOCK_METHOD1(Foo, bool(int))` &lt;/td&gt; &lt;/tr&gt;
<a class="l" name="311" href="#311">311</a>&lt;tr&gt; &lt;td&gt; New &lt;/td&gt; &lt;td&gt; `MOCK_METHOD(bool, Foo, (int))` &lt;/td&gt; &lt;/tr&gt;
<a class="l" name="312" href="#312">312</a>
<a class="l" name="313" href="#313">313</a>&lt;tr&gt; &lt;th colspan=2&gt; Const Method &lt;/th&gt;&lt;/tr&gt; &lt;tr&gt; &lt;td&gt; Old &lt;/td&gt; &lt;td&gt;
<a class="l" name="314" href="#314">314</a>`MOCK_CONST_METHOD1(Foo, bool(int))` &lt;/td&gt; &lt;/tr&gt; &lt;tr&gt; &lt;td&gt; New &lt;/td&gt; &lt;td&gt;
<a class="l" name="315" href="#315">315</a>`MOCK_METHOD(bool, Foo, (int), (const))` &lt;/td&gt; &lt;/tr&gt;
<a class="l" name="316" href="#316">316</a>
<a class="l" name="317" href="#317">317</a>&lt;tr&gt; &lt;th colspan=2&gt; Method in a Class Template &lt;/th&gt;&lt;/tr&gt; &lt;tr&gt; &lt;td&gt; Old &lt;/td&gt;
<a class="l" name="318" href="#318">318</a>&lt;td&gt; `MOCK_METHOD1_T(Foo, bool(int))` &lt;/td&gt; &lt;/tr&gt; &lt;tr&gt; &lt;td&gt; New &lt;/td&gt; &lt;td&gt;
<a class="l" name="319" href="#319">319</a>`MOCK_METHOD(bool, Foo, (int))` &lt;/td&gt; &lt;/tr&gt;
<a class="hl" name="320" href="#320">320</a>
<a class="l" name="321" href="#321">321</a>&lt;tr&gt; &lt;th colspan=2&gt; Const Method in a Class Template &lt;/th&gt;&lt;/tr&gt; &lt;tr&gt; &lt;td&gt; Old
<a class="l" name="322" href="#322">322</a>&lt;/td&gt; &lt;td&gt; `MOCK_CONST_METHOD1_T(Foo, bool(int))` &lt;/td&gt; &lt;/tr&gt; &lt;tr&gt; &lt;td&gt; New
<a class="l" name="323" href="#323">323</a>&lt;/td&gt; &lt;td&gt; `MOCK_METHOD(bool, Foo, (int), (const))` &lt;/td&gt; &lt;/tr&gt;
<a class="l" name="324" href="#324">324</a>
<a class="l" name="325" href="#325">325</a>&lt;tr&gt; &lt;th colspan=2&gt; Method with Call Type &lt;/th&gt;&lt;/tr&gt; &lt;tr&gt; &lt;td&gt; Old &lt;/td&gt; &lt;td&gt;
<a class="l" name="326" href="#326">326</a>`MOCK_METHOD1_WITH_CALLTYPE(STDMETHODCALLTYPE, Foo, bool(int))` &lt;/td&gt; &lt;/tr&gt; &lt;tr&gt;
<a class="l" name="327" href="#327">327</a>&lt;td&gt; New &lt;/td&gt; &lt;td&gt; `MOCK_METHOD(bool, Foo, (int),
<a class="l" name="328" href="#328">328</a>(Calltype(STDMETHODCALLTYPE)))` &lt;/td&gt; &lt;/tr&gt;
<a class="l" name="329" href="#329">329</a>
<a class="hl" name="330" href="#330">330</a>&lt;tr&gt; &lt;th colspan=2&gt; Const Method with Call Type &lt;/th&gt;&lt;/tr&gt; &lt;tr&gt; &lt;td&gt; Old&lt;/td&gt;
<a class="l" name="331" href="#331">331</a>&lt;td&gt; `MOCK_CONST_METHOD1_WITH_CALLTYPE(STDMETHODCALLTYPE, Foo, bool(int))` &lt;/td&gt;
<a class="l" name="332" href="#332">332</a>&lt;/tr&gt; &lt;tr&gt; &lt;td&gt; New &lt;/td&gt; &lt;td&gt; `MOCK_METHOD(bool, Foo, (int), (const,
<a class="l" name="333" href="#333">333</a>Calltype(STDMETHODCALLTYPE)))` &lt;/td&gt; &lt;/tr&gt;
<a class="l" name="334" href="#334">334</a>
<a class="l" name="335" href="#335">335</a>&lt;tr&gt; &lt;th colspan=2&gt; Method with Call Type in a Class Template &lt;/th&gt;&lt;/tr&gt; &lt;tr&gt;
<a class="l" name="336" href="#336">336</a>&lt;td&gt; Old &lt;/td&gt; &lt;td&gt; `MOCK_METHOD1_T_WITH_CALLTYPE(STDMETHODCALLTYPE, Foo,
<a class="l" name="337" href="#337">337</a>bool(int))` &lt;/td&gt; &lt;/tr&gt; &lt;tr&gt; &lt;td&gt; New &lt;/td&gt; &lt;td&gt; `MOCK_METHOD(bool, Foo, (int),
<a class="l" name="338" href="#338">338</a>(Calltype(STDMETHODCALLTYPE)))` &lt;/td&gt; &lt;/tr&gt;
<a class="l" name="339" href="#339">339</a>
<a class="hl" name="340" href="#340">340</a>&lt;tr&gt; &lt;th colspan=2&gt; Const Method with Call Type in a Class Template &lt;/th&gt;&lt;/tr&gt;
<a class="l" name="341" href="#341">341</a>&lt;tr&gt; &lt;td&gt; Old &lt;/td&gt; &lt;td&gt; `MOCK_CONST_METHOD1_T_WITH_CALLTYPE(STDMETHODCALLTYPE,
<a class="l" name="342" href="#342">342</a>Foo, bool(int))` &lt;/td&gt; &lt;/tr&gt; &lt;tr&gt; &lt;td&gt; New &lt;/td&gt; &lt;td&gt; `MOCK_METHOD(bool, Foo,
<a class="l" name="343" href="#343">343</a>(int), (const, Calltype(STDMETHODCALLTYPE)))` &lt;/td&gt; &lt;/tr&gt;
<a class="l" name="344" href="#344">344</a>
<a class="l" name="345" href="#345">345</a>&lt;/table&gt;
<a class="l" name="346" href="#346">346</a>
<a class="l" name="347" href="#347">347</a>### The Nice, the Strict, and the Naggy {#NiceStrictNaggy}
<a class="l" name="348" href="#348">348</a>
<a class="l" name="349" href="#349">349</a>If a mock method has no `EXPECT_CALL` spec but is called, we say that it's an
<a class="hl" name="350" href="#350">350</a>"uninteresting call", and the default action (which can be specified using
<a class="l" name="351" href="#351">351</a>`ON_CALL()`) of the method will be taken. Currently, an uninteresting call will
<a class="l" name="352" href="#352">352</a>also by default cause gMock to print a warning. (In the future, we might remove
<a class="l" name="353" href="#353">353</a>this warning by default.)
<a class="l" name="354" href="#354">354</a>
<a class="l" name="355" href="#355">355</a>However, sometimes you may want to ignore these uninteresting calls, and
<a class="l" name="356" href="#356">356</a>sometimes you may want to treat them as errors. gMock lets you make the decision
<a class="l" name="357" href="#357">357</a>on a per-mock-object basis.
<a class="l" name="358" href="#358">358</a>
<a class="l" name="359" href="#359">359</a>Suppose your test uses a mock class `MockFoo`:
<a class="hl" name="360" href="#360">360</a>
<a class="l" name="361" href="#361">361</a>```cpp
<a class="l" name="362" href="#362">362</a>TEST(...) {
<a class="l" name="363" href="#363">363</a>  MockFoo mock_foo;
<a class="l" name="364" href="#364">364</a>  EXPECT_CALL(mock_foo, DoThis());
<a class="l" name="365" href="#365">365</a>  ... code that uses mock_foo ...
<a class="l" name="366" href="#366">366</a>}
<a class="l" name="367" href="#367">367</a>```
<a class="l" name="368" href="#368">368</a>
<a class="l" name="369" href="#369">369</a>If a method of `mock_foo` other than `DoThis()` is called, you will get a
<a class="hl" name="370" href="#370">370</a>warning. However, if you rewrite your test to use `NiceMock&lt;MockFoo&gt;` instead,
<a class="l" name="371" href="#371">371</a>you can suppress the warning:
<a class="l" name="372" href="#372">372</a>
<a class="l" name="373" href="#373">373</a>```cpp
<a class="l" name="374" href="#374">374</a>using ::testing::NiceMock;
<a class="l" name="375" href="#375">375</a>
<a class="l" name="376" href="#376">376</a>TEST(...) {
<a class="l" name="377" href="#377">377</a>  NiceMock&lt;MockFoo&gt; mock_foo;
<a class="l" name="378" href="#378">378</a>  EXPECT_CALL(mock_foo, DoThis());
<a class="l" name="379" href="#379">379</a>  ... code that uses mock_foo ...
<a class="hl" name="380" href="#380">380</a>}
<a class="l" name="381" href="#381">381</a>```
<a class="l" name="382" href="#382">382</a>
<a class="l" name="383" href="#383">383</a>`NiceMock&lt;MockFoo&gt;` is a subclass of `MockFoo`, so it can be used wherever
<a class="l" name="384" href="#384">384</a>`MockFoo` is accepted.
<a class="l" name="385" href="#385">385</a>
<a class="l" name="386" href="#386">386</a>It also works if `MockFoo`'s constructor takes some arguments, as
<a class="l" name="387" href="#387">387</a>`NiceMock&lt;MockFoo&gt;` "inherits" `MockFoo`'s constructors:
<a class="l" name="388" href="#388">388</a>
<a class="l" name="389" href="#389">389</a>```cpp
<a class="hl" name="390" href="#390">390</a>using ::testing::NiceMock;
<a class="l" name="391" href="#391">391</a>
<a class="l" name="392" href="#392">392</a>TEST(...) {
<a class="l" name="393" href="#393">393</a>  NiceMock&lt;MockFoo&gt; mock_foo(5, "hi");  // Calls MockFoo(5, "hi").
<a class="l" name="394" href="#394">394</a>  EXPECT_CALL(mock_foo, DoThis());
<a class="l" name="395" href="#395">395</a>  ... code that uses mock_foo ...
<a class="l" name="396" href="#396">396</a>}
<a class="l" name="397" href="#397">397</a>```
<a class="l" name="398" href="#398">398</a>
<a class="l" name="399" href="#399">399</a>The usage of `StrictMock` is similar, except that it makes all uninteresting
<a class="hl" name="400" href="#400">400</a>calls failures:
<a class="l" name="401" href="#401">401</a>
<a class="l" name="402" href="#402">402</a>```cpp
<a class="l" name="403" href="#403">403</a>using ::testing::StrictMock;
<a class="l" name="404" href="#404">404</a>
<a class="l" name="405" href="#405">405</a>TEST(...) {
<a class="l" name="406" href="#406">406</a>  StrictMock&lt;MockFoo&gt; mock_foo;
<a class="l" name="407" href="#407">407</a>  EXPECT_CALL(mock_foo, DoThis());
<a class="l" name="408" href="#408">408</a>  ... code that uses mock_foo ...
<a class="l" name="409" href="#409">409</a>
<a class="hl" name="410" href="#410">410</a>  // The test will fail if a method of mock_foo other than DoThis()
<a class="l" name="411" href="#411">411</a>  // is called.
<a class="l" name="412" href="#412">412</a>}
<a class="l" name="413" href="#413">413</a>```
<a class="l" name="414" href="#414">414</a>
<a class="l" name="415" href="#415">415</a>NOTE: `NiceMock` and `StrictMock` only affects *uninteresting* calls (calls of
<a class="l" name="416" href="#416">416</a>*methods* with no expectations); they do not affect *unexpected* calls (calls of
<a class="l" name="417" href="#417">417</a>methods with expectations, but they don't match). See
<a class="l" name="418" href="#418">418</a>[Understanding Uninteresting vs Unexpected Calls](#uninteresting-vs-unexpected).
<a class="l" name="419" href="#419">419</a>
<a class="hl" name="420" href="#420">420</a>There are some caveats though (sadly they are side effects of C++'s
<a class="l" name="421" href="#421">421</a>limitations):
<a class="l" name="422" href="#422">422</a>
<a class="l" name="423" href="#423">423</a>1.  `NiceMock&lt;MockFoo&gt;` and `StrictMock&lt;MockFoo&gt;` only work for mock methods
<a class="l" name="424" href="#424">424</a>    defined using the `MOCK_METHOD` macro **directly** in the `MockFoo` class.
<a class="l" name="425" href="#425">425</a>    If a mock method is defined in a **base class** of `MockFoo`, the "nice" or
<a class="l" name="426" href="#426">426</a>    "strict" modifier may not affect it, depending on the compiler. In
<a class="l" name="427" href="#427">427</a>    particular, nesting `NiceMock` and `StrictMock` (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="l" name="428" href="#428">428</a>    `NiceMock&lt;StrictMock&lt;MockFoo&gt; &gt;`) is **not** supported.
<a class="l" name="429" href="#429">429</a>2.  `NiceMock&lt;MockFoo&gt;` and `StrictMock&lt;MockFoo&gt;` may not work correctly if the
<a class="hl" name="430" href="#430">430</a>    destructor of `MockFoo` is not virtual. We would like to fix this, but it
<a class="l" name="431" href="#431">431</a>    requires cleaning up existing tests.
<a class="l" name="432" href="#432">432</a>3.  During the constructor or destructor of `MockFoo`, the mock object is *not*
<a class="l" name="433" href="#433">433</a>    nice or strict. This may cause surprises if the constructor or destructor
<a class="l" name="434" href="#434">434</a>    calls a mock method on `this` object. (This behavior, however, is consistent
<a class="l" name="435" href="#435">435</a>    with C++'s general rule: if a constructor or destructor calls a virtual
<a class="l" name="436" href="#436">436</a>    method of `this` object, that method is treated as non-virtual. In other
<a class="l" name="437" href="#437">437</a>    words, to the base class's constructor or destructor, `this` object behaves
<a class="l" name="438" href="#438">438</a>    like an instance of the base class, not the derived class. This rule is
<a class="l" name="439" href="#439">439</a>    required for safety. Otherwise a base constructor may use members of a
<a class="hl" name="440" href="#440">440</a>    derived class before they are initialized, or a base destructor may use
<a class="l" name="441" href="#441">441</a>    members of a derived class after they have been destroyed.)
<a class="l" name="442" href="#442">442</a>
<a class="l" name="443" href="#443">443</a>Finally, you should be **very cautious** about when to use naggy or strict
<a class="l" name="444" href="#444">444</a>mocks, as they tend to make tests more brittle and harder to maintain. When you
<a class="l" name="445" href="#445">445</a>refactor your code without changing its externally visible behavior, ideally you
<a class="l" name="446" href="#446">446</a>shouldn't need to update any tests. If your code interacts with a naggy mock,
<a class="l" name="447" href="#447">447</a>however, you may start to get spammed with warnings as the result of your
<a class="l" name="448" href="#448">448</a>change. Worse, if your code interacts with a strict mock, your tests may start
<a class="l" name="449" href="#449">449</a>to fail and you'll be forced to fix them. Our general recommendation is to use
<a class="hl" name="450" href="#450">450</a>nice mocks (not yet the default) most of the time, use naggy mocks (the current
<a class="l" name="451" href="#451">451</a>default) when developing or debugging tests, and use strict mocks only as the
<a class="l" name="452" href="#452">452</a>last resort.
<a class="l" name="453" href="#453">453</a>
<a class="l" name="454" href="#454">454</a>### Simplifying the Interface without Breaking Existing Code {#SimplerInterfaces}
<a class="l" name="455" href="#455">455</a>
<a class="l" name="456" href="#456">456</a>Sometimes a method has a long list of arguments that is mostly uninteresting.
<a class="l" name="457" href="#457">457</a>For example:
<a class="l" name="458" href="#458">458</a>
<a class="l" name="459" href="#459">459</a>```cpp
<a class="hl" name="460" href="#460">460</a>class LogSink {
<a class="l" name="461" href="#461">461</a> public:
<a class="l" name="462" href="#462">462</a>  ...
<a class="l" name="463" href="#463">463</a>  virtual void send(LogSeverity severity, const char* full_filename,
<a class="l" name="464" href="#464">464</a>                    const char* base_filename, int line,
<a class="l" name="465" href="#465">465</a>                    const struct tm* tm_time,
<a class="l" name="466" href="#466">466</a>                    const char* message, size_t message_len) = 0;
<a class="l" name="467" href="#467">467</a>};
<a class="l" name="468" href="#468">468</a>```
<a class="l" name="469" href="#469">469</a>
<a class="hl" name="470" href="#470">470</a>This method's argument list is lengthy and hard to work with (the `message`
<a class="l" name="471" href="#471">471</a>argument is not even 0-terminated). If we mock it as is, using the mock will be
<a class="l" name="472" href="#472">472</a>awkward. If, however, we try to simplify this interface, we'll need to fix all
<a class="l" name="473" href="#473">473</a>clients depending on it, which is often infeasible.
<a class="l" name="474" href="#474">474</a>
<a class="l" name="475" href="#475">475</a>The trick is to redispatch the method in the mock class:
<a class="l" name="476" href="#476">476</a>
<a class="l" name="477" href="#477">477</a>```cpp
<a class="l" name="478" href="#478">478</a>class ScopedMockLog : public LogSink {
<a class="l" name="479" href="#479">479</a> public:
<a class="hl" name="480" href="#480">480</a>  ...
<a class="l" name="481" href="#481">481</a>  virtual void send(LogSeverity severity, const char* full_filename,
<a class="l" name="482" href="#482">482</a>                    const char* base_filename, int line, const tm* tm_time,
<a class="l" name="483" href="#483">483</a>                    const char* message, size_t message_len) {
<a class="l" name="484" href="#484">484</a>    // We are only interested in the log severity, full file name, and
<a class="l" name="485" href="#485">485</a>    // log message.
<a class="l" name="486" href="#486">486</a>    Log(severity, full_filename, std::string(message, message_len));
<a class="l" name="487" href="#487">487</a>  }
<a class="l" name="488" href="#488">488</a>
<a class="l" name="489" href="#489">489</a>  // Implements the mock method:
<a class="hl" name="490" href="#490">490</a>  //
<a class="l" name="491" href="#491">491</a>  //   void Log(LogSeverity severity,
<a class="l" name="492" href="#492">492</a>  //            const string&amp; file_path,
<a class="l" name="493" href="#493">493</a>  //            const string&amp; message);
<a class="l" name="494" href="#494">494</a>  MOCK_METHOD(void, Log,
<a class="l" name="495" href="#495">495</a>              (LogSeverity severity, const string&amp; file_path,
<a class="l" name="496" href="#496">496</a>               const string&amp; message));
<a class="l" name="497" href="#497">497</a>};
<a class="l" name="498" href="#498">498</a>```
<a class="l" name="499" href="#499">499</a>
<a class="hl" name="500" href="#500">500</a>By defining a new mock method with a trimmed argument list, we make the mock
<a class="l" name="501" href="#501">501</a>class more user-friendly.
<a class="l" name="502" href="#502">502</a>
<a class="l" name="503" href="#503">503</a>This technique may also be applied to make overloaded methods more amenable to
<a class="l" name="504" href="#504">504</a>mocking. For example, when overloads have been used to implement default
<a class="l" name="505" href="#505">505</a>arguments:
<a class="l" name="506" href="#506">506</a>
<a class="l" name="507" href="#507">507</a>```cpp
<a class="l" name="508" href="#508">508</a>class MockTurtleFactory : public TurtleFactory {
<a class="l" name="509" href="#509">509</a> public:
<a class="hl" name="510" href="#510">510</a>  Turtle* MakeTurtle(int length, int weight) override { ... }
<a class="l" name="511" href="#511">511</a>  Turtle* MakeTurtle(int length, int weight, int speed) override { ... }
<a class="l" name="512" href="#512">512</a>
<a class="l" name="513" href="#513">513</a>  // the above methods delegate to this one:
<a class="l" name="514" href="#514">514</a>  MOCK_METHOD(Turtle*, DoMakeTurtle, ());
<a class="l" name="515" href="#515">515</a>};
<a class="l" name="516" href="#516">516</a>```
<a class="l" name="517" href="#517">517</a>
<a class="l" name="518" href="#518">518</a>This allows tests that don't care which overload was invoked to avoid specifying
<a class="l" name="519" href="#519">519</a>argument matchers:
<a class="hl" name="520" href="#520">520</a>
<a class="l" name="521" href="#521">521</a>```cpp
<a class="l" name="522" href="#522">522</a>ON_CALL(factory, DoMakeTurtle)
<a class="l" name="523" href="#523">523</a>    .WillByDefault(MakeMockTurtle());
<a class="l" name="524" href="#524">524</a>```
<a class="l" name="525" href="#525">525</a>
<a class="l" name="526" href="#526">526</a>### Alternative to Mocking Concrete Classes
<a class="l" name="527" href="#527">527</a>
<a class="l" name="528" href="#528">528</a>Often you may find yourself using classes that don't implement interfaces. In
<a class="l" name="529" href="#529">529</a>order to test your code that uses such a class (let's call it `Concrete`), you
<a class="hl" name="530" href="#530">530</a>may be tempted to make the methods of `Concrete` virtual and then mock it.
<a class="l" name="531" href="#531">531</a>
<a class="l" name="532" href="#532">532</a>Try not to do that.
<a class="l" name="533" href="#533">533</a>
<a class="l" name="534" href="#534">534</a>Making a non-virtual function virtual is a big decision. It creates an extension
<a class="l" name="535" href="#535">535</a>point where subclasses can tweak your class' behavior. This weakens your control
<a class="l" name="536" href="#536">536</a>on the class because now it's harder to maintain the class invariants. You
<a class="l" name="537" href="#537">537</a>should make a function virtual only when there is a valid reason for a subclass
<a class="l" name="538" href="#538">538</a>to override it.
<a class="l" name="539" href="#539">539</a>
<a class="hl" name="540" href="#540">540</a>Mocking concrete classes directly is problematic as it creates a tight coupling
<a class="l" name="541" href="#541">541</a>between the class and the tests - any small change in the class may invalidate
<a class="l" name="542" href="#542">542</a>your tests and make test maintenance a pain.
<a class="l" name="543" href="#543">543</a>
<a class="l" name="544" href="#544">544</a>To avoid such problems, many programmers have been practicing "coding to
<a class="l" name="545" href="#545">545</a>interfaces": instead of talking to the `Concrete` class, your code would define
<a class="l" name="546" href="#546">546</a>an interface and talk to it. Then you implement that interface as an adaptor on
<a class="l" name="547" href="#547">547</a>top of `Concrete`. In tests, you can easily mock that interface to observe how
<a class="l" name="548" href="#548">548</a>your code is doing.
<a class="l" name="549" href="#549">549</a>
<a class="hl" name="550" href="#550">550</a>This technique incurs some overhead:
<a class="l" name="551" href="#551">551</a>
<a class="l" name="552" href="#552">552</a>*   You pay the cost of virtual function calls (usually not a problem).
<a class="l" name="553" href="#553">553</a>*   There is more abstraction for the programmers to learn.
<a class="l" name="554" href="#554">554</a>
<a class="l" name="555" href="#555">555</a>However, it can also bring significant benefits in addition to better
<a class="l" name="556" href="#556">556</a>testability:
<a class="l" name="557" href="#557">557</a>
<a class="l" name="558" href="#558">558</a>*   `Concrete`'s API may not fit your problem domain very well, as you may not
<a class="l" name="559" href="#559">559</a>    be the only client it tries to serve. By designing your own interface, you
<a class="hl" name="560" href="#560">560</a>    have a chance to tailor it to your need - you may add higher-level
<a class="l" name="561" href="#561">561</a>    functionalities, rename stuff, etc instead of just trimming the class. This
<a class="l" name="562" href="#562">562</a>    allows you to write your code (user of the interface) in a more natural way,
<a class="l" name="563" href="#563">563</a>    which means it will be more readable, more maintainable, and you'll be more
<a class="l" name="564" href="#564">564</a>    productive.
<a class="l" name="565" href="#565">565</a>*   If `Concrete`'s implementation ever has to change, you don't have to rewrite
<a class="l" name="566" href="#566">566</a>    everywhere it is used. Instead, you can absorb the change in your
<a class="l" name="567" href="#567">567</a>    implementation of the interface, and your other code and tests will be
<a class="l" name="568" href="#568">568</a>    insulated from this change.
<a class="l" name="569" href="#569">569</a>
<a class="hl" name="570" href="#570">570</a>Some people worry that if everyone is practicing this technique, they will end
<a class="l" name="571" href="#571">571</a>up writing lots of redundant code. This concern is totally understandable.
<a class="l" name="572" href="#572">572</a>However, there are two reasons why it may not be the case:
<a class="l" name="573" href="#573">573</a>
<a class="l" name="574" href="#574">574</a>*   Different projects may need to use `Concrete` in different ways, so the best
<a class="l" name="575" href="#575">575</a>    interfaces for them will be different. Therefore, each of them will have its
<a class="l" name="576" href="#576">576</a>    own domain-specific interface on top of `Concrete`, and they will not be the
<a class="l" name="577" href="#577">577</a>    same code.
<a class="l" name="578" href="#578">578</a>*   If enough projects want to use the same interface, they can always share it,
<a class="l" name="579" href="#579">579</a>    just like they have been sharing `Concrete`. You can check in the interface
<a class="hl" name="580" href="#580">580</a>    and the adaptor somewhere near `Concrete` (perhaps in a `contrib`
<a class="l" name="581" href="#581">581</a>    sub-directory) and let many projects use it.
<a class="l" name="582" href="#582">582</a>
<a class="l" name="583" href="#583">583</a>You need to weigh the pros and cons carefully for your particular problem, but
<a class="l" name="584" href="#584">584</a>I'd like to assure you that the Java community has been practicing this for a
<a class="l" name="585" href="#585">585</a>long time and it's a proven effective technique applicable in a wide variety of
<a class="l" name="586" href="#586">586</a>situations. :-)
<a class="l" name="587" href="#587">587</a>
<a class="l" name="588" href="#588">588</a>### Delegating Calls to a Fake {#DelegatingToFake}
<a class="l" name="589" href="#589">589</a>
<a class="hl" name="590" href="#590">590</a>Some times you have a non-trivial fake implementation of an interface. For
<a class="l" name="591" href="#591">591</a>example:
<a class="l" name="592" href="#592">592</a>
<a class="l" name="593" href="#593">593</a>```cpp
<a class="l" name="594" href="#594">594</a>class Foo {
<a class="l" name="595" href="#595">595</a> public:
<a class="l" name="596" href="#596">596</a>  virtual ~Foo() {}
<a class="l" name="597" href="#597">597</a>  virtual char DoThis(int n) = 0;
<a class="l" name="598" href="#598">598</a>  virtual void DoThat(const char* s, int* p) = 0;
<a class="l" name="599" href="#599">599</a>};
<a class="hl" name="600" href="#600">600</a>
<a class="l" name="601" href="#601">601</a>class FakeFoo : public Foo {
<a class="l" name="602" href="#602">602</a> public:
<a class="l" name="603" href="#603">603</a>  char DoThis(int n) override {
<a class="l" name="604" href="#604">604</a>    return (n &gt; 0) ? '+' :
<a class="l" name="605" href="#605">605</a>           (n &lt; 0) ? '-' : '0';
<a class="l" name="606" href="#606">606</a>  }
<a class="l" name="607" href="#607">607</a>
<a class="l" name="608" href="#608">608</a>  void DoThat(const char* s, int* p) override {
<a class="l" name="609" href="#609">609</a>    *p = strlen(s);
<a class="hl" name="610" href="#610">610</a>  }
<a class="l" name="611" href="#611">611</a>};
<a class="l" name="612" href="#612">612</a>```
<a class="l" name="613" href="#613">613</a>
<a class="l" name="614" href="#614">614</a>Now you want to mock this interface such that you can set expectations on it.
<a class="l" name="615" href="#615">615</a>However, you also want to use `FakeFoo` for the default behavior, as duplicating
<a class="l" name="616" href="#616">616</a>it in the mock object is, well, a lot of work.
<a class="l" name="617" href="#617">617</a>
<a class="l" name="618" href="#618">618</a>When you define the mock class using gMock, you can have it delegate its default
<a class="l" name="619" href="#619">619</a>action to a fake class you already have, using this pattern:
<a class="hl" name="620" href="#620">620</a>
<a class="l" name="621" href="#621">621</a>```cpp
<a class="l" name="622" href="#622">622</a>class MockFoo : public Foo {
<a class="l" name="623" href="#623">623</a> public:
<a class="l" name="624" href="#624">624</a>  // Normal mock method definitions using gMock.
<a class="l" name="625" href="#625">625</a>  MOCK_METHOD(char, DoThis, (int n), (override));
<a class="l" name="626" href="#626">626</a>  MOCK_METHOD(void, DoThat, (const char* s, int* p), (override));
<a class="l" name="627" href="#627">627</a>
<a class="l" name="628" href="#628">628</a>  // Delegates the default actions of the methods to a FakeFoo object.
<a class="l" name="629" href="#629">629</a>  // This must be called *before* the custom ON_CALL() statements.
<a class="hl" name="630" href="#630">630</a>  void DelegateToFake() {
<a class="l" name="631" href="#631">631</a>    ON_CALL(*this, DoThis).WillByDefault([this](int n) {
<a class="l" name="632" href="#632">632</a>      return <a href="/googletest/s?path=fake_.DoThis&amp;project=googletest">fake_.DoThis</a>(n);
<a class="l" name="633" href="#633">633</a>    });
<a class="l" name="634" href="#634">634</a>    ON_CALL(*this, DoThat).WillByDefault([this](const char* s, int* p) {
<a class="l" name="635" href="#635">635</a>      <a href="/googletest/s?path=fake_.DoThat&amp;project=googletest">fake_.DoThat</a>(s, p);
<a class="l" name="636" href="#636">636</a>    });
<a class="l" name="637" href="#637">637</a>  }
<a class="l" name="638" href="#638">638</a>
<a class="l" name="639" href="#639">639</a> private:
<a class="hl" name="640" href="#640">640</a>  FakeFoo fake_;  // Keeps an instance of the fake in the mock.
<a class="l" name="641" href="#641">641</a>};
<a class="l" name="642" href="#642">642</a>```
<a class="l" name="643" href="#643">643</a>
<a class="l" name="644" href="#644">644</a>With that, you can use `MockFoo` in your tests as usual. Just remember that if
<a class="l" name="645" href="#645">645</a>you don't explicitly set an action in an `ON_CALL()` or `EXPECT_CALL()`, the
<a class="l" name="646" href="#646">646</a>fake will be called upon to do it.:
<a class="l" name="647" href="#647">647</a>
<a class="l" name="648" href="#648">648</a>```cpp
<a class="l" name="649" href="#649">649</a>using ::testing::_;
<a class="hl" name="650" href="#650">650</a>
<a class="l" name="651" href="#651">651</a>TEST(AbcTest, Xyz) {
<a class="l" name="652" href="#652">652</a>  MockFoo foo;
<a class="l" name="653" href="#653">653</a>
<a class="l" name="654" href="#654">654</a>  <a href="/googletest/s?path=foo.DelegateToFake&amp;project=googletest">foo.DelegateToFake</a>();  // Enables the fake for delegation.
<a class="l" name="655" href="#655">655</a>
<a class="l" name="656" href="#656">656</a>  // Put your ON_CALL(foo, ...)s here, if any.
<a class="l" name="657" href="#657">657</a>
<a class="l" name="658" href="#658">658</a>  // No action specified, meaning to use the default action.
<a class="l" name="659" href="#659">659</a>  EXPECT_CALL(foo, DoThis(5));
<a class="hl" name="660" href="#660">660</a>  EXPECT_CALL(foo, DoThat(_, _));
<a class="l" name="661" href="#661">661</a>
<a class="l" name="662" href="#662">662</a>  int n = 0;
<a class="l" name="663" href="#663">663</a>  EXPECT_EQ('+', <a href="/googletest/s?path=foo.DoThis&amp;project=googletest">foo.DoThis</a>(5));  // FakeFoo::DoThis() is invoked.
<a class="l" name="664" href="#664">664</a>  <a href="/googletest/s?path=foo.DoThat&amp;project=googletest">foo.DoThat</a>("Hi", &amp;n);  // FakeFoo::DoThat() is invoked.
<a class="l" name="665" href="#665">665</a>  EXPECT_EQ(2, n);
<a class="l" name="666" href="#666">666</a>}
<a class="l" name="667" href="#667">667</a>```
<a class="l" name="668" href="#668">668</a>
<a class="l" name="669" href="#669">669</a>**Some tips:**
<a class="hl" name="670" href="#670">670</a>
<a class="l" name="671" href="#671">671</a>*   If you want, you can still override the default action by providing your own
<a class="l" name="672" href="#672">672</a>    `ON_CALL()` or using `.WillOnce()` / `.WillRepeatedly()` in `EXPECT_CALL()`.
<a class="l" name="673" href="#673">673</a>*   In `DelegateToFake()`, you only need to delegate the methods whose fake
<a class="l" name="674" href="#674">674</a>    implementation you intend to use.
<a class="l" name="675" href="#675">675</a>
<a class="l" name="676" href="#676">676</a>*   The general technique discussed here works for overloaded methods, but
<a class="l" name="677" href="#677">677</a>    you'll need to tell the compiler which version you mean. To disambiguate a
<a class="l" name="678" href="#678">678</a>    mock function (the one you specify inside the parentheses of `ON_CALL()`),
<a class="l" name="679" href="#679">679</a>    use [this technique](#SelectOverload); to disambiguate a fake function (the
<a class="hl" name="680" href="#680">680</a>    one you place inside `Invoke()`), use a `static_cast` to specify the
<a class="l" name="681" href="#681">681</a>    function's type. For instance, if class `Foo` has methods `char DoThis(int
<a class="l" name="682" href="#682">682</a>    n)` and `bool DoThis(double x) const`, and you want to invoke the latter,
<a class="l" name="683" href="#683">683</a>    you need to write `Invoke(&amp;fake_, static_cast&lt;bool (FakeFoo::*)(double)
<a class="l" name="684" href="#684">684</a>    const&gt;(&amp;FakeFoo::DoThis))` instead of `Invoke(&amp;fake_, &amp;FakeFoo::DoThis)`
<a class="l" name="685" href="#685">685</a>    (The strange-looking thing inside the angled brackets of `static_cast` is
<a class="l" name="686" href="#686">686</a>    the type of a function pointer to the second `DoThis()` method.).
<a class="l" name="687" href="#687">687</a>
<a class="l" name="688" href="#688">688</a>*   Having to mix a mock and a fake is often a sign of something gone wrong.
<a class="l" name="689" href="#689">689</a>    Perhaps you haven't got used to the interaction-based way of testing yet. Or
<a class="hl" name="690" href="#690">690</a>    perhaps your interface is taking on too many roles and should be split up.
<a class="l" name="691" href="#691">691</a>    Therefore, **don't abuse this**. We would only recommend to do it as an
<a class="l" name="692" href="#692">692</a>    intermediate step when you are refactoring your code.
<a class="l" name="693" href="#693">693</a>
<a class="l" name="694" href="#694">694</a>Regarding the tip on mixing a mock and a fake, here's an example on why it may
<a class="l" name="695" href="#695">695</a>be a bad sign: Suppose you have a class `System` for low-level system
<a class="l" name="696" href="#696">696</a>operations. In particular, it does file and I/O operations. And suppose you want
<a class="l" name="697" href="#697">697</a>to test how your code uses `System` to do I/O, and you just want the file
<a class="l" name="698" href="#698">698</a>operations to work normally. If you mock out the entire `System` class, you'll
<a class="l" name="699" href="#699">699</a>have to provide a fake implementation for the file operation part, which
<a class="hl" name="700" href="#700">700</a>suggests that `System` is taking on too many roles.
<a class="l" name="701" href="#701">701</a>
<a class="l" name="702" href="#702">702</a>Instead, you can define a `FileOps` interface and an `IOOps` interface and split
<a class="l" name="703" href="#703">703</a>`System`'s functionalities into the two. Then you can mock `IOOps` without
<a class="l" name="704" href="#704">704</a>mocking `FileOps`.
<a class="l" name="705" href="#705">705</a>
<a class="l" name="706" href="#706">706</a>### Delegating Calls to a Real Object
<a class="l" name="707" href="#707">707</a>
<a class="l" name="708" href="#708">708</a>When using testing doubles (mocks, fakes, stubs, and etc), sometimes their
<a class="l" name="709" href="#709">709</a>behaviors will differ from those of the real objects. This difference could be
<a class="hl" name="710" href="#710">710</a>either intentional (as in simulating an error such that you can test the error
<a class="l" name="711" href="#711">711</a>handling code) or unintentional. If your mocks have different behaviors than the
<a class="l" name="712" href="#712">712</a>real objects by mistake, you could end up with code that passes the tests but
<a class="l" name="713" href="#713">713</a>fails in production.
<a class="l" name="714" href="#714">714</a>
<a class="l" name="715" href="#715">715</a>You can use the *delegating-to-real* technique to ensure that your mock has the
<a class="l" name="716" href="#716">716</a>same behavior as the real object while retaining the ability to validate calls.
<a class="l" name="717" href="#717">717</a>This technique is very similar to the [delegating-to-fake](#DelegatingToFake)
<a class="l" name="718" href="#718">718</a>technique, the difference being that we use a real object instead of a fake.
<a class="l" name="719" href="#719">719</a>Here's an example:
<a class="hl" name="720" href="#720">720</a>
<a class="l" name="721" href="#721">721</a>```cpp
<a class="l" name="722" href="#722">722</a>using ::testing::AtLeast;
<a class="l" name="723" href="#723">723</a>
<a class="l" name="724" href="#724">724</a>class MockFoo : public Foo {
<a class="l" name="725" href="#725">725</a> public:
<a class="l" name="726" href="#726">726</a>  MockFoo() {
<a class="l" name="727" href="#727">727</a>    // By default, all calls are delegated to the real object.
<a class="l" name="728" href="#728">728</a>    ON_CALL(*this, DoThis).WillByDefault([this](int n) {
<a class="l" name="729" href="#729">729</a>      return <a href="/googletest/s?path=real_.DoThis&amp;project=googletest">real_.DoThis</a>(n);
<a class="hl" name="730" href="#730">730</a>    });
<a class="l" name="731" href="#731">731</a>    ON_CALL(*this, DoThat).WillByDefault([this](const char* s, int* p) {
<a class="l" name="732" href="#732">732</a>      <a href="/googletest/s?path=real_.DoThat&amp;project=googletest">real_.DoThat</a>(s, p);
<a class="l" name="733" href="#733">733</a>    });
<a class="l" name="734" href="#734">734</a>    ...
<a class="l" name="735" href="#735">735</a>  }
<a class="l" name="736" href="#736">736</a>  MOCK_METHOD(char, DoThis, ...);
<a class="l" name="737" href="#737">737</a>  MOCK_METHOD(void, DoThat, ...);
<a class="l" name="738" href="#738">738</a>  ...
<a class="l" name="739" href="#739">739</a> private:
<a class="hl" name="740" href="#740">740</a>  Foo real_;
<a class="l" name="741" href="#741">741</a>};
<a class="l" name="742" href="#742">742</a>
<a class="l" name="743" href="#743">743</a>...
<a class="l" name="744" href="#744">744</a>  MockFoo mock;
<a class="l" name="745" href="#745">745</a>  EXPECT_CALL(mock, DoThis())
<a class="l" name="746" href="#746">746</a>      .Times(3);
<a class="l" name="747" href="#747">747</a>  EXPECT_CALL(mock, DoThat("Hi"))
<a class="l" name="748" href="#748">748</a>      .Times(AtLeast(1));
<a class="l" name="749" href="#749">749</a>  ... use mock in test ...
<a class="hl" name="750" href="#750">750</a>```
<a class="l" name="751" href="#751">751</a>
<a class="l" name="752" href="#752">752</a>With this, gMock will verify that your code made the right calls (with the right
<a class="l" name="753" href="#753">753</a>arguments, in the right order, called the right number of times, etc), and a
<a class="l" name="754" href="#754">754</a>real object will answer the calls (so the behavior will be the same as in
<a class="l" name="755" href="#755">755</a>production). This gives you the best of both worlds.
<a class="l" name="756" href="#756">756</a>
<a class="l" name="757" href="#757">757</a>### Delegating Calls to a Parent Class
<a class="l" name="758" href="#758">758</a>
<a class="l" name="759" href="#759">759</a>Ideally, you should code to interfaces, whose methods are all pure virtual. In
<a class="hl" name="760" href="#760">760</a>reality, sometimes you do need to mock a virtual method that is not pure (<a href="/googletest/s?path=i.e&amp;project=googletest">i.e</a>,
<a class="l" name="761" href="#761">761</a>it already has an implementation). For example:
<a class="l" name="762" href="#762">762</a>
<a class="l" name="763" href="#763">763</a>```cpp
<a class="l" name="764" href="#764">764</a>class Foo {
<a class="l" name="765" href="#765">765</a> public:
<a class="l" name="766" href="#766">766</a>  virtual ~Foo();
<a class="l" name="767" href="#767">767</a>
<a class="l" name="768" href="#768">768</a>  virtual void Pure(int n) = 0;
<a class="l" name="769" href="#769">769</a>  virtual int Concrete(const char* str) { ... }
<a class="hl" name="770" href="#770">770</a>};
<a class="l" name="771" href="#771">771</a>
<a class="l" name="772" href="#772">772</a>class MockFoo : public Foo {
<a class="l" name="773" href="#773">773</a> public:
<a class="l" name="774" href="#774">774</a>  // Mocking a pure method.
<a class="l" name="775" href="#775">775</a>  MOCK_METHOD(void, Pure, (int n), (override));
<a class="l" name="776" href="#776">776</a>  // Mocking a concrete method.  Foo::Concrete() is shadowed.
<a class="l" name="777" href="#777">777</a>  MOCK_METHOD(int, Concrete, (const char* str), (override));
<a class="l" name="778" href="#778">778</a>};
<a class="l" name="779" href="#779">779</a>```
<a class="hl" name="780" href="#780">780</a>
<a class="l" name="781" href="#781">781</a>Sometimes you may want to call `Foo::Concrete()` instead of
<a class="l" name="782" href="#782">782</a>`MockFoo::Concrete()`. Perhaps you want to do it as part of a stub action, or
<a class="l" name="783" href="#783">783</a>perhaps your test doesn't need to mock `Concrete()` at all (but it would be
<a class="l" name="784" href="#784">784</a>oh-so painful to have to define a new mock class whenever you don't need to mock
<a class="l" name="785" href="#785">785</a>one of its methods).
<a class="l" name="786" href="#786">786</a>
<a class="l" name="787" href="#787">787</a>You can call `Foo::Concrete()` inside an action by:
<a class="l" name="788" href="#788">788</a>
<a class="l" name="789" href="#789">789</a>```cpp
<a class="hl" name="790" href="#790">790</a>...
<a class="l" name="791" href="#791">791</a>  EXPECT_CALL(foo, Concrete).WillOnce([&amp;foo](const char* str) {
<a class="l" name="792" href="#792">792</a>    return <a href="/googletest/s?path=foo.Foo&amp;project=googletest">foo.Foo</a>::Concrete(str);
<a class="l" name="793" href="#793">793</a>  });
<a class="l" name="794" href="#794">794</a>```
<a class="l" name="795" href="#795">795</a>
<a class="l" name="796" href="#796">796</a>or tell the mock object that you don't want to mock `Concrete()`:
<a class="l" name="797" href="#797">797</a>
<a class="l" name="798" href="#798">798</a>```cpp
<a class="l" name="799" href="#799">799</a>...
<a class="hl" name="800" href="#800">800</a>  ON_CALL(foo, Concrete).WillByDefault([&amp;foo](const char* str) {
<a class="l" name="801" href="#801">801</a>    return <a href="/googletest/s?path=foo.Foo&amp;project=googletest">foo.Foo</a>::Concrete(str);
<a class="l" name="802" href="#802">802</a>  });
<a class="l" name="803" href="#803">803</a>```
<a class="l" name="804" href="#804">804</a>
<a class="l" name="805" href="#805">805</a>(Why don't we just write `{ return <a href="/googletest/s?path=foo.Concrete&amp;project=googletest">foo.Concrete</a>(str); }`? If you do that,
<a class="l" name="806" href="#806">806</a>`MockFoo::Concrete()` will be called (and cause an infinite recursion) since
<a class="l" name="807" href="#807">807</a>`Foo::Concrete()` is virtual. That's just how C++ works.)
<a class="l" name="808" href="#808">808</a>
<a class="l" name="809" href="#809">809</a>## Using Matchers
<a class="hl" name="810" href="#810">810</a>
<a class="l" name="811" href="#811">811</a>### Matching Argument Values Exactly
<a class="l" name="812" href="#812">812</a>
<a class="l" name="813" href="#813">813</a>You can specify exactly which arguments a mock method is expecting:
<a class="l" name="814" href="#814">814</a>
<a class="l" name="815" href="#815">815</a>```cpp
<a class="l" name="816" href="#816">816</a>using ::testing::Return;
<a class="l" name="817" href="#817">817</a>...
<a class="l" name="818" href="#818">818</a>  EXPECT_CALL(foo, DoThis(5))
<a class="l" name="819" href="#819">819</a>      .WillOnce(Return('a'));
<a class="hl" name="820" href="#820">820</a>  EXPECT_CALL(foo, DoThat("Hello", bar));
<a class="l" name="821" href="#821">821</a>```
<a class="l" name="822" href="#822">822</a>
<a class="l" name="823" href="#823">823</a>### Using Simple Matchers
<a class="l" name="824" href="#824">824</a>
<a class="l" name="825" href="#825">825</a>You can use matchers to match arguments that have a certain property:
<a class="l" name="826" href="#826">826</a>
<a class="l" name="827" href="#827">827</a>```cpp
<a class="l" name="828" href="#828">828</a>using ::testing::NotNull;
<a class="l" name="829" href="#829">829</a>using ::testing::Return;
<a class="hl" name="830" href="#830">830</a>...
<a class="l" name="831" href="#831">831</a>  EXPECT_CALL(foo, DoThis(Ge(5)))  // The argument must be &gt;= 5.
<a class="l" name="832" href="#832">832</a>      .WillOnce(Return('a'));
<a class="l" name="833" href="#833">833</a>  EXPECT_CALL(foo, DoThat("Hello", NotNull()));
<a class="l" name="834" href="#834">834</a>      // The second argument must not be NULL.
<a class="l" name="835" href="#835">835</a>```
<a class="l" name="836" href="#836">836</a>
<a class="l" name="837" href="#837">837</a>A frequently used matcher is `_`, which matches anything:
<a class="l" name="838" href="#838">838</a>
<a class="l" name="839" href="#839">839</a>```cpp
<a class="hl" name="840" href="#840">840</a>  EXPECT_CALL(foo, DoThat(_, NotNull()));
<a class="l" name="841" href="#841">841</a>```
<a class="l" name="842" href="#842">842</a>&lt;!-- GOOGLETEST_CM0022 DO NOT DELETE --&gt;
<a class="l" name="843" href="#843">843</a>
<a class="l" name="844" href="#844">844</a>### Combining Matchers {#CombiningMatchers}
<a class="l" name="845" href="#845">845</a>
<a class="l" name="846" href="#846">846</a>You can build complex matchers from existing ones using `AllOf()`,
<a class="l" name="847" href="#847">847</a>`AllOfArray()`, `AnyOf()`, `AnyOfArray()` and `Not()`:
<a class="l" name="848" href="#848">848</a>
<a class="l" name="849" href="#849">849</a>```cpp
<a class="hl" name="850" href="#850">850</a>using ::testing::AllOf;
<a class="l" name="851" href="#851">851</a>using ::testing::Gt;
<a class="l" name="852" href="#852">852</a>using ::testing::HasSubstr;
<a class="l" name="853" href="#853">853</a>using ::testing::Ne;
<a class="l" name="854" href="#854">854</a>using ::testing::Not;
<a class="l" name="855" href="#855">855</a>...
<a class="l" name="856" href="#856">856</a>  // The argument must be &gt; 5 and != 10.
<a class="l" name="857" href="#857">857</a>  EXPECT_CALL(foo, DoThis(AllOf(Gt(5),
<a class="l" name="858" href="#858">858</a>                                Ne(10))));
<a class="l" name="859" href="#859">859</a>
<a class="hl" name="860" href="#860">860</a>  // The first argument must not contain sub-string "blah".
<a class="l" name="861" href="#861">861</a>  EXPECT_CALL(foo, DoThat(Not(HasSubstr("blah")),
<a class="l" name="862" href="#862">862</a>                          NULL));
<a class="l" name="863" href="#863">863</a>```
<a class="l" name="864" href="#864">864</a>
<a class="l" name="865" href="#865">865</a>Matchers are function objects, and parametrized matchers can be composed just
<a class="l" name="866" href="#866">866</a>like any other function. However because their types can be long and rarely
<a class="l" name="867" href="#867">867</a>provide meaningful information, it can be easier to express them with C++14
<a class="l" name="868" href="#868">868</a>generic lambdas to avoid specifying types. For example,
<a class="l" name="869" href="#869">869</a>
<a class="hl" name="870" href="#870">870</a>```cpp
<a class="l" name="871" href="#871">871</a>using ::testing::Contains;
<a class="l" name="872" href="#872">872</a>using ::testing::Property;
<a class="l" name="873" href="#873">873</a>
<a class="l" name="874" href="#874">874</a>inline constexpr auto HasFoo = [](const auto&amp; f) {
<a class="l" name="875" href="#875">875</a>  return Property(&amp;MyClass::foo, Contains(f));
<a class="l" name="876" href="#876">876</a>};
<a class="l" name="877" href="#877">877</a>...
<a class="l" name="878" href="#878">878</a>  EXPECT_THAT(x, HasFoo("blah"));
<a class="l" name="879" href="#879">879</a>```
<a class="hl" name="880" href="#880">880</a>
<a class="l" name="881" href="#881">881</a>### Casting Matchers {#SafeMatcherCast}
<a class="l" name="882" href="#882">882</a>
<a class="l" name="883" href="#883">883</a>gMock matchers are statically typed, meaning that the compiler can catch your
<a class="l" name="884" href="#884">884</a>mistake if you use a matcher of the wrong type (for example, if you use `Eq(5)`
<a class="l" name="885" href="#885">885</a>to match a `string` argument). Good for you!
<a class="l" name="886" href="#886">886</a>
<a class="l" name="887" href="#887">887</a>Sometimes, however, you know what you're doing and want the compiler to give you
<a class="l" name="888" href="#888">888</a>some slack. One example is that you have a matcher for `long` and the argument
<a class="l" name="889" href="#889">889</a>you want to match is `int`. While the two types aren't exactly the same, there
<a class="hl" name="890" href="#890">890</a>is nothing really wrong with using a `Matcher&lt;long&gt;` to match an `int` - after
<a class="l" name="891" href="#891">891</a>all, we can first convert the `int` argument to a `long` losslessly before
<a class="l" name="892" href="#892">892</a>giving it to the matcher.
<a class="l" name="893" href="#893">893</a>
<a class="l" name="894" href="#894">894</a>To support this need, gMock gives you the `SafeMatcherCast&lt;T&gt;(m)` function. It
<a class="l" name="895" href="#895">895</a>casts a matcher `m` to type `Matcher&lt;T&gt;`. To ensure safety, gMock checks that
<a class="l" name="896" href="#896">896</a>(let `U` be the type `m` accepts :
<a class="l" name="897" href="#897">897</a>
<a class="l" name="898" href="#898">898</a>1.  Type `T` can be *implicitly* cast to type `U`;
<a class="l" name="899" href="#899">899</a>2.  When both `T` and `U` are built-in arithmetic types (`bool`, integers, and
<a class="hl" name="900" href="#900">900</a>    floating-point numbers), the conversion from `T` to `U` is not lossy (in
<a class="l" name="901" href="#901">901</a>    other words, any value representable by `T` can also be represented by `U`);
<a class="l" name="902" href="#902">902</a>    and
<a class="l" name="903" href="#903">903</a>3.  When `U` is a reference, `T` must also be a reference (as the underlying
<a class="l" name="904" href="#904">904</a>    matcher may be interested in the address of the `U` value).
<a class="l" name="905" href="#905">905</a>
<a class="l" name="906" href="#906">906</a>The code won't compile if any of these conditions isn't met.
<a class="l" name="907" href="#907">907</a>
<a class="l" name="908" href="#908">908</a>Here's one example:
<a class="l" name="909" href="#909">909</a>
<a class="hl" name="910" href="#910">910</a>```cpp
<a class="l" name="911" href="#911">911</a>using ::testing::SafeMatcherCast;
<a class="l" name="912" href="#912">912</a>
<a class="l" name="913" href="#913">913</a>// A base class and a child class.
<a class="l" name="914" href="#914">914</a>class Base { ... };
<a class="l" name="915" href="#915">915</a>class Derived : public Base { ... };
<a class="l" name="916" href="#916">916</a>
<a class="l" name="917" href="#917">917</a>class MockFoo : public Foo {
<a class="l" name="918" href="#918">918</a> public:
<a class="l" name="919" href="#919">919</a>  MOCK_METHOD(void, DoThis, (Derived* derived), (override));
<a class="hl" name="920" href="#920">920</a>};
<a class="l" name="921" href="#921">921</a>
<a class="l" name="922" href="#922">922</a>...
<a class="l" name="923" href="#923">923</a>  MockFoo foo;
<a class="l" name="924" href="#924">924</a>  // m is a Matcher&lt;Base*&gt; we got from somewhere.
<a class="l" name="925" href="#925">925</a>  EXPECT_CALL(foo, DoThis(SafeMatcherCast&lt;Derived*&gt;(m)));
<a class="l" name="926" href="#926">926</a>```
<a class="l" name="927" href="#927">927</a>
<a class="l" name="928" href="#928">928</a>If you find `SafeMatcherCast&lt;T&gt;(m)` too limiting, you can use a similar function
<a class="l" name="929" href="#929">929</a>`MatcherCast&lt;T&gt;(m)`. The difference is that `MatcherCast` works as long as you
<a class="hl" name="930" href="#930">930</a>can `static_cast` type `T` to type `U`.
<a class="l" name="931" href="#931">931</a>
<a class="l" name="932" href="#932">932</a>`MatcherCast` essentially lets you bypass C++'s type system (`static_cast` isn't
<a class="l" name="933" href="#933">933</a>always safe as it could throw away information, for example), so be careful not
<a class="l" name="934" href="#934">934</a>to <a href="/googletest/s?path=misuse/abuse&amp;project=googletest">misuse/abuse</a> it.
<a class="l" name="935" href="#935">935</a>
<a class="l" name="936" href="#936">936</a>### Selecting Between Overloaded Functions {#SelectOverload}
<a class="l" name="937" href="#937">937</a>
<a class="l" name="938" href="#938">938</a>If you expect an overloaded function to be called, the compiler may need some
<a class="l" name="939" href="#939">939</a>help on which overloaded version it is.
<a class="hl" name="940" href="#940">940</a>
<a class="l" name="941" href="#941">941</a>To disambiguate functions overloaded on the const-ness of this object, use the
<a class="l" name="942" href="#942">942</a>`Const()` argument wrapper.
<a class="l" name="943" href="#943">943</a>
<a class="l" name="944" href="#944">944</a>```cpp
<a class="l" name="945" href="#945">945</a>using ::testing::ReturnRef;
<a class="l" name="946" href="#946">946</a>
<a class="l" name="947" href="#947">947</a>class MockFoo : public Foo {
<a class="l" name="948" href="#948">948</a>  ...
<a class="l" name="949" href="#949">949</a>  MOCK_METHOD(Bar&amp;, GetBar, (), (override));
<a class="hl" name="950" href="#950">950</a>  MOCK_METHOD(const Bar&amp;, GetBar, (), (const, override));
<a class="l" name="951" href="#951">951</a>};
<a class="l" name="952" href="#952">952</a>
<a class="l" name="953" href="#953">953</a>...
<a class="l" name="954" href="#954">954</a>  MockFoo foo;
<a class="l" name="955" href="#955">955</a>  Bar bar1, bar2;
<a class="l" name="956" href="#956">956</a>  EXPECT_CALL(foo, GetBar())         // The non-const GetBar().
<a class="l" name="957" href="#957">957</a>      .WillOnce(ReturnRef(bar1));
<a class="l" name="958" href="#958">958</a>  EXPECT_CALL(Const(foo), GetBar())  // The const GetBar().
<a class="l" name="959" href="#959">959</a>      .WillOnce(ReturnRef(bar2));
<a class="hl" name="960" href="#960">960</a>```
<a class="l" name="961" href="#961">961</a>
<a class="l" name="962" href="#962">962</a>(`Const()` is defined by gMock and returns a `const` reference to its argument.)
<a class="l" name="963" href="#963">963</a>
<a class="l" name="964" href="#964">964</a>To disambiguate overloaded functions with the same number of arguments but
<a class="l" name="965" href="#965">965</a>different argument types, you may need to specify the exact type of a matcher,
<a class="l" name="966" href="#966">966</a>either by wrapping your matcher in `Matcher&lt;type&gt;()`, or using a matcher whose
<a class="l" name="967" href="#967">967</a>type is fixed (`TypedEq&lt;type&gt;`, `An&lt;type&gt;()`, etc):
<a class="l" name="968" href="#968">968</a>
<a class="l" name="969" href="#969">969</a>```cpp
<a class="hl" name="970" href="#970">970</a>using ::testing::An;
<a class="l" name="971" href="#971">971</a>using ::testing::Matcher;
<a class="l" name="972" href="#972">972</a>using ::testing::TypedEq;
<a class="l" name="973" href="#973">973</a>
<a class="l" name="974" href="#974">974</a>class MockPrinter : public Printer {
<a class="l" name="975" href="#975">975</a> public:
<a class="l" name="976" href="#976">976</a>  MOCK_METHOD(void, Print, (int n), (override));
<a class="l" name="977" href="#977">977</a>  MOCK_METHOD(void, Print, (char c), (override));
<a class="l" name="978" href="#978">978</a>};
<a class="l" name="979" href="#979">979</a>
<a class="hl" name="980" href="#980">980</a>TEST(PrinterTest, Print) {
<a class="l" name="981" href="#981">981</a>  MockPrinter printer;
<a class="l" name="982" href="#982">982</a>
<a class="l" name="983" href="#983">983</a>  EXPECT_CALL(printer, Print(An&lt;int&gt;()));            // void Print(int);
<a class="l" name="984" href="#984">984</a>  EXPECT_CALL(printer, Print(Matcher&lt;int&gt;(Lt(5))));  // void Print(int);
<a class="l" name="985" href="#985">985</a>  EXPECT_CALL(printer, Print(TypedEq&lt;char&gt;('a')));   // void Print(char);
<a class="l" name="986" href="#986">986</a>
<a class="l" name="987" href="#987">987</a>  <a href="/googletest/s?path=printer.Print&amp;project=googletest">printer.Print</a>(3);
<a class="l" name="988" href="#988">988</a>  <a href="/googletest/s?path=printer.Print&amp;project=googletest">printer.Print</a>(6);
<a class="l" name="989" href="#989">989</a>  <a href="/googletest/s?path=printer.Print&amp;project=googletest">printer.Print</a>('a');
<a class="hl" name="990" href="#990">990</a>}
<a class="l" name="991" href="#991">991</a>```
<a class="l" name="992" href="#992">992</a>
<a class="l" name="993" href="#993">993</a>### Performing Different Actions Based on the Arguments
<a class="l" name="994" href="#994">994</a>
<a class="l" name="995" href="#995">995</a>When a mock method is called, the *last* matching expectation that's still
<a class="l" name="996" href="#996">996</a>active will be selected (think "newer overrides older"). So, you can make a
<a class="l" name="997" href="#997">997</a>method do different things depending on its argument values like this:
<a class="l" name="998" href="#998">998</a>
<a class="l" name="999" href="#999">999</a>```cpp
<a class="hl" name="1000" href="#1000">1000</a>using ::testing::_;
<a class="l" name="1001" href="#1001">1001</a>using ::testing::Lt;
<a class="l" name="1002" href="#1002">1002</a>using ::testing::Return;
<a class="l" name="1003" href="#1003">1003</a>...
<a class="l" name="1004" href="#1004">1004</a>  // The default case.
<a class="l" name="1005" href="#1005">1005</a>  EXPECT_CALL(foo, DoThis(_))
<a class="l" name="1006" href="#1006">1006</a>      .WillRepeatedly(Return('b'));
<a class="l" name="1007" href="#1007">1007</a>  // The more specific case.
<a class="l" name="1008" href="#1008">1008</a>  EXPECT_CALL(foo, DoThis(Lt(5)))
<a class="l" name="1009" href="#1009">1009</a>      .WillRepeatedly(Return('a'));
<a class="hl" name="1010" href="#1010">1010</a>```
<a class="l" name="1011" href="#1011">1011</a>
<a class="l" name="1012" href="#1012">1012</a>Now, if `<a href="/googletest/s?path=foo.DoThis&amp;project=googletest">foo.DoThis</a>()` is called with a value less than 5, `'a'` will be
<a class="l" name="1013" href="#1013">1013</a>returned; otherwise `'b'` will be returned.
<a class="l" name="1014" href="#1014">1014</a>
<a class="l" name="1015" href="#1015">1015</a>### Matching Multiple Arguments as a Whole
<a class="l" name="1016" href="#1016">1016</a>
<a class="l" name="1017" href="#1017">1017</a>Sometimes it's not enough to match the arguments individually. For example, we
<a class="l" name="1018" href="#1018">1018</a>may want to say that the first argument must be less than the second argument.
<a class="l" name="1019" href="#1019">1019</a>The `With()` clause allows us to match all arguments of a mock function as a
<a class="hl" name="1020" href="#1020">1020</a>whole. For example,
<a class="l" name="1021" href="#1021">1021</a>
<a class="l" name="1022" href="#1022">1022</a>```cpp
<a class="l" name="1023" href="#1023">1023</a>using ::testing::_;
<a class="l" name="1024" href="#1024">1024</a>using ::testing::Ne;
<a class="l" name="1025" href="#1025">1025</a>using ::testing::Lt;
<a class="l" name="1026" href="#1026">1026</a>...
<a class="l" name="1027" href="#1027">1027</a>  EXPECT_CALL(foo, InRange(Ne(0), _))
<a class="l" name="1028" href="#1028">1028</a>      .With(Lt());
<a class="l" name="1029" href="#1029">1029</a>```
<a class="hl" name="1030" href="#1030">1030</a>
<a class="l" name="1031" href="#1031">1031</a>says that the first argument of `InRange()` must not be 0, and must be less than
<a class="l" name="1032" href="#1032">1032</a>the second argument.
<a class="l" name="1033" href="#1033">1033</a>
<a class="l" name="1034" href="#1034">1034</a>The expression inside `With()` must be a matcher of type `Matcher&lt;std::tuple&lt;A1,
<a class="l" name="1035" href="#1035">1035</a>..., An&gt;&gt;`, where `A1`, ..., `An` are the types of the function arguments.
<a class="l" name="1036" href="#1036">1036</a>
<a class="l" name="1037" href="#1037">1037</a>You can also write `AllArgs(m)` instead of `m` inside `.With()`. The two forms
<a class="l" name="1038" href="#1038">1038</a>are equivalent, but `.With(AllArgs(Lt()))` is more readable than `.With(Lt())`.
<a class="l" name="1039" href="#1039">1039</a>
<a class="hl" name="1040" href="#1040">1040</a>You can use `Args&lt;k1, ..., kn&gt;(m)` to match the `n` selected arguments (as a
<a class="l" name="1041" href="#1041">1041</a>tuple) against `m`. For example,
<a class="l" name="1042" href="#1042">1042</a>
<a class="l" name="1043" href="#1043">1043</a>```cpp
<a class="l" name="1044" href="#1044">1044</a>using ::testing::_;
<a class="l" name="1045" href="#1045">1045</a>using ::testing::AllOf;
<a class="l" name="1046" href="#1046">1046</a>using ::testing::Args;
<a class="l" name="1047" href="#1047">1047</a>using ::testing::Lt;
<a class="l" name="1048" href="#1048">1048</a>...
<a class="l" name="1049" href="#1049">1049</a>  EXPECT_CALL(foo, Blah)
<a class="hl" name="1050" href="#1050">1050</a>      .With(AllOf(Args&lt;0, 1&gt;(Lt()), Args&lt;1, 2&gt;(Lt())));
<a class="l" name="1051" href="#1051">1051</a>```
<a class="l" name="1052" href="#1052">1052</a>
<a class="l" name="1053" href="#1053">1053</a>says that `Blah` will be called with arguments `x`, `y`, and `z` where `x &lt; y &lt;
<a class="l" name="1054" href="#1054">1054</a>z`. Note that in this example, it wasn't necessary specify the positional
<a class="l" name="1055" href="#1055">1055</a>matchers.
<a class="l" name="1056" href="#1056">1056</a>
<a class="l" name="1057" href="#1057">1057</a>As a convenience and example, gMock provides some matchers for 2-tuples,
<a class="l" name="1058" href="#1058">1058</a>including the `Lt()` matcher above. See [here](#MultiArgMatchers) for the
<a class="l" name="1059" href="#1059">1059</a>complete list.
<a class="hl" name="1060" href="#1060">1060</a>
<a class="l" name="1061" href="#1061">1061</a>Note that if you want to pass the arguments to a predicate of your own (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="l" name="1062" href="#1062">1062</a>`.With(Args&lt;0, 1&gt;(Truly(&amp;MyPredicate)))`), that predicate MUST be written to
<a class="l" name="1063" href="#1063">1063</a>take a `std::tuple` as its argument; gMock will pass the `n` selected arguments
<a class="l" name="1064" href="#1064">1064</a>as *one* single tuple to the predicate.
<a class="l" name="1065" href="#1065">1065</a>
<a class="l" name="1066" href="#1066">1066</a>### Using Matchers as Predicates
<a class="l" name="1067" href="#1067">1067</a>
<a class="l" name="1068" href="#1068">1068</a>Have you noticed that a matcher is just a fancy predicate that also knows how to
<a class="l" name="1069" href="#1069">1069</a>describe itself? Many existing algorithms take predicates as arguments (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="hl" name="1070" href="#1070">1070</a>those defined in STL's `&lt;algorithm&gt;` header), and it would be a shame if gMock
<a class="l" name="1071" href="#1071">1071</a>matchers were not allowed to participate.
<a class="l" name="1072" href="#1072">1072</a>
<a class="l" name="1073" href="#1073">1073</a>Luckily, you can use a matcher where a unary predicate functor is expected by
<a class="l" name="1074" href="#1074">1074</a>wrapping it inside the `Matches()` function. For example,
<a class="l" name="1075" href="#1075">1075</a>
<a class="l" name="1076" href="#1076">1076</a>```cpp
<a class="l" name="1077" href="#1077">1077</a>#include &lt;algorithm&gt;
<a class="l" name="1078" href="#1078">1078</a>#include &lt;vector&gt;
<a class="l" name="1079" href="#1079">1079</a>
<a class="hl" name="1080" href="#1080">1080</a>using ::testing::Matches;
<a class="l" name="1081" href="#1081">1081</a>using ::testing::Ge;
<a class="l" name="1082" href="#1082">1082</a>
<a class="l" name="1083" href="#1083">1083</a>vector&lt;int&gt; v;
<a class="l" name="1084" href="#1084">1084</a>...
<a class="l" name="1085" href="#1085">1085</a>// How many elements in v are &gt;= 10?
<a class="l" name="1086" href="#1086">1086</a>const int count = count_if(<a href="/googletest/s?path=v.begin&amp;project=googletest">v.begin</a>(), <a href="/googletest/s?path=v.end&amp;project=googletest">v.end</a>(), Matches(Ge(10)));
<a class="l" name="1087" href="#1087">1087</a>```
<a class="l" name="1088" href="#1088">1088</a>
<a class="l" name="1089" href="#1089">1089</a>Since you can build complex matchers from simpler ones easily using gMock, this
<a class="hl" name="1090" href="#1090">1090</a>gives you a way to conveniently construct composite predicates (doing the same
<a class="l" name="1091" href="#1091">1091</a>using STL's `&lt;functional&gt;` header is just painful). For example, here's a
<a class="l" name="1092" href="#1092">1092</a>predicate that's satisfied by any number that is &gt;= 0, &lt;= 100, and != 50:
<a class="l" name="1093" href="#1093">1093</a>
<a class="l" name="1094" href="#1094">1094</a>```cpp
<a class="l" name="1095" href="#1095">1095</a>using testing::AllOf;
<a class="l" name="1096" href="#1096">1096</a>using testing::Ge;
<a class="l" name="1097" href="#1097">1097</a>using testing::Le;
<a class="l" name="1098" href="#1098">1098</a>using testing::Matches;
<a class="l" name="1099" href="#1099">1099</a>using testing::Ne;
<a class="hl" name="1100" href="#1100">1100</a>...
<a class="l" name="1101" href="#1101">1101</a>Matches(AllOf(Ge(0), Le(100), Ne(50)))
<a class="l" name="1102" href="#1102">1102</a>```
<a class="l" name="1103" href="#1103">1103</a>
<a class="l" name="1104" href="#1104">1104</a>### Using Matchers in googletest Assertions
<a class="l" name="1105" href="#1105">1105</a>
<a class="l" name="1106" href="#1106">1106</a>Since matchers are basically predicates that also know how to describe
<a class="l" name="1107" href="#1107">1107</a>themselves, there is a way to take advantage of them in googletest assertions.
<a class="l" name="1108" href="#1108">1108</a>It's called `ASSERT_THAT` and `EXPECT_THAT`:
<a class="l" name="1109" href="#1109">1109</a>
<a class="hl" name="1110" href="#1110">1110</a>```cpp
<a class="l" name="1111" href="#1111">1111</a>  ASSERT_THAT(value, matcher);  // Asserts that value matches matcher.
<a class="l" name="1112" href="#1112">1112</a>  EXPECT_THAT(value, matcher);  // The non-fatal version.
<a class="l" name="1113" href="#1113">1113</a>```
<a class="l" name="1114" href="#1114">1114</a>
<a class="l" name="1115" href="#1115">1115</a>For example, in a googletest test you can write:
<a class="l" name="1116" href="#1116">1116</a>
<a class="l" name="1117" href="#1117">1117</a>```cpp
<a class="l" name="1118" href="#1118">1118</a>#include "<a href="/googletest/s?path=gmock/gmock.h&amp;project=googletest">gmock/gmock.h</a>"
<a class="l" name="1119" href="#1119">1119</a>
<a class="hl" name="1120" href="#1120">1120</a>using ::testing::AllOf;
<a class="l" name="1121" href="#1121">1121</a>using ::testing::Ge;
<a class="l" name="1122" href="#1122">1122</a>using ::testing::Le;
<a class="l" name="1123" href="#1123">1123</a>using ::testing::MatchesRegex;
<a class="l" name="1124" href="#1124">1124</a>using ::testing::StartsWith;
<a class="l" name="1125" href="#1125">1125</a>
<a class="l" name="1126" href="#1126">1126</a>...
<a class="l" name="1127" href="#1127">1127</a>  EXPECT_THAT(Foo(), StartsWith("Hello"));
<a class="l" name="1128" href="#1128">1128</a>  EXPECT_THAT(Bar(), MatchesRegex("Line \\d+"));
<a class="l" name="1129" href="#1129">1129</a>  ASSERT_THAT(Baz(), AllOf(Ge(5), Le(10)));
<a class="hl" name="1130" href="#1130">1130</a>```
<a class="l" name="1131" href="#1131">1131</a>
<a class="l" name="1132" href="#1132">1132</a>which (as you can probably guess) executes `Foo()`, `Bar()`, and `Baz()`, and
<a class="l" name="1133" href="#1133">1133</a>verifies that:
<a class="l" name="1134" href="#1134">1134</a>
<a class="l" name="1135" href="#1135">1135</a>*   `Foo()` returns a string that starts with `"Hello"`.
<a class="l" name="1136" href="#1136">1136</a>*   `Bar()` returns a string that matches regular expression `"Line \\d+"`.
<a class="l" name="1137" href="#1137">1137</a>*   `Baz()` returns a number in the range [5, 10].
<a class="l" name="1138" href="#1138">1138</a>
<a class="l" name="1139" href="#1139">1139</a>The nice thing about these macros is that *they read like English*. They
<a class="hl" name="1140" href="#1140">1140</a>generate informative messages too. For example, if the first `EXPECT_THAT()`
<a class="l" name="1141" href="#1141">1141</a>above fails, the message will be something like:
<a class="l" name="1142" href="#1142">1142</a>
<a class="l" name="1143" href="#1143">1143</a>```cpp
<a class="l" name="1144" href="#1144">1144</a>Value of: Foo()
<a class="l" name="1145" href="#1145">1145</a>  Actual: "Hi, world!"
<a class="l" name="1146" href="#1146">1146</a>Expected: starts with "Hello"
<a class="l" name="1147" href="#1147">1147</a>```
<a class="l" name="1148" href="#1148">1148</a>
<a class="l" name="1149" href="#1149">1149</a>**Credit:** The idea of `(ASSERT|EXPECT)_THAT` was borrowed from Joe Walnes'
<a class="hl" name="1150" href="#1150">1150</a>Hamcrest project, which adds `assertThat()` to JUnit.
<a class="l" name="1151" href="#1151">1151</a>
<a class="l" name="1152" href="#1152">1152</a>### Using Predicates as Matchers
<a class="l" name="1153" href="#1153">1153</a>
<a class="l" name="1154" href="#1154">1154</a>gMock provides a [built-in set](<a href="/googletest/s?path=cheat_sheet.md&amp;project=googletest">cheat_sheet.md</a>#MatcherList) of matchers. In case
<a class="l" name="1155" href="#1155">1155</a>you find them lacking, you can use an arbitrary unary predicate function or
<a class="l" name="1156" href="#1156">1156</a>functor as a matcher - as long as the predicate accepts a value of the type you
<a class="l" name="1157" href="#1157">1157</a>want. You do this by wrapping the predicate inside the `Truly()` function, for
<a class="l" name="1158" href="#1158">1158</a>example:
<a class="l" name="1159" href="#1159">1159</a>
<a class="hl" name="1160" href="#1160">1160</a>```cpp
<a class="l" name="1161" href="#1161">1161</a>using ::testing::Truly;
<a class="l" name="1162" href="#1162">1162</a>
<a class="l" name="1163" href="#1163">1163</a>int IsEven(int n) { return (n % 2) == 0 ? 1 : 0; }
<a class="l" name="1164" href="#1164">1164</a>...
<a class="l" name="1165" href="#1165">1165</a>  // Bar() must be called with an even number.
<a class="l" name="1166" href="#1166">1166</a>  EXPECT_CALL(foo, Bar(Truly(IsEven)));
<a class="l" name="1167" href="#1167">1167</a>```
<a class="l" name="1168" href="#1168">1168</a>
<a class="l" name="1169" href="#1169">1169</a>Note that the predicate function / functor doesn't have to return `bool`. It
<a class="hl" name="1170" href="#1170">1170</a>works as long as the return value can be used as the condition in in statement
<a class="l" name="1171" href="#1171">1171</a>`if (condition) ...`.
<a class="l" name="1172" href="#1172">1172</a>
<a class="l" name="1173" href="#1173">1173</a>&lt;!-- GOOGLETEST_CM0023 DO NOT DELETE --&gt;
<a class="l" name="1174" href="#1174">1174</a>
<a class="l" name="1175" href="#1175">1175</a>### Matching Arguments that Are Not Copyable
<a class="l" name="1176" href="#1176">1176</a>
<a class="l" name="1177" href="#1177">1177</a>When you do an `EXPECT_CALL(mock_obj, Foo(bar))`, gMock saves away a copy of
<a class="l" name="1178" href="#1178">1178</a>`bar`. When `Foo()` is called later, gMock compares the argument to `Foo()` with
<a class="l" name="1179" href="#1179">1179</a>the saved copy of `bar`. This way, you don't need to worry about `bar` being
<a class="hl" name="1180" href="#1180">1180</a>modified or destroyed after the `EXPECT_CALL()` is executed. The same is true
<a class="l" name="1181" href="#1181">1181</a>when you use matchers like `Eq(bar)`, `Le(bar)`, and so on.
<a class="l" name="1182" href="#1182">1182</a>
<a class="l" name="1183" href="#1183">1183</a>But what if `bar` cannot be copied (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> has no copy constructor)? You could
<a class="l" name="1184" href="#1184">1184</a>define your own matcher function or callback and use it with `Truly()`, as the
<a class="l" name="1185" href="#1185">1185</a>previous couple of recipes have shown. Or, you may be able to get away from it
<a class="l" name="1186" href="#1186">1186</a>if you can guarantee that `bar` won't be changed after the `EXPECT_CALL()` is
<a class="l" name="1187" href="#1187">1187</a>executed. Just tell gMock that it should save a reference to `bar`, instead of a
<a class="l" name="1188" href="#1188">1188</a>copy of it. Here's how:
<a class="l" name="1189" href="#1189">1189</a>
<a class="hl" name="1190" href="#1190">1190</a>```cpp
<a class="l" name="1191" href="#1191">1191</a>using ::testing::Eq;
<a class="l" name="1192" href="#1192">1192</a>using ::testing::Lt;
<a class="l" name="1193" href="#1193">1193</a>...
<a class="l" name="1194" href="#1194">1194</a>  // Expects that Foo()'s argument == bar.
<a class="l" name="1195" href="#1195">1195</a>  EXPECT_CALL(mock_obj, Foo(Eq(std::ref(bar))));
<a class="l" name="1196" href="#1196">1196</a>
<a class="l" name="1197" href="#1197">1197</a>  // Expects that Foo()'s argument &lt; bar.
<a class="l" name="1198" href="#1198">1198</a>  EXPECT_CALL(mock_obj, Foo(Lt(std::ref(bar))));
<a class="l" name="1199" href="#1199">1199</a>```
<a class="hl" name="1200" href="#1200">1200</a>
<a class="l" name="1201" href="#1201">1201</a>Remember: if you do this, don't change `bar` after the `EXPECT_CALL()`, or the
<a class="l" name="1202" href="#1202">1202</a>result is undefined.
<a class="l" name="1203" href="#1203">1203</a>
<a class="l" name="1204" href="#1204">1204</a>### Validating a Member of an Object
<a class="l" name="1205" href="#1205">1205</a>
<a class="l" name="1206" href="#1206">1206</a>Often a mock function takes a reference to object as an argument. When matching
<a class="l" name="1207" href="#1207">1207</a>the argument, you may not want to compare the entire object against a fixed
<a class="l" name="1208" href="#1208">1208</a>object, as that may be over-specification. Instead, you may need to validate a
<a class="l" name="1209" href="#1209">1209</a>certain member variable or the result of a certain getter method of the object.
<a class="hl" name="1210" href="#1210">1210</a>You can do this with `Field()` and `Property()`. More specifically,
<a class="l" name="1211" href="#1211">1211</a>
<a class="l" name="1212" href="#1212">1212</a>```cpp
<a class="l" name="1213" href="#1213">1213</a>Field(&amp;Foo::bar, m)
<a class="l" name="1214" href="#1214">1214</a>```
<a class="l" name="1215" href="#1215">1215</a>
<a class="l" name="1216" href="#1216">1216</a>is a matcher that matches a `Foo` object whose `bar` member variable satisfies
<a class="l" name="1217" href="#1217">1217</a>matcher `m`.
<a class="l" name="1218" href="#1218">1218</a>
<a class="l" name="1219" href="#1219">1219</a>```cpp
<a class="hl" name="1220" href="#1220">1220</a>Property(&amp;Foo::baz, m)
<a class="l" name="1221" href="#1221">1221</a>```
<a class="l" name="1222" href="#1222">1222</a>
<a class="l" name="1223" href="#1223">1223</a>is a matcher that matches a `Foo` object whose `baz()` method returns a value
<a class="l" name="1224" href="#1224">1224</a>that satisfies matcher `m`.
<a class="l" name="1225" href="#1225">1225</a>
<a class="l" name="1226" href="#1226">1226</a>For example:
<a class="l" name="1227" href="#1227">1227</a>
<a class="l" name="1228" href="#1228">1228</a>&lt;!-- mdformat off(github rendering does not support multiline tables) --&gt;
<a class="l" name="1229" href="#1229">1229</a>| Expression                   | Description                              |
<a class="hl" name="1230" href="#1230">1230</a>| :--------------------------- | :--------------------------------------- |
<a class="l" name="1231" href="#1231">1231</a>| `Field(&amp;Foo::number, Ge(3))` | Matches `x` where `<a href="/googletest/s?path=x.number&amp;project=googletest">x.number</a> &gt;= 3`.       |
<a class="l" name="1232" href="#1232">1232</a>| `Property(&amp;Foo::name,  StartsWith("John "))` | Matches `x` where `<a href="/googletest/s?path=x.name&amp;project=googletest">x.name</a>()` starts with  `"John "`. |
<a class="l" name="1233" href="#1233">1233</a>&lt;!-- mdformat on --&gt;
<a class="l" name="1234" href="#1234">1234</a>
<a class="l" name="1235" href="#1235">1235</a>Note that in `Property(&amp;Foo::baz, ...)`, method `baz()` must take no argument
<a class="l" name="1236" href="#1236">1236</a>and be declared as `const`.
<a class="l" name="1237" href="#1237">1237</a>
<a class="l" name="1238" href="#1238">1238</a>BTW, `Field()` and `Property()` can also match plain pointers to objects. For
<a class="l" name="1239" href="#1239">1239</a>instance,
<a class="hl" name="1240" href="#1240">1240</a>
<a class="l" name="1241" href="#1241">1241</a>```cpp
<a class="l" name="1242" href="#1242">1242</a>using ::testing::Field;
<a class="l" name="1243" href="#1243">1243</a>using ::testing::Ge;
<a class="l" name="1244" href="#1244">1244</a>...
<a class="l" name="1245" href="#1245">1245</a>Field(&amp;Foo::number, Ge(3))
<a class="l" name="1246" href="#1246">1246</a>```
<a class="l" name="1247" href="#1247">1247</a>
<a class="l" name="1248" href="#1248">1248</a>matches a plain pointer `p` where `p-&gt;number &gt;= 3`. If `p` is `NULL`, the match
<a class="l" name="1249" href="#1249">1249</a>will always fail regardless of the inner matcher.
<a class="hl" name="1250" href="#1250">1250</a>
<a class="l" name="1251" href="#1251">1251</a>What if you want to validate more than one members at the same time? Remember
<a class="l" name="1252" href="#1252">1252</a>that there are [`AllOf()` and `AllOfArray()`](#CombiningMatchers).
<a class="l" name="1253" href="#1253">1253</a>
<a class="l" name="1254" href="#1254">1254</a>Finally `Field()` and `Property()` provide overloads that take the field or
<a class="l" name="1255" href="#1255">1255</a>property names as the first argument to include it in the error message. This
<a class="l" name="1256" href="#1256">1256</a>can be useful when creating combined matchers.
<a class="l" name="1257" href="#1257">1257</a>
<a class="l" name="1258" href="#1258">1258</a>```cpp
<a class="l" name="1259" href="#1259">1259</a>using ::testing::AllOf;
<a class="hl" name="1260" href="#1260">1260</a>using ::testing::Field;
<a class="l" name="1261" href="#1261">1261</a>using ::testing::Matcher;
<a class="l" name="1262" href="#1262">1262</a>using ::testing::SafeMatcherCast;
<a class="l" name="1263" href="#1263">1263</a>
<a class="l" name="1264" href="#1264">1264</a>Matcher&lt;Foo&gt; IsFoo(const Foo&amp; foo) {
<a class="l" name="1265" href="#1265">1265</a>  return AllOf(Field("some_field", &amp;Foo::some_field, <a href="/googletest/s?path=foo.some_field&amp;project=googletest">foo.some_field</a>),
<a class="l" name="1266" href="#1266">1266</a>               Field("other_field", &amp;Foo::other_field, <a href="/googletest/s?path=foo.other_field&amp;project=googletest">foo.other_field</a>),
<a class="l" name="1267" href="#1267">1267</a>               Field("last_field", &amp;Foo::last_field, <a href="/googletest/s?path=foo.last_field&amp;project=googletest">foo.last_field</a>));
<a class="l" name="1268" href="#1268">1268</a>}
<a class="l" name="1269" href="#1269">1269</a>```
<a class="hl" name="1270" href="#1270">1270</a>
<a class="l" name="1271" href="#1271">1271</a>### Validating the Value Pointed to by a Pointer Argument
<a class="l" name="1272" href="#1272">1272</a>
<a class="l" name="1273" href="#1273">1273</a>C++ functions often take pointers as arguments. You can use matchers like
<a class="l" name="1274" href="#1274">1274</a>`IsNull()`, `NotNull()`, and other comparison matchers to match a pointer, but
<a class="l" name="1275" href="#1275">1275</a>what if you want to make sure the value *pointed to* by the pointer, instead of
<a class="l" name="1276" href="#1276">1276</a>the pointer itself, has a certain property? Well, you can use the `Pointee(m)`
<a class="l" name="1277" href="#1277">1277</a>matcher.
<a class="l" name="1278" href="#1278">1278</a>
<a class="l" name="1279" href="#1279">1279</a>`Pointee(m)` matches a pointer if and only if `m` matches the value the pointer
<a class="hl" name="1280" href="#1280">1280</a>points to. For example:
<a class="l" name="1281" href="#1281">1281</a>
<a class="l" name="1282" href="#1282">1282</a>```cpp
<a class="l" name="1283" href="#1283">1283</a>using ::testing::Ge;
<a class="l" name="1284" href="#1284">1284</a>using ::testing::Pointee;
<a class="l" name="1285" href="#1285">1285</a>...
<a class="l" name="1286" href="#1286">1286</a>  EXPECT_CALL(foo, Bar(Pointee(Ge(3))));
<a class="l" name="1287" href="#1287">1287</a>```
<a class="l" name="1288" href="#1288">1288</a>
<a class="l" name="1289" href="#1289">1289</a>expects `<a href="/googletest/s?path=foo.Bar&amp;project=googletest">foo.Bar</a>()` to be called with a pointer that points to a value greater
<a class="hl" name="1290" href="#1290">1290</a>than or equal to 3.
<a class="l" name="1291" href="#1291">1291</a>
<a class="l" name="1292" href="#1292">1292</a>One nice thing about `Pointee()` is that it treats a `NULL` pointer as a match
<a class="l" name="1293" href="#1293">1293</a>failure, so you can write `Pointee(m)` instead of
<a class="l" name="1294" href="#1294">1294</a>
<a class="l" name="1295" href="#1295">1295</a>```cpp
<a class="l" name="1296" href="#1296">1296</a>using ::testing::AllOf;
<a class="l" name="1297" href="#1297">1297</a>using ::testing::NotNull;
<a class="l" name="1298" href="#1298">1298</a>using ::testing::Pointee;
<a class="l" name="1299" href="#1299">1299</a>...
<a class="hl" name="1300" href="#1300">1300</a>  AllOf(NotNull(), Pointee(m))
<a class="l" name="1301" href="#1301">1301</a>```
<a class="l" name="1302" href="#1302">1302</a>
<a class="l" name="1303" href="#1303">1303</a>without worrying that a `NULL` pointer will crash your test.
<a class="l" name="1304" href="#1304">1304</a>
<a class="l" name="1305" href="#1305">1305</a>Also, did we tell you that `Pointee()` works with both raw pointers **and**
<a class="l" name="1306" href="#1306">1306</a>smart pointers (`std::unique_ptr`, `std::shared_ptr`, etc)?
<a class="l" name="1307" href="#1307">1307</a>
<a class="l" name="1308" href="#1308">1308</a>What if you have a pointer to pointer? You guessed it - you can use nested
<a class="l" name="1309" href="#1309">1309</a>`Pointee()` to probe deeper inside the value. For example,
<a class="hl" name="1310" href="#1310">1310</a>`Pointee(Pointee(Lt(3)))` matches a pointer that points to a pointer that points
<a class="l" name="1311" href="#1311">1311</a>to a number less than 3 (what a mouthful...).
<a class="l" name="1312" href="#1312">1312</a>
<a class="l" name="1313" href="#1313">1313</a>### Testing a Certain Property of an Object
<a class="l" name="1314" href="#1314">1314</a>
<a class="l" name="1315" href="#1315">1315</a>Sometimes you want to specify that an object argument has a certain property,
<a class="l" name="1316" href="#1316">1316</a>but there is no existing matcher that does this. If you want good error
<a class="l" name="1317" href="#1317">1317</a>messages, you should [define a matcher](#NewMatchers). If you want to do it
<a class="l" name="1318" href="#1318">1318</a>quick and dirty, you could get away with writing an ordinary function.
<a class="l" name="1319" href="#1319">1319</a>
<a class="hl" name="1320" href="#1320">1320</a>Let's say you have a mock function that takes an object of type `Foo`, which has
<a class="l" name="1321" href="#1321">1321</a>an `int bar()` method and an `int baz()` method, and you want to constrain that
<a class="l" name="1322" href="#1322">1322</a>the argument's `bar()` value plus its `baz()` value is a given number. Here's
<a class="l" name="1323" href="#1323">1323</a>how you can define a matcher to do it:
<a class="l" name="1324" href="#1324">1324</a>
<a class="l" name="1325" href="#1325">1325</a>```cpp
<a class="l" name="1326" href="#1326">1326</a>using ::testing::Matcher;
<a class="l" name="1327" href="#1327">1327</a>using ::testing::MatcherInterface;
<a class="l" name="1328" href="#1328">1328</a>using ::testing::MatchResultListener;
<a class="l" name="1329" href="#1329">1329</a>
<a class="hl" name="1330" href="#1330">1330</a>class BarPlusBazEqMatcher : public MatcherInterface&lt;const Foo&amp;&gt; {
<a class="l" name="1331" href="#1331">1331</a> public:
<a class="l" name="1332" href="#1332">1332</a>  explicit BarPlusBazEqMatcher(int expected_sum)
<a class="l" name="1333" href="#1333">1333</a>      : expected_sum_(expected_sum) {}
<a class="l" name="1334" href="#1334">1334</a>
<a class="l" name="1335" href="#1335">1335</a>  bool MatchAndExplain(const Foo&amp; foo,
<a class="l" name="1336" href="#1336">1336</a>                       MatchResultListener* /* listener */) const override {
<a class="l" name="1337" href="#1337">1337</a>    return (<a href="/googletest/s?path=foo.bar&amp;project=googletest">foo.bar</a>() + <a href="/googletest/s?path=foo.baz&amp;project=googletest">foo.baz</a>()) == expected_sum_;
<a class="l" name="1338" href="#1338">1338</a>  }
<a class="l" name="1339" href="#1339">1339</a>
<a class="hl" name="1340" href="#1340">1340</a>  void DescribeTo(std::ostream* os) const override {
<a class="l" name="1341" href="#1341">1341</a>    *os &lt;&lt; "bar() + baz() equals " &lt;&lt; expected_sum_;
<a class="l" name="1342" href="#1342">1342</a>  }
<a class="l" name="1343" href="#1343">1343</a>
<a class="l" name="1344" href="#1344">1344</a>  void DescribeNegationTo(std::ostream* os) const override {
<a class="l" name="1345" href="#1345">1345</a>    *os &lt;&lt; "bar() + baz() does not equal " &lt;&lt; expected_sum_;
<a class="l" name="1346" href="#1346">1346</a>  }
<a class="l" name="1347" href="#1347">1347</a> private:
<a class="l" name="1348" href="#1348">1348</a>  const int expected_sum_;
<a class="l" name="1349" href="#1349">1349</a>};
<a class="hl" name="1350" href="#1350">1350</a>
<a class="l" name="1351" href="#1351">1351</a>Matcher&lt;const Foo&amp;&gt; BarPlusBazEq(int expected_sum) {
<a class="l" name="1352" href="#1352">1352</a>  return MakeMatcher(new BarPlusBazEqMatcher(expected_sum));
<a class="l" name="1353" href="#1353">1353</a>}
<a class="l" name="1354" href="#1354">1354</a>
<a class="l" name="1355" href="#1355">1355</a>...
<a class="l" name="1356" href="#1356">1356</a>  EXPECT_CALL(..., DoThis(BarPlusBazEq(5)))...;
<a class="l" name="1357" href="#1357">1357</a>```
<a class="l" name="1358" href="#1358">1358</a>
<a class="l" name="1359" href="#1359">1359</a>### Matching Containers
<a class="hl" name="1360" href="#1360">1360</a>
<a class="l" name="1361" href="#1361">1361</a>Sometimes an STL container (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> list, vector, map, ...) is passed to a mock
<a class="l" name="1362" href="#1362">1362</a>function and you may want to validate it. Since most STL containers support the
<a class="l" name="1363" href="#1363">1363</a>`==` operator, you can write `Eq(expected_container)` or simply
<a class="l" name="1364" href="#1364">1364</a>`expected_container` to match a container exactly.
<a class="l" name="1365" href="#1365">1365</a>
<a class="l" name="1366" href="#1366">1366</a>Sometimes, though, you may want to be more flexible (for example, the first
<a class="l" name="1367" href="#1367">1367</a>element must be an exact match, but the second element can be any positive
<a class="l" name="1368" href="#1368">1368</a>number, and so on). Also, containers used in tests often have a small number of
<a class="l" name="1369" href="#1369">1369</a>elements, and having to define the expected container out-of-line is a bit of a
<a class="hl" name="1370" href="#1370">1370</a>hassle.
<a class="l" name="1371" href="#1371">1371</a>
<a class="l" name="1372" href="#1372">1372</a>You can use the `ElementsAre()` or `UnorderedElementsAre()` matcher in such
<a class="l" name="1373" href="#1373">1373</a>cases:
<a class="l" name="1374" href="#1374">1374</a>
<a class="l" name="1375" href="#1375">1375</a>```cpp
<a class="l" name="1376" href="#1376">1376</a>using ::testing::_;
<a class="l" name="1377" href="#1377">1377</a>using ::testing::ElementsAre;
<a class="l" name="1378" href="#1378">1378</a>using ::testing::Gt;
<a class="l" name="1379" href="#1379">1379</a>...
<a class="hl" name="1380" href="#1380">1380</a>  MOCK_METHOD(void, Foo, (const vector&lt;int&gt;&amp; numbers), (override));
<a class="l" name="1381" href="#1381">1381</a>...
<a class="l" name="1382" href="#1382">1382</a>  EXPECT_CALL(mock, Foo(ElementsAre(1, Gt(0), _, 5)));
<a class="l" name="1383" href="#1383">1383</a>```
<a class="l" name="1384" href="#1384">1384</a>
<a class="l" name="1385" href="#1385">1385</a>The above matcher says that the container must have 4 elements, which must be 1,
<a class="l" name="1386" href="#1386">1386</a>greater than 0, anything, and 5 respectively.
<a class="l" name="1387" href="#1387">1387</a>
<a class="l" name="1388" href="#1388">1388</a>If you instead write:
<a class="l" name="1389" href="#1389">1389</a>
<a class="hl" name="1390" href="#1390">1390</a>```cpp
<a class="l" name="1391" href="#1391">1391</a>using ::testing::_;
<a class="l" name="1392" href="#1392">1392</a>using ::testing::Gt;
<a class="l" name="1393" href="#1393">1393</a>using ::testing::UnorderedElementsAre;
<a class="l" name="1394" href="#1394">1394</a>...
<a class="l" name="1395" href="#1395">1395</a>  MOCK_METHOD(void, Foo, (const vector&lt;int&gt;&amp; numbers), (override));
<a class="l" name="1396" href="#1396">1396</a>...
<a class="l" name="1397" href="#1397">1397</a>  EXPECT_CALL(mock, Foo(UnorderedElementsAre(1, Gt(0), _, 5)));
<a class="l" name="1398" href="#1398">1398</a>```
<a class="l" name="1399" href="#1399">1399</a>
<a class="hl" name="1400" href="#1400">1400</a>It means that the container must have 4 elements, which (under some permutation)
<a class="l" name="1401" href="#1401">1401</a>must be 1, greater than 0, anything, and 5 respectively.
<a class="l" name="1402" href="#1402">1402</a>
<a class="l" name="1403" href="#1403">1403</a>As an alternative you can place the arguments in a C-style array and use
<a class="l" name="1404" href="#1404">1404</a>`ElementsAreArray()` or `UnorderedElementsAreArray()` instead:
<a class="l" name="1405" href="#1405">1405</a>
<a class="l" name="1406" href="#1406">1406</a>```cpp
<a class="l" name="1407" href="#1407">1407</a>using ::testing::ElementsAreArray;
<a class="l" name="1408" href="#1408">1408</a>...
<a class="l" name="1409" href="#1409">1409</a>  // ElementsAreArray accepts an array of element values.
<a class="hl" name="1410" href="#1410">1410</a>  const int expected_vector1[] = {1, 5, 2, 4, ...};
<a class="l" name="1411" href="#1411">1411</a>  EXPECT_CALL(mock, Foo(ElementsAreArray(expected_vector1)));
<a class="l" name="1412" href="#1412">1412</a>
<a class="l" name="1413" href="#1413">1413</a>  // Or, an array of element matchers.
<a class="l" name="1414" href="#1414">1414</a>  Matcher&lt;int&gt; expected_vector2[] = {1, Gt(2), _, 3, ...};
<a class="l" name="1415" href="#1415">1415</a>  EXPECT_CALL(mock, Foo(ElementsAreArray(expected_vector2)));
<a class="l" name="1416" href="#1416">1416</a>```
<a class="l" name="1417" href="#1417">1417</a>
<a class="l" name="1418" href="#1418">1418</a>In case the array needs to be dynamically created (and therefore the array size
<a class="l" name="1419" href="#1419">1419</a>cannot be inferred by the compiler), you can give `ElementsAreArray()` an
<a class="hl" name="1420" href="#1420">1420</a>additional argument to specify the array size:
<a class="l" name="1421" href="#1421">1421</a>
<a class="l" name="1422" href="#1422">1422</a>```cpp
<a class="l" name="1423" href="#1423">1423</a>using ::testing::ElementsAreArray;
<a class="l" name="1424" href="#1424">1424</a>...
<a class="l" name="1425" href="#1425">1425</a>  int* const expected_vector3 = new int[count];
<a class="l" name="1426" href="#1426">1426</a>  ... fill expected_vector3 with values ...
<a class="l" name="1427" href="#1427">1427</a>  EXPECT_CALL(mock, Foo(ElementsAreArray(expected_vector3, count)));
<a class="l" name="1428" href="#1428">1428</a>```
<a class="l" name="1429" href="#1429">1429</a>
<a class="hl" name="1430" href="#1430">1430</a>Use `Pair` when comparing maps or other associative containers.
<a class="l" name="1431" href="#1431">1431</a>
<a class="l" name="1432" href="#1432">1432</a>```cpp
<a class="l" name="1433" href="#1433">1433</a>using testing::ElementsAre;
<a class="l" name="1434" href="#1434">1434</a>using testing::Pair;
<a class="l" name="1435" href="#1435">1435</a>...
<a class="l" name="1436" href="#1436">1436</a>  std::map&lt;string, int&gt; m = {{"a", 1}, {"b", 2}, {"c", 3}};
<a class="l" name="1437" href="#1437">1437</a>  EXPECT_THAT(m, ElementsAre(Pair("a", 1), Pair("b", 2), Pair("c", 3)));
<a class="l" name="1438" href="#1438">1438</a>```
<a class="l" name="1439" href="#1439">1439</a>
<a class="hl" name="1440" href="#1440">1440</a>**Tips:**
<a class="l" name="1441" href="#1441">1441</a>
<a class="l" name="1442" href="#1442">1442</a>*   `ElementsAre*()` can be used to match *any* container that implements the
<a class="l" name="1443" href="#1443">1443</a>    STL iterator pattern (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> it has a `const_iterator` type and supports
<a class="l" name="1444" href="#1444">1444</a>    `begin()/end()`), not just the ones defined in STL. It will even work with
<a class="l" name="1445" href="#1445">1445</a>    container types yet to be written - as long as they follows the above
<a class="l" name="1446" href="#1446">1446</a>    pattern.
<a class="l" name="1447" href="#1447">1447</a>*   You can use nested `ElementsAre*()` to match nested (multi-dimensional)
<a class="l" name="1448" href="#1448">1448</a>    containers.
<a class="l" name="1449" href="#1449">1449</a>*   If the container is passed by pointer instead of by reference, just write
<a class="hl" name="1450" href="#1450">1450</a>    `Pointee(ElementsAre*(...))`.
<a class="l" name="1451" href="#1451">1451</a>*   The order of elements *matters* for `ElementsAre*()`. If you are using it
<a class="l" name="1452" href="#1452">1452</a>    with containers whose element order are undefined (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `hash_map`) you
<a class="l" name="1453" href="#1453">1453</a>    should use `WhenSorted` around `ElementsAre`.
<a class="l" name="1454" href="#1454">1454</a>
<a class="l" name="1455" href="#1455">1455</a>### Sharing Matchers
<a class="l" name="1456" href="#1456">1456</a>
<a class="l" name="1457" href="#1457">1457</a>Under the hood, a gMock matcher object consists of a pointer to a ref-counted
<a class="l" name="1458" href="#1458">1458</a>implementation object. Copying matchers is allowed and very efficient, as only
<a class="l" name="1459" href="#1459">1459</a>the pointer is copied. When the last matcher that references the implementation
<a class="hl" name="1460" href="#1460">1460</a>object dies, the implementation object will be deleted.
<a class="l" name="1461" href="#1461">1461</a>
<a class="l" name="1462" href="#1462">1462</a>Therefore, if you have some complex matcher that you want to use again and
<a class="l" name="1463" href="#1463">1463</a>again, there is no need to build it everytime. Just assign it to a matcher
<a class="l" name="1464" href="#1464">1464</a>variable and use that variable repeatedly! For example,
<a class="l" name="1465" href="#1465">1465</a>
<a class="l" name="1466" href="#1466">1466</a>```cpp
<a class="l" name="1467" href="#1467">1467</a>using ::testing::AllOf;
<a class="l" name="1468" href="#1468">1468</a>using ::testing::Gt;
<a class="l" name="1469" href="#1469">1469</a>using ::testing::Le;
<a class="hl" name="1470" href="#1470">1470</a>using ::testing::Matcher;
<a class="l" name="1471" href="#1471">1471</a>...
<a class="l" name="1472" href="#1472">1472</a>  Matcher&lt;int&gt; in_range = AllOf(Gt(5), Le(10));
<a class="l" name="1473" href="#1473">1473</a>  ... use in_range as a matcher in multiple EXPECT_CALLs ...
<a class="l" name="1474" href="#1474">1474</a>```
<a class="l" name="1475" href="#1475">1475</a>
<a class="l" name="1476" href="#1476">1476</a>### Matchers must have no side-effects {#PureMatchers}
<a class="l" name="1477" href="#1477">1477</a>
<a class="l" name="1478" href="#1478">1478</a>WARNING: gMock does not guarantee when or how many times a matcher will be
<a class="l" name="1479" href="#1479">1479</a>invoked. Therefore, all matchers must be *purely functional*: they cannot have
<a class="hl" name="1480" href="#1480">1480</a>any side effects, and the match result must not depend on anything other than
<a class="l" name="1481" href="#1481">1481</a>the matcher's parameters and the value being matched.
<a class="l" name="1482" href="#1482">1482</a>
<a class="l" name="1483" href="#1483">1483</a>This requirement must be satisfied no matter how a matcher is defined (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>, if
<a class="l" name="1484" href="#1484">1484</a>it is one of the standard matchers, or a custom matcher). In particular, a
<a class="l" name="1485" href="#1485">1485</a>matcher can never call a mock function, as that will affect the state of the
<a class="l" name="1486" href="#1486">1486</a>mock object and gMock.
<a class="l" name="1487" href="#1487">1487</a>
<a class="l" name="1488" href="#1488">1488</a>## Setting Expectations
<a class="l" name="1489" href="#1489">1489</a>
<a class="hl" name="1490" href="#1490">1490</a>### Knowing When to Expect {#UseOnCall}
<a class="l" name="1491" href="#1491">1491</a>
<a class="l" name="1492" href="#1492">1492</a>&lt;!-- GOOGLETEST_CM0018 DO NOT DELETE --&gt;
<a class="l" name="1493" href="#1493">1493</a>
<a class="l" name="1494" href="#1494">1494</a>**`ON_CALL`** is likely the *single most under-utilized construct* in gMock.
<a class="l" name="1495" href="#1495">1495</a>
<a class="l" name="1496" href="#1496">1496</a>There are basically two constructs for defining the behavior of a mock object:
<a class="l" name="1497" href="#1497">1497</a>`ON_CALL` and `EXPECT_CALL`. The difference? `ON_CALL` defines what happens when
<a class="l" name="1498" href="#1498">1498</a>a mock method is called, but &lt;em&gt;doesn't imply any expectation on the method
<a class="l" name="1499" href="#1499">1499</a>being called&lt;/em&gt;. `EXPECT_CALL` not only defines the behavior, but also sets an
<a class="hl" name="1500" href="#1500">1500</a>expectation that &lt;em&gt;the method will be called with the given arguments, for the
<a class="l" name="1501" href="#1501">1501</a>given number of times&lt;/em&gt; (and *in the given order* when you specify the order
<a class="l" name="1502" href="#1502">1502</a>too).
<a class="l" name="1503" href="#1503">1503</a>
<a class="l" name="1504" href="#1504">1504</a>Since `EXPECT_CALL` does more, isn't it better than `ON_CALL`? Not really. Every
<a class="l" name="1505" href="#1505">1505</a>`EXPECT_CALL` adds a constraint on the behavior of the code under test. Having
<a class="l" name="1506" href="#1506">1506</a>more constraints than necessary is *baaad* - even worse than not having enough
<a class="l" name="1507" href="#1507">1507</a>constraints.
<a class="l" name="1508" href="#1508">1508</a>
<a class="l" name="1509" href="#1509">1509</a>This may be counter-intuitive. How could tests that verify more be worse than
<a class="hl" name="1510" href="#1510">1510</a>tests that verify less? Isn't verification the whole point of tests?
<a class="l" name="1511" href="#1511">1511</a>
<a class="l" name="1512" href="#1512">1512</a>The answer lies in *what* a test should verify. **A good test verifies the
<a class="l" name="1513" href="#1513">1513</a>contract of the code.** If a test over-specifies, it doesn't leave enough
<a class="l" name="1514" href="#1514">1514</a>freedom to the implementation. As a result, changing the implementation without
<a class="l" name="1515" href="#1515">1515</a>breaking the contract (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> refactoring and optimization), which should be
<a class="l" name="1516" href="#1516">1516</a>perfectly fine to do, can break such tests. Then you have to spend time fixing
<a class="l" name="1517" href="#1517">1517</a>them, only to see them broken again the next time the implementation is changed.
<a class="l" name="1518" href="#1518">1518</a>
<a class="l" name="1519" href="#1519">1519</a>Keep in mind that one doesn't have to verify more than one property in one test.
<a class="hl" name="1520" href="#1520">1520</a>In fact, **it's a good style to verify only one thing in one test.** If you do
<a class="l" name="1521" href="#1521">1521</a>that, a bug will likely break only one or two tests instead of dozens (which
<a class="l" name="1522" href="#1522">1522</a>case would you rather debug?). If you are also in the habit of giving tests
<a class="l" name="1523" href="#1523">1523</a>descriptive names that tell what they verify, you can often easily guess what's
<a class="l" name="1524" href="#1524">1524</a>wrong just from the test log itself.
<a class="l" name="1525" href="#1525">1525</a>
<a class="l" name="1526" href="#1526">1526</a>So use `ON_CALL` by default, and only use `EXPECT_CALL` when you actually intend
<a class="l" name="1527" href="#1527">1527</a>to verify that the call is made. For example, you may have a bunch of `ON_CALL`s
<a class="l" name="1528" href="#1528">1528</a>in your test fixture to set the common mock behavior shared by all tests in the
<a class="l" name="1529" href="#1529">1529</a>same group, and write (scarcely) different `EXPECT_CALL`s in different `TEST_F`s
<a class="hl" name="1530" href="#1530">1530</a>to verify different aspects of the code's behavior. Compared with the style
<a class="l" name="1531" href="#1531">1531</a>where each `TEST` has many `EXPECT_CALL`s, this leads to tests that are more
<a class="l" name="1532" href="#1532">1532</a>resilient to implementational changes (and thus less likely to require
<a class="l" name="1533" href="#1533">1533</a>maintenance) and makes the intent of the tests more obvious (so they are easier
<a class="l" name="1534" href="#1534">1534</a>to maintain when you do need to maintain them).
<a class="l" name="1535" href="#1535">1535</a>
<a class="l" name="1536" href="#1536">1536</a>If you are bothered by the "Uninteresting mock function call" message printed
<a class="l" name="1537" href="#1537">1537</a>when a mock method without an `EXPECT_CALL` is called, you may use a `NiceMock`
<a class="l" name="1538" href="#1538">1538</a>instead to suppress all such messages for the mock object, or suppress the
<a class="l" name="1539" href="#1539">1539</a>message for specific methods by adding `EXPECT_CALL(...).Times(AnyNumber())`. DO
<a class="hl" name="1540" href="#1540">1540</a>NOT suppress it by blindly adding an `EXPECT_CALL(...)`, or you'll have a test
<a class="l" name="1541" href="#1541">1541</a>that's a pain to maintain.
<a class="l" name="1542" href="#1542">1542</a>
<a class="l" name="1543" href="#1543">1543</a>### Ignoring Uninteresting Calls
<a class="l" name="1544" href="#1544">1544</a>
<a class="l" name="1545" href="#1545">1545</a>If you are not interested in how a mock method is called, just don't say
<a class="l" name="1546" href="#1546">1546</a>anything about it. In this case, if the method is ever called, gMock will
<a class="l" name="1547" href="#1547">1547</a>perform its default action to allow the test program to continue. If you are not
<a class="l" name="1548" href="#1548">1548</a>happy with the default action taken by gMock, you can override it using
<a class="l" name="1549" href="#1549">1549</a>`DefaultValue&lt;T&gt;::Set()` (described [here](#DefaultValue)) or `ON_CALL()`.
<a class="hl" name="1550" href="#1550">1550</a>
<a class="l" name="1551" href="#1551">1551</a>Please note that once you expressed interest in a particular mock method (via
<a class="l" name="1552" href="#1552">1552</a>`EXPECT_CALL()`), all invocations to it must match some expectation. If this
<a class="l" name="1553" href="#1553">1553</a>function is called but the arguments don't match any `EXPECT_CALL()` statement,
<a class="l" name="1554" href="#1554">1554</a>it will be an error.
<a class="l" name="1555" href="#1555">1555</a>
<a class="l" name="1556" href="#1556">1556</a>### Disallowing Unexpected Calls
<a class="l" name="1557" href="#1557">1557</a>
<a class="l" name="1558" href="#1558">1558</a>If a mock method shouldn't be called at all, explicitly say so:
<a class="l" name="1559" href="#1559">1559</a>
<a class="hl" name="1560" href="#1560">1560</a>```cpp
<a class="l" name="1561" href="#1561">1561</a>using ::testing::_;
<a class="l" name="1562" href="#1562">1562</a>...
<a class="l" name="1563" href="#1563">1563</a>  EXPECT_CALL(foo, Bar(_))
<a class="l" name="1564" href="#1564">1564</a>      .Times(0);
<a class="l" name="1565" href="#1565">1565</a>```
<a class="l" name="1566" href="#1566">1566</a>
<a class="l" name="1567" href="#1567">1567</a>If some calls to the method are allowed, but the rest are not, just list all the
<a class="l" name="1568" href="#1568">1568</a>expected calls:
<a class="l" name="1569" href="#1569">1569</a>
<a class="hl" name="1570" href="#1570">1570</a>```cpp
<a class="l" name="1571" href="#1571">1571</a>using ::testing::AnyNumber;
<a class="l" name="1572" href="#1572">1572</a>using ::testing::Gt;
<a class="l" name="1573" href="#1573">1573</a>...
<a class="l" name="1574" href="#1574">1574</a>  EXPECT_CALL(foo, Bar(5));
<a class="l" name="1575" href="#1575">1575</a>  EXPECT_CALL(foo, Bar(Gt(10)))
<a class="l" name="1576" href="#1576">1576</a>      .Times(AnyNumber());
<a class="l" name="1577" href="#1577">1577</a>```
<a class="l" name="1578" href="#1578">1578</a>
<a class="l" name="1579" href="#1579">1579</a>A call to `<a href="/googletest/s?path=foo.Bar&amp;project=googletest">foo.Bar</a>()` that doesn't match any of the `EXPECT_CALL()` statements
<a class="hl" name="1580" href="#1580">1580</a>will be an error.
<a class="l" name="1581" href="#1581">1581</a>
<a class="l" name="1582" href="#1582">1582</a>### Understanding Uninteresting vs Unexpected Calls {#uninteresting-vs-unexpected}
<a class="l" name="1583" href="#1583">1583</a>
<a class="l" name="1584" href="#1584">1584</a>*Uninteresting* calls and *unexpected* calls are different concepts in gMock.
<a class="l" name="1585" href="#1585">1585</a>*Very* different.
<a class="l" name="1586" href="#1586">1586</a>
<a class="l" name="1587" href="#1587">1587</a>A call `<a href="/googletest/s?path=x.Y&amp;project=googletest">x.Y</a>(...)` is **uninteresting** if there's *not even a single*
<a class="l" name="1588" href="#1588">1588</a>`EXPECT_CALL(x, Y(...))` set. In other words, the test isn't interested in the
<a class="l" name="1589" href="#1589">1589</a>`<a href="/googletest/s?path=x.Y&amp;project=googletest">x.Y</a>()` method at all, as evident in that the test doesn't care to say anything
<a class="hl" name="1590" href="#1590">1590</a>about it.
<a class="l" name="1591" href="#1591">1591</a>
<a class="l" name="1592" href="#1592">1592</a>A call `<a href="/googletest/s?path=x.Y&amp;project=googletest">x.Y</a>(...)` is **unexpected** if there are *some* `EXPECT_CALL(x,
<a class="l" name="1593" href="#1593">1593</a>Y(...))`s set, but none of them matches the call. Put another way, the test is
<a class="l" name="1594" href="#1594">1594</a>interested in the `<a href="/googletest/s?path=x.Y&amp;project=googletest">x.Y</a>()` method (therefore it explicitly sets some
<a class="l" name="1595" href="#1595">1595</a>`EXPECT_CALL` to verify how it's called); however, the verification fails as the
<a class="l" name="1596" href="#1596">1596</a>test doesn't expect this particular call to happen.
<a class="l" name="1597" href="#1597">1597</a>
<a class="l" name="1598" href="#1598">1598</a>**An unexpected call is always an error,** as the code under test doesn't behave
<a class="l" name="1599" href="#1599">1599</a>the way the test expects it to behave.
<a class="hl" name="1600" href="#1600">1600</a>
<a class="l" name="1601" href="#1601">1601</a>**By default, an uninteresting call is not an error,** as it violates no
<a class="l" name="1602" href="#1602">1602</a>constraint specified by the test. (gMock's philosophy is that saying nothing
<a class="l" name="1603" href="#1603">1603</a>means there is no constraint.) However, it leads to a warning, as it *might*
<a class="l" name="1604" href="#1604">1604</a>indicate a problem (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> the test author might have forgotten to specify a
<a class="l" name="1605" href="#1605">1605</a>constraint).
<a class="l" name="1606" href="#1606">1606</a>
<a class="l" name="1607" href="#1607">1607</a>In gMock, `NiceMock` and `StrictMock` can be used to make a mock class "nice" or
<a class="l" name="1608" href="#1608">1608</a>"strict". How does this affect uninteresting calls and unexpected calls?
<a class="l" name="1609" href="#1609">1609</a>
<a class="hl" name="1610" href="#1610">1610</a>A **nice mock** suppresses uninteresting call *warnings*. It is less chatty than
<a class="l" name="1611" href="#1611">1611</a>the default mock, but otherwise is the same. If a test fails with a default
<a class="l" name="1612" href="#1612">1612</a>mock, it will also fail using a nice mock instead. And vice versa. Don't expect
<a class="l" name="1613" href="#1613">1613</a>making a mock nice to change the test's result.
<a class="l" name="1614" href="#1614">1614</a>
<a class="l" name="1615" href="#1615">1615</a>A **strict mock** turns uninteresting call warnings into errors. So making a
<a class="l" name="1616" href="#1616">1616</a>mock strict may change the test's result.
<a class="l" name="1617" href="#1617">1617</a>
<a class="l" name="1618" href="#1618">1618</a>Let's look at an example:
<a class="l" name="1619" href="#1619">1619</a>
<a class="hl" name="1620" href="#1620">1620</a>```cpp
<a class="l" name="1621" href="#1621">1621</a>TEST(...) {
<a class="l" name="1622" href="#1622">1622</a>  NiceMock&lt;MockDomainRegistry&gt; mock_registry;
<a class="l" name="1623" href="#1623">1623</a>  EXPECT_CALL(mock_registry, GetDomainOwner("<a href="/googletest/s?path=google.com&amp;project=googletest">google.com</a>"))
<a class="l" name="1624" href="#1624">1624</a>          .WillRepeatedly(Return("Larry Page"));
<a class="l" name="1625" href="#1625">1625</a>
<a class="l" name="1626" href="#1626">1626</a>  // Use mock_registry in code under test.
<a class="l" name="1627" href="#1627">1627</a>  ... &amp;mock_registry ...
<a class="l" name="1628" href="#1628">1628</a>}
<a class="l" name="1629" href="#1629">1629</a>```
<a class="hl" name="1630" href="#1630">1630</a>
<a class="l" name="1631" href="#1631">1631</a>The sole `EXPECT_CALL` here says that all calls to `GetDomainOwner()` must have
<a class="l" name="1632" href="#1632">1632</a>`"<a href="/googletest/s?path=google.com&amp;project=googletest">google.com</a>"` as the argument. If `GetDomainOwner("<a href="/googletest/s?path=yahoo.com&amp;project=googletest">yahoo.com</a>")` is called, it
<a class="l" name="1633" href="#1633">1633</a>will be an unexpected call, and thus an error. *Having a nice mock doesn't
<a class="l" name="1634" href="#1634">1634</a>change the severity of an unexpected call.*
<a class="l" name="1635" href="#1635">1635</a>
<a class="l" name="1636" href="#1636">1636</a>So how do we tell gMock that `GetDomainOwner()` can be called with some other
<a class="l" name="1637" href="#1637">1637</a>arguments as well? The standard technique is to add a "catch all" `EXPECT_CALL`:
<a class="l" name="1638" href="#1638">1638</a>
<a class="l" name="1639" href="#1639">1639</a>```cpp
<a class="hl" name="1640" href="#1640">1640</a>  EXPECT_CALL(mock_registry, GetDomainOwner(_))
<a class="l" name="1641" href="#1641">1641</a>        .Times(AnyNumber());  // catches all other calls to this method.
<a class="l" name="1642" href="#1642">1642</a>  EXPECT_CALL(mock_registry, GetDomainOwner("<a href="/googletest/s?path=google.com&amp;project=googletest">google.com</a>"))
<a class="l" name="1643" href="#1643">1643</a>        .WillRepeatedly(Return("Larry Page"));
<a class="l" name="1644" href="#1644">1644</a>```
<a class="l" name="1645" href="#1645">1645</a>
<a class="l" name="1646" href="#1646">1646</a>Remember that `_` is the wildcard matcher that matches anything. With this, if
<a class="l" name="1647" href="#1647">1647</a>`GetDomainOwner("<a href="/googletest/s?path=google.com&amp;project=googletest">google.com</a>")` is called, it will do what the second
<a class="l" name="1648" href="#1648">1648</a>`EXPECT_CALL` says; if it is called with a different argument, it will do what
<a class="l" name="1649" href="#1649">1649</a>the first `EXPECT_CALL` says.
<a class="hl" name="1650" href="#1650">1650</a>
<a class="l" name="1651" href="#1651">1651</a>Note that the order of the two `EXPECT_CALL`s is important, as a newer
<a class="l" name="1652" href="#1652">1652</a>`EXPECT_CALL` takes precedence over an older one.
<a class="l" name="1653" href="#1653">1653</a>
<a class="l" name="1654" href="#1654">1654</a>For more on uninteresting calls, nice mocks, and strict mocks, read
<a class="l" name="1655" href="#1655">1655</a>["The Nice, the Strict, and the Naggy"](#NiceStrictNaggy).
<a class="l" name="1656" href="#1656">1656</a>
<a class="l" name="1657" href="#1657">1657</a>### Ignoring Uninteresting Arguments {#ParameterlessExpectations}
<a class="l" name="1658" href="#1658">1658</a>
<a class="l" name="1659" href="#1659">1659</a>If your test doesn't care about the parameters (it only cares about the number
<a class="hl" name="1660" href="#1660">1660</a>or order of calls), you can often simply omit the parameter list:
<a class="l" name="1661" href="#1661">1661</a>
<a class="l" name="1662" href="#1662">1662</a>```cpp
<a class="l" name="1663" href="#1663">1663</a>  // Expect <a href="/googletest/s?path=foo.Bar&amp;project=googletest">foo.Bar</a>( ... ) twice with any arguments.
<a class="l" name="1664" href="#1664">1664</a>  EXPECT_CALL(foo, Bar).Times(2);
<a class="l" name="1665" href="#1665">1665</a>
<a class="l" name="1666" href="#1666">1666</a>  // Delegate to the given method whenever the factory is invoked.
<a class="l" name="1667" href="#1667">1667</a>  ON_CALL(foo_factory, MakeFoo)
<a class="l" name="1668" href="#1668">1668</a>      .WillByDefault(&amp;BuildFooForTest);
<a class="l" name="1669" href="#1669">1669</a>```
<a class="hl" name="1670" href="#1670">1670</a>
<a class="l" name="1671" href="#1671">1671</a>This functionality is only available when a method is not overloaded; to prevent
<a class="l" name="1672" href="#1672">1672</a>unexpected behavior it is a compilation error to try to set an expectation on a
<a class="l" name="1673" href="#1673">1673</a>method where the specific overload is ambiguous. You can work around this by
<a class="l" name="1674" href="#1674">1674</a>supplying a [simpler mock interface](#SimplerInterfaces) than the mocked class
<a class="l" name="1675" href="#1675">1675</a>provides.
<a class="l" name="1676" href="#1676">1676</a>
<a class="l" name="1677" href="#1677">1677</a>This pattern is also useful when the arguments are interesting, but match logic
<a class="l" name="1678" href="#1678">1678</a>is substantially complex. You can leave the argument list unspecified and use
<a class="l" name="1679" href="#1679">1679</a>SaveArg actions to [save the values for later verification](#SaveArgVerify). If
<a class="hl" name="1680" href="#1680">1680</a>you do that, you can easily differentiate calling the method the wrong number of
<a class="l" name="1681" href="#1681">1681</a>times from calling it with the wrong arguments.
<a class="l" name="1682" href="#1682">1682</a>
<a class="l" name="1683" href="#1683">1683</a>### Expecting Ordered Calls {#OrderedCalls}
<a class="l" name="1684" href="#1684">1684</a>
<a class="l" name="1685" href="#1685">1685</a>Although an `EXPECT_CALL()` statement defined later takes precedence when gMock
<a class="l" name="1686" href="#1686">1686</a>tries to match a function call with an expectation, by default calls don't have
<a class="l" name="1687" href="#1687">1687</a>to happen in the order `EXPECT_CALL()` statements are written. For example, if
<a class="l" name="1688" href="#1688">1688</a>the arguments match the matchers in the second `EXPECT_CALL()`, but not those in
<a class="l" name="1689" href="#1689">1689</a>the first and third, then the second expectation will be used.
<a class="hl" name="1690" href="#1690">1690</a>
<a class="l" name="1691" href="#1691">1691</a>If you would rather have all calls occur in the order of the expectations, put
<a class="l" name="1692" href="#1692">1692</a>the `EXPECT_CALL()` statements in a block where you define a variable of type
<a class="l" name="1693" href="#1693">1693</a>`InSequence`:
<a class="l" name="1694" href="#1694">1694</a>
<a class="l" name="1695" href="#1695">1695</a>```cpp
<a class="l" name="1696" href="#1696">1696</a>using ::testing::_;
<a class="l" name="1697" href="#1697">1697</a>using ::testing::InSequence;
<a class="l" name="1698" href="#1698">1698</a>
<a class="l" name="1699" href="#1699">1699</a>  {
<a class="hl" name="1700" href="#1700">1700</a>    InSequence s;
<a class="l" name="1701" href="#1701">1701</a>
<a class="l" name="1702" href="#1702">1702</a>    EXPECT_CALL(foo, DoThis(5));
<a class="l" name="1703" href="#1703">1703</a>    EXPECT_CALL(bar, DoThat(_))
<a class="l" name="1704" href="#1704">1704</a>        .Times(2);
<a class="l" name="1705" href="#1705">1705</a>    EXPECT_CALL(foo, DoThis(6));
<a class="l" name="1706" href="#1706">1706</a>  }
<a class="l" name="1707" href="#1707">1707</a>```
<a class="l" name="1708" href="#1708">1708</a>
<a class="l" name="1709" href="#1709">1709</a>In this example, we expect a call to `<a href="/googletest/s?path=foo.DoThis&amp;project=googletest">foo.DoThis</a>(5)`, followed by two calls to
<a class="hl" name="1710" href="#1710">1710</a>`<a href="/googletest/s?path=bar.DoThat&amp;project=googletest">bar.DoThat</a>()` where the argument can be anything, which are in turn followed by
<a class="l" name="1711" href="#1711">1711</a>a call to `<a href="/googletest/s?path=foo.DoThis&amp;project=googletest">foo.DoThis</a>(6)`. If a call occurred out-of-order, gMock will report an
<a class="l" name="1712" href="#1712">1712</a>error.
<a class="l" name="1713" href="#1713">1713</a>
<a class="l" name="1714" href="#1714">1714</a>### Expecting Partially Ordered Calls {#PartialOrder}
<a class="l" name="1715" href="#1715">1715</a>
<a class="l" name="1716" href="#1716">1716</a>Sometimes requiring everything to occur in a predetermined order can lead to
<a class="l" name="1717" href="#1717">1717</a>brittle tests. For example, we may care about `A` occurring before both `B` and
<a class="l" name="1718" href="#1718">1718</a>`C`, but aren't interested in the relative order of `B` and `C`. In this case,
<a class="l" name="1719" href="#1719">1719</a>the test should reflect our real intent, instead of being overly constraining.
<a class="hl" name="1720" href="#1720">1720</a>
<a class="l" name="1721" href="#1721">1721</a>gMock allows you to impose an arbitrary DAG (directed acyclic graph) on the
<a class="l" name="1722" href="#1722">1722</a>calls. One way to express the DAG is to use the
<a class="l" name="1723" href="#1723">1723</a>[After](<a href="/googletest/s?path=cheat_sheet.md&amp;project=googletest">cheat_sheet.md</a>#AfterClause) clause of `EXPECT_CALL`.
<a class="l" name="1724" href="#1724">1724</a>
<a class="l" name="1725" href="#1725">1725</a>Another way is via the `InSequence()` clause (not the same as the `InSequence`
<a class="l" name="1726" href="#1726">1726</a>class), which we borrowed from jMock 2. It's less flexible than `After()`, but
<a class="l" name="1727" href="#1727">1727</a>more convenient when you have long chains of sequential calls, as it doesn't
<a class="l" name="1728" href="#1728">1728</a>require you to come up with different names for the expectations in the chains.
<a class="l" name="1729" href="#1729">1729</a>Here's how it works:
<a class="hl" name="1730" href="#1730">1730</a>
<a class="l" name="1731" href="#1731">1731</a>If we view `EXPECT_CALL()` statements as nodes in a graph, and add an edge from
<a class="l" name="1732" href="#1732">1732</a>node A to node B wherever A must occur before B, we can get a DAG. We use the
<a class="l" name="1733" href="#1733">1733</a>term "sequence" to mean a directed path in this DAG. Now, if we decompose the
<a class="l" name="1734" href="#1734">1734</a>DAG into sequences, we just need to know which sequences each `EXPECT_CALL()`
<a class="l" name="1735" href="#1735">1735</a>belongs to in order to be able to reconstruct the original DAG.
<a class="l" name="1736" href="#1736">1736</a>
<a class="l" name="1737" href="#1737">1737</a>So, to specify the partial order on the expectations we need to do two things:
<a class="l" name="1738" href="#1738">1738</a>first to define some `Sequence` objects, and then for each `EXPECT_CALL()` say
<a class="l" name="1739" href="#1739">1739</a>which `Sequence` objects it is part of.
<a class="hl" name="1740" href="#1740">1740</a>
<a class="l" name="1741" href="#1741">1741</a>Expectations in the same sequence must occur in the order they are written. For
<a class="l" name="1742" href="#1742">1742</a>example,
<a class="l" name="1743" href="#1743">1743</a>
<a class="l" name="1744" href="#1744">1744</a>```cpp
<a class="l" name="1745" href="#1745">1745</a>using ::testing::Sequence;
<a class="l" name="1746" href="#1746">1746</a>...
<a class="l" name="1747" href="#1747">1747</a>  Sequence s1, s2;
<a class="l" name="1748" href="#1748">1748</a>
<a class="l" name="1749" href="#1749">1749</a>  EXPECT_CALL(foo, A())
<a class="hl" name="1750" href="#1750">1750</a>      .InSequence(s1, s2);
<a class="l" name="1751" href="#1751">1751</a>  EXPECT_CALL(bar, B())
<a class="l" name="1752" href="#1752">1752</a>      .InSequence(s1);
<a class="l" name="1753" href="#1753">1753</a>  EXPECT_CALL(bar, C())
<a class="l" name="1754" href="#1754">1754</a>      .InSequence(s2);
<a class="l" name="1755" href="#1755">1755</a>  EXPECT_CALL(foo, D())
<a class="l" name="1756" href="#1756">1756</a>      .InSequence(s2);
<a class="l" name="1757" href="#1757">1757</a>```
<a class="l" name="1758" href="#1758">1758</a>
<a class="l" name="1759" href="#1759">1759</a>specifies the following DAG (where `s1` is `A -&gt; B`, and `s2` is `A -&gt; C -&gt; D`):
<a class="hl" name="1760" href="#1760">1760</a>
<a class="l" name="1761" href="#1761">1761</a>```text
<a class="l" name="1762" href="#1762">1762</a>       +---&gt; B
<a class="l" name="1763" href="#1763">1763</a>       |
<a class="l" name="1764" href="#1764">1764</a>  A ---|
<a class="l" name="1765" href="#1765">1765</a>       |
<a class="l" name="1766" href="#1766">1766</a>        +---&gt; C ---&gt; D
<a class="l" name="1767" href="#1767">1767</a>```
<a class="l" name="1768" href="#1768">1768</a>
<a class="l" name="1769" href="#1769">1769</a>This means that A must occur before B and C, and C must occur before D. There's
<a class="hl" name="1770" href="#1770">1770</a>no restriction about the order other than these.
<a class="l" name="1771" href="#1771">1771</a>
<a class="l" name="1772" href="#1772">1772</a>### Controlling When an Expectation Retires
<a class="l" name="1773" href="#1773">1773</a>
<a class="l" name="1774" href="#1774">1774</a>When a mock method is called, gMock only considers expectations that are still
<a class="l" name="1775" href="#1775">1775</a>active. An expectation is active when created, and becomes inactive (aka
<a class="l" name="1776" href="#1776">1776</a>*retires*) when a call that has to occur later has occurred. For example, in
<a class="l" name="1777" href="#1777">1777</a>
<a class="l" name="1778" href="#1778">1778</a>```cpp
<a class="l" name="1779" href="#1779">1779</a>using ::testing::_;
<a class="hl" name="1780" href="#1780">1780</a>using ::testing::Sequence;
<a class="l" name="1781" href="#1781">1781</a>...
<a class="l" name="1782" href="#1782">1782</a>  Sequence s1, s2;
<a class="l" name="1783" href="#1783">1783</a>
<a class="l" name="1784" href="#1784">1784</a>  EXPECT_CALL(log, Log(WARNING, _, "File too large."))      // #1
<a class="l" name="1785" href="#1785">1785</a>      .Times(AnyNumber())
<a class="l" name="1786" href="#1786">1786</a>      .InSequence(s1, s2);
<a class="l" name="1787" href="#1787">1787</a>  EXPECT_CALL(log, Log(WARNING, _, "Data set is empty."))   // #2
<a class="l" name="1788" href="#1788">1788</a>      .InSequence(s1);
<a class="l" name="1789" href="#1789">1789</a>  EXPECT_CALL(log, Log(WARNING, _, "User not found."))      // #3
<a class="hl" name="1790" href="#1790">1790</a>      .InSequence(s2);
<a class="l" name="1791" href="#1791">1791</a>```
<a class="l" name="1792" href="#1792">1792</a>
<a class="l" name="1793" href="#1793">1793</a>as soon as either #2 or #3 is matched, #1 will retire. If a warning `"File too
<a class="l" name="1794" href="#1794">1794</a>large."` is logged after this, it will be an error.
<a class="l" name="1795" href="#1795">1795</a>
<a class="l" name="1796" href="#1796">1796</a>Note that an expectation doesn't retire automatically when it's saturated. For
<a class="l" name="1797" href="#1797">1797</a>example,
<a class="l" name="1798" href="#1798">1798</a>
<a class="l" name="1799" href="#1799">1799</a>```cpp
<a class="hl" name="1800" href="#1800">1800</a>using ::testing::_;
<a class="l" name="1801" href="#1801">1801</a>...
<a class="l" name="1802" href="#1802">1802</a>  EXPECT_CALL(log, Log(WARNING, _, _));                     // #1
<a class="l" name="1803" href="#1803">1803</a>  EXPECT_CALL(log, Log(WARNING, _, "File too large."));     // #2
<a class="l" name="1804" href="#1804">1804</a>```
<a class="l" name="1805" href="#1805">1805</a>
<a class="l" name="1806" href="#1806">1806</a>says that there will be exactly one warning with the message `"File too
<a class="l" name="1807" href="#1807">1807</a>large."`. If the second warning contains this message too, #2 will match again
<a class="l" name="1808" href="#1808">1808</a>and result in an upper-bound-violated error.
<a class="l" name="1809" href="#1809">1809</a>
<a class="hl" name="1810" href="#1810">1810</a>If this is not what you want, you can ask an expectation to retire as soon as it
<a class="l" name="1811" href="#1811">1811</a>becomes saturated:
<a class="l" name="1812" href="#1812">1812</a>
<a class="l" name="1813" href="#1813">1813</a>```cpp
<a class="l" name="1814" href="#1814">1814</a>using ::testing::_;
<a class="l" name="1815" href="#1815">1815</a>...
<a class="l" name="1816" href="#1816">1816</a>  EXPECT_CALL(log, Log(WARNING, _, _));                     // #1
<a class="l" name="1817" href="#1817">1817</a>  EXPECT_CALL(log, Log(WARNING, _, "File too large."))      // #2
<a class="l" name="1818" href="#1818">1818</a>      .RetiresOnSaturation();
<a class="l" name="1819" href="#1819">1819</a>```
<a class="hl" name="1820" href="#1820">1820</a>
<a class="l" name="1821" href="#1821">1821</a>Here #2 can be used only once, so if you have two warnings with the message
<a class="l" name="1822" href="#1822">1822</a>`"File too large."`, the first will match #2 and the second will match #1 -
<a class="l" name="1823" href="#1823">1823</a>there will be no error.
<a class="l" name="1824" href="#1824">1824</a>
<a class="l" name="1825" href="#1825">1825</a>## Using Actions
<a class="l" name="1826" href="#1826">1826</a>
<a class="l" name="1827" href="#1827">1827</a>### Returning References from Mock Methods
<a class="l" name="1828" href="#1828">1828</a>
<a class="l" name="1829" href="#1829">1829</a>If a mock function's return type is a reference, you need to use `ReturnRef()`
<a class="hl" name="1830" href="#1830">1830</a>instead of `Return()` to return a result:
<a class="l" name="1831" href="#1831">1831</a>
<a class="l" name="1832" href="#1832">1832</a>```cpp
<a class="l" name="1833" href="#1833">1833</a>using ::testing::ReturnRef;
<a class="l" name="1834" href="#1834">1834</a>
<a class="l" name="1835" href="#1835">1835</a>class MockFoo : public Foo {
<a class="l" name="1836" href="#1836">1836</a> public:
<a class="l" name="1837" href="#1837">1837</a>  MOCK_METHOD(Bar&amp;, GetBar, (), (override));
<a class="l" name="1838" href="#1838">1838</a>};
<a class="l" name="1839" href="#1839">1839</a>...
<a class="hl" name="1840" href="#1840">1840</a>  MockFoo foo;
<a class="l" name="1841" href="#1841">1841</a>  Bar bar;
<a class="l" name="1842" href="#1842">1842</a>  EXPECT_CALL(foo, GetBar())
<a class="l" name="1843" href="#1843">1843</a>      .WillOnce(ReturnRef(bar));
<a class="l" name="1844" href="#1844">1844</a>...
<a class="l" name="1845" href="#1845">1845</a>```
<a class="l" name="1846" href="#1846">1846</a>
<a class="l" name="1847" href="#1847">1847</a>### Returning Live Values from Mock Methods
<a class="l" name="1848" href="#1848">1848</a>
<a class="l" name="1849" href="#1849">1849</a>The `Return(x)` action saves a copy of `x` when the action is created, and
<a class="hl" name="1850" href="#1850">1850</a>always returns the same value whenever it's executed. Sometimes you may want to
<a class="l" name="1851" href="#1851">1851</a>instead return the *live* value of `x` (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> its value at the time when the
<a class="l" name="1852" href="#1852">1852</a>action is *executed*.). Use either `ReturnRef()` or `ReturnPointee()` for this
<a class="l" name="1853" href="#1853">1853</a>purpose.
<a class="l" name="1854" href="#1854">1854</a>
<a class="l" name="1855" href="#1855">1855</a>If the mock function's return type is a reference, you can do it using
<a class="l" name="1856" href="#1856">1856</a>`ReturnRef(x)`, as shown in the previous recipe ("Returning References from Mock
<a class="l" name="1857" href="#1857">1857</a>Methods"). However, gMock doesn't let you use `ReturnRef()` in a mock function
<a class="l" name="1858" href="#1858">1858</a>whose return type is not a reference, as doing that usually indicates a user
<a class="l" name="1859" href="#1859">1859</a>error. So, what shall you do?
<a class="hl" name="1860" href="#1860">1860</a>
<a class="l" name="1861" href="#1861">1861</a>Though you may be tempted, DO NOT use `std::ref()`:
<a class="l" name="1862" href="#1862">1862</a>
<a class="l" name="1863" href="#1863">1863</a>```cpp
<a class="l" name="1864" href="#1864">1864</a>using testing::Return;
<a class="l" name="1865" href="#1865">1865</a>
<a class="l" name="1866" href="#1866">1866</a>class MockFoo : public Foo {
<a class="l" name="1867" href="#1867">1867</a> public:
<a class="l" name="1868" href="#1868">1868</a>  MOCK_METHOD(int, GetValue, (), (override));
<a class="l" name="1869" href="#1869">1869</a>};
<a class="hl" name="1870" href="#1870">1870</a>...
<a class="l" name="1871" href="#1871">1871</a>  int x = 0;
<a class="l" name="1872" href="#1872">1872</a>  MockFoo foo;
<a class="l" name="1873" href="#1873">1873</a>  EXPECT_CALL(foo, GetValue())
<a class="l" name="1874" href="#1874">1874</a>      .WillRepeatedly(Return(std::ref(x)));  // Wrong!
<a class="l" name="1875" href="#1875">1875</a>  x = 42;
<a class="l" name="1876" href="#1876">1876</a>  EXPECT_EQ(42, <a href="/googletest/s?path=foo.GetValue&amp;project=googletest">foo.GetValue</a>());
<a class="l" name="1877" href="#1877">1877</a>```
<a class="l" name="1878" href="#1878">1878</a>
<a class="l" name="1879" href="#1879">1879</a>Unfortunately, it doesn't work here. The above code will fail with error:
<a class="hl" name="1880" href="#1880">1880</a>
<a class="l" name="1881" href="#1881">1881</a>```text
<a class="l" name="1882" href="#1882">1882</a>Value of: <a href="/googletest/s?path=foo.GetValue&amp;project=googletest">foo.GetValue</a>()
<a class="l" name="1883" href="#1883">1883</a>  Actual: 0
<a class="l" name="1884" href="#1884">1884</a>Expected: 42
<a class="l" name="1885" href="#1885">1885</a>```
<a class="l" name="1886" href="#1886">1886</a>
<a class="l" name="1887" href="#1887">1887</a>The reason is that `Return(*value*)` converts `value` to the actual return type
<a class="l" name="1888" href="#1888">1888</a>of the mock function at the time when the action is *created*, not when it is
<a class="l" name="1889" href="#1889">1889</a>*executed*. (This behavior was chosen for the action to be safe when `value` is
<a class="hl" name="1890" href="#1890">1890</a>a proxy object that references some temporary objects.) As a result,
<a class="l" name="1891" href="#1891">1891</a>`std::ref(x)` is converted to an `int` value (instead of a `const int&amp;`) when
<a class="l" name="1892" href="#1892">1892</a>the expectation is set, and `Return(std::ref(x))` will always return 0.
<a class="l" name="1893" href="#1893">1893</a>
<a class="l" name="1894" href="#1894">1894</a>`ReturnPointee(pointer)` was provided to solve this problem specifically. It
<a class="l" name="1895" href="#1895">1895</a>returns the value pointed to by `pointer` at the time the action is *executed*:
<a class="l" name="1896" href="#1896">1896</a>
<a class="l" name="1897" href="#1897">1897</a>```cpp
<a class="l" name="1898" href="#1898">1898</a>using testing::ReturnPointee;
<a class="l" name="1899" href="#1899">1899</a>...
<a class="hl" name="1900" href="#1900">1900</a>  int x = 0;
<a class="l" name="1901" href="#1901">1901</a>  MockFoo foo;
<a class="l" name="1902" href="#1902">1902</a>  EXPECT_CALL(foo, GetValue())
<a class="l" name="1903" href="#1903">1903</a>      .WillRepeatedly(ReturnPointee(&amp;x));  // Note the &amp; here.
<a class="l" name="1904" href="#1904">1904</a>  x = 42;
<a class="l" name="1905" href="#1905">1905</a>  EXPECT_EQ(42, <a href="/googletest/s?path=foo.GetValue&amp;project=googletest">foo.GetValue</a>());  // This will succeed now.
<a class="l" name="1906" href="#1906">1906</a>```
<a class="l" name="1907" href="#1907">1907</a>
<a class="l" name="1908" href="#1908">1908</a>### Combining Actions
<a class="l" name="1909" href="#1909">1909</a>
<a class="hl" name="1910" href="#1910">1910</a>Want to do more than one thing when a function is called? That's fine. `DoAll()`
<a class="l" name="1911" href="#1911">1911</a>allow you to do sequence of actions every time. Only the return value of the
<a class="l" name="1912" href="#1912">1912</a>last action in the sequence will be used.
<a class="l" name="1913" href="#1913">1913</a>
<a class="l" name="1914" href="#1914">1914</a>```cpp
<a class="l" name="1915" href="#1915">1915</a>using ::testing::_;
<a class="l" name="1916" href="#1916">1916</a>using ::testing::DoAll;
<a class="l" name="1917" href="#1917">1917</a>
<a class="l" name="1918" href="#1918">1918</a>class MockFoo : public Foo {
<a class="l" name="1919" href="#1919">1919</a> public:
<a class="hl" name="1920" href="#1920">1920</a>  MOCK_METHOD(bool, Bar, (int n), (override));
<a class="l" name="1921" href="#1921">1921</a>};
<a class="l" name="1922" href="#1922">1922</a>...
<a class="l" name="1923" href="#1923">1923</a>  EXPECT_CALL(foo, Bar(_))
<a class="l" name="1924" href="#1924">1924</a>      .WillOnce(DoAll(action_1,
<a class="l" name="1925" href="#1925">1925</a>                      action_2,
<a class="l" name="1926" href="#1926">1926</a>                      ...
<a class="l" name="1927" href="#1927">1927</a>                      action_n));
<a class="l" name="1928" href="#1928">1928</a>```
<a class="l" name="1929" href="#1929">1929</a>
<a class="hl" name="1930" href="#1930">1930</a>### Verifying Complex Arguments {#SaveArgVerify}
<a class="l" name="1931" href="#1931">1931</a>
<a class="l" name="1932" href="#1932">1932</a>If you want to verify that a method is called with a particular argument but the
<a class="l" name="1933" href="#1933">1933</a>match criteria is complex, it can be difficult to distinguish between
<a class="l" name="1934" href="#1934">1934</a>cardinality failures (calling the method the wrong number of times) and argument
<a class="l" name="1935" href="#1935">1935</a>match failures. Similarly, if you are matching multiple parameters, it may not
<a class="l" name="1936" href="#1936">1936</a>be easy to distinguishing which argument failed to match. For example:
<a class="l" name="1937" href="#1937">1937</a>
<a class="l" name="1938" href="#1938">1938</a>```cpp
<a class="l" name="1939" href="#1939">1939</a>  // Not ideal: this could fail because of a problem with arg1 or arg2, or maybe
<a class="hl" name="1940" href="#1940">1940</a>  // just the method wasn't called.
<a class="l" name="1941" href="#1941">1941</a>  EXPECT_CALL(foo, SendValues(_, ElementsAre(1, 4, 4, 7), EqualsProto( ... )));
<a class="l" name="1942" href="#1942">1942</a>```
<a class="l" name="1943" href="#1943">1943</a>
<a class="l" name="1944" href="#1944">1944</a>You can instead save the arguments and test them individually:
<a class="l" name="1945" href="#1945">1945</a>
<a class="l" name="1946" href="#1946">1946</a>```cpp
<a class="l" name="1947" href="#1947">1947</a>  EXPECT_CALL(foo, SendValues)
<a class="l" name="1948" href="#1948">1948</a>      .WillOnce(DoAll(SaveArg&lt;1&gt;(&amp;actual_array), SaveArg&lt;2&gt;(&amp;actual_proto)));
<a class="l" name="1949" href="#1949">1949</a>  ... run the test
<a class="hl" name="1950" href="#1950">1950</a>  EXPECT_THAT(actual_array, ElementsAre(1, 4, 4, 7));
<a class="l" name="1951" href="#1951">1951</a>  EXPECT_THAT(actual_proto, EqualsProto( ... ));
<a class="l" name="1952" href="#1952">1952</a>```
<a class="l" name="1953" href="#1953">1953</a>
<a class="l" name="1954" href="#1954">1954</a>### Mocking Side Effects {#MockingSideEffects}
<a class="l" name="1955" href="#1955">1955</a>
<a class="l" name="1956" href="#1956">1956</a>Sometimes a method exhibits its effect not via returning a value but via side
<a class="l" name="1957" href="#1957">1957</a>effects. For example, it may change some global state or modify an output
<a class="l" name="1958" href="#1958">1958</a>argument. To mock side effects, in general you can define your own action by
<a class="l" name="1959" href="#1959">1959</a>implementing `::testing::ActionInterface`.
<a class="hl" name="1960" href="#1960">1960</a>
<a class="l" name="1961" href="#1961">1961</a>If all you need to do is to change an output argument, the built-in
<a class="l" name="1962" href="#1962">1962</a>`SetArgPointee()` action is convenient:
<a class="l" name="1963" href="#1963">1963</a>
<a class="l" name="1964" href="#1964">1964</a>```cpp
<a class="l" name="1965" href="#1965">1965</a>using ::testing::_;
<a class="l" name="1966" href="#1966">1966</a>using ::testing::SetArgPointee;
<a class="l" name="1967" href="#1967">1967</a>
<a class="l" name="1968" href="#1968">1968</a>class MockMutator : public Mutator {
<a class="l" name="1969" href="#1969">1969</a> public:
<a class="hl" name="1970" href="#1970">1970</a>  MOCK_METHOD(void, Mutate, (bool mutate, int* value), (override));
<a class="l" name="1971" href="#1971">1971</a>  ...
<a class="l" name="1972" href="#1972">1972</a>}
<a class="l" name="1973" href="#1973">1973</a>...
<a class="l" name="1974" href="#1974">1974</a>  MockMutator mutator;
<a class="l" name="1975" href="#1975">1975</a>  EXPECT_CALL(mutator, Mutate(true, _))
<a class="l" name="1976" href="#1976">1976</a>      .WillOnce(SetArgPointee&lt;1&gt;(5));
<a class="l" name="1977" href="#1977">1977</a>```
<a class="l" name="1978" href="#1978">1978</a>
<a class="l" name="1979" href="#1979">1979</a>In this example, when `<a href="/googletest/s?path=mutator.Mutate&amp;project=googletest">mutator.Mutate</a>()` is called, we will assign 5 to the
<a class="hl" name="1980" href="#1980">1980</a>`int` variable pointed to by argument #1 (0-based).
<a class="l" name="1981" href="#1981">1981</a>
<a class="l" name="1982" href="#1982">1982</a>`SetArgPointee()` conveniently makes an internal copy of the value you pass to
<a class="l" name="1983" href="#1983">1983</a>it, removing the need to keep the value in scope and alive. The implication
<a class="l" name="1984" href="#1984">1984</a>however is that the value must have a copy constructor and assignment operator.
<a class="l" name="1985" href="#1985">1985</a>
<a class="l" name="1986" href="#1986">1986</a>If the mock method also needs to return a value as well, you can chain
<a class="l" name="1987" href="#1987">1987</a>`SetArgPointee()` with `Return()` using `DoAll()`, remembering to put the
<a class="l" name="1988" href="#1988">1988</a>`Return()` statement last:
<a class="l" name="1989" href="#1989">1989</a>
<a class="hl" name="1990" href="#1990">1990</a>```cpp
<a class="l" name="1991" href="#1991">1991</a>using ::testing::_;
<a class="l" name="1992" href="#1992">1992</a>using ::testing::Return;
<a class="l" name="1993" href="#1993">1993</a>using ::testing::SetArgPointee;
<a class="l" name="1994" href="#1994">1994</a>
<a class="l" name="1995" href="#1995">1995</a>class MockMutator : public Mutator {
<a class="l" name="1996" href="#1996">1996</a> public:
<a class="l" name="1997" href="#1997">1997</a>  ...
<a class="l" name="1998" href="#1998">1998</a>  MOCK_METHOD(bool, MutateInt, (int* value), (override));
<a class="l" name="1999" href="#1999">1999</a>}
<a class="hl" name="2000" href="#2000">2000</a>...
<a class="l" name="2001" href="#2001">2001</a>  MockMutator mutator;
<a class="l" name="2002" href="#2002">2002</a>  EXPECT_CALL(mutator, MutateInt(_))
<a class="l" name="2003" href="#2003">2003</a>      .WillOnce(DoAll(SetArgPointee&lt;0&gt;(5),
<a class="l" name="2004" href="#2004">2004</a>                      Return(true)));
<a class="l" name="2005" href="#2005">2005</a>```
<a class="l" name="2006" href="#2006">2006</a>
<a class="l" name="2007" href="#2007">2007</a>Note, however, that if you use the `ReturnOKWith()` method, it will override the
<a class="l" name="2008" href="#2008">2008</a>values provided by `SetArgPointee()` in the response parameters of your function
<a class="l" name="2009" href="#2009">2009</a>call.
<a class="hl" name="2010" href="#2010">2010</a>
<a class="l" name="2011" href="#2011">2011</a>If the output argument is an array, use the `SetArrayArgument&lt;N&gt;(first, last)`
<a class="l" name="2012" href="#2012">2012</a>action instead. It copies the elements in source range `[first, last)` to the
<a class="l" name="2013" href="#2013">2013</a>array pointed to by the `N`-th (0-based) argument:
<a class="l" name="2014" href="#2014">2014</a>
<a class="l" name="2015" href="#2015">2015</a>```cpp
<a class="l" name="2016" href="#2016">2016</a>using ::testing::NotNull;
<a class="l" name="2017" href="#2017">2017</a>using ::testing::SetArrayArgument;
<a class="l" name="2018" href="#2018">2018</a>
<a class="l" name="2019" href="#2019">2019</a>class MockArrayMutator : public ArrayMutator {
<a class="hl" name="2020" href="#2020">2020</a> public:
<a class="l" name="2021" href="#2021">2021</a>  MOCK_METHOD(void, Mutate, (int* values, int num_values), (override));
<a class="l" name="2022" href="#2022">2022</a>  ...
<a class="l" name="2023" href="#2023">2023</a>}
<a class="l" name="2024" href="#2024">2024</a>...
<a class="l" name="2025" href="#2025">2025</a>  MockArrayMutator mutator;
<a class="l" name="2026" href="#2026">2026</a>  int values[5] = {1, 2, 3, 4, 5};
<a class="l" name="2027" href="#2027">2027</a>  EXPECT_CALL(mutator, Mutate(NotNull(), 5))
<a class="l" name="2028" href="#2028">2028</a>      .WillOnce(SetArrayArgument&lt;0&gt;(values, values + 5));
<a class="l" name="2029" href="#2029">2029</a>```
<a class="hl" name="2030" href="#2030">2030</a>
<a class="l" name="2031" href="#2031">2031</a>This also works when the argument is an output iterator:
<a class="l" name="2032" href="#2032">2032</a>
<a class="l" name="2033" href="#2033">2033</a>```cpp
<a class="l" name="2034" href="#2034">2034</a>using ::testing::_;
<a class="l" name="2035" href="#2035">2035</a>using ::testing::SetArrayArgument;
<a class="l" name="2036" href="#2036">2036</a>
<a class="l" name="2037" href="#2037">2037</a>class MockRolodex : public Rolodex {
<a class="l" name="2038" href="#2038">2038</a> public:
<a class="l" name="2039" href="#2039">2039</a>  MOCK_METHOD(void, GetNames, (std::back_insert_iterator&lt;vector&lt;string&gt;&gt;),
<a class="hl" name="2040" href="#2040">2040</a>              (override));
<a class="l" name="2041" href="#2041">2041</a>  ...
<a class="l" name="2042" href="#2042">2042</a>}
<a class="l" name="2043" href="#2043">2043</a>...
<a class="l" name="2044" href="#2044">2044</a>  MockRolodex rolodex;
<a class="l" name="2045" href="#2045">2045</a>  vector&lt;string&gt; names;
<a class="l" name="2046" href="#2046">2046</a>  <a href="/googletest/s?path=names.push_back&amp;project=googletest">names.push_back</a>("George");
<a class="l" name="2047" href="#2047">2047</a>  <a href="/googletest/s?path=names.push_back&amp;project=googletest">names.push_back</a>("John");
<a class="l" name="2048" href="#2048">2048</a>  <a href="/googletest/s?path=names.push_back&amp;project=googletest">names.push_back</a>("Thomas");
<a class="l" name="2049" href="#2049">2049</a>  EXPECT_CALL(rolodex, GetNames(_))
<a class="hl" name="2050" href="#2050">2050</a>      .WillOnce(SetArrayArgument&lt;0&gt;(<a href="/googletest/s?path=names.begin&amp;project=googletest">names.begin</a>(), <a href="/googletest/s?path=names.end&amp;project=googletest">names.end</a>()));
<a class="l" name="2051" href="#2051">2051</a>```
<a class="l" name="2052" href="#2052">2052</a>
<a class="l" name="2053" href="#2053">2053</a>### Changing a Mock Object's Behavior Based on the State
<a class="l" name="2054" href="#2054">2054</a>
<a class="l" name="2055" href="#2055">2055</a>If you expect a call to change the behavior of a mock object, you can use
<a class="l" name="2056" href="#2056">2056</a>`::testing::InSequence` to specify different behaviors before and after the
<a class="l" name="2057" href="#2057">2057</a>call:
<a class="l" name="2058" href="#2058">2058</a>
<a class="l" name="2059" href="#2059">2059</a>```cpp
<a class="hl" name="2060" href="#2060">2060</a>using ::testing::InSequence;
<a class="l" name="2061" href="#2061">2061</a>using ::testing::Return;
<a class="l" name="2062" href="#2062">2062</a>
<a class="l" name="2063" href="#2063">2063</a>...
<a class="l" name="2064" href="#2064">2064</a>  {
<a class="l" name="2065" href="#2065">2065</a>     InSequence seq;
<a class="l" name="2066" href="#2066">2066</a>     EXPECT_CALL(my_mock, IsDirty())
<a class="l" name="2067" href="#2067">2067</a>         .WillRepeatedly(Return(true));
<a class="l" name="2068" href="#2068">2068</a>     EXPECT_CALL(my_mock, Flush());
<a class="l" name="2069" href="#2069">2069</a>     EXPECT_CALL(my_mock, IsDirty())
<a class="hl" name="2070" href="#2070">2070</a>         .WillRepeatedly(Return(false));
<a class="l" name="2071" href="#2071">2071</a>  }
<a class="l" name="2072" href="#2072">2072</a>  <a href="/googletest/s?path=my_mock.FlushIfDirty&amp;project=googletest">my_mock.FlushIfDirty</a>();
<a class="l" name="2073" href="#2073">2073</a>```
<a class="l" name="2074" href="#2074">2074</a>
<a class="l" name="2075" href="#2075">2075</a>This makes `<a href="/googletest/s?path=my_mock.IsDirty&amp;project=googletest">my_mock.IsDirty</a>()` return `true` before `<a href="/googletest/s?path=my_mock.Flush&amp;project=googletest">my_mock.Flush</a>()` is called
<a class="l" name="2076" href="#2076">2076</a>and return `false` afterwards.
<a class="l" name="2077" href="#2077">2077</a>
<a class="l" name="2078" href="#2078">2078</a>If the behavior change is more complex, you can store the effects in a variable
<a class="l" name="2079" href="#2079">2079</a>and make a mock method get its return value from that variable:
<a class="hl" name="2080" href="#2080">2080</a>
<a class="l" name="2081" href="#2081">2081</a>```cpp
<a class="l" name="2082" href="#2082">2082</a>using ::testing::_;
<a class="l" name="2083" href="#2083">2083</a>using ::testing::SaveArg;
<a class="l" name="2084" href="#2084">2084</a>using ::testing::Return;
<a class="l" name="2085" href="#2085">2085</a>
<a class="l" name="2086" href="#2086">2086</a>ACTION_P(ReturnPointee, p) { return *p; }
<a class="l" name="2087" href="#2087">2087</a>...
<a class="l" name="2088" href="#2088">2088</a>  int previous_value = 0;
<a class="l" name="2089" href="#2089">2089</a>  EXPECT_CALL(my_mock, GetPrevValue)
<a class="hl" name="2090" href="#2090">2090</a>      .WillRepeatedly(ReturnPointee(&amp;previous_value));
<a class="l" name="2091" href="#2091">2091</a>  EXPECT_CALL(my_mock, UpdateValue)
<a class="l" name="2092" href="#2092">2092</a>      .WillRepeatedly(SaveArg&lt;0&gt;(&amp;previous_value));
<a class="l" name="2093" href="#2093">2093</a>  <a href="/googletest/s?path=my_mock.DoSomethingToUpdateValue&amp;project=googletest">my_mock.DoSomethingToUpdateValue</a>();
<a class="l" name="2094" href="#2094">2094</a>```
<a class="l" name="2095" href="#2095">2095</a>
<a class="l" name="2096" href="#2096">2096</a>Here `<a href="/googletest/s?path=my_mock.GetPrevValue&amp;project=googletest">my_mock.GetPrevValue</a>()` will always return the argument of the last
<a class="l" name="2097" href="#2097">2097</a>`UpdateValue()` call.
<a class="l" name="2098" href="#2098">2098</a>
<a class="l" name="2099" href="#2099">2099</a>### Setting the Default Value for a Return Type {#DefaultValue}
<a class="hl" name="2100" href="#2100">2100</a>
<a class="l" name="2101" href="#2101">2101</a>If a mock method's return type is a built-in C++ type or pointer, by default it
<a class="l" name="2102" href="#2102">2102</a>will return 0 when invoked. Also, in C++ 11 and above, a mock method whose
<a class="l" name="2103" href="#2103">2103</a>return type has a default constructor will return a default-constructed value by
<a class="l" name="2104" href="#2104">2104</a>default. You only need to specify an action if this default value doesn't work
<a class="l" name="2105" href="#2105">2105</a>for you.
<a class="l" name="2106" href="#2106">2106</a>
<a class="l" name="2107" href="#2107">2107</a>Sometimes, you may want to change this default value, or you may want to specify
<a class="l" name="2108" href="#2108">2108</a>a default value for types gMock doesn't know about. You can do this using the
<a class="l" name="2109" href="#2109">2109</a>`::testing::DefaultValue` class template:
<a class="hl" name="2110" href="#2110">2110</a>
<a class="l" name="2111" href="#2111">2111</a>```cpp
<a class="l" name="2112" href="#2112">2112</a>using ::testing::DefaultValue;
<a class="l" name="2113" href="#2113">2113</a>
<a class="l" name="2114" href="#2114">2114</a>class MockFoo : public Foo {
<a class="l" name="2115" href="#2115">2115</a> public:
<a class="l" name="2116" href="#2116">2116</a>  MOCK_METHOD(Bar, CalculateBar, (), (override));
<a class="l" name="2117" href="#2117">2117</a>};
<a class="l" name="2118" href="#2118">2118</a>
<a class="l" name="2119" href="#2119">2119</a>
<a class="hl" name="2120" href="#2120">2120</a>...
<a class="l" name="2121" href="#2121">2121</a>  Bar default_bar;
<a class="l" name="2122" href="#2122">2122</a>  // Sets the default return value for type Bar.
<a class="l" name="2123" href="#2123">2123</a>  DefaultValue&lt;Bar&gt;::Set(default_bar);
<a class="l" name="2124" href="#2124">2124</a>
<a class="l" name="2125" href="#2125">2125</a>  MockFoo foo;
<a class="l" name="2126" href="#2126">2126</a>
<a class="l" name="2127" href="#2127">2127</a>  // We don't need to specify an action here, as the default
<a class="l" name="2128" href="#2128">2128</a>  // return value works for us.
<a class="l" name="2129" href="#2129">2129</a>  EXPECT_CALL(foo, CalculateBar());
<a class="hl" name="2130" href="#2130">2130</a>
<a class="l" name="2131" href="#2131">2131</a>  <a href="/googletest/s?path=foo.CalculateBar&amp;project=googletest">foo.CalculateBar</a>();  // This should return default_bar.
<a class="l" name="2132" href="#2132">2132</a>
<a class="l" name="2133" href="#2133">2133</a>  // Unsets the default return value.
<a class="l" name="2134" href="#2134">2134</a>  DefaultValue&lt;Bar&gt;::Clear();
<a class="l" name="2135" href="#2135">2135</a>```
<a class="l" name="2136" href="#2136">2136</a>
<a class="l" name="2137" href="#2137">2137</a>Please note that changing the default value for a type can make your tests hard
<a class="l" name="2138" href="#2138">2138</a>to understand. We recommend you to use this feature judiciously. For example,
<a class="l" name="2139" href="#2139">2139</a>you may want to make sure the `Set()` and `Clear()` calls are right next to the
<a class="hl" name="2140" href="#2140">2140</a>code that uses your mock.
<a class="l" name="2141" href="#2141">2141</a>
<a class="l" name="2142" href="#2142">2142</a>### Setting the Default Actions for a Mock Method
<a class="l" name="2143" href="#2143">2143</a>
<a class="l" name="2144" href="#2144">2144</a>You've learned how to change the default value of a given type. However, this
<a class="l" name="2145" href="#2145">2145</a>may be too coarse for your purpose: perhaps you have two mock methods with the
<a class="l" name="2146" href="#2146">2146</a>same return type and you want them to have different behaviors. The `ON_CALL()`
<a class="l" name="2147" href="#2147">2147</a>macro allows you to customize your mock's behavior at the method level:
<a class="l" name="2148" href="#2148">2148</a>
<a class="l" name="2149" href="#2149">2149</a>```cpp
<a class="hl" name="2150" href="#2150">2150</a>using ::testing::_;
<a class="l" name="2151" href="#2151">2151</a>using ::testing::AnyNumber;
<a class="l" name="2152" href="#2152">2152</a>using ::testing::Gt;
<a class="l" name="2153" href="#2153">2153</a>using ::testing::Return;
<a class="l" name="2154" href="#2154">2154</a>...
<a class="l" name="2155" href="#2155">2155</a>  ON_CALL(foo, Sign(_))
<a class="l" name="2156" href="#2156">2156</a>      .WillByDefault(Return(-1));
<a class="l" name="2157" href="#2157">2157</a>  ON_CALL(foo, Sign(0))
<a class="l" name="2158" href="#2158">2158</a>      .WillByDefault(Return(0));
<a class="l" name="2159" href="#2159">2159</a>  ON_CALL(foo, Sign(Gt(0)))
<a class="hl" name="2160" href="#2160">2160</a>      .WillByDefault(Return(1));
<a class="l" name="2161" href="#2161">2161</a>
<a class="l" name="2162" href="#2162">2162</a>  EXPECT_CALL(foo, Sign(_))
<a class="l" name="2163" href="#2163">2163</a>      .Times(AnyNumber());
<a class="l" name="2164" href="#2164">2164</a>
<a class="l" name="2165" href="#2165">2165</a>  <a href="/googletest/s?path=foo.Sign&amp;project=googletest">foo.Sign</a>(5);   // This should return 1.
<a class="l" name="2166" href="#2166">2166</a>  <a href="/googletest/s?path=foo.Sign&amp;project=googletest">foo.Sign</a>(-9);  // This should return -1.
<a class="l" name="2167" href="#2167">2167</a>  <a href="/googletest/s?path=foo.Sign&amp;project=googletest">foo.Sign</a>(0);   // This should return 0.
<a class="l" name="2168" href="#2168">2168</a>```
<a class="l" name="2169" href="#2169">2169</a>
<a class="hl" name="2170" href="#2170">2170</a>As you may have guessed, when there are more than one `ON_CALL()` statements,
<a class="l" name="2171" href="#2171">2171</a>the newer ones in the order take precedence over the older ones. In other words,
<a class="l" name="2172" href="#2172">2172</a>the **last** one that matches the function arguments will be used. This matching
<a class="l" name="2173" href="#2173">2173</a>order allows you to set up the common behavior in a mock object's constructor or
<a class="l" name="2174" href="#2174">2174</a>the test fixture's set-up phase and specialize the mock's behavior later.
<a class="l" name="2175" href="#2175">2175</a>
<a class="l" name="2176" href="#2176">2176</a>Note that both `ON_CALL` and `EXPECT_CALL` have the same "later statements take
<a class="l" name="2177" href="#2177">2177</a>precedence" rule, but they don't interact. That is, `EXPECT_CALL`s have their
<a class="l" name="2178" href="#2178">2178</a>own precedence order distinct from the `ON_CALL` precedence order.
<a class="l" name="2179" href="#2179">2179</a>
<a class="hl" name="2180" href="#2180">2180</a>### Using <a href="/googletest/s?path=Functions/Methods/Functors/Lambdas&amp;project=googletest">Functions/Methods/Functors/Lambdas</a> as Actions {#FunctionsAsActions}
<a class="l" name="2181" href="#2181">2181</a>
<a class="l" name="2182" href="#2182">2182</a>If the built-in actions don't suit you, you can use an existing callable
<a class="l" name="2183" href="#2183">2183</a>(function, `std::function`, method, functor, lambda) as an action.
<a class="l" name="2184" href="#2184">2184</a>
<a class="l" name="2185" href="#2185">2185</a>&lt;!-- GOOGLETEST_CM0024 DO NOT DELETE --&gt;
<a class="l" name="2186" href="#2186">2186</a>
<a class="l" name="2187" href="#2187">2187</a>```cpp
<a class="l" name="2188" href="#2188">2188</a>using ::testing::_; using ::testing::Invoke;
<a class="l" name="2189" href="#2189">2189</a>
<a class="hl" name="2190" href="#2190">2190</a>class MockFoo : public Foo {
<a class="l" name="2191" href="#2191">2191</a> public:
<a class="l" name="2192" href="#2192">2192</a>  MOCK_METHOD(int, Sum, (int x, int y), (override));
<a class="l" name="2193" href="#2193">2193</a>  MOCK_METHOD(bool, ComplexJob, (int x), (override));
<a class="l" name="2194" href="#2194">2194</a>};
<a class="l" name="2195" href="#2195">2195</a>
<a class="l" name="2196" href="#2196">2196</a>int CalculateSum(int x, int y) { return x + y; }
<a class="l" name="2197" href="#2197">2197</a>int Sum3(int x, int y, int z) { return x + y + z; }
<a class="l" name="2198" href="#2198">2198</a>
<a class="l" name="2199" href="#2199">2199</a>class Helper {
<a class="hl" name="2200" href="#2200">2200</a> public:
<a class="l" name="2201" href="#2201">2201</a>  bool ComplexJob(int x);
<a class="l" name="2202" href="#2202">2202</a>};
<a class="l" name="2203" href="#2203">2203</a>
<a class="l" name="2204" href="#2204">2204</a>...
<a class="l" name="2205" href="#2205">2205</a>  MockFoo foo;
<a class="l" name="2206" href="#2206">2206</a>  Helper helper;
<a class="l" name="2207" href="#2207">2207</a>  EXPECT_CALL(foo, Sum(_, _))
<a class="l" name="2208" href="#2208">2208</a>      .WillOnce(&amp;CalculateSum)
<a class="l" name="2209" href="#2209">2209</a>      .WillRepeatedly(Invoke(NewPermanentCallback(Sum3, 1)));
<a class="hl" name="2210" href="#2210">2210</a>  EXPECT_CALL(foo, ComplexJob(_))
<a class="l" name="2211" href="#2211">2211</a>      .WillOnce(Invoke(&amp;helper, &amp;Helper::ComplexJob))
<a class="l" name="2212" href="#2212">2212</a>      .WillOnce([] { return true; })
<a class="l" name="2213" href="#2213">2213</a>      .WillRepeatedly([](int x) { return x &gt; 0; });
<a class="l" name="2214" href="#2214">2214</a>
<a class="l" name="2215" href="#2215">2215</a>  <a href="/googletest/s?path=foo.Sum&amp;project=googletest">foo.Sum</a>(5, 6);         // Invokes CalculateSum(5, 6).
<a class="l" name="2216" href="#2216">2216</a>  <a href="/googletest/s?path=foo.Sum&amp;project=googletest">foo.Sum</a>(2, 3);         // Invokes Sum3(1, 2, 3).
<a class="l" name="2217" href="#2217">2217</a>  <a href="/googletest/s?path=foo.ComplexJob&amp;project=googletest">foo.ComplexJob</a>(10);    // Invokes <a href="/googletest/s?path=helper.ComplexJob&amp;project=googletest">helper.ComplexJob</a>(10).
<a class="l" name="2218" href="#2218">2218</a>  <a href="/googletest/s?path=foo.ComplexJob&amp;project=googletest">foo.ComplexJob</a>(-1);    // Invokes the inline lambda.
<a class="l" name="2219" href="#2219">2219</a>```
<a class="hl" name="2220" href="#2220">2220</a>
<a class="l" name="2221" href="#2221">2221</a>The only requirement is that the type of the function, etc must be *compatible*
<a class="l" name="2222" href="#2222">2222</a>with the signature of the mock function, meaning that the latter's arguments (if
<a class="l" name="2223" href="#2223">2223</a>it takes any) can be implicitly converted to the corresponding arguments of the
<a class="l" name="2224" href="#2224">2224</a>former, and the former's return type can be implicitly converted to that of the
<a class="l" name="2225" href="#2225">2225</a>latter. So, you can invoke something whose type is *not* exactly the same as the
<a class="l" name="2226" href="#2226">2226</a>mock function, as long as it's safe to do so - nice, huh?
<a class="l" name="2227" href="#2227">2227</a>
<a class="l" name="2228" href="#2228">2228</a>**`Note:`{.escaped}**
<a class="l" name="2229" href="#2229">2229</a>
<a class="hl" name="2230" href="#2230">2230</a>*   The action takes ownership of the callback and will delete it when the
<a class="l" name="2231" href="#2231">2231</a>    action itself is destructed.
<a class="l" name="2232" href="#2232">2232</a>*   If the type of a callback is derived from a base callback type `C`, you need
<a class="l" name="2233" href="#2233">2233</a>    to implicitly cast it to `C` to resolve the overloading, <a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="l" name="2234" href="#2234">2234</a>
<a class="l" name="2235" href="#2235">2235</a>    ```cpp
<a class="l" name="2236" href="#2236">2236</a>    using ::testing::Invoke;
<a class="l" name="2237" href="#2237">2237</a>    ...
<a class="l" name="2238" href="#2238">2238</a>      ResultCallback&lt;bool&gt;* is_ok = ...;
<a class="l" name="2239" href="#2239">2239</a>      ... Invoke(is_ok) ...;  // This works.
<a class="hl" name="2240" href="#2240">2240</a>
<a class="l" name="2241" href="#2241">2241</a>      BlockingClosure* done = new BlockingClosure;
<a class="l" name="2242" href="#2242">2242</a>      ... Invoke(implicit_cast&lt;Closure*&gt;(done)) ...;  // The cast is necessary.
<a class="l" name="2243" href="#2243">2243</a>    ```
<a class="l" name="2244" href="#2244">2244</a>
<a class="l" name="2245" href="#2245">2245</a>### Using Functions with Extra Info as Actions
<a class="l" name="2246" href="#2246">2246</a>
<a class="l" name="2247" href="#2247">2247</a>The function or functor you call using `Invoke()` must have the same number of
<a class="l" name="2248" href="#2248">2248</a>arguments as the mock function you use it for. Sometimes you may have a function
<a class="l" name="2249" href="#2249">2249</a>that takes more arguments, and you are willing to pass in the extra arguments
<a class="hl" name="2250" href="#2250">2250</a>yourself to fill the gap. You can do this in gMock using callbacks with
<a class="l" name="2251" href="#2251">2251</a>pre-bound arguments. Here's an example:
<a class="l" name="2252" href="#2252">2252</a>
<a class="l" name="2253" href="#2253">2253</a>```cpp
<a class="l" name="2254" href="#2254">2254</a>using ::testing::Invoke;
<a class="l" name="2255" href="#2255">2255</a>
<a class="l" name="2256" href="#2256">2256</a>class MockFoo : public Foo {
<a class="l" name="2257" href="#2257">2257</a> public:
<a class="l" name="2258" href="#2258">2258</a>  MOCK_METHOD(char, DoThis, (int n), (override));
<a class="l" name="2259" href="#2259">2259</a>};
<a class="hl" name="2260" href="#2260">2260</a>
<a class="l" name="2261" href="#2261">2261</a>char SignOfSum(int x, int y) {
<a class="l" name="2262" href="#2262">2262</a>  const int sum = x + y;
<a class="l" name="2263" href="#2263">2263</a>  return (sum &gt; 0) ? '+' : (sum &lt; 0) ? '-' : '0';
<a class="l" name="2264" href="#2264">2264</a>}
<a class="l" name="2265" href="#2265">2265</a>
<a class="l" name="2266" href="#2266">2266</a>TEST_F(FooTest, Test) {
<a class="l" name="2267" href="#2267">2267</a>  MockFoo foo;
<a class="l" name="2268" href="#2268">2268</a>
<a class="l" name="2269" href="#2269">2269</a>  EXPECT_CALL(foo, DoThis(2))
<a class="hl" name="2270" href="#2270">2270</a>      .WillOnce(Invoke(NewPermanentCallback(SignOfSum, 5)));
<a class="l" name="2271" href="#2271">2271</a>  EXPECT_EQ('+', <a href="/googletest/s?path=foo.DoThis&amp;project=googletest">foo.DoThis</a>(2));  // Invokes SignOfSum(5, 2).
<a class="l" name="2272" href="#2272">2272</a>}
<a class="l" name="2273" href="#2273">2273</a>```
<a class="l" name="2274" href="#2274">2274</a>
<a class="l" name="2275" href="#2275">2275</a>### Invoking a <a href="/googletest/s?path=Function/Method/Functor/Lambda/Callback&amp;project=googletest">Function/Method/Functor/Lambda/Callback</a> Without Arguments
<a class="l" name="2276" href="#2276">2276</a>
<a class="l" name="2277" href="#2277">2277</a>`Invoke()` passes the mock function's arguments to the function, etc being
<a class="l" name="2278" href="#2278">2278</a>invoked such that the callee has the full context of the call to work with. If
<a class="l" name="2279" href="#2279">2279</a>the invoked function is not interested in some or all of the arguments, it can
<a class="hl" name="2280" href="#2280">2280</a>simply ignore them.
<a class="l" name="2281" href="#2281">2281</a>
<a class="l" name="2282" href="#2282">2282</a>Yet, a common pattern is that a test author wants to invoke a function without
<a class="l" name="2283" href="#2283">2283</a>the arguments of the mock function. She could do that using a wrapper function
<a class="l" name="2284" href="#2284">2284</a>that throws away the arguments before invoking an underlining nullary function.
<a class="l" name="2285" href="#2285">2285</a>Needless to say, this can be tedious and obscures the intent of the test.
<a class="l" name="2286" href="#2286">2286</a>
<a class="l" name="2287" href="#2287">2287</a>There are two solutions to this problem. First, you can pass any callable of
<a class="l" name="2288" href="#2288">2288</a>zero args as an action. Alternatively, use `InvokeWithoutArgs()`, which is like
<a class="l" name="2289" href="#2289">2289</a>`Invoke()` except that it doesn't pass the mock function's arguments to the
<a class="hl" name="2290" href="#2290">2290</a>callee. Here's an example of each:
<a class="l" name="2291" href="#2291">2291</a>
<a class="l" name="2292" href="#2292">2292</a>```cpp
<a class="l" name="2293" href="#2293">2293</a>using ::testing::_;
<a class="l" name="2294" href="#2294">2294</a>using ::testing::InvokeWithoutArgs;
<a class="l" name="2295" href="#2295">2295</a>
<a class="l" name="2296" href="#2296">2296</a>class MockFoo : public Foo {
<a class="l" name="2297" href="#2297">2297</a> public:
<a class="l" name="2298" href="#2298">2298</a>  MOCK_METHOD(bool, ComplexJob, (int n), (override));
<a class="l" name="2299" href="#2299">2299</a>};
<a class="hl" name="2300" href="#2300">2300</a>
<a class="l" name="2301" href="#2301">2301</a>bool Job1() { ... }
<a class="l" name="2302" href="#2302">2302</a>bool Job2(int n, char c) { ... }
<a class="l" name="2303" href="#2303">2303</a>
<a class="l" name="2304" href="#2304">2304</a>...
<a class="l" name="2305" href="#2305">2305</a>  MockFoo foo;
<a class="l" name="2306" href="#2306">2306</a>  EXPECT_CALL(foo, ComplexJob(_))
<a class="l" name="2307" href="#2307">2307</a>      .WillOnce([] { Job1(); });
<a class="l" name="2308" href="#2308">2308</a>      .WillOnce(InvokeWithoutArgs(NewPermanentCallback(Job2, 5, 'a')));
<a class="l" name="2309" href="#2309">2309</a>
<a class="hl" name="2310" href="#2310">2310</a>  <a href="/googletest/s?path=foo.ComplexJob&amp;project=googletest">foo.ComplexJob</a>(10);  // Invokes Job1().
<a class="l" name="2311" href="#2311">2311</a>  <a href="/googletest/s?path=foo.ComplexJob&amp;project=googletest">foo.ComplexJob</a>(20);  // Invokes Job2(5, 'a').
<a class="l" name="2312" href="#2312">2312</a>```
<a class="l" name="2313" href="#2313">2313</a>
<a class="l" name="2314" href="#2314">2314</a>**`Note:`{.escaped}**
<a class="l" name="2315" href="#2315">2315</a>
<a class="l" name="2316" href="#2316">2316</a>*   The action takes ownership of the callback and will delete it when the
<a class="l" name="2317" href="#2317">2317</a>    action itself is destructed.
<a class="l" name="2318" href="#2318">2318</a>*   If the type of a callback is derived from a base callback type `C`, you need
<a class="l" name="2319" href="#2319">2319</a>    to implicitly cast it to `C` to resolve the overloading, <a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="hl" name="2320" href="#2320">2320</a>
<a class="l" name="2321" href="#2321">2321</a>    ```cpp
<a class="l" name="2322" href="#2322">2322</a>    using ::testing::InvokeWithoutArgs;
<a class="l" name="2323" href="#2323">2323</a>    ...
<a class="l" name="2324" href="#2324">2324</a>      ResultCallback&lt;bool&gt;* is_ok = ...;
<a class="l" name="2325" href="#2325">2325</a>      ... InvokeWithoutArgs(is_ok) ...;  // This works.
<a class="l" name="2326" href="#2326">2326</a>
<a class="l" name="2327" href="#2327">2327</a>      BlockingClosure* done = ...;
<a class="l" name="2328" href="#2328">2328</a>      ... InvokeWithoutArgs(implicit_cast&lt;Closure*&gt;(done)) ...;
<a class="l" name="2329" href="#2329">2329</a>      // The cast is necessary.
<a class="hl" name="2330" href="#2330">2330</a>    ```
<a class="l" name="2331" href="#2331">2331</a>
<a class="l" name="2332" href="#2332">2332</a>### Invoking an Argument of the Mock Function
<a class="l" name="2333" href="#2333">2333</a>
<a class="l" name="2334" href="#2334">2334</a>Sometimes a mock function will receive a function pointer, a functor (in other
<a class="l" name="2335" href="#2335">2335</a>words, a "callable") as an argument, <a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="l" name="2336" href="#2336">2336</a>
<a class="l" name="2337" href="#2337">2337</a>```cpp
<a class="l" name="2338" href="#2338">2338</a>class MockFoo : public Foo {
<a class="l" name="2339" href="#2339">2339</a> public:
<a class="hl" name="2340" href="#2340">2340</a>  MOCK_METHOD(bool, DoThis, (int n, (ResultCallback1&lt;bool, int&gt;* callback)),
<a class="l" name="2341" href="#2341">2341</a>              (override));
<a class="l" name="2342" href="#2342">2342</a>};
<a class="l" name="2343" href="#2343">2343</a>```
<a class="l" name="2344" href="#2344">2344</a>
<a class="l" name="2345" href="#2345">2345</a>and you may want to invoke this callable argument:
<a class="l" name="2346" href="#2346">2346</a>
<a class="l" name="2347" href="#2347">2347</a>```cpp
<a class="l" name="2348" href="#2348">2348</a>using ::testing::_;
<a class="l" name="2349" href="#2349">2349</a>...
<a class="hl" name="2350" href="#2350">2350</a>  MockFoo foo;
<a class="l" name="2351" href="#2351">2351</a>  EXPECT_CALL(foo, DoThis(_, _))
<a class="l" name="2352" href="#2352">2352</a>      .WillOnce(...);
<a class="l" name="2353" href="#2353">2353</a>      // Will execute callback-&gt;Run(5), where callback is the
<a class="l" name="2354" href="#2354">2354</a>      // second argument DoThis() receives.
<a class="l" name="2355" href="#2355">2355</a>```
<a class="l" name="2356" href="#2356">2356</a>
<a class="l" name="2357" href="#2357">2357</a>NOTE: The section below is legacy documentation from before C++ had lambdas:
<a class="l" name="2358" href="#2358">2358</a>
<a class="l" name="2359" href="#2359">2359</a>Arghh, you need to refer to a mock function argument but C++ has no lambda
<a class="hl" name="2360" href="#2360">2360</a>(yet), so you have to define your own action. :-( Or do you really?
<a class="l" name="2361" href="#2361">2361</a>
<a class="l" name="2362" href="#2362">2362</a>Well, gMock has an action to solve *exactly* this problem:
<a class="l" name="2363" href="#2363">2363</a>
<a class="l" name="2364" href="#2364">2364</a>```cpp
<a class="l" name="2365" href="#2365">2365</a>InvokeArgument&lt;N&gt;(arg_1, arg_2, ..., arg_m)
<a class="l" name="2366" href="#2366">2366</a>```
<a class="l" name="2367" href="#2367">2367</a>
<a class="l" name="2368" href="#2368">2368</a>will invoke the `N`-th (0-based) argument the mock function receives, with
<a class="l" name="2369" href="#2369">2369</a>`arg_1`, `arg_2`, ..., and `arg_m`. No matter if the argument is a function
<a class="hl" name="2370" href="#2370">2370</a>pointer, a functor, or a callback. gMock handles them all.
<a class="l" name="2371" href="#2371">2371</a>
<a class="l" name="2372" href="#2372">2372</a>With that, you could write:
<a class="l" name="2373" href="#2373">2373</a>
<a class="l" name="2374" href="#2374">2374</a>```cpp
<a class="l" name="2375" href="#2375">2375</a>using ::testing::_;
<a class="l" name="2376" href="#2376">2376</a>using ::testing::InvokeArgument;
<a class="l" name="2377" href="#2377">2377</a>...
<a class="l" name="2378" href="#2378">2378</a>  EXPECT_CALL(foo, DoThis(_, _))
<a class="l" name="2379" href="#2379">2379</a>      .WillOnce(InvokeArgument&lt;1&gt;(5));
<a class="hl" name="2380" href="#2380">2380</a>      // Will execute callback-&gt;Run(5), where callback is the
<a class="l" name="2381" href="#2381">2381</a>      // second argument DoThis() receives.
<a class="l" name="2382" href="#2382">2382</a>```
<a class="l" name="2383" href="#2383">2383</a>
<a class="l" name="2384" href="#2384">2384</a>What if the callable takes an argument by reference? No problem - just wrap it
<a class="l" name="2385" href="#2385">2385</a>inside `std::ref()`:
<a class="l" name="2386" href="#2386">2386</a>
<a class="l" name="2387" href="#2387">2387</a>```cpp
<a class="l" name="2388" href="#2388">2388</a>  ...
<a class="l" name="2389" href="#2389">2389</a>  MOCK_METHOD(bool, Bar,
<a class="hl" name="2390" href="#2390">2390</a>              ((ResultCallback2&lt;bool, int, const Helper&amp;&gt;* callback)),
<a class="l" name="2391" href="#2391">2391</a>              (override));
<a class="l" name="2392" href="#2392">2392</a>  ...
<a class="l" name="2393" href="#2393">2393</a>  using ::testing::_;
<a class="l" name="2394" href="#2394">2394</a>  using ::testing::InvokeArgument;
<a class="l" name="2395" href="#2395">2395</a>  ...
<a class="l" name="2396" href="#2396">2396</a>  MockFoo foo;
<a class="l" name="2397" href="#2397">2397</a>  Helper helper;
<a class="l" name="2398" href="#2398">2398</a>  ...
<a class="l" name="2399" href="#2399">2399</a>  EXPECT_CALL(foo, Bar(_))
<a class="hl" name="2400" href="#2400">2400</a>      .WillOnce(InvokeArgument&lt;0&gt;(5, std::ref(helper)));
<a class="l" name="2401" href="#2401">2401</a>      // std::ref(helper) guarantees that a reference to helper, not a copy of
<a class="l" name="2402" href="#2402">2402</a>      // it, will be passed to the callback.
<a class="l" name="2403" href="#2403">2403</a>```
<a class="l" name="2404" href="#2404">2404</a>
<a class="l" name="2405" href="#2405">2405</a>What if the callable takes an argument by reference and we do **not** wrap the
<a class="l" name="2406" href="#2406">2406</a>argument in `std::ref()`? Then `InvokeArgument()` will *make a copy* of the
<a class="l" name="2407" href="#2407">2407</a>argument, and pass a *reference to the copy*, instead of a reference to the
<a class="l" name="2408" href="#2408">2408</a>original value, to the callable. This is especially handy when the argument is a
<a class="l" name="2409" href="#2409">2409</a>temporary value:
<a class="hl" name="2410" href="#2410">2410</a>
<a class="l" name="2411" href="#2411">2411</a>```cpp
<a class="l" name="2412" href="#2412">2412</a>  ...
<a class="l" name="2413" href="#2413">2413</a>  MOCK_METHOD(bool, DoThat, (bool (*f)(const double&amp; x, const string&amp; s)),
<a class="l" name="2414" href="#2414">2414</a>              (override));
<a class="l" name="2415" href="#2415">2415</a>  ...
<a class="l" name="2416" href="#2416">2416</a>  using ::testing::_;
<a class="l" name="2417" href="#2417">2417</a>  using ::testing::InvokeArgument;
<a class="l" name="2418" href="#2418">2418</a>  ...
<a class="l" name="2419" href="#2419">2419</a>  MockFoo foo;
<a class="hl" name="2420" href="#2420">2420</a>  ...
<a class="l" name="2421" href="#2421">2421</a>  EXPECT_CALL(foo, DoThat(_))
<a class="l" name="2422" href="#2422">2422</a>      .WillOnce(InvokeArgument&lt;0&gt;(5.0, string("Hi")));
<a class="l" name="2423" href="#2423">2423</a>      // Will execute (*f)(5.0, string("Hi")), where f is the function pointer
<a class="l" name="2424" href="#2424">2424</a>      // DoThat() receives.  Note that the values 5.0 and string("Hi") are
<a class="l" name="2425" href="#2425">2425</a>      // temporary and dead once the EXPECT_CALL() statement finishes.  Yet
<a class="l" name="2426" href="#2426">2426</a>      // it's fine to perform this action later, since a copy of the values
<a class="l" name="2427" href="#2427">2427</a>      // are kept inside the InvokeArgument action.
<a class="l" name="2428" href="#2428">2428</a>```
<a class="l" name="2429" href="#2429">2429</a>
<a class="hl" name="2430" href="#2430">2430</a>### Ignoring an Action's Result
<a class="l" name="2431" href="#2431">2431</a>
<a class="l" name="2432" href="#2432">2432</a>Sometimes you have an action that returns *something*, but you need an action
<a class="l" name="2433" href="#2433">2433</a>that returns `void` (perhaps you want to use it in a mock function that returns
<a class="l" name="2434" href="#2434">2434</a>`void`, or perhaps it needs to be used in `DoAll()` and it's not the last in the
<a class="l" name="2435" href="#2435">2435</a>list). `IgnoreResult()` lets you do that. For example:
<a class="l" name="2436" href="#2436">2436</a>
<a class="l" name="2437" href="#2437">2437</a>```cpp
<a class="l" name="2438" href="#2438">2438</a>using ::testing::_;
<a class="l" name="2439" href="#2439">2439</a>using ::testing::DoAll;
<a class="hl" name="2440" href="#2440">2440</a>using ::testing::IgnoreResult;
<a class="l" name="2441" href="#2441">2441</a>using ::testing::Return;
<a class="l" name="2442" href="#2442">2442</a>
<a class="l" name="2443" href="#2443">2443</a>int Process(const MyData&amp; data);
<a class="l" name="2444" href="#2444">2444</a>string DoSomething();
<a class="l" name="2445" href="#2445">2445</a>
<a class="l" name="2446" href="#2446">2446</a>class MockFoo : public Foo {
<a class="l" name="2447" href="#2447">2447</a> public:
<a class="l" name="2448" href="#2448">2448</a>  MOCK_METHOD(void, Abc, (const MyData&amp; data), (override));
<a class="l" name="2449" href="#2449">2449</a>  MOCK_METHOD(bool, Xyz, (), (override));
<a class="hl" name="2450" href="#2450">2450</a>};
<a class="l" name="2451" href="#2451">2451</a>
<a class="l" name="2452" href="#2452">2452</a>  ...
<a class="l" name="2453" href="#2453">2453</a>  MockFoo foo;
<a class="l" name="2454" href="#2454">2454</a>  EXPECT_CALL(foo, Abc(_))
<a class="l" name="2455" href="#2455">2455</a>      // .WillOnce(Invoke(Process));
<a class="l" name="2456" href="#2456">2456</a>      // The above line won't compile as Process() returns int but Abc() needs
<a class="l" name="2457" href="#2457">2457</a>      // to return void.
<a class="l" name="2458" href="#2458">2458</a>      .WillOnce(IgnoreResult(Process));
<a class="l" name="2459" href="#2459">2459</a>  EXPECT_CALL(foo, Xyz())
<a class="hl" name="2460" href="#2460">2460</a>      .WillOnce(DoAll(IgnoreResult(DoSomething),
<a class="l" name="2461" href="#2461">2461</a>                      // Ignores the string DoSomething() returns.
<a class="l" name="2462" href="#2462">2462</a>                      Return(true)));
<a class="l" name="2463" href="#2463">2463</a>```
<a class="l" name="2464" href="#2464">2464</a>
<a class="l" name="2465" href="#2465">2465</a>Note that you **cannot** use `IgnoreResult()` on an action that already returns
<a class="l" name="2466" href="#2466">2466</a>`void`. Doing so will lead to ugly compiler errors.
<a class="l" name="2467" href="#2467">2467</a>
<a class="l" name="2468" href="#2468">2468</a>### Selecting an Action's Arguments {#SelectingArgs}
<a class="l" name="2469" href="#2469">2469</a>
<a class="hl" name="2470" href="#2470">2470</a>Say you have a mock function `Foo()` that takes seven arguments, and you have a
<a class="l" name="2471" href="#2471">2471</a>custom action that you want to invoke when `Foo()` is called. Trouble is, the
<a class="l" name="2472" href="#2472">2472</a>custom action only wants three arguments:
<a class="l" name="2473" href="#2473">2473</a>
<a class="l" name="2474" href="#2474">2474</a>```cpp
<a class="l" name="2475" href="#2475">2475</a>using ::testing::_;
<a class="l" name="2476" href="#2476">2476</a>using ::testing::Invoke;
<a class="l" name="2477" href="#2477">2477</a>...
<a class="l" name="2478" href="#2478">2478</a>  MOCK_METHOD(bool, Foo,
<a class="l" name="2479" href="#2479">2479</a>              (bool visible, const string&amp; name, int x, int y,
<a class="hl" name="2480" href="#2480">2480</a>               (const map&lt;pair&lt;int, int&gt;&gt;), double&amp; weight, double min_weight,
<a class="l" name="2481" href="#2481">2481</a>               double max_wight));
<a class="l" name="2482" href="#2482">2482</a>...
<a class="l" name="2483" href="#2483">2483</a>bool IsVisibleInQuadrant1(bool visible, int x, int y) {
<a class="l" name="2484" href="#2484">2484</a>  return visible &amp;&amp; x &gt;= 0 &amp;&amp; y &gt;= 0;
<a class="l" name="2485" href="#2485">2485</a>}
<a class="l" name="2486" href="#2486">2486</a>...
<a class="l" name="2487" href="#2487">2487</a>  EXPECT_CALL(mock, Foo)
<a class="l" name="2488" href="#2488">2488</a>      .WillOnce(Invoke(IsVisibleInQuadrant1));  // Uh, won't compile. :-(
<a class="l" name="2489" href="#2489">2489</a>```
<a class="hl" name="2490" href="#2490">2490</a>
<a class="l" name="2491" href="#2491">2491</a>To please the compiler God, you need to define an "adaptor" that has the same
<a class="l" name="2492" href="#2492">2492</a>signature as `Foo()` and calls the custom action with the right arguments:
<a class="l" name="2493" href="#2493">2493</a>
<a class="l" name="2494" href="#2494">2494</a>```cpp
<a class="l" name="2495" href="#2495">2495</a>using ::testing::_;
<a class="l" name="2496" href="#2496">2496</a>using ::testing::Invoke;
<a class="l" name="2497" href="#2497">2497</a>...
<a class="l" name="2498" href="#2498">2498</a>bool MyIsVisibleInQuadrant1(bool visible, const string&amp; name, int x, int y,
<a class="l" name="2499" href="#2499">2499</a>                            const map&lt;pair&lt;int, int&gt;, double&gt;&amp; weight,
<a class="hl" name="2500" href="#2500">2500</a>                            double min_weight, double max_wight) {
<a class="l" name="2501" href="#2501">2501</a>  return IsVisibleInQuadrant1(visible, x, y);
<a class="l" name="2502" href="#2502">2502</a>}
<a class="l" name="2503" href="#2503">2503</a>...
<a class="l" name="2504" href="#2504">2504</a>  EXPECT_CALL(mock, Foo)
<a class="l" name="2505" href="#2505">2505</a>      .WillOnce(Invoke(MyIsVisibleInQuadrant1));  // Now it works.
<a class="l" name="2506" href="#2506">2506</a>```
<a class="l" name="2507" href="#2507">2507</a>
<a class="l" name="2508" href="#2508">2508</a>But isn't this awkward?
<a class="l" name="2509" href="#2509">2509</a>
<a class="hl" name="2510" href="#2510">2510</a>gMock provides a generic *action adaptor*, so you can spend your time minding
<a class="l" name="2511" href="#2511">2511</a>more important business than writing your own adaptors. Here's the syntax:
<a class="l" name="2512" href="#2512">2512</a>
<a class="l" name="2513" href="#2513">2513</a>```cpp
<a class="l" name="2514" href="#2514">2514</a>WithArgs&lt;N1, N2, ..., Nk&gt;(action)
<a class="l" name="2515" href="#2515">2515</a>```
<a class="l" name="2516" href="#2516">2516</a>
<a class="l" name="2517" href="#2517">2517</a>creates an action that passes the arguments of the mock function at the given
<a class="l" name="2518" href="#2518">2518</a>indices (0-based) to the inner `action` and performs it. Using `WithArgs`, our
<a class="l" name="2519" href="#2519">2519</a>original example can be written as:
<a class="hl" name="2520" href="#2520">2520</a>
<a class="l" name="2521" href="#2521">2521</a>```cpp
<a class="l" name="2522" href="#2522">2522</a>using ::testing::_;
<a class="l" name="2523" href="#2523">2523</a>using ::testing::Invoke;
<a class="l" name="2524" href="#2524">2524</a>using ::testing::WithArgs;
<a class="l" name="2525" href="#2525">2525</a>...
<a class="l" name="2526" href="#2526">2526</a>  EXPECT_CALL(mock, Foo)
<a class="l" name="2527" href="#2527">2527</a>      .WillOnce(WithArgs&lt;0, 2, 3&gt;(Invoke(IsVisibleInQuadrant1)));  // No need to define your own adaptor.
<a class="l" name="2528" href="#2528">2528</a>```
<a class="l" name="2529" href="#2529">2529</a>
<a class="hl" name="2530" href="#2530">2530</a>For better readability, gMock also gives you:
<a class="l" name="2531" href="#2531">2531</a>
<a class="l" name="2532" href="#2532">2532</a>*   `WithoutArgs(action)` when the inner `action` takes *no* argument, and
<a class="l" name="2533" href="#2533">2533</a>*   `WithArg&lt;N&gt;(action)` (no `s` after `Arg`) when the inner `action` takes
<a class="l" name="2534" href="#2534">2534</a>    *one* argument.
<a class="l" name="2535" href="#2535">2535</a>
<a class="l" name="2536" href="#2536">2536</a>As you may have realized, `InvokeWithoutArgs(...)` is just syntactic sugar for
<a class="l" name="2537" href="#2537">2537</a>`WithoutArgs(Invoke(...))`.
<a class="l" name="2538" href="#2538">2538</a>
<a class="l" name="2539" href="#2539">2539</a>Here are more tips:
<a class="hl" name="2540" href="#2540">2540</a>
<a class="l" name="2541" href="#2541">2541</a>*   The inner action used in `WithArgs` and friends does not have to be
<a class="l" name="2542" href="#2542">2542</a>    `Invoke()` -- it can be anything.
<a class="l" name="2543" href="#2543">2543</a>*   You can repeat an argument in the argument list if necessary, <a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="l" name="2544" href="#2544">2544</a>    `WithArgs&lt;2, 3, 3, 5&gt;(...)`.
<a class="l" name="2545" href="#2545">2545</a>*   You can change the order of the arguments, <a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `WithArgs&lt;3, 2, 1&gt;(...)`.
<a class="l" name="2546" href="#2546">2546</a>*   The types of the selected arguments do *not* have to match the signature of
<a class="l" name="2547" href="#2547">2547</a>    the inner action exactly. It works as long as they can be implicitly
<a class="l" name="2548" href="#2548">2548</a>    converted to the corresponding arguments of the inner action. For example,
<a class="l" name="2549" href="#2549">2549</a>    if the 4-th argument of the mock function is an `int` and `my_action` takes
<a class="hl" name="2550" href="#2550">2550</a>    a `double`, `WithArg&lt;4&gt;(my_action)` will work.
<a class="l" name="2551" href="#2551">2551</a>
<a class="l" name="2552" href="#2552">2552</a>### Ignoring Arguments in Action Functions
<a class="l" name="2553" href="#2553">2553</a>
<a class="l" name="2554" href="#2554">2554</a>The [selecting-an-action's-arguments](#SelectingArgs) recipe showed us one way
<a class="l" name="2555" href="#2555">2555</a>to make a mock function and an action with incompatible argument lists fit
<a class="l" name="2556" href="#2556">2556</a>together. The downside is that wrapping the action in `WithArgs&lt;...&gt;()` can get
<a class="l" name="2557" href="#2557">2557</a>tedious for people writing the tests.
<a class="l" name="2558" href="#2558">2558</a>
<a class="l" name="2559" href="#2559">2559</a>If you are defining a function (or method, functor, lambda, callback) to be used
<a class="hl" name="2560" href="#2560">2560</a>with `Invoke*()`, and you are not interested in some of its arguments, an
<a class="l" name="2561" href="#2561">2561</a>alternative to `WithArgs` is to declare the uninteresting arguments as `Unused`.
<a class="l" name="2562" href="#2562">2562</a>This makes the definition less cluttered and less fragile in case the types of
<a class="l" name="2563" href="#2563">2563</a>the uninteresting arguments change. It could also increase the chance the action
<a class="l" name="2564" href="#2564">2564</a>function can be reused. For example, given
<a class="l" name="2565" href="#2565">2565</a>
<a class="l" name="2566" href="#2566">2566</a>```cpp
<a class="l" name="2567" href="#2567">2567</a> public:
<a class="l" name="2568" href="#2568">2568</a>  MOCK_METHOD(double, Foo, double(const string&amp; label, double x, double y),
<a class="l" name="2569" href="#2569">2569</a>              (override));
<a class="hl" name="2570" href="#2570">2570</a>  MOCK_METHOD(double, Bar, (int index, double x, double y), (override));
<a class="l" name="2571" href="#2571">2571</a>```
<a class="l" name="2572" href="#2572">2572</a>
<a class="l" name="2573" href="#2573">2573</a>instead of
<a class="l" name="2574" href="#2574">2574</a>
<a class="l" name="2575" href="#2575">2575</a>```cpp
<a class="l" name="2576" href="#2576">2576</a>using ::testing::_;
<a class="l" name="2577" href="#2577">2577</a>using ::testing::Invoke;
<a class="l" name="2578" href="#2578">2578</a>
<a class="l" name="2579" href="#2579">2579</a>double DistanceToOriginWithLabel(const string&amp; label, double x, double y) {
<a class="hl" name="2580" href="#2580">2580</a>  return sqrt(x*x + y*y);
<a class="l" name="2581" href="#2581">2581</a>}
<a class="l" name="2582" href="#2582">2582</a>double DistanceToOriginWithIndex(int index, double x, double y) {
<a class="l" name="2583" href="#2583">2583</a>  return sqrt(x*x + y*y);
<a class="l" name="2584" href="#2584">2584</a>}
<a class="l" name="2585" href="#2585">2585</a>...
<a class="l" name="2586" href="#2586">2586</a>  EXPECT_CALL(mock, Foo("abc", _, _))
<a class="l" name="2587" href="#2587">2587</a>      .WillOnce(Invoke(DistanceToOriginWithLabel));
<a class="l" name="2588" href="#2588">2588</a>  EXPECT_CALL(mock, Bar(5, _, _))
<a class="l" name="2589" href="#2589">2589</a>      .WillOnce(Invoke(DistanceToOriginWithIndex));
<a class="hl" name="2590" href="#2590">2590</a>```
<a class="l" name="2591" href="#2591">2591</a>
<a class="l" name="2592" href="#2592">2592</a>you could write
<a class="l" name="2593" href="#2593">2593</a>
<a class="l" name="2594" href="#2594">2594</a>```cpp
<a class="l" name="2595" href="#2595">2595</a>using ::testing::_;
<a class="l" name="2596" href="#2596">2596</a>using ::testing::Invoke;
<a class="l" name="2597" href="#2597">2597</a>using ::testing::Unused;
<a class="l" name="2598" href="#2598">2598</a>
<a class="l" name="2599" href="#2599">2599</a>double DistanceToOrigin(Unused, double x, double y) {
<a class="hl" name="2600" href="#2600">2600</a>  return sqrt(x*x + y*y);
<a class="l" name="2601" href="#2601">2601</a>}
<a class="l" name="2602" href="#2602">2602</a>...
<a class="l" name="2603" href="#2603">2603</a>  EXPECT_CALL(mock, Foo("abc", _, _))
<a class="l" name="2604" href="#2604">2604</a>      .WillOnce(Invoke(DistanceToOrigin));
<a class="l" name="2605" href="#2605">2605</a>  EXPECT_CALL(mock, Bar(5, _, _))
<a class="l" name="2606" href="#2606">2606</a>      .WillOnce(Invoke(DistanceToOrigin));
<a class="l" name="2607" href="#2607">2607</a>```
<a class="l" name="2608" href="#2608">2608</a>
<a class="l" name="2609" href="#2609">2609</a>### Sharing Actions
<a class="hl" name="2610" href="#2610">2610</a>
<a class="l" name="2611" href="#2611">2611</a>Just like matchers, a gMock action object consists of a pointer to a ref-counted
<a class="l" name="2612" href="#2612">2612</a>implementation object. Therefore copying actions is also allowed and very
<a class="l" name="2613" href="#2613">2613</a>efficient. When the last action that references the implementation object dies,
<a class="l" name="2614" href="#2614">2614</a>the implementation object will be deleted.
<a class="l" name="2615" href="#2615">2615</a>
<a class="l" name="2616" href="#2616">2616</a>If you have some complex action that you want to use again and again, you may
<a class="l" name="2617" href="#2617">2617</a>not have to build it from scratch everytime. If the action doesn't have an
<a class="l" name="2618" href="#2618">2618</a>internal state (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> if it always does the same thing no matter how many times
<a class="l" name="2619" href="#2619">2619</a>it has been called), you can assign it to an action variable and use that
<a class="hl" name="2620" href="#2620">2620</a>variable repeatedly. For example:
<a class="l" name="2621" href="#2621">2621</a>
<a class="l" name="2622" href="#2622">2622</a>```cpp
<a class="l" name="2623" href="#2623">2623</a>using ::testing::Action;
<a class="l" name="2624" href="#2624">2624</a>using ::testing::DoAll;
<a class="l" name="2625" href="#2625">2625</a>using ::testing::Return;
<a class="l" name="2626" href="#2626">2626</a>using ::testing::SetArgPointee;
<a class="l" name="2627" href="#2627">2627</a>...
<a class="l" name="2628" href="#2628">2628</a>  Action&lt;bool(int*)&gt; set_flag = DoAll(SetArgPointee&lt;0&gt;(5),
<a class="l" name="2629" href="#2629">2629</a>                                      Return(true));
<a class="hl" name="2630" href="#2630">2630</a>  ... use set_flag in .WillOnce() and .WillRepeatedly() ...
<a class="l" name="2631" href="#2631">2631</a>```
<a class="l" name="2632" href="#2632">2632</a>
<a class="l" name="2633" href="#2633">2633</a>However, if the action has its own state, you may be surprised if you share the
<a class="l" name="2634" href="#2634">2634</a>action object. Suppose you have an action factory `IncrementCounter(init)` which
<a class="l" name="2635" href="#2635">2635</a>creates an action that increments and returns a counter whose initial value is
<a class="l" name="2636" href="#2636">2636</a>`init`, using two actions created from the same expression and using a shared
<a class="l" name="2637" href="#2637">2637</a>action will exhibit different behaviors. Example:
<a class="l" name="2638" href="#2638">2638</a>
<a class="l" name="2639" href="#2639">2639</a>```cpp
<a class="hl" name="2640" href="#2640">2640</a>  EXPECT_CALL(foo, DoThis())
<a class="l" name="2641" href="#2641">2641</a>      .WillRepeatedly(IncrementCounter(0));
<a class="l" name="2642" href="#2642">2642</a>  EXPECT_CALL(foo, DoThat())
<a class="l" name="2643" href="#2643">2643</a>      .WillRepeatedly(IncrementCounter(0));
<a class="l" name="2644" href="#2644">2644</a>  <a href="/googletest/s?path=foo.DoThis&amp;project=googletest">foo.DoThis</a>();  // Returns 1.
<a class="l" name="2645" href="#2645">2645</a>  <a href="/googletest/s?path=foo.DoThis&amp;project=googletest">foo.DoThis</a>();  // Returns 2.
<a class="l" name="2646" href="#2646">2646</a>  <a href="/googletest/s?path=foo.DoThat&amp;project=googletest">foo.DoThat</a>();  // Returns 1 - Blah() uses a different
<a class="l" name="2647" href="#2647">2647</a>                 // counter than Bar()'s.
<a class="l" name="2648" href="#2648">2648</a>```
<a class="l" name="2649" href="#2649">2649</a>
<a class="hl" name="2650" href="#2650">2650</a>versus
<a class="l" name="2651" href="#2651">2651</a>
<a class="l" name="2652" href="#2652">2652</a>```cpp
<a class="l" name="2653" href="#2653">2653</a>using ::testing::Action;
<a class="l" name="2654" href="#2654">2654</a>...
<a class="l" name="2655" href="#2655">2655</a>  Action&lt;int()&gt; increment = IncrementCounter(0);
<a class="l" name="2656" href="#2656">2656</a>  EXPECT_CALL(foo, DoThis())
<a class="l" name="2657" href="#2657">2657</a>      .WillRepeatedly(increment);
<a class="l" name="2658" href="#2658">2658</a>  EXPECT_CALL(foo, DoThat())
<a class="l" name="2659" href="#2659">2659</a>      .WillRepeatedly(increment);
<a class="hl" name="2660" href="#2660">2660</a>  <a href="/googletest/s?path=foo.DoThis&amp;project=googletest">foo.DoThis</a>();  // Returns 1.
<a class="l" name="2661" href="#2661">2661</a>  <a href="/googletest/s?path=foo.DoThis&amp;project=googletest">foo.DoThis</a>();  // Returns 2.
<a class="l" name="2662" href="#2662">2662</a>  <a href="/googletest/s?path=foo.DoThat&amp;project=googletest">foo.DoThat</a>();  // Returns 3 - the counter is shared.
<a class="l" name="2663" href="#2663">2663</a>```
<a class="l" name="2664" href="#2664">2664</a>
<a class="l" name="2665" href="#2665">2665</a>### Testing Asynchronous Behavior
<a class="l" name="2666" href="#2666">2666</a>
<a class="l" name="2667" href="#2667">2667</a>One oft-encountered problem with gMock is that it can be hard to test
<a class="l" name="2668" href="#2668">2668</a>asynchronous behavior. Suppose you had a `EventQueue` class that you wanted to
<a class="l" name="2669" href="#2669">2669</a>test, and you created a separate `EventDispatcher` interface so that you could
<a class="hl" name="2670" href="#2670">2670</a>easily mock it out. However, the implementation of the class fired all the
<a class="l" name="2671" href="#2671">2671</a>events on a background thread, which made test timings difficult. You could just
<a class="l" name="2672" href="#2672">2672</a>insert `sleep()` statements and hope for the best, but that makes your test
<a class="l" name="2673" href="#2673">2673</a>behavior nondeterministic. A better way is to use gMock actions and
<a class="l" name="2674" href="#2674">2674</a>`Notification` objects to force your asynchronous test to behave synchronously.
<a class="l" name="2675" href="#2675">2675</a>
<a class="l" name="2676" href="#2676">2676</a>```cpp
<a class="l" name="2677" href="#2677">2677</a>using ::testing::DoAll;
<a class="l" name="2678" href="#2678">2678</a>using ::testing::InvokeWithoutArgs;
<a class="l" name="2679" href="#2679">2679</a>using ::testing::Return;
<a class="hl" name="2680" href="#2680">2680</a>
<a class="l" name="2681" href="#2681">2681</a>class MockEventDispatcher : public EventDispatcher {
<a class="l" name="2682" href="#2682">2682</a>  MOCK_METHOD(bool, DispatchEvent, (int32), (override));
<a class="l" name="2683" href="#2683">2683</a>};
<a class="l" name="2684" href="#2684">2684</a>
<a class="l" name="2685" href="#2685">2685</a>ACTION_P(Notify, notification) {
<a class="l" name="2686" href="#2686">2686</a>  notification-&gt;Notify();
<a class="l" name="2687" href="#2687">2687</a>}
<a class="l" name="2688" href="#2688">2688</a>
<a class="l" name="2689" href="#2689">2689</a>TEST(EventQueueTest, EnqueueEventTest) {
<a class="hl" name="2690" href="#2690">2690</a>  MockEventDispatcher mock_event_dispatcher;
<a class="l" name="2691" href="#2691">2691</a>  EventQueue event_queue(&amp;mock_event_dispatcher);
<a class="l" name="2692" href="#2692">2692</a>
<a class="l" name="2693" href="#2693">2693</a>  const int32 kEventId = 321;
<a class="l" name="2694" href="#2694">2694</a>  absl::Notification done;
<a class="l" name="2695" href="#2695">2695</a>  EXPECT_CALL(mock_event_dispatcher, DispatchEvent(kEventId))
<a class="l" name="2696" href="#2696">2696</a>      .WillOnce(Notify(&amp;done));
<a class="l" name="2697" href="#2697">2697</a>
<a class="l" name="2698" href="#2698">2698</a>  <a href="/googletest/s?path=event_queue.EnqueueEvent&amp;project=googletest">event_queue.EnqueueEvent</a>(kEventId);
<a class="l" name="2699" href="#2699">2699</a>  <a href="/googletest/s?path=done.WaitForNotification&amp;project=googletest">done.WaitForNotification</a>();
<a class="hl" name="2700" href="#2700">2700</a>}
<a class="l" name="2701" href="#2701">2701</a>```
<a class="l" name="2702" href="#2702">2702</a>
<a class="l" name="2703" href="#2703">2703</a>In the example above, we set our normal gMock expectations, but then add an
<a class="l" name="2704" href="#2704">2704</a>additional action to notify the `Notification` object. Now we can just call
<a class="l" name="2705" href="#2705">2705</a>`Notification::WaitForNotification()` in the main thread to wait for the
<a class="l" name="2706" href="#2706">2706</a>asynchronous call to finish. After that, our test suite is complete and we can
<a class="l" name="2707" href="#2707">2707</a>safely exit.
<a class="l" name="2708" href="#2708">2708</a>
<a class="l" name="2709" href="#2709">2709</a>Note: this example has a downside: namely, if the expectation is not satisfied,
<a class="hl" name="2710" href="#2710">2710</a>our test will run forever. It will eventually time-out and fail, but it will
<a class="l" name="2711" href="#2711">2711</a>take longer and be slightly harder to debug. To alleviate this problem, you can
<a class="l" name="2712" href="#2712">2712</a>use `WaitForNotificationWithTimeout(ms)` instead of `WaitForNotification()`.
<a class="l" name="2713" href="#2713">2713</a>
<a class="l" name="2714" href="#2714">2714</a>## Misc Recipes on Using gMock
<a class="l" name="2715" href="#2715">2715</a>
<a class="l" name="2716" href="#2716">2716</a>### Mocking Methods That Use Move-Only Types
<a class="l" name="2717" href="#2717">2717</a>
<a class="l" name="2718" href="#2718">2718</a>C++11 introduced *move-only types*. A move-only-typed value can be moved from
<a class="l" name="2719" href="#2719">2719</a>one object to another, but cannot be copied. `std::unique_ptr&lt;T&gt;` is probably
<a class="hl" name="2720" href="#2720">2720</a>the most commonly used move-only type.
<a class="l" name="2721" href="#2721">2721</a>
<a class="l" name="2722" href="#2722">2722</a>Mocking a method that takes <a href="/googletest/s?path=and/or&amp;project=googletest">and/or</a> returns move-only types presents some
<a class="l" name="2723" href="#2723">2723</a>challenges, but nothing insurmountable. This recipe shows you how you can do it.
<a class="l" name="2724" href="#2724">2724</a>Note that the support for move-only method arguments was only introduced to
<a class="l" name="2725" href="#2725">2725</a>gMock in April 2017; in older code, you may find more complex
<a class="l" name="2726" href="#2726">2726</a>[workarounds](#LegacyMoveOnly) for lack of this feature.
<a class="l" name="2727" href="#2727">2727</a>
<a class="l" name="2728" href="#2728">2728</a>Let&#8217;s say we are working on a fictional project that lets one post and share
<a class="l" name="2729" href="#2729">2729</a>snippets called &#8220;buzzes&#8221;. Your code uses these types:
<a class="hl" name="2730" href="#2730">2730</a>
<a class="l" name="2731" href="#2731">2731</a>```cpp
<a class="l" name="2732" href="#2732">2732</a>enum class AccessLevel { kInternal, kPublic };
<a class="l" name="2733" href="#2733">2733</a>
<a class="l" name="2734" href="#2734">2734</a>class Buzz {
<a class="l" name="2735" href="#2735">2735</a> public:
<a class="l" name="2736" href="#2736">2736</a>  explicit Buzz(AccessLevel access) { ... }
<a class="l" name="2737" href="#2737">2737</a>  ...
<a class="l" name="2738" href="#2738">2738</a>};
<a class="l" name="2739" href="#2739">2739</a>
<a class="hl" name="2740" href="#2740">2740</a>class Buzzer {
<a class="l" name="2741" href="#2741">2741</a> public:
<a class="l" name="2742" href="#2742">2742</a>  virtual ~Buzzer() {}
<a class="l" name="2743" href="#2743">2743</a>  virtual std::unique_ptr&lt;Buzz&gt; MakeBuzz(StringPiece text) = 0;
<a class="l" name="2744" href="#2744">2744</a>  virtual bool ShareBuzz(std::unique_ptr&lt;Buzz&gt; buzz, int64_t timestamp) = 0;
<a class="l" name="2745" href="#2745">2745</a>  ...
<a class="l" name="2746" href="#2746">2746</a>};
<a class="l" name="2747" href="#2747">2747</a>```
<a class="l" name="2748" href="#2748">2748</a>
<a class="l" name="2749" href="#2749">2749</a>A `Buzz` object represents a snippet being posted. A class that implements the
<a class="hl" name="2750" href="#2750">2750</a>`Buzzer` interface is capable of creating and sharing `Buzz`es. Methods in
<a class="l" name="2751" href="#2751">2751</a>`Buzzer` may return a `unique_ptr&lt;Buzz&gt;` or take a `unique_ptr&lt;Buzz&gt;`. Now we
<a class="l" name="2752" href="#2752">2752</a>need to mock `Buzzer` in our tests.
<a class="l" name="2753" href="#2753">2753</a>
<a class="l" name="2754" href="#2754">2754</a>To mock a method that accepts or returns move-only types, you just use the
<a class="l" name="2755" href="#2755">2755</a>familiar `MOCK_METHOD` syntax as usual:
<a class="l" name="2756" href="#2756">2756</a>
<a class="l" name="2757" href="#2757">2757</a>```cpp
<a class="l" name="2758" href="#2758">2758</a>class MockBuzzer : public Buzzer {
<a class="l" name="2759" href="#2759">2759</a> public:
<a class="hl" name="2760" href="#2760">2760</a>  MOCK_METHOD(std::unique_ptr&lt;Buzz&gt;, MakeBuzz, (StringPiece text), (override));
<a class="l" name="2761" href="#2761">2761</a>  MOCK_METHOD(bool, ShareBuzz, (std::unique_ptr&lt;Buzz&gt; buzz, int64_t timestamp),
<a class="l" name="2762" href="#2762">2762</a>              (override));
<a class="l" name="2763" href="#2763">2763</a>};
<a class="l" name="2764" href="#2764">2764</a>```
<a class="l" name="2765" href="#2765">2765</a>
<a class="l" name="2766" href="#2766">2766</a>Now that we have the mock class defined, we can use it in tests. In the
<a class="l" name="2767" href="#2767">2767</a>following code examples, we assume that we have defined a `MockBuzzer` object
<a class="l" name="2768" href="#2768">2768</a>named `mock_buzzer_`:
<a class="l" name="2769" href="#2769">2769</a>
<a class="hl" name="2770" href="#2770">2770</a>```cpp
<a class="l" name="2771" href="#2771">2771</a>  MockBuzzer mock_buzzer_;
<a class="l" name="2772" href="#2772">2772</a>```
<a class="l" name="2773" href="#2773">2773</a>
<a class="l" name="2774" href="#2774">2774</a>First let&#8217;s see how we can set expectations on the `MakeBuzz()` method, which
<a class="l" name="2775" href="#2775">2775</a>returns a `unique_ptr&lt;Buzz&gt;`.
<a class="l" name="2776" href="#2776">2776</a>
<a class="l" name="2777" href="#2777">2777</a>As usual, if you set an expectation without an action (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> the `.WillOnce()` or
<a class="l" name="2778" href="#2778">2778</a>`.WillRepeatedly()` clause), when that expectation fires, the default action for
<a class="l" name="2779" href="#2779">2779</a>that method will be taken. Since `unique_ptr&lt;&gt;` has a default constructor that
<a class="hl" name="2780" href="#2780">2780</a>returns a null `unique_ptr`, that&#8217;s what you&#8217;ll get if you don&#8217;t specify an
<a class="l" name="2781" href="#2781">2781</a>action:
<a class="l" name="2782" href="#2782">2782</a>
<a class="l" name="2783" href="#2783">2783</a>```cpp
<a class="l" name="2784" href="#2784">2784</a>  // Use the default action.
<a class="l" name="2785" href="#2785">2785</a>  EXPECT_CALL(mock_buzzer_, MakeBuzz("hello"));
<a class="l" name="2786" href="#2786">2786</a>
<a class="l" name="2787" href="#2787">2787</a>  // Triggers the previous EXPECT_CALL.
<a class="l" name="2788" href="#2788">2788</a>  EXPECT_EQ(nullptr, <a href="/googletest/s?path=mock_buzzer_.MakeBuzz&amp;project=googletest">mock_buzzer_.MakeBuzz</a>("hello"));
<a class="l" name="2789" href="#2789">2789</a>```
<a class="hl" name="2790" href="#2790">2790</a>
<a class="l" name="2791" href="#2791">2791</a>If you are not happy with the default action, you can tweak it as usual; see
<a class="l" name="2792" href="#2792">2792</a>[Setting Default Actions](#OnCall).
<a class="l" name="2793" href="#2793">2793</a>
<a class="l" name="2794" href="#2794">2794</a>If you just need to return a pre-defined move-only value, you can use the
<a class="l" name="2795" href="#2795">2795</a>`Return(ByMove(...))` action:
<a class="l" name="2796" href="#2796">2796</a>
<a class="l" name="2797" href="#2797">2797</a>```cpp
<a class="l" name="2798" href="#2798">2798</a>  // When this fires, the unique_ptr&lt;&gt; specified by ByMove(...) will
<a class="l" name="2799" href="#2799">2799</a>  // be returned.
<a class="hl" name="2800" href="#2800">2800</a>  EXPECT_CALL(mock_buzzer_, MakeBuzz("world"))
<a class="l" name="2801" href="#2801">2801</a>      .WillOnce(Return(ByMove(MakeUnique&lt;Buzz&gt;(AccessLevel::kInternal))));
<a class="l" name="2802" href="#2802">2802</a>
<a class="l" name="2803" href="#2803">2803</a>  EXPECT_NE(nullptr, <a href="/googletest/s?path=mock_buzzer_.MakeBuzz&amp;project=googletest">mock_buzzer_.MakeBuzz</a>("world"));
<a class="l" name="2804" href="#2804">2804</a>```
<a class="l" name="2805" href="#2805">2805</a>
<a class="l" name="2806" href="#2806">2806</a>Note that `ByMove()` is essential here - if you drop it, the code won&#8217;t compile.
<a class="l" name="2807" href="#2807">2807</a>
<a class="l" name="2808" href="#2808">2808</a>Quiz time! What do you think will happen if a `Return(ByMove(...))` action is
<a class="l" name="2809" href="#2809">2809</a>performed more than once (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> you write `...
<a class="hl" name="2810" href="#2810">2810</a>.WillRepeatedly(Return(ByMove(...)));`)? Come think of it, after the first time
<a class="l" name="2811" href="#2811">2811</a>the action runs, the source value will be consumed (since it&#8217;s a move-only
<a class="l" name="2812" href="#2812">2812</a>value), so the next time around, there&#8217;s no value to move from -- you&#8217;ll get a
<a class="l" name="2813" href="#2813">2813</a>run-time error that `Return(ByMove(...))` can only be run once.
<a class="l" name="2814" href="#2814">2814</a>
<a class="l" name="2815" href="#2815">2815</a>If you need your mock method to do more than just moving a pre-defined value,
<a class="l" name="2816" href="#2816">2816</a>remember that you can always use a lambda or a callable object, which can do
<a class="l" name="2817" href="#2817">2817</a>pretty much anything you want:
<a class="l" name="2818" href="#2818">2818</a>
<a class="l" name="2819" href="#2819">2819</a>```cpp
<a class="hl" name="2820" href="#2820">2820</a>  EXPECT_CALL(mock_buzzer_, MakeBuzz("x"))
<a class="l" name="2821" href="#2821">2821</a>      .WillRepeatedly([](StringPiece text) {
<a class="l" name="2822" href="#2822">2822</a>        return MakeUnique&lt;Buzz&gt;(AccessLevel::kInternal);
<a class="l" name="2823" href="#2823">2823</a>      });
<a class="l" name="2824" href="#2824">2824</a>
<a class="l" name="2825" href="#2825">2825</a>  EXPECT_NE(nullptr, <a href="/googletest/s?path=mock_buzzer_.MakeBuzz&amp;project=googletest">mock_buzzer_.MakeBuzz</a>("x"));
<a class="l" name="2826" href="#2826">2826</a>  EXPECT_NE(nullptr, <a href="/googletest/s?path=mock_buzzer_.MakeBuzz&amp;project=googletest">mock_buzzer_.MakeBuzz</a>("x"));
<a class="l" name="2827" href="#2827">2827</a>```
<a class="l" name="2828" href="#2828">2828</a>
<a class="l" name="2829" href="#2829">2829</a>Every time this `EXPECT_CALL` fires, a new `unique_ptr&lt;Buzz&gt;` will be created
<a class="hl" name="2830" href="#2830">2830</a>and returned. You cannot do this with `Return(ByMove(...))`.
<a class="l" name="2831" href="#2831">2831</a>
<a class="l" name="2832" href="#2832">2832</a>That covers returning move-only values; but how do we work with methods
<a class="l" name="2833" href="#2833">2833</a>accepting move-only arguments? The answer is that they work normally, although
<a class="l" name="2834" href="#2834">2834</a>some actions will not compile when any of method's arguments are move-only. You
<a class="l" name="2835" href="#2835">2835</a>can always use `Return`, or a [lambda or functor](#FunctionsAsActions):
<a class="l" name="2836" href="#2836">2836</a>
<a class="l" name="2837" href="#2837">2837</a>```cpp
<a class="l" name="2838" href="#2838">2838</a>  using ::testing::Unused;
<a class="l" name="2839" href="#2839">2839</a>
<a class="hl" name="2840" href="#2840">2840</a>  EXPECT_CALL(mock_buzzer_, ShareBuzz(NotNull(), _)).WillOnce(Return(true));
<a class="l" name="2841" href="#2841">2841</a>  EXPECT_TRUE(<a href="/googletest/s?path=mock_buzzer_.ShareBuzz&amp;project=googletest">mock_buzzer_.ShareBuzz</a>(MakeUnique&lt;Buzz&gt;(AccessLevel::kInternal)),
<a class="l" name="2842" href="#2842">2842</a>              0);
<a class="l" name="2843" href="#2843">2843</a>
<a class="l" name="2844" href="#2844">2844</a>  EXPECT_CALL(mock_buzzer_, ShareBuzz(_, _)).WillOnce(
<a class="l" name="2845" href="#2845">2845</a>      [](std::unique_ptr&lt;Buzz&gt; buzz, Unused) { return buzz != nullptr; });
<a class="l" name="2846" href="#2846">2846</a>  EXPECT_FALSE(<a href="/googletest/s?path=mock_buzzer_.ShareBuzz&amp;project=googletest">mock_buzzer_.ShareBuzz</a>(nullptr, 0));
<a class="l" name="2847" href="#2847">2847</a>```
<a class="l" name="2848" href="#2848">2848</a>
<a class="l" name="2849" href="#2849">2849</a>Many built-in actions (`WithArgs`, `WithoutArgs`,`DeleteArg`, `SaveArg`, ...)
<a class="hl" name="2850" href="#2850">2850</a>could in principle support move-only arguments, but the support for this is not
<a class="l" name="2851" href="#2851">2851</a>implemented yet. If this is blocking you, please file a bug.
<a class="l" name="2852" href="#2852">2852</a>
<a class="l" name="2853" href="#2853">2853</a>A few actions (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `DoAll`) copy their arguments internally, so they can never
<a class="l" name="2854" href="#2854">2854</a>work with non-copyable objects; you'll have to use functors instead.
<a class="l" name="2855" href="#2855">2855</a>
<a class="l" name="2856" href="#2856">2856</a>#### Legacy workarounds for move-only types {#LegacyMoveOnly}
<a class="l" name="2857" href="#2857">2857</a>
<a class="l" name="2858" href="#2858">2858</a>Support for move-only function arguments was only introduced to gMock in April
<a class="l" name="2859" href="#2859">2859</a>2017. In older code, you may encounter the following workaround for the lack of
<a class="hl" name="2860" href="#2860">2860</a>this feature (it is no longer necessary - we're including it just for
<a class="l" name="2861" href="#2861">2861</a>reference):
<a class="l" name="2862" href="#2862">2862</a>
<a class="l" name="2863" href="#2863">2863</a>```cpp
<a class="l" name="2864" href="#2864">2864</a>class MockBuzzer : public Buzzer {
<a class="l" name="2865" href="#2865">2865</a> public:
<a class="l" name="2866" href="#2866">2866</a>  MOCK_METHOD(bool, DoShareBuzz, (Buzz* buzz, Time timestamp));
<a class="l" name="2867" href="#2867">2867</a>  bool ShareBuzz(std::unique_ptr&lt;Buzz&gt; buzz, Time timestamp) override {
<a class="l" name="2868" href="#2868">2868</a>    return DoShareBuzz(<a href="/googletest/s?path=buzz.get&amp;project=googletest">buzz.get</a>(), timestamp);
<a class="l" name="2869" href="#2869">2869</a>  }
<a class="hl" name="2870" href="#2870">2870</a>};
<a class="l" name="2871" href="#2871">2871</a>```
<a class="l" name="2872" href="#2872">2872</a>
<a class="l" name="2873" href="#2873">2873</a>The trick is to delegate the `ShareBuzz()` method to a mock method (let&#8217;s call
<a class="l" name="2874" href="#2874">2874</a>it `DoShareBuzz()`) that does not take move-only parameters. Then, instead of
<a class="l" name="2875" href="#2875">2875</a>setting expectations on `ShareBuzz()`, you set them on the `DoShareBuzz()` mock
<a class="l" name="2876" href="#2876">2876</a>method:
<a class="l" name="2877" href="#2877">2877</a>
<a class="l" name="2878" href="#2878">2878</a>```cpp
<a class="l" name="2879" href="#2879">2879</a>  MockBuzzer mock_buzzer_;
<a class="hl" name="2880" href="#2880">2880</a>  EXPECT_CALL(mock_buzzer_, DoShareBuzz(NotNull(), _));
<a class="l" name="2881" href="#2881">2881</a>
<a class="l" name="2882" href="#2882">2882</a>  // When one calls ShareBuzz() on the MockBuzzer like this, the call is
<a class="l" name="2883" href="#2883">2883</a>  // forwarded to DoShareBuzz(), which is mocked.  Therefore this statement
<a class="l" name="2884" href="#2884">2884</a>  // will trigger the above EXPECT_CALL.
<a class="l" name="2885" href="#2885">2885</a>  <a href="/googletest/s?path=mock_buzzer_.ShareBuzz&amp;project=googletest">mock_buzzer_.ShareBuzz</a>(MakeUnique&lt;Buzz&gt;(AccessLevel::kInternal), 0);
<a class="l" name="2886" href="#2886">2886</a>```
<a class="l" name="2887" href="#2887">2887</a>
<a class="l" name="2888" href="#2888">2888</a>### Making the Compilation Faster
<a class="l" name="2889" href="#2889">2889</a>
<a class="hl" name="2890" href="#2890">2890</a>Believe it or not, the *vast majority* of the time spent on compiling a mock
<a class="l" name="2891" href="#2891">2891</a>class is in generating its constructor and destructor, as they perform
<a class="l" name="2892" href="#2892">2892</a>non-trivial tasks (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> verification of the expectations). What's more, mock
<a class="l" name="2893" href="#2893">2893</a>methods with different signatures have different types and thus their
<a class="l" name="2894" href="#2894">2894</a><a href="/googletest/s?path=constructors/destructors&amp;project=googletest">constructors/destructors</a> need to be generated by the compiler separately. As a
<a class="l" name="2895" href="#2895">2895</a>result, if you mock many different types of methods, compiling your mock class
<a class="l" name="2896" href="#2896">2896</a>can get really slow.
<a class="l" name="2897" href="#2897">2897</a>
<a class="l" name="2898" href="#2898">2898</a>If you are experiencing slow compilation, you can move the definition of your
<a class="l" name="2899" href="#2899">2899</a>mock class' constructor and destructor out of the class body and into a `.cc`
<a class="hl" name="2900" href="#2900">2900</a>file. This way, even if you `#include` your mock class in N files, the compiler
<a class="l" name="2901" href="#2901">2901</a>only needs to generate its constructor and destructor once, resulting in a much
<a class="l" name="2902" href="#2902">2902</a>faster compilation.
<a class="l" name="2903" href="#2903">2903</a>
<a class="l" name="2904" href="#2904">2904</a>Let's illustrate the idea using an example. Here's the definition of a mock
<a class="l" name="2905" href="#2905">2905</a>class before applying this recipe:
<a class="l" name="2906" href="#2906">2906</a>
<a class="l" name="2907" href="#2907">2907</a>```cpp
<a class="l" name="2908" href="#2908">2908</a>// File <a href="/googletest/s?path=mock_foo.h.&amp;project=googletest">mock_foo.h.</a>
<a class="l" name="2909" href="#2909">2909</a>...
<a class="hl" name="2910" href="#2910">2910</a>class MockFoo : public Foo {
<a class="l" name="2911" href="#2911">2911</a> public:
<a class="l" name="2912" href="#2912">2912</a>  // Since we don't declare the constructor or the destructor,
<a class="l" name="2913" href="#2913">2913</a>  // the compiler will generate them in every translation unit
<a class="l" name="2914" href="#2914">2914</a>  // where this mock class is used.
<a class="l" name="2915" href="#2915">2915</a>
<a class="l" name="2916" href="#2916">2916</a>  MOCK_METHOD(int, DoThis, (), (override));
<a class="l" name="2917" href="#2917">2917</a>  MOCK_METHOD(bool, DoThat, (const char* str), (override));
<a class="l" name="2918" href="#2918">2918</a>  ... more mock methods ...
<a class="l" name="2919" href="#2919">2919</a>};
<a class="hl" name="2920" href="#2920">2920</a>```
<a class="l" name="2921" href="#2921">2921</a>
<a class="l" name="2922" href="#2922">2922</a>After the change, it would look like:
<a class="l" name="2923" href="#2923">2923</a>
<a class="l" name="2924" href="#2924">2924</a>```cpp
<a class="l" name="2925" href="#2925">2925</a>// File <a href="/googletest/s?path=mock_foo.h.&amp;project=googletest">mock_foo.h.</a>
<a class="l" name="2926" href="#2926">2926</a>...
<a class="l" name="2927" href="#2927">2927</a>class MockFoo : public Foo {
<a class="l" name="2928" href="#2928">2928</a> public:
<a class="l" name="2929" href="#2929">2929</a>  // The constructor and destructor are declared, but not defined, here.
<a class="hl" name="2930" href="#2930">2930</a>  MockFoo();
<a class="l" name="2931" href="#2931">2931</a>  virtual ~MockFoo();
<a class="l" name="2932" href="#2932">2932</a>
<a class="l" name="2933" href="#2933">2933</a>  MOCK_METHOD(int, DoThis, (), (override));
<a class="l" name="2934" href="#2934">2934</a>  MOCK_METHOD(bool, DoThat, (const char* str), (override));
<a class="l" name="2935" href="#2935">2935</a>  ... more mock methods ...
<a class="l" name="2936" href="#2936">2936</a>};
<a class="l" name="2937" href="#2937">2937</a>```
<a class="l" name="2938" href="#2938">2938</a>
<a class="l" name="2939" href="#2939">2939</a>and
<a class="hl" name="2940" href="#2940">2940</a>
<a class="l" name="2941" href="#2941">2941</a>```cpp
<a class="l" name="2942" href="#2942">2942</a>// File <a href="/googletest/s?path=mock_foo.cc.&amp;project=googletest">mock_foo.cc.</a>
<a class="l" name="2943" href="#2943">2943</a>#include "<a href="/googletest/s?path=path/to/mock_foo.h&amp;project=googletest">path/to/mock_foo.h</a>"
<a class="l" name="2944" href="#2944">2944</a>
<a class="l" name="2945" href="#2945">2945</a>// The definitions may appear trivial, but the functions actually do a
<a class="l" name="2946" href="#2946">2946</a>// lot of things through the <a href="/googletest/s?path=constructors/destructors&amp;project=googletest">constructors/destructors</a> of the member
<a class="l" name="2947" href="#2947">2947</a>// variables used to implement the mock methods.
<a class="l" name="2948" href="#2948">2948</a>MockFoo::MockFoo() {}
<a class="l" name="2949" href="#2949">2949</a>MockFoo::~MockFoo() {}
<a class="hl" name="2950" href="#2950">2950</a>```
<a class="l" name="2951" href="#2951">2951</a>
<a class="l" name="2952" href="#2952">2952</a>### Forcing a Verification
<a class="l" name="2953" href="#2953">2953</a>
<a class="l" name="2954" href="#2954">2954</a>When it's being destroyed, your friendly mock object will automatically verify
<a class="l" name="2955" href="#2955">2955</a>that all expectations on it have been satisfied, and will generate googletest
<a class="l" name="2956" href="#2956">2956</a>failures if not. This is convenient as it leaves you with one less thing to
<a class="l" name="2957" href="#2957">2957</a>worry about. That is, unless you are not sure if your mock object will be
<a class="l" name="2958" href="#2958">2958</a>destroyed.
<a class="l" name="2959" href="#2959">2959</a>
<a class="hl" name="2960" href="#2960">2960</a>How could it be that your mock object won't eventually be destroyed? Well, it
<a class="l" name="2961" href="#2961">2961</a>might be created on the heap and owned by the code you are testing. Suppose
<a class="l" name="2962" href="#2962">2962</a>there's a bug in that code and it doesn't delete the mock object properly - you
<a class="l" name="2963" href="#2963">2963</a>could end up with a passing test when there's actually a bug.
<a class="l" name="2964" href="#2964">2964</a>
<a class="l" name="2965" href="#2965">2965</a>Using a heap checker is a good idea and can alleviate the concern, but its
<a class="l" name="2966" href="#2966">2966</a>implementation is not 100% reliable. So, sometimes you do want to *force* gMock
<a class="l" name="2967" href="#2967">2967</a>to verify a mock object before it is (hopefully) destructed. You can do this
<a class="l" name="2968" href="#2968">2968</a>with `Mock::VerifyAndClearExpectations(&amp;mock_object)`:
<a class="l" name="2969" href="#2969">2969</a>
<a class="hl" name="2970" href="#2970">2970</a>```cpp
<a class="l" name="2971" href="#2971">2971</a>TEST(MyServerTest, ProcessesRequest) {
<a class="l" name="2972" href="#2972">2972</a>  using ::testing::Mock;
<a class="l" name="2973" href="#2973">2973</a>
<a class="l" name="2974" href="#2974">2974</a>  MockFoo* const foo = new MockFoo;
<a class="l" name="2975" href="#2975">2975</a>  EXPECT_CALL(*foo, ...)...;
<a class="l" name="2976" href="#2976">2976</a>  // ... other expectations ...
<a class="l" name="2977" href="#2977">2977</a>
<a class="l" name="2978" href="#2978">2978</a>  // server now owns foo.
<a class="l" name="2979" href="#2979">2979</a>  MyServer server(foo);
<a class="hl" name="2980" href="#2980">2980</a>  <a href="/googletest/s?path=server.ProcessRequest&amp;project=googletest">server.ProcessRequest</a>(...);
<a class="l" name="2981" href="#2981">2981</a>
<a class="l" name="2982" href="#2982">2982</a>  // In case that server's destructor will forget to delete foo,
<a class="l" name="2983" href="#2983">2983</a>  // this will verify the expectations anyway.
<a class="l" name="2984" href="#2984">2984</a>  Mock::VerifyAndClearExpectations(foo);
<a class="l" name="2985" href="#2985">2985</a>}  // server is destroyed when it goes out of scope here.
<a class="l" name="2986" href="#2986">2986</a>```
<a class="l" name="2987" href="#2987">2987</a>
<a class="l" name="2988" href="#2988">2988</a>**Tip:** The `Mock::VerifyAndClearExpectations()` function returns a `bool` to
<a class="l" name="2989" href="#2989">2989</a>indicate whether the verification was successful (`true` for yes), so you can
<a class="hl" name="2990" href="#2990">2990</a>wrap that function call inside a `ASSERT_TRUE()` if there is no point going
<a class="l" name="2991" href="#2991">2991</a>further when the verification has failed.
<a class="l" name="2992" href="#2992">2992</a>
<a class="l" name="2993" href="#2993">2993</a>### Using Check Points {#UsingCheckPoints}
<a class="l" name="2994" href="#2994">2994</a>
<a class="l" name="2995" href="#2995">2995</a>Sometimes you may want to "reset" a mock object at various check points in your
<a class="l" name="2996" href="#2996">2996</a>test: at each check point, you verify that all existing expectations on the mock
<a class="l" name="2997" href="#2997">2997</a>object have been satisfied, and then you set some new expectations on it as if
<a class="l" name="2998" href="#2998">2998</a>it's newly created. This allows you to work with a mock object in "phases" whose
<a class="l" name="2999" href="#2999">2999</a>sizes are each manageable.
<a class="hl" name="3000" href="#3000">3000</a>
<a class="l" name="3001" href="#3001">3001</a>One such scenario is that in your test's `SetUp()` function, you may want to put
<a class="l" name="3002" href="#3002">3002</a>the object you are testing into a certain state, with the help from a mock
<a class="l" name="3003" href="#3003">3003</a>object. Once in the desired state, you want to clear all expectations on the
<a class="l" name="3004" href="#3004">3004</a>mock, such that in the `TEST_F` body you can set fresh expectations on it.
<a class="l" name="3005" href="#3005">3005</a>
<a class="l" name="3006" href="#3006">3006</a>As you may have figured out, the `Mock::VerifyAndClearExpectations()` function
<a class="l" name="3007" href="#3007">3007</a>we saw in the previous recipe can help you here. Or, if you are using
<a class="l" name="3008" href="#3008">3008</a>`ON_CALL()` to set default actions on the mock object and want to clear the
<a class="l" name="3009" href="#3009">3009</a>default actions as well, use `Mock::VerifyAndClear(&amp;mock_object)` instead. This
<a class="hl" name="3010" href="#3010">3010</a>function does what `Mock::VerifyAndClearExpectations(&amp;mock_object)` does and
<a class="l" name="3011" href="#3011">3011</a>returns the same `bool`, **plus** it clears the `ON_CALL()` statements on
<a class="l" name="3012" href="#3012">3012</a>`mock_object` too.
<a class="l" name="3013" href="#3013">3013</a>
<a class="l" name="3014" href="#3014">3014</a>Another trick you can use to achieve the same effect is to put the expectations
<a class="l" name="3015" href="#3015">3015</a>in sequences and insert calls to a dummy "check-point" function at specific
<a class="l" name="3016" href="#3016">3016</a>places. Then you can verify that the mock function calls do happen at the right
<a class="l" name="3017" href="#3017">3017</a>time. For example, if you are exercising code:
<a class="l" name="3018" href="#3018">3018</a>
<a class="l" name="3019" href="#3019">3019</a>```cpp
<a class="hl" name="3020" href="#3020">3020</a>  Foo(1);
<a class="l" name="3021" href="#3021">3021</a>  Foo(2);
<a class="l" name="3022" href="#3022">3022</a>  Foo(3);
<a class="l" name="3023" href="#3023">3023</a>```
<a class="l" name="3024" href="#3024">3024</a>
<a class="l" name="3025" href="#3025">3025</a>and want to verify that `Foo(1)` and `Foo(3)` both invoke `<a href="/googletest/s?path=mock.Bar&amp;project=googletest">mock.Bar</a>("a")`, but
<a class="l" name="3026" href="#3026">3026</a>`Foo(2)` doesn't invoke anything. You can write:
<a class="l" name="3027" href="#3027">3027</a>
<a class="l" name="3028" href="#3028">3028</a>```cpp
<a class="l" name="3029" href="#3029">3029</a>using ::testing::MockFunction;
<a class="hl" name="3030" href="#3030">3030</a>
<a class="l" name="3031" href="#3031">3031</a>TEST(FooTest, InvokesBarCorrectly) {
<a class="l" name="3032" href="#3032">3032</a>  MyMock mock;
<a class="l" name="3033" href="#3033">3033</a>  // Class MockFunction&lt;F&gt; has exactly one mock method.  It is named
<a class="l" name="3034" href="#3034">3034</a>  // Call() and has type F.
<a class="l" name="3035" href="#3035">3035</a>  MockFunction&lt;void(string check_point_name)&gt; check;
<a class="l" name="3036" href="#3036">3036</a>  {
<a class="l" name="3037" href="#3037">3037</a>    InSequence s;
<a class="l" name="3038" href="#3038">3038</a>
<a class="l" name="3039" href="#3039">3039</a>    EXPECT_CALL(mock, Bar("a"));
<a class="hl" name="3040" href="#3040">3040</a>    EXPECT_CALL(check, Call("1"));
<a class="l" name="3041" href="#3041">3041</a>    EXPECT_CALL(check, Call("2"));
<a class="l" name="3042" href="#3042">3042</a>    EXPECT_CALL(mock, Bar("a"));
<a class="l" name="3043" href="#3043">3043</a>  }
<a class="l" name="3044" href="#3044">3044</a>  Foo(1);
<a class="l" name="3045" href="#3045">3045</a>  <a href="/googletest/s?path=check.Call&amp;project=googletest">check.Call</a>("1");
<a class="l" name="3046" href="#3046">3046</a>  Foo(2);
<a class="l" name="3047" href="#3047">3047</a>  <a href="/googletest/s?path=check.Call&amp;project=googletest">check.Call</a>("2");
<a class="l" name="3048" href="#3048">3048</a>  Foo(3);
<a class="l" name="3049" href="#3049">3049</a>}
<a class="hl" name="3050" href="#3050">3050</a>```
<a class="l" name="3051" href="#3051">3051</a>
<a class="l" name="3052" href="#3052">3052</a>The expectation spec says that the first `Bar("a")` must happen before check
<a class="l" name="3053" href="#3053">3053</a>point "1", the second `Bar("a")` must happen after check point "2", and nothing
<a class="l" name="3054" href="#3054">3054</a>should happen between the two check points. The explicit check points make it
<a class="l" name="3055" href="#3055">3055</a>easy to tell which `Bar("a")` is called by which call to `Foo()`.
<a class="l" name="3056" href="#3056">3056</a>
<a class="l" name="3057" href="#3057">3057</a>### Mocking Destructors
<a class="l" name="3058" href="#3058">3058</a>
<a class="l" name="3059" href="#3059">3059</a>Sometimes you want to make sure a mock object is destructed at the right time,
<a class="hl" name="3060" href="#3060">3060</a><a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> after `bar-&gt;A()` is called but before `bar-&gt;B()` is called. We already know
<a class="l" name="3061" href="#3061">3061</a>that you can specify constraints on the [order](#OrderedCalls) of mock function
<a class="l" name="3062" href="#3062">3062</a>calls, so all we need to do is to mock the destructor of the mock function.
<a class="l" name="3063" href="#3063">3063</a>
<a class="l" name="3064" href="#3064">3064</a>This sounds simple, except for one problem: a destructor is a special function
<a class="l" name="3065" href="#3065">3065</a>with special syntax and special semantics, and the `MOCK_METHOD` macro doesn't
<a class="l" name="3066" href="#3066">3066</a>work for it:
<a class="l" name="3067" href="#3067">3067</a>
<a class="l" name="3068" href="#3068">3068</a>```cpp
<a class="l" name="3069" href="#3069">3069</a>MOCK_METHOD(void, ~MockFoo, ());  // Won't compile!
<a class="hl" name="3070" href="#3070">3070</a>```
<a class="l" name="3071" href="#3071">3071</a>
<a class="l" name="3072" href="#3072">3072</a>The good news is that you can use a simple pattern to achieve the same effect.
<a class="l" name="3073" href="#3073">3073</a>First, add a mock function `Die()` to your mock class and call it in the
<a class="l" name="3074" href="#3074">3074</a>destructor, like this:
<a class="l" name="3075" href="#3075">3075</a>
<a class="l" name="3076" href="#3076">3076</a>```cpp
<a class="l" name="3077" href="#3077">3077</a>class MockFoo : public Foo {
<a class="l" name="3078" href="#3078">3078</a>  ...
<a class="l" name="3079" href="#3079">3079</a>  // Add the following two lines to the mock class.
<a class="hl" name="3080" href="#3080">3080</a>  MOCK_METHOD(void, Die, ());
<a class="l" name="3081" href="#3081">3081</a>  ~MockFoo() override { Die(); }
<a class="l" name="3082" href="#3082">3082</a>};
<a class="l" name="3083" href="#3083">3083</a>```
<a class="l" name="3084" href="#3084">3084</a>
<a class="l" name="3085" href="#3085">3085</a>(If the name `Die()` clashes with an existing symbol, choose another name.) Now,
<a class="l" name="3086" href="#3086">3086</a>we have translated the problem of testing when a `MockFoo` object dies to
<a class="l" name="3087" href="#3087">3087</a>testing when its `Die()` method is called:
<a class="l" name="3088" href="#3088">3088</a>
<a class="l" name="3089" href="#3089">3089</a>```cpp
<a class="hl" name="3090" href="#3090">3090</a>  MockFoo* foo = new MockFoo;
<a class="l" name="3091" href="#3091">3091</a>  MockBar* bar = new MockBar;
<a class="l" name="3092" href="#3092">3092</a>  ...
<a class="l" name="3093" href="#3093">3093</a>  {
<a class="l" name="3094" href="#3094">3094</a>    InSequence s;
<a class="l" name="3095" href="#3095">3095</a>
<a class="l" name="3096" href="#3096">3096</a>    // Expects *foo to die after bar-&gt;A() and before bar-&gt;B().
<a class="l" name="3097" href="#3097">3097</a>    EXPECT_CALL(*bar, A());
<a class="l" name="3098" href="#3098">3098</a>    EXPECT_CALL(*foo, Die());
<a class="l" name="3099" href="#3099">3099</a>    EXPECT_CALL(*bar, B());
<a class="hl" name="3100" href="#3100">3100</a>  }
<a class="l" name="3101" href="#3101">3101</a>```
<a class="l" name="3102" href="#3102">3102</a>
<a class="l" name="3103" href="#3103">3103</a>And that's that.
<a class="l" name="3104" href="#3104">3104</a>
<a class="l" name="3105" href="#3105">3105</a>### Using gMock and Threads {#UsingThreads}
<a class="l" name="3106" href="#3106">3106</a>
<a class="l" name="3107" href="#3107">3107</a>In a **unit** test, it's best if you could isolate and test a piece of code in a
<a class="l" name="3108" href="#3108">3108</a>single-threaded context. That avoids race conditions and dead locks, and makes
<a class="l" name="3109" href="#3109">3109</a>debugging your test much easier.
<a class="hl" name="3110" href="#3110">3110</a>
<a class="l" name="3111" href="#3111">3111</a>Yet most programs are multi-threaded, and sometimes to test something we need to
<a class="l" name="3112" href="#3112">3112</a>pound on it from more than one thread. gMock works for this purpose too.
<a class="l" name="3113" href="#3113">3113</a>
<a class="l" name="3114" href="#3114">3114</a>Remember the steps for using a mock:
<a class="l" name="3115" href="#3115">3115</a>
<a class="l" name="3116" href="#3116">3116</a>1.  Create a mock object `foo`.
<a class="l" name="3117" href="#3117">3117</a>2.  Set its default actions and expectations using `ON_CALL()` and
<a class="l" name="3118" href="#3118">3118</a>    `EXPECT_CALL()`.
<a class="l" name="3119" href="#3119">3119</a>3.  The code under test calls methods of `foo`.
<a class="hl" name="3120" href="#3120">3120</a>4.  Optionally, verify and reset the mock.
<a class="l" name="3121" href="#3121">3121</a>5.  Destroy the mock yourself, or let the code under test destroy it. The
<a class="l" name="3122" href="#3122">3122</a>    destructor will automatically verify it.
<a class="l" name="3123" href="#3123">3123</a>
<a class="l" name="3124" href="#3124">3124</a>If you follow the following simple rules, your mocks and threads can live
<a class="l" name="3125" href="#3125">3125</a>happily together:
<a class="l" name="3126" href="#3126">3126</a>
<a class="l" name="3127" href="#3127">3127</a>*   Execute your *test code* (as opposed to the code being tested) in *one*
<a class="l" name="3128" href="#3128">3128</a>    thread. This makes your test easy to follow.
<a class="l" name="3129" href="#3129">3129</a>*   Obviously, you can do step #1 without locking.
<a class="hl" name="3130" href="#3130">3130</a>*   When doing step #2 and #5, make sure no other thread is accessing `foo`.
<a class="l" name="3131" href="#3131">3131</a>    Obvious too, huh?
<a class="l" name="3132" href="#3132">3132</a>*   #3 and #4 can be done either in one thread or in multiple threads - anyway
<a class="l" name="3133" href="#3133">3133</a>    you want. gMock takes care of the locking, so you don't have to do any -
<a class="l" name="3134" href="#3134">3134</a>    unless required by your test logic.
<a class="l" name="3135" href="#3135">3135</a>
<a class="l" name="3136" href="#3136">3136</a>If you violate the rules (for example, if you set expectations on a mock while
<a class="l" name="3137" href="#3137">3137</a>another thread is calling its methods), you get undefined behavior. That's not
<a class="l" name="3138" href="#3138">3138</a>fun, so don't do it.
<a class="l" name="3139" href="#3139">3139</a>
<a class="hl" name="3140" href="#3140">3140</a>gMock guarantees that the action for a mock function is done in the same thread
<a class="l" name="3141" href="#3141">3141</a>that called the mock function. For example, in
<a class="l" name="3142" href="#3142">3142</a>
<a class="l" name="3143" href="#3143">3143</a>```cpp
<a class="l" name="3144" href="#3144">3144</a>  EXPECT_CALL(mock, Foo(1))
<a class="l" name="3145" href="#3145">3145</a>      .WillOnce(action1);
<a class="l" name="3146" href="#3146">3146</a>  EXPECT_CALL(mock, Foo(2))
<a class="l" name="3147" href="#3147">3147</a>      .WillOnce(action2);
<a class="l" name="3148" href="#3148">3148</a>```
<a class="l" name="3149" href="#3149">3149</a>
<a class="hl" name="3150" href="#3150">3150</a>if `Foo(1)` is called in thread 1 and `Foo(2)` is called in thread 2, gMock will
<a class="l" name="3151" href="#3151">3151</a>execute `action1` in thread 1 and `action2` in thread 2.
<a class="l" name="3152" href="#3152">3152</a>
<a class="l" name="3153" href="#3153">3153</a>gMock does *not* impose a sequence on actions performed in different threads
<a class="l" name="3154" href="#3154">3154</a>(doing so may create deadlocks as the actions may need to cooperate). This means
<a class="l" name="3155" href="#3155">3155</a>that the execution of `action1` and `action2` in the above example *may*
<a class="l" name="3156" href="#3156">3156</a>interleave. If this is a problem, you should add proper synchronization logic to
<a class="l" name="3157" href="#3157">3157</a>`action1` and `action2` to make the test thread-safe.
<a class="l" name="3158" href="#3158">3158</a>
<a class="l" name="3159" href="#3159">3159</a>Also, remember that `DefaultValue&lt;T&gt;` is a global resource that potentially
<a class="hl" name="3160" href="#3160">3160</a>affects *all* living mock objects in your program. Naturally, you won't want to
<a class="l" name="3161" href="#3161">3161</a>mess with it from multiple threads or when there still are mocks in action.
<a class="l" name="3162" href="#3162">3162</a>
<a class="l" name="3163" href="#3163">3163</a>### Controlling How Much Information gMock Prints
<a class="l" name="3164" href="#3164">3164</a>
<a class="l" name="3165" href="#3165">3165</a>When gMock sees something that has the potential of being an error (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> a mock
<a class="l" name="3166" href="#3166">3166</a>function with no expectation is called, <a href="/googletest/s?path=a.k.a.&amp;project=googletest">a.k.a.</a> an uninteresting call, which is
<a class="l" name="3167" href="#3167">3167</a>allowed but perhaps you forgot to explicitly ban the call), it prints some
<a class="l" name="3168" href="#3168">3168</a>warning messages, including the arguments of the function, the return value, and
<a class="l" name="3169" href="#3169">3169</a>the stack trace. Hopefully this will remind you to take a look and see if there
<a class="hl" name="3170" href="#3170">3170</a>is indeed a problem.
<a class="l" name="3171" href="#3171">3171</a>
<a class="l" name="3172" href="#3172">3172</a>Sometimes you are confident that your tests are correct and may not appreciate
<a class="l" name="3173" href="#3173">3173</a>such friendly messages. Some other times, you are debugging your tests or
<a class="l" name="3174" href="#3174">3174</a>learning about the behavior of the code you are testing, and wish you could
<a class="l" name="3175" href="#3175">3175</a>observe every mock call that happens (including argument values, the return
<a class="l" name="3176" href="#3176">3176</a>value, and the stack trace). Clearly, one size doesn't fit all.
<a class="l" name="3177" href="#3177">3177</a>
<a class="l" name="3178" href="#3178">3178</a>You can control how much gMock tells you using the `--gmock_verbose=LEVEL`
<a class="l" name="3179" href="#3179">3179</a>command-line flag, where `LEVEL` is a string with three possible values:
<a class="hl" name="3180" href="#3180">3180</a>
<a class="l" name="3181" href="#3181">3181</a>*   `info`: gMock will print all informational messages, warnings, and errors
<a class="l" name="3182" href="#3182">3182</a>    (most verbose). At this setting, gMock will also log any calls to the
<a class="l" name="3183" href="#3183">3183</a>    `<a href="/googletest/s?path=ON_CALL/EXPECT_CALL&amp;project=googletest">ON_CALL/EXPECT_CALL</a>` macros. It will include a stack trace in
<a class="l" name="3184" href="#3184">3184</a>    "uninteresting call" warnings.
<a class="l" name="3185" href="#3185">3185</a>*   `warning`: gMock will print both warnings and errors (less verbose); it will
<a class="l" name="3186" href="#3186">3186</a>    omit the stack traces in "uninteresting call" warnings. This is the default.
<a class="l" name="3187" href="#3187">3187</a>*   `error`: gMock will print errors only (least verbose).
<a class="l" name="3188" href="#3188">3188</a>
<a class="l" name="3189" href="#3189">3189</a>Alternatively, you can adjust the value of that flag from within your tests like
<a class="hl" name="3190" href="#3190">3190</a>so:
<a class="l" name="3191" href="#3191">3191</a>
<a class="l" name="3192" href="#3192">3192</a>```cpp
<a class="l" name="3193" href="#3193">3193</a>  ::testing::FLAGS_gmock_verbose = "error";
<a class="l" name="3194" href="#3194">3194</a>```
<a class="l" name="3195" href="#3195">3195</a>
<a class="l" name="3196" href="#3196">3196</a>If you find gMock printing too many stack frames with its informational or
<a class="l" name="3197" href="#3197">3197</a>warning messages, remember that you can control their amount with the
<a class="l" name="3198" href="#3198">3198</a>`--gtest_stack_trace_depth=max_depth` flag.
<a class="l" name="3199" href="#3199">3199</a>
<a class="hl" name="3200" href="#3200">3200</a>Now, judiciously use the right flag to enable gMock serve you better!
<a class="l" name="3201" href="#3201">3201</a>
<a class="l" name="3202" href="#3202">3202</a>### Gaining Super Vision into Mock Calls
<a class="l" name="3203" href="#3203">3203</a>
<a class="l" name="3204" href="#3204">3204</a>You have a test using gMock. It fails: gMock tells you some expectations aren't
<a class="l" name="3205" href="#3205">3205</a>satisfied. However, you aren't sure why: Is there a typo somewhere in the
<a class="l" name="3206" href="#3206">3206</a>matchers? Did you mess up the order of the `EXPECT_CALL`s? Or is the code under
<a class="l" name="3207" href="#3207">3207</a>test doing something wrong? How can you find out the cause?
<a class="l" name="3208" href="#3208">3208</a>
<a class="l" name="3209" href="#3209">3209</a>Won't it be nice if you have X-ray vision and can actually see the trace of all
<a class="hl" name="3210" href="#3210">3210</a>`EXPECT_CALL`s and mock method calls as they are made? For each call, would you
<a class="l" name="3211" href="#3211">3211</a>like to see its actual argument values and which `EXPECT_CALL` gMock thinks it
<a class="l" name="3212" href="#3212">3212</a>matches? If you still need some help to figure out who made these calls, how
<a class="l" name="3213" href="#3213">3213</a>about being able to see the complete stack trace at each mock call?
<a class="l" name="3214" href="#3214">3214</a>
<a class="l" name="3215" href="#3215">3215</a>You can unlock this power by running your test with the `--gmock_verbose=info`
<a class="l" name="3216" href="#3216">3216</a>flag. For example, given the test program:
<a class="l" name="3217" href="#3217">3217</a>
<a class="l" name="3218" href="#3218">3218</a>```cpp
<a class="l" name="3219" href="#3219">3219</a>#include "<a href="/googletest/s?path=gmock/gmock.h&amp;project=googletest">gmock/gmock.h</a>"
<a class="hl" name="3220" href="#3220">3220</a>
<a class="l" name="3221" href="#3221">3221</a>using testing::_;
<a class="l" name="3222" href="#3222">3222</a>using testing::HasSubstr;
<a class="l" name="3223" href="#3223">3223</a>using testing::Return;
<a class="l" name="3224" href="#3224">3224</a>
<a class="l" name="3225" href="#3225">3225</a>class MockFoo {
<a class="l" name="3226" href="#3226">3226</a> public:
<a class="l" name="3227" href="#3227">3227</a>  MOCK_METHOD(void, F, (const string&amp; x, const string&amp; y));
<a class="l" name="3228" href="#3228">3228</a>};
<a class="l" name="3229" href="#3229">3229</a>
<a class="hl" name="3230" href="#3230">3230</a>TEST(Foo, Bar) {
<a class="l" name="3231" href="#3231">3231</a>  MockFoo mock;
<a class="l" name="3232" href="#3232">3232</a>  EXPECT_CALL(mock, F(_, _)).WillRepeatedly(Return());
<a class="l" name="3233" href="#3233">3233</a>  EXPECT_CALL(mock, F("a", "b"));
<a class="l" name="3234" href="#3234">3234</a>  EXPECT_CALL(mock, F("c", HasSubstr("d")));
<a class="l" name="3235" href="#3235">3235</a>
<a class="l" name="3236" href="#3236">3236</a>  <a href="/googletest/s?path=mock.F&amp;project=googletest">mock.F</a>("a", "good");
<a class="l" name="3237" href="#3237">3237</a>  <a href="/googletest/s?path=mock.F&amp;project=googletest">mock.F</a>("a", "b");
<a class="l" name="3238" href="#3238">3238</a>}
<a class="l" name="3239" href="#3239">3239</a>```
<a class="hl" name="3240" href="#3240">3240</a>
<a class="l" name="3241" href="#3241">3241</a>if you run it with `--gmock_verbose=info`, you will see this output:
<a class="l" name="3242" href="#3242">3242</a>
<a class="l" name="3243" href="#3243">3243</a>```shell
<a class="l" name="3244" href="#3244">3244</a>[ RUN       ] <a href="/googletest/s?path=Foo.Bar&amp;project=googletest">Foo.Bar</a>
<a class="l" name="3245" href="#3245">3245</a>
<a class="l" name="3246" href="#3246">3246</a><a href="/googletest/s?path=foo_test.cc&amp;project=googletest">foo_test.cc</a>:14: EXPECT_CALL(mock, F(_, _)) invoked
<a class="l" name="3247" href="#3247">3247</a>Stack trace: ...
<a class="l" name="3248" href="#3248">3248</a>
<a class="l" name="3249" href="#3249">3249</a><a href="/googletest/s?path=foo_test.cc&amp;project=googletest">foo_test.cc</a>:15: EXPECT_CALL(mock, F("a", "b")) invoked
<a class="hl" name="3250" href="#3250">3250</a>Stack trace: ...
<a class="l" name="3251" href="#3251">3251</a>
<a class="l" name="3252" href="#3252">3252</a><a href="/googletest/s?path=foo_test.cc&amp;project=googletest">foo_test.cc</a>:16: EXPECT_CALL(mock, F("c", HasSubstr("d"))) invoked
<a class="l" name="3253" href="#3253">3253</a>Stack trace: ...
<a class="l" name="3254" href="#3254">3254</a>
<a class="l" name="3255" href="#3255">3255</a><a href="/googletest/s?path=foo_test.cc&amp;project=googletest">foo_test.cc</a>:14: Mock function call matches EXPECT_CALL(mock, F(_, _))...
<a class="l" name="3256" href="#3256">3256</a>    Function call: F(@0x7fff7c8dad40"a",@0x7fff7c8dad10"good")
<a class="l" name="3257" href="#3257">3257</a>Stack trace: ...
<a class="l" name="3258" href="#3258">3258</a>
<a class="l" name="3259" href="#3259">3259</a><a href="/googletest/s?path=foo_test.cc&amp;project=googletest">foo_test.cc</a>:15: Mock function call matches EXPECT_CALL(mock, F("a", "b"))...
<a class="hl" name="3260" href="#3260">3260</a>    Function call: F(@0x7fff7c8dada0"a",@0x7fff7c8dad70"b")
<a class="l" name="3261" href="#3261">3261</a>Stack trace: ...
<a class="l" name="3262" href="#3262">3262</a>
<a class="l" name="3263" href="#3263">3263</a><a href="/googletest/s?path=foo_test.cc&amp;project=googletest">foo_test.cc</a>:16: Failure
<a class="l" name="3264" href="#3264">3264</a>Actual function call count doesn't match EXPECT_CALL(mock, F("c", HasSubstr("d")))...
<a class="l" name="3265" href="#3265">3265</a>         Expected: to be called once
<a class="l" name="3266" href="#3266">3266</a>           Actual: never called - unsatisfied and active
<a class="l" name="3267" href="#3267">3267</a>[  FAILED  ] <a href="/googletest/s?path=Foo.Bar&amp;project=googletest">Foo.Bar</a>
<a class="l" name="3268" href="#3268">3268</a>```
<a class="l" name="3269" href="#3269">3269</a>
<a class="hl" name="3270" href="#3270">3270</a>Suppose the bug is that the `"c"` in the third `EXPECT_CALL` is a typo and
<a class="l" name="3271" href="#3271">3271</a>should actually be `"a"`. With the above message, you should see that the actual
<a class="l" name="3272" href="#3272">3272</a>`F("a", "good")` call is matched by the first `EXPECT_CALL`, not the third as
<a class="l" name="3273" href="#3273">3273</a>you thought. From that it should be obvious that the third `EXPECT_CALL` is
<a class="l" name="3274" href="#3274">3274</a>written wrong. Case solved.
<a class="l" name="3275" href="#3275">3275</a>
<a class="l" name="3276" href="#3276">3276</a>If you are interested in the mock call trace but not the stack traces, you can
<a class="l" name="3277" href="#3277">3277</a>combine `--gmock_verbose=info` with `--gtest_stack_trace_depth=0` on the test
<a class="l" name="3278" href="#3278">3278</a>command line.
<a class="l" name="3279" href="#3279">3279</a>
<a class="hl" name="3280" href="#3280">3280</a>&lt;!-- GOOGLETEST_CM0025 DO NOT DELETE --&gt;
<a class="l" name="3281" href="#3281">3281</a>
<a class="l" name="3282" href="#3282">3282</a>### Running Tests in Emacs
<a class="l" name="3283" href="#3283">3283</a>
<a class="l" name="3284" href="#3284">3284</a>If you build and run your tests in Emacs using the `M-x google-compile` command
<a class="l" name="3285" href="#3285">3285</a>(as many googletest users do), the source file locations of gMock and googletest
<a class="l" name="3286" href="#3286">3286</a>errors will be highlighted. Just press `&lt;Enter&gt;` on one of them and you'll be
<a class="l" name="3287" href="#3287">3287</a>taken to the offending line. Or, you can just type `C-x`` to jump to the next
<a class="l" name="3288" href="#3288">3288</a>error.
<a class="l" name="3289" href="#3289">3289</a>
<a class="hl" name="3290" href="#3290">3290</a>To make it even easier, you can add the following lines to your `~/.emacs` file:
<a class="l" name="3291" href="#3291">3291</a>
<a class="l" name="3292" href="#3292">3292</a>```text
<a class="l" name="3293" href="#3293">3293</a>(global-set-key "\M-m"  'google-compile)  ; m is for make
<a class="l" name="3294" href="#3294">3294</a>(global-set-key [M-down] 'next-error)
<a class="l" name="3295" href="#3295">3295</a>(global-set-key [M-up]  '(lambda () (interactive) (next-error -1)))
<a class="l" name="3296" href="#3296">3296</a>```
<a class="l" name="3297" href="#3297">3297</a>
<a class="l" name="3298" href="#3298">3298</a>Then you can type `M-m` to start a build (if you want to run the test as well,
<a class="l" name="3299" href="#3299">3299</a>just make sure `<a href="/googletest/s?path=foo_test.run&amp;project=googletest">foo_test.run</a>` or `runtests` is in the build command you supply
<a class="hl" name="3300" href="#3300">3300</a>after typing `M-m`), or `M-up`/`M-down` to move back and forth between errors.
<a class="l" name="3301" href="#3301">3301</a>
<a class="l" name="3302" href="#3302">3302</a>## Extending gMock
<a class="l" name="3303" href="#3303">3303</a>
<a class="l" name="3304" href="#3304">3304</a>### Writing New Matchers Quickly {#NewMatchers}
<a class="l" name="3305" href="#3305">3305</a>
<a class="l" name="3306" href="#3306">3306</a>WARNING: gMock does not guarantee when or how many times a matcher will be
<a class="l" name="3307" href="#3307">3307</a>invoked. Therefore, all matchers must be functionally pure. See
<a class="l" name="3308" href="#3308">3308</a>[this section](#PureMatchers) for more details.
<a class="l" name="3309" href="#3309">3309</a>
<a class="hl" name="3310" href="#3310">3310</a>The `MATCHER*` family of macros can be used to define custom matchers easily.
<a class="l" name="3311" href="#3311">3311</a>The syntax:
<a class="l" name="3312" href="#3312">3312</a>
<a class="l" name="3313" href="#3313">3313</a>```cpp
<a class="l" name="3314" href="#3314">3314</a>MATCHER(name, description_string_expression) { statements; }
<a class="l" name="3315" href="#3315">3315</a>```
<a class="l" name="3316" href="#3316">3316</a>
<a class="l" name="3317" href="#3317">3317</a>will define a matcher with the given name that executes the statements, which
<a class="l" name="3318" href="#3318">3318</a>must return a `bool` to indicate if the match succeeds. Inside the statements,
<a class="l" name="3319" href="#3319">3319</a>you can refer to the value being matched by `arg`, and refer to its type by
<a class="hl" name="3320" href="#3320">3320</a>`arg_type`.
<a class="l" name="3321" href="#3321">3321</a>
<a class="l" name="3322" href="#3322">3322</a>The *description string* is a `string`-typed expression that documents what the
<a class="l" name="3323" href="#3323">3323</a>matcher does, and is used to generate the failure message when the match fails.
<a class="l" name="3324" href="#3324">3324</a>It can (and should) reference the special `bool` variable `negation`, and should
<a class="l" name="3325" href="#3325">3325</a>evaluate to the description of the matcher when `negation` is `false`, or that
<a class="l" name="3326" href="#3326">3326</a>of the matcher's negation when `negation` is `true`.
<a class="l" name="3327" href="#3327">3327</a>
<a class="l" name="3328" href="#3328">3328</a>For convenience, we allow the description string to be empty (`""`), in which
<a class="l" name="3329" href="#3329">3329</a>case gMock will use the sequence of words in the matcher name as the
<a class="hl" name="3330" href="#3330">3330</a>description.
<a class="l" name="3331" href="#3331">3331</a>
<a class="l" name="3332" href="#3332">3332</a>For example:
<a class="l" name="3333" href="#3333">3333</a>
<a class="l" name="3334" href="#3334">3334</a>```cpp
<a class="l" name="3335" href="#3335">3335</a>MATCHER(IsDivisibleBy7, "") { return (arg % 7) == 0; }
<a class="l" name="3336" href="#3336">3336</a>```
<a class="l" name="3337" href="#3337">3337</a>
<a class="l" name="3338" href="#3338">3338</a>allows you to write
<a class="l" name="3339" href="#3339">3339</a>
<a class="hl" name="3340" href="#3340">3340</a>```cpp
<a class="l" name="3341" href="#3341">3341</a>  // Expects <a href="/googletest/s?path=mock_foo.Bar&amp;project=googletest">mock_foo.Bar</a>(n) to be called where n is divisible by 7.
<a class="l" name="3342" href="#3342">3342</a>  EXPECT_CALL(mock_foo, Bar(IsDivisibleBy7()));
<a class="l" name="3343" href="#3343">3343</a>```
<a class="l" name="3344" href="#3344">3344</a>
<a class="l" name="3345" href="#3345">3345</a>or,
<a class="l" name="3346" href="#3346">3346</a>
<a class="l" name="3347" href="#3347">3347</a>```cpp
<a class="l" name="3348" href="#3348">3348</a>  using ::testing::Not;
<a class="l" name="3349" href="#3349">3349</a>  ...
<a class="hl" name="3350" href="#3350">3350</a>  // Verifies that two values are divisible by 7.
<a class="l" name="3351" href="#3351">3351</a>  EXPECT_THAT(some_expression, IsDivisibleBy7());
<a class="l" name="3352" href="#3352">3352</a>  EXPECT_THAT(some_other_expression, Not(IsDivisibleBy7()));
<a class="l" name="3353" href="#3353">3353</a>```
<a class="l" name="3354" href="#3354">3354</a>
<a class="l" name="3355" href="#3355">3355</a>If the above assertions fail, they will print something like:
<a class="l" name="3356" href="#3356">3356</a>
<a class="l" name="3357" href="#3357">3357</a>```shell
<a class="l" name="3358" href="#3358">3358</a>  Value of: some_expression
<a class="l" name="3359" href="#3359">3359</a>  Expected: is divisible by 7
<a class="hl" name="3360" href="#3360">3360</a>    Actual: 27
<a class="l" name="3361" href="#3361">3361</a>  ...
<a class="l" name="3362" href="#3362">3362</a>  Value of: some_other_expression
<a class="l" name="3363" href="#3363">3363</a>  Expected: not (is divisible by 7)
<a class="l" name="3364" href="#3364">3364</a>    Actual: 21
<a class="l" name="3365" href="#3365">3365</a>```
<a class="l" name="3366" href="#3366">3366</a>
<a class="l" name="3367" href="#3367">3367</a>where the descriptions `"is divisible by 7"` and `"not (is divisible by 7)"` are
<a class="l" name="3368" href="#3368">3368</a>automatically calculated from the matcher name `IsDivisibleBy7`.
<a class="l" name="3369" href="#3369">3369</a>
<a class="hl" name="3370" href="#3370">3370</a>As you may have noticed, the auto-generated descriptions (especially those for
<a class="l" name="3371" href="#3371">3371</a>the negation) may not be so great. You can always override them with a `string`
<a class="l" name="3372" href="#3372">3372</a>expression of your own:
<a class="l" name="3373" href="#3373">3373</a>
<a class="l" name="3374" href="#3374">3374</a>```cpp
<a class="l" name="3375" href="#3375">3375</a>MATCHER(IsDivisibleBy7,
<a class="l" name="3376" href="#3376">3376</a>        absl::StrCat(negation ? "isn't" : "is", " divisible by 7")) {
<a class="l" name="3377" href="#3377">3377</a>  return (arg % 7) == 0;
<a class="l" name="3378" href="#3378">3378</a>}
<a class="l" name="3379" href="#3379">3379</a>```
<a class="hl" name="3380" href="#3380">3380</a>
<a class="l" name="3381" href="#3381">3381</a>Optionally, you can stream additional information to a hidden argument named
<a class="l" name="3382" href="#3382">3382</a>`result_listener` to explain the match result. For example, a better definition
<a class="l" name="3383" href="#3383">3383</a>of `IsDivisibleBy7` is:
<a class="l" name="3384" href="#3384">3384</a>
<a class="l" name="3385" href="#3385">3385</a>```cpp
<a class="l" name="3386" href="#3386">3386</a>MATCHER(IsDivisibleBy7, "") {
<a class="l" name="3387" href="#3387">3387</a>  if ((arg % 7) == 0)
<a class="l" name="3388" href="#3388">3388</a>    return true;
<a class="l" name="3389" href="#3389">3389</a>
<a class="hl" name="3390" href="#3390">3390</a>  *result_listener &lt;&lt; "the remainder is " &lt;&lt; (arg % 7);
<a class="l" name="3391" href="#3391">3391</a>  return false;
<a class="l" name="3392" href="#3392">3392</a>}
<a class="l" name="3393" href="#3393">3393</a>```
<a class="l" name="3394" href="#3394">3394</a>
<a class="l" name="3395" href="#3395">3395</a>With this definition, the above assertion will give a better message:
<a class="l" name="3396" href="#3396">3396</a>
<a class="l" name="3397" href="#3397">3397</a>```shell
<a class="l" name="3398" href="#3398">3398</a>  Value of: some_expression
<a class="l" name="3399" href="#3399">3399</a>  Expected: is divisible by 7
<a class="hl" name="3400" href="#3400">3400</a>    Actual: 27 (the remainder is 6)
<a class="l" name="3401" href="#3401">3401</a>```
<a class="l" name="3402" href="#3402">3402</a>
<a class="l" name="3403" href="#3403">3403</a>You should let `MatchAndExplain()` print *any additional information* that can
<a class="l" name="3404" href="#3404">3404</a>help a user understand the match result. Note that it should explain why the
<a class="l" name="3405" href="#3405">3405</a>match succeeds in case of a success (unless it's obvious) - this is useful when
<a class="l" name="3406" href="#3406">3406</a>the matcher is used inside `Not()`. There is no need to print the argument value
<a class="l" name="3407" href="#3407">3407</a>itself, as gMock already prints it for you.
<a class="l" name="3408" href="#3408">3408</a>
<a class="l" name="3409" href="#3409">3409</a>NOTE: The type of the value being matched (`arg_type`) is determined by the
<a class="hl" name="3410" href="#3410">3410</a>context in which you use the matcher and is supplied to you by the compiler, so
<a class="l" name="3411" href="#3411">3411</a>you don't need to worry about declaring it (nor can you). This allows the
<a class="l" name="3412" href="#3412">3412</a>matcher to be polymorphic. For example, `IsDivisibleBy7()` can be used to match
<a class="l" name="3413" href="#3413">3413</a>any type where the value of `(arg % 7) == 0` can be implicitly converted to a
<a class="l" name="3414" href="#3414">3414</a>`bool`. In the `Bar(IsDivisibleBy7())` example above, if method `Bar()` takes an
<a class="l" name="3415" href="#3415">3415</a>`int`, `arg_type` will be `int`; if it takes an `unsigned long`, `arg_type` will
<a class="l" name="3416" href="#3416">3416</a>be `unsigned long`; and so on.
<a class="l" name="3417" href="#3417">3417</a>
<a class="l" name="3418" href="#3418">3418</a>### Writing New Parameterized Matchers Quickly
<a class="l" name="3419" href="#3419">3419</a>
<a class="hl" name="3420" href="#3420">3420</a>Sometimes you'll want to define a matcher that has parameters. For that you can
<a class="l" name="3421" href="#3421">3421</a>use the macro:
<a class="l" name="3422" href="#3422">3422</a>
<a class="l" name="3423" href="#3423">3423</a>```cpp
<a class="l" name="3424" href="#3424">3424</a>MATCHER_P(name, param_name, description_string) { statements; }
<a class="l" name="3425" href="#3425">3425</a>```
<a class="l" name="3426" href="#3426">3426</a>
<a class="l" name="3427" href="#3427">3427</a>where the description string can be either `""` or a `string` expression that
<a class="l" name="3428" href="#3428">3428</a>references `negation` and `param_name`.
<a class="l" name="3429" href="#3429">3429</a>
<a class="hl" name="3430" href="#3430">3430</a>For example:
<a class="l" name="3431" href="#3431">3431</a>
<a class="l" name="3432" href="#3432">3432</a>```cpp
<a class="l" name="3433" href="#3433">3433</a>MATCHER_P(HasAbsoluteValue, value, "") { return abs(arg) == value; }
<a class="l" name="3434" href="#3434">3434</a>```
<a class="l" name="3435" href="#3435">3435</a>
<a class="l" name="3436" href="#3436">3436</a>will allow you to write:
<a class="l" name="3437" href="#3437">3437</a>
<a class="l" name="3438" href="#3438">3438</a>```cpp
<a class="l" name="3439" href="#3439">3439</a>  EXPECT_THAT(Blah("a"), HasAbsoluteValue(n));
<a class="hl" name="3440" href="#3440">3440</a>```
<a class="l" name="3441" href="#3441">3441</a>
<a class="l" name="3442" href="#3442">3442</a>which may lead to this message (assuming `n` is 10):
<a class="l" name="3443" href="#3443">3443</a>
<a class="l" name="3444" href="#3444">3444</a>```shell
<a class="l" name="3445" href="#3445">3445</a>  Value of: Blah("a")
<a class="l" name="3446" href="#3446">3446</a>  Expected: has absolute value 10
<a class="l" name="3447" href="#3447">3447</a>    Actual: -9
<a class="l" name="3448" href="#3448">3448</a>```
<a class="l" name="3449" href="#3449">3449</a>
<a class="hl" name="3450" href="#3450">3450</a>Note that both the matcher description and its parameter are printed, making the
<a class="l" name="3451" href="#3451">3451</a>message human-friendly.
<a class="l" name="3452" href="#3452">3452</a>
<a class="l" name="3453" href="#3453">3453</a>In the matcher definition body, you can write `foo_type` to reference the type
<a class="l" name="3454" href="#3454">3454</a>of a parameter named `foo`. For example, in the body of
<a class="l" name="3455" href="#3455">3455</a>`MATCHER_P(HasAbsoluteValue, value)` above, you can write `value_type` to refer
<a class="l" name="3456" href="#3456">3456</a>to the type of `value`.
<a class="l" name="3457" href="#3457">3457</a>
<a class="l" name="3458" href="#3458">3458</a>gMock also provides `MATCHER_P2`, `MATCHER_P3`, ..., up to `MATCHER_P10` to
<a class="l" name="3459" href="#3459">3459</a>support multi-parameter matchers:
<a class="hl" name="3460" href="#3460">3460</a>
<a class="l" name="3461" href="#3461">3461</a>```cpp
<a class="l" name="3462" href="#3462">3462</a>MATCHER_Pk(name, param_1, ..., param_k, description_string) { statements; }
<a class="l" name="3463" href="#3463">3463</a>```
<a class="l" name="3464" href="#3464">3464</a>
<a class="l" name="3465" href="#3465">3465</a>Please note that the custom description string is for a particular *instance* of
<a class="l" name="3466" href="#3466">3466</a>the matcher, where the parameters have been bound to actual values. Therefore
<a class="l" name="3467" href="#3467">3467</a>usually you'll want the parameter values to be part of the description. gMock
<a class="l" name="3468" href="#3468">3468</a>lets you do that by referencing the matcher parameters in the description string
<a class="l" name="3469" href="#3469">3469</a>expression.
<a class="hl" name="3470" href="#3470">3470</a>
<a class="l" name="3471" href="#3471">3471</a>For example,
<a class="l" name="3472" href="#3472">3472</a>
<a class="l" name="3473" href="#3473">3473</a>```cpp
<a class="l" name="3474" href="#3474">3474</a>using ::testing::PrintToString;
<a class="l" name="3475" href="#3475">3475</a>MATCHER_P2(InClosedRange, low, hi,
<a class="l" name="3476" href="#3476">3476</a>           absl::StrFormat("%s in range [%s, %s]", negation ? "isn't" : "is",
<a class="l" name="3477" href="#3477">3477</a>                           PrintToString(low), PrintToString(hi))) {
<a class="l" name="3478" href="#3478">3478</a>  return low &lt;= arg &amp;&amp; arg &lt;= hi;
<a class="l" name="3479" href="#3479">3479</a>}
<a class="hl" name="3480" href="#3480">3480</a>...
<a class="l" name="3481" href="#3481">3481</a>EXPECT_THAT(3, InClosedRange(4, 6));
<a class="l" name="3482" href="#3482">3482</a>```
<a class="l" name="3483" href="#3483">3483</a>
<a class="l" name="3484" href="#3484">3484</a>would generate a failure that contains the message:
<a class="l" name="3485" href="#3485">3485</a>
<a class="l" name="3486" href="#3486">3486</a>```shell
<a class="l" name="3487" href="#3487">3487</a>  Expected: is in range [4, 6]
<a class="l" name="3488" href="#3488">3488</a>```
<a class="l" name="3489" href="#3489">3489</a>
<a class="hl" name="3490" href="#3490">3490</a>If you specify `""` as the description, the failure message will contain the
<a class="l" name="3491" href="#3491">3491</a>sequence of words in the matcher name followed by the parameter values printed
<a class="l" name="3492" href="#3492">3492</a>as a tuple. For example,
<a class="l" name="3493" href="#3493">3493</a>
<a class="l" name="3494" href="#3494">3494</a>```cpp
<a class="l" name="3495" href="#3495">3495</a>  MATCHER_P2(InClosedRange, low, hi, "") { ... }
<a class="l" name="3496" href="#3496">3496</a>  ...
<a class="l" name="3497" href="#3497">3497</a>  EXPECT_THAT(3, InClosedRange(4, 6));
<a class="l" name="3498" href="#3498">3498</a>```
<a class="l" name="3499" href="#3499">3499</a>
<a class="hl" name="3500" href="#3500">3500</a>would generate a failure that contains the text:
<a class="l" name="3501" href="#3501">3501</a>
<a class="l" name="3502" href="#3502">3502</a>```shell
<a class="l" name="3503" href="#3503">3503</a>  Expected: in closed range (4, 6)
<a class="l" name="3504" href="#3504">3504</a>```
<a class="l" name="3505" href="#3505">3505</a>
<a class="l" name="3506" href="#3506">3506</a>For the purpose of typing, you can view
<a class="l" name="3507" href="#3507">3507</a>
<a class="l" name="3508" href="#3508">3508</a>```cpp
<a class="l" name="3509" href="#3509">3509</a>MATCHER_Pk(Foo, p1, ..., pk, description_string) { ... }
<a class="hl" name="3510" href="#3510">3510</a>```
<a class="l" name="3511" href="#3511">3511</a>
<a class="l" name="3512" href="#3512">3512</a>as shorthand for
<a class="l" name="3513" href="#3513">3513</a>
<a class="l" name="3514" href="#3514">3514</a>```cpp
<a class="l" name="3515" href="#3515">3515</a>template &lt;typename p1_type, ..., typename pk_type&gt;
<a class="l" name="3516" href="#3516">3516</a>FooMatcherPk&lt;p1_type, ..., pk_type&gt;
<a class="l" name="3517" href="#3517">3517</a>Foo(p1_type p1, ..., pk_type pk) { ... }
<a class="l" name="3518" href="#3518">3518</a>```
<a class="l" name="3519" href="#3519">3519</a>
<a class="hl" name="3520" href="#3520">3520</a>When you write `Foo(v1, ..., vk)`, the compiler infers the types of the
<a class="l" name="3521" href="#3521">3521</a>parameters `v1`, ..., and `vk` for you. If you are not happy with the result of
<a class="l" name="3522" href="#3522">3522</a>the type inference, you can specify the types by explicitly instantiating the
<a class="l" name="3523" href="#3523">3523</a>template, as in `Foo&lt;long, bool&gt;(5, false)`. As said earlier, you don't get to
<a class="l" name="3524" href="#3524">3524</a>(or need to) specify `arg_type` as that's determined by the context in which the
<a class="l" name="3525" href="#3525">3525</a>matcher is used.
<a class="l" name="3526" href="#3526">3526</a>
<a class="l" name="3527" href="#3527">3527</a>You can assign the result of expression `Foo(p1, ..., pk)` to a variable of type
<a class="l" name="3528" href="#3528">3528</a>`FooMatcherPk&lt;p1_type, ..., pk_type&gt;`. This can be useful when composing
<a class="l" name="3529" href="#3529">3529</a>matchers. Matchers that don't have a parameter or have only one parameter have
<a class="hl" name="3530" href="#3530">3530</a>special types: you can assign `Foo()` to a `FooMatcher`-typed variable, and
<a class="l" name="3531" href="#3531">3531</a>assign `Foo(p)` to a `FooMatcherP&lt;p_type&gt;`-typed variable.
<a class="l" name="3532" href="#3532">3532</a>
<a class="l" name="3533" href="#3533">3533</a>While you can instantiate a matcher template with reference types, passing the
<a class="l" name="3534" href="#3534">3534</a>parameters by pointer usually makes your code more readable. If, however, you
<a class="l" name="3535" href="#3535">3535</a>still want to pass a parameter by reference, be aware that in the failure
<a class="l" name="3536" href="#3536">3536</a>message generated by the matcher you will see the value of the referenced object
<a class="l" name="3537" href="#3537">3537</a>but not its address.
<a class="l" name="3538" href="#3538">3538</a>
<a class="l" name="3539" href="#3539">3539</a>You can overload matchers with different numbers of parameters:
<a class="hl" name="3540" href="#3540">3540</a>
<a class="l" name="3541" href="#3541">3541</a>```cpp
<a class="l" name="3542" href="#3542">3542</a>MATCHER_P(Blah, a, description_string_1) { ... }
<a class="l" name="3543" href="#3543">3543</a>MATCHER_P2(Blah, a, b, description_string_2) { ... }
<a class="l" name="3544" href="#3544">3544</a>```
<a class="l" name="3545" href="#3545">3545</a>
<a class="l" name="3546" href="#3546">3546</a>While it's tempting to always use the `MATCHER*` macros when defining a new
<a class="l" name="3547" href="#3547">3547</a>matcher, you should also consider implementing `MatcherInterface` or using
<a class="l" name="3548" href="#3548">3548</a>`MakePolymorphicMatcher()` instead (see the recipes that follow), especially if
<a class="l" name="3549" href="#3549">3549</a>you need to use the matcher a lot. While these approaches require more work,
<a class="hl" name="3550" href="#3550">3550</a>they give you more control on the types of the value being matched and the
<a class="l" name="3551" href="#3551">3551</a>matcher parameters, which in general leads to better compiler error messages
<a class="l" name="3552" href="#3552">3552</a>that pay off in the long run. They also allow overloading matchers based on
<a class="l" name="3553" href="#3553">3553</a>parameter types (as opposed to just based on the number of parameters).
<a class="l" name="3554" href="#3554">3554</a>
<a class="l" name="3555" href="#3555">3555</a>### Writing New Monomorphic Matchers
<a class="l" name="3556" href="#3556">3556</a>
<a class="l" name="3557" href="#3557">3557</a>A matcher of argument type `T` implements `::testing::MatcherInterface&lt;T&gt;` and
<a class="l" name="3558" href="#3558">3558</a>does two things: it tests whether a value of type `T` matches the matcher, and
<a class="l" name="3559" href="#3559">3559</a>can describe what kind of values it matches. The latter ability is used for
<a class="hl" name="3560" href="#3560">3560</a>generating readable error messages when expectations are violated.
<a class="l" name="3561" href="#3561">3561</a>
<a class="l" name="3562" href="#3562">3562</a>The interface looks like this:
<a class="l" name="3563" href="#3563">3563</a>
<a class="l" name="3564" href="#3564">3564</a>```cpp
<a class="l" name="3565" href="#3565">3565</a>class MatchResultListener {
<a class="l" name="3566" href="#3566">3566</a> public:
<a class="l" name="3567" href="#3567">3567</a>  ...
<a class="l" name="3568" href="#3568">3568</a>  // Streams x to the underlying ostream; does nothing if the ostream
<a class="l" name="3569" href="#3569">3569</a>  // is NULL.
<a class="hl" name="3570" href="#3570">3570</a>  template &lt;typename T&gt;
<a class="l" name="3571" href="#3571">3571</a>  MatchResultListener&amp; operator&lt;&lt;(const T&amp; x);
<a class="l" name="3572" href="#3572">3572</a>
<a class="l" name="3573" href="#3573">3573</a>  // Returns the underlying ostream.
<a class="l" name="3574" href="#3574">3574</a>  std::ostream* stream();
<a class="l" name="3575" href="#3575">3575</a>};
<a class="l" name="3576" href="#3576">3576</a>
<a class="l" name="3577" href="#3577">3577</a>template &lt;typename T&gt;
<a class="l" name="3578" href="#3578">3578</a>class MatcherInterface {
<a class="l" name="3579" href="#3579">3579</a> public:
<a class="hl" name="3580" href="#3580">3580</a>  virtual ~MatcherInterface();
<a class="l" name="3581" href="#3581">3581</a>
<a class="l" name="3582" href="#3582">3582</a>  // Returns true if and only if the matcher matches x; also explains the match
<a class="l" name="3583" href="#3583">3583</a>  // result to 'listener'.
<a class="l" name="3584" href="#3584">3584</a>  virtual bool MatchAndExplain(T x, MatchResultListener* listener) const = 0;
<a class="l" name="3585" href="#3585">3585</a>
<a class="l" name="3586" href="#3586">3586</a>  // Describes this matcher to an ostream.
<a class="l" name="3587" href="#3587">3587</a>  virtual void DescribeTo(std::ostream* os) const = 0;
<a class="l" name="3588" href="#3588">3588</a>
<a class="l" name="3589" href="#3589">3589</a>  // Describes the negation of this matcher to an ostream.
<a class="hl" name="3590" href="#3590">3590</a>  virtual void DescribeNegationTo(std::ostream* os) const;
<a class="l" name="3591" href="#3591">3591</a>};
<a class="l" name="3592" href="#3592">3592</a>```
<a class="l" name="3593" href="#3593">3593</a>
<a class="l" name="3594" href="#3594">3594</a>If you need a custom matcher but `Truly()` is not a good option (for example,
<a class="l" name="3595" href="#3595">3595</a>you may not be happy with the way `Truly(predicate)` describes itself, or you
<a class="l" name="3596" href="#3596">3596</a>may want your matcher to be polymorphic as `Eq(value)` is), you can define a
<a class="l" name="3597" href="#3597">3597</a>matcher to do whatever you want in two steps: first implement the matcher
<a class="l" name="3598" href="#3598">3598</a>interface, and then define a factory function to create a matcher instance. The
<a class="l" name="3599" href="#3599">3599</a>second step is not strictly needed but it makes the syntax of using the matcher
<a class="hl" name="3600" href="#3600">3600</a>nicer.
<a class="l" name="3601" href="#3601">3601</a>
<a class="l" name="3602" href="#3602">3602</a>For example, you can define a matcher to test whether an `int` is divisible by 7
<a class="l" name="3603" href="#3603">3603</a>and then use it like this:
<a class="l" name="3604" href="#3604">3604</a>
<a class="l" name="3605" href="#3605">3605</a>```cpp
<a class="l" name="3606" href="#3606">3606</a>using ::testing::MakeMatcher;
<a class="l" name="3607" href="#3607">3607</a>using ::testing::Matcher;
<a class="l" name="3608" href="#3608">3608</a>using ::testing::MatcherInterface;
<a class="l" name="3609" href="#3609">3609</a>using ::testing::MatchResultListener;
<a class="hl" name="3610" href="#3610">3610</a>
<a class="l" name="3611" href="#3611">3611</a>class DivisibleBy7Matcher : public MatcherInterface&lt;int&gt; {
<a class="l" name="3612" href="#3612">3612</a> public:
<a class="l" name="3613" href="#3613">3613</a>  bool MatchAndExplain(int n,
<a class="l" name="3614" href="#3614">3614</a>                       MatchResultListener* /* listener */) const override {
<a class="l" name="3615" href="#3615">3615</a>    return (n % 7) == 0;
<a class="l" name="3616" href="#3616">3616</a>  }
<a class="l" name="3617" href="#3617">3617</a>
<a class="l" name="3618" href="#3618">3618</a>  void DescribeTo(std::ostream* os) const override {
<a class="l" name="3619" href="#3619">3619</a>    *os &lt;&lt; "is divisible by 7";
<a class="hl" name="3620" href="#3620">3620</a>  }
<a class="l" name="3621" href="#3621">3621</a>
<a class="l" name="3622" href="#3622">3622</a>  void DescribeNegationTo(std::ostream* os) const override {
<a class="l" name="3623" href="#3623">3623</a>    *os &lt;&lt; "is not divisible by 7";
<a class="l" name="3624" href="#3624">3624</a>  }
<a class="l" name="3625" href="#3625">3625</a>};
<a class="l" name="3626" href="#3626">3626</a>
<a class="l" name="3627" href="#3627">3627</a>Matcher&lt;int&gt; DivisibleBy7() {
<a class="l" name="3628" href="#3628">3628</a>  return MakeMatcher(new DivisibleBy7Matcher);
<a class="l" name="3629" href="#3629">3629</a>}
<a class="hl" name="3630" href="#3630">3630</a>
<a class="l" name="3631" href="#3631">3631</a>...
<a class="l" name="3632" href="#3632">3632</a>  EXPECT_CALL(foo, Bar(DivisibleBy7()));
<a class="l" name="3633" href="#3633">3633</a>```
<a class="l" name="3634" href="#3634">3634</a>
<a class="l" name="3635" href="#3635">3635</a>You may improve the matcher message by streaming additional information to the
<a class="l" name="3636" href="#3636">3636</a>`listener` argument in `MatchAndExplain()`:
<a class="l" name="3637" href="#3637">3637</a>
<a class="l" name="3638" href="#3638">3638</a>```cpp
<a class="l" name="3639" href="#3639">3639</a>class DivisibleBy7Matcher : public MatcherInterface&lt;int&gt; {
<a class="hl" name="3640" href="#3640">3640</a> public:
<a class="l" name="3641" href="#3641">3641</a>  bool MatchAndExplain(int n,
<a class="l" name="3642" href="#3642">3642</a>                       MatchResultListener* listener) const override {
<a class="l" name="3643" href="#3643">3643</a>    const int remainder = n % 7;
<a class="l" name="3644" href="#3644">3644</a>    if (remainder != 0) {
<a class="l" name="3645" href="#3645">3645</a>      *listener &lt;&lt; "the remainder is " &lt;&lt; remainder;
<a class="l" name="3646" href="#3646">3646</a>    }
<a class="l" name="3647" href="#3647">3647</a>    return remainder == 0;
<a class="l" name="3648" href="#3648">3648</a>  }
<a class="l" name="3649" href="#3649">3649</a>  ...
<a class="hl" name="3650" href="#3650">3650</a>};
<a class="l" name="3651" href="#3651">3651</a>```
<a class="l" name="3652" href="#3652">3652</a>
<a class="l" name="3653" href="#3653">3653</a>Then, `EXPECT_THAT(x, DivisibleBy7());` may generate a message like this:
<a class="l" name="3654" href="#3654">3654</a>
<a class="l" name="3655" href="#3655">3655</a>```shell
<a class="l" name="3656" href="#3656">3656</a>Value of: x
<a class="l" name="3657" href="#3657">3657</a>Expected: is divisible by 7
<a class="l" name="3658" href="#3658">3658</a>  Actual: 23 (the remainder is 2)
<a class="l" name="3659" href="#3659">3659</a>```
<a class="hl" name="3660" href="#3660">3660</a>
<a class="l" name="3661" href="#3661">3661</a>### Writing New Polymorphic Matchers
<a class="l" name="3662" href="#3662">3662</a>
<a class="l" name="3663" href="#3663">3663</a>You've learned how to write your own matchers in the previous recipe. Just one
<a class="l" name="3664" href="#3664">3664</a>problem: a matcher created using `MakeMatcher()` only works for one particular
<a class="l" name="3665" href="#3665">3665</a>type of arguments. If you want a *polymorphic* matcher that works with arguments
<a class="l" name="3666" href="#3666">3666</a>of several types (for instance, `Eq(x)` can be used to match a *`value`* as long
<a class="l" name="3667" href="#3667">3667</a>as `value == x` compiles -- *`value`* and `x` don't have to share the same
<a class="l" name="3668" href="#3668">3668</a>type), you can learn the trick from `<a href="/googletest/s?path=testing/base/public/gmock-matchers.h&amp;project=googletest">testing/base/public/gmock-matchers.h</a>` but
<a class="l" name="3669" href="#3669">3669</a>it's a bit involved.
<a class="hl" name="3670" href="#3670">3670</a>
<a class="l" name="3671" href="#3671">3671</a>Fortunately, most of the time you can define a polymorphic matcher easily with
<a class="l" name="3672" href="#3672">3672</a>the help of `MakePolymorphicMatcher()`. Here's how you can define `NotNull()` as
<a class="l" name="3673" href="#3673">3673</a>an example:
<a class="l" name="3674" href="#3674">3674</a>
<a class="l" name="3675" href="#3675">3675</a>```cpp
<a class="l" name="3676" href="#3676">3676</a>using ::testing::MakePolymorphicMatcher;
<a class="l" name="3677" href="#3677">3677</a>using ::testing::MatchResultListener;
<a class="l" name="3678" href="#3678">3678</a>using ::testing::PolymorphicMatcher;
<a class="l" name="3679" href="#3679">3679</a>
<a class="hl" name="3680" href="#3680">3680</a>class NotNullMatcher {
<a class="l" name="3681" href="#3681">3681</a> public:
<a class="l" name="3682" href="#3682">3682</a>  // To implement a polymorphic matcher, first define a COPYABLE class
<a class="l" name="3683" href="#3683">3683</a>  // that has three members MatchAndExplain(), DescribeTo(), and
<a class="l" name="3684" href="#3684">3684</a>  // DescribeNegationTo(), like the following.
<a class="l" name="3685" href="#3685">3685</a>
<a class="l" name="3686" href="#3686">3686</a>  // In this example, we want to use NotNull() with any pointer, so
<a class="l" name="3687" href="#3687">3687</a>  // MatchAndExplain() accepts a pointer of any type as its first argument.
<a class="l" name="3688" href="#3688">3688</a>  // In general, you can define MatchAndExplain() as an ordinary method or
<a class="l" name="3689" href="#3689">3689</a>  // a method template, or even overload it.
<a class="hl" name="3690" href="#3690">3690</a>  template &lt;typename T&gt;
<a class="l" name="3691" href="#3691">3691</a>  bool MatchAndExplain(T* p,
<a class="l" name="3692" href="#3692">3692</a>                       MatchResultListener* /* listener */) const {
<a class="l" name="3693" href="#3693">3693</a>    return p != NULL;
<a class="l" name="3694" href="#3694">3694</a>  }
<a class="l" name="3695" href="#3695">3695</a>
<a class="l" name="3696" href="#3696">3696</a>  // Describes the property of a value matching this matcher.
<a class="l" name="3697" href="#3697">3697</a>  void DescribeTo(std::ostream* os) const { *os &lt;&lt; "is not NULL"; }
<a class="l" name="3698" href="#3698">3698</a>
<a class="l" name="3699" href="#3699">3699</a>  // Describes the property of a value NOT matching this matcher.
<a class="hl" name="3700" href="#3700">3700</a>  void DescribeNegationTo(std::ostream* os) const { *os &lt;&lt; "is NULL"; }
<a class="l" name="3701" href="#3701">3701</a>};
<a class="l" name="3702" href="#3702">3702</a>
<a class="l" name="3703" href="#3703">3703</a>// To construct a polymorphic matcher, pass an instance of the class
<a class="l" name="3704" href="#3704">3704</a>// to MakePolymorphicMatcher().  Note the return type.
<a class="l" name="3705" href="#3705">3705</a>PolymorphicMatcher&lt;NotNullMatcher&gt; NotNull() {
<a class="l" name="3706" href="#3706">3706</a>  return MakePolymorphicMatcher(NotNullMatcher());
<a class="l" name="3707" href="#3707">3707</a>}
<a class="l" name="3708" href="#3708">3708</a>
<a class="l" name="3709" href="#3709">3709</a>...
<a class="hl" name="3710" href="#3710">3710</a>
<a class="l" name="3711" href="#3711">3711</a>  EXPECT_CALL(foo, Bar(NotNull()));  // The argument must be a non-NULL pointer.
<a class="l" name="3712" href="#3712">3712</a>```
<a class="l" name="3713" href="#3713">3713</a>
<a class="l" name="3714" href="#3714">3714</a>**Note:** Your polymorphic matcher class does **not** need to inherit from
<a class="l" name="3715" href="#3715">3715</a>`MatcherInterface` or any other class, and its methods do **not** need to be
<a class="l" name="3716" href="#3716">3716</a>virtual.
<a class="l" name="3717" href="#3717">3717</a>
<a class="l" name="3718" href="#3718">3718</a>Like in a monomorphic matcher, you may explain the match result by streaming
<a class="l" name="3719" href="#3719">3719</a>additional information to the `listener` argument in `MatchAndExplain()`.
<a class="hl" name="3720" href="#3720">3720</a>
<a class="l" name="3721" href="#3721">3721</a>### Writing New Cardinalities
<a class="l" name="3722" href="#3722">3722</a>
<a class="l" name="3723" href="#3723">3723</a>A cardinality is used in `Times()` to tell gMock how many times you expect a
<a class="l" name="3724" href="#3724">3724</a>call to occur. It doesn't have to be exact. For example, you can say
<a class="l" name="3725" href="#3725">3725</a>`AtLeast(5)` or `Between(2, 4)`.
<a class="l" name="3726" href="#3726">3726</a>
<a class="l" name="3727" href="#3727">3727</a>If the [built-in set](<a href="/googletest/s?path=cheat_sheet.md&amp;project=googletest">cheat_sheet.md</a>#CardinalityList) of cardinalities doesn't
<a class="l" name="3728" href="#3728">3728</a>suit you, you are free to define your own by implementing the following
<a class="l" name="3729" href="#3729">3729</a>interface (in namespace `testing`):
<a class="hl" name="3730" href="#3730">3730</a>
<a class="l" name="3731" href="#3731">3731</a>```cpp
<a class="l" name="3732" href="#3732">3732</a>class CardinalityInterface {
<a class="l" name="3733" href="#3733">3733</a> public:
<a class="l" name="3734" href="#3734">3734</a>  virtual ~CardinalityInterface();
<a class="l" name="3735" href="#3735">3735</a>
<a class="l" name="3736" href="#3736">3736</a>  // Returns true if and only if call_count calls will satisfy this cardinality.
<a class="l" name="3737" href="#3737">3737</a>  virtual bool IsSatisfiedByCallCount(int call_count) const = 0;
<a class="l" name="3738" href="#3738">3738</a>
<a class="l" name="3739" href="#3739">3739</a>  // Returns true if and only if call_count calls will saturate this
<a class="hl" name="3740" href="#3740">3740</a>  // cardinality.
<a class="l" name="3741" href="#3741">3741</a>  virtual bool IsSaturatedByCallCount(int call_count) const = 0;
<a class="l" name="3742" href="#3742">3742</a>
<a class="l" name="3743" href="#3743">3743</a>  // Describes self to an ostream.
<a class="l" name="3744" href="#3744">3744</a>  virtual void DescribeTo(std::ostream* os) const = 0;
<a class="l" name="3745" href="#3745">3745</a>};
<a class="l" name="3746" href="#3746">3746</a>```
<a class="l" name="3747" href="#3747">3747</a>
<a class="l" name="3748" href="#3748">3748</a>For example, to specify that a call must occur even number of times, you can
<a class="l" name="3749" href="#3749">3749</a>write
<a class="hl" name="3750" href="#3750">3750</a>
<a class="l" name="3751" href="#3751">3751</a>```cpp
<a class="l" name="3752" href="#3752">3752</a>using ::testing::Cardinality;
<a class="l" name="3753" href="#3753">3753</a>using ::testing::CardinalityInterface;
<a class="l" name="3754" href="#3754">3754</a>using ::testing::MakeCardinality;
<a class="l" name="3755" href="#3755">3755</a>
<a class="l" name="3756" href="#3756">3756</a>class EvenNumberCardinality : public CardinalityInterface {
<a class="l" name="3757" href="#3757">3757</a> public:
<a class="l" name="3758" href="#3758">3758</a>  bool IsSatisfiedByCallCount(int call_count) const override {
<a class="l" name="3759" href="#3759">3759</a>    return (call_count % 2) == 0;
<a class="hl" name="3760" href="#3760">3760</a>  }
<a class="l" name="3761" href="#3761">3761</a>
<a class="l" name="3762" href="#3762">3762</a>  bool IsSaturatedByCallCount(int call_count) const override {
<a class="l" name="3763" href="#3763">3763</a>    return false;
<a class="l" name="3764" href="#3764">3764</a>  }
<a class="l" name="3765" href="#3765">3765</a>
<a class="l" name="3766" href="#3766">3766</a>  void DescribeTo(std::ostream* os) const {
<a class="l" name="3767" href="#3767">3767</a>    *os &lt;&lt; "called even number of times";
<a class="l" name="3768" href="#3768">3768</a>  }
<a class="l" name="3769" href="#3769">3769</a>};
<a class="hl" name="3770" href="#3770">3770</a>
<a class="l" name="3771" href="#3771">3771</a>Cardinality EvenNumber() {
<a class="l" name="3772" href="#3772">3772</a>  return MakeCardinality(new EvenNumberCardinality);
<a class="l" name="3773" href="#3773">3773</a>}
<a class="l" name="3774" href="#3774">3774</a>
<a class="l" name="3775" href="#3775">3775</a>...
<a class="l" name="3776" href="#3776">3776</a>  EXPECT_CALL(foo, Bar(3))
<a class="l" name="3777" href="#3777">3777</a>      .Times(EvenNumber());
<a class="l" name="3778" href="#3778">3778</a>```
<a class="l" name="3779" href="#3779">3779</a>
<a class="hl" name="3780" href="#3780">3780</a>### Writing New Actions Quickly {#QuickNewActions}
<a class="l" name="3781" href="#3781">3781</a>
<a class="l" name="3782" href="#3782">3782</a>If the built-in actions don't work for you, you can easily define your own one.
<a class="l" name="3783" href="#3783">3783</a>Just define a functor class with a (possibly templated) call operator, matching
<a class="l" name="3784" href="#3784">3784</a>the signature of your action.
<a class="l" name="3785" href="#3785">3785</a>
<a class="l" name="3786" href="#3786">3786</a>```cpp
<a class="l" name="3787" href="#3787">3787</a>struct Increment {
<a class="l" name="3788" href="#3788">3788</a>  template &lt;typename T&gt;
<a class="l" name="3789" href="#3789">3789</a>  T operator()(T* arg) {
<a class="hl" name="3790" href="#3790">3790</a>    return ++(*arg);
<a class="l" name="3791" href="#3791">3791</a>  }
<a class="l" name="3792" href="#3792">3792</a>}
<a class="l" name="3793" href="#3793">3793</a>```
<a class="l" name="3794" href="#3794">3794</a>
<a class="l" name="3795" href="#3795">3795</a>The same approach works with stateful functors (or any callable, really):
<a class="l" name="3796" href="#3796">3796</a>
<a class="l" name="3797" href="#3797">3797</a>```
<a class="l" name="3798" href="#3798">3798</a>struct MultiplyBy {
<a class="l" name="3799" href="#3799">3799</a>  template &lt;typename T&gt;
<a class="hl" name="3800" href="#3800">3800</a>  T operator()(T arg) { return arg * multiplier; }
<a class="l" name="3801" href="#3801">3801</a>
<a class="l" name="3802" href="#3802">3802</a>  int multiplier;
<a class="l" name="3803" href="#3803">3803</a>}
<a class="l" name="3804" href="#3804">3804</a>
<a class="l" name="3805" href="#3805">3805</a>// Then use:
<a class="l" name="3806" href="#3806">3806</a>// EXPECT_CALL(...).WillOnce(MultiplyBy{7});
<a class="l" name="3807" href="#3807">3807</a>```
<a class="l" name="3808" href="#3808">3808</a>
<a class="l" name="3809" href="#3809">3809</a>#### Legacy macro-based Actions
<a class="hl" name="3810" href="#3810">3810</a>
<a class="l" name="3811" href="#3811">3811</a>Before C++11, the functor-based actions were not supported; the old way of
<a class="l" name="3812" href="#3812">3812</a>writing actions was through a set of `ACTION*` macros. We suggest to avoid them
<a class="l" name="3813" href="#3813">3813</a>in new code; they hide a lot of logic behind the macro, potentially leading to
<a class="l" name="3814" href="#3814">3814</a>harder-to-understand compiler errors. Nevertheless, we cover them here for
<a class="l" name="3815" href="#3815">3815</a>completeness.
<a class="l" name="3816" href="#3816">3816</a>
<a class="l" name="3817" href="#3817">3817</a>By writing
<a class="l" name="3818" href="#3818">3818</a>
<a class="l" name="3819" href="#3819">3819</a>```cpp
<a class="hl" name="3820" href="#3820">3820</a>ACTION(name) { statements; }
<a class="l" name="3821" href="#3821">3821</a>```
<a class="l" name="3822" href="#3822">3822</a>
<a class="l" name="3823" href="#3823">3823</a>in a namespace scope (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> not inside a class or function), you will define an
<a class="l" name="3824" href="#3824">3824</a>action with the given name that executes the statements. The value returned by
<a class="l" name="3825" href="#3825">3825</a>`statements` will be used as the return value of the action. Inside the
<a class="l" name="3826" href="#3826">3826</a>statements, you can refer to the K-th (0-based) argument of the mock function as
<a class="l" name="3827" href="#3827">3827</a>`argK`. For example:
<a class="l" name="3828" href="#3828">3828</a>
<a class="l" name="3829" href="#3829">3829</a>```cpp
<a class="hl" name="3830" href="#3830">3830</a>ACTION(IncrementArg1) { return ++(*arg1); }
<a class="l" name="3831" href="#3831">3831</a>```
<a class="l" name="3832" href="#3832">3832</a>
<a class="l" name="3833" href="#3833">3833</a>allows you to write
<a class="l" name="3834" href="#3834">3834</a>
<a class="l" name="3835" href="#3835">3835</a>```cpp
<a class="l" name="3836" href="#3836">3836</a>... WillOnce(IncrementArg1());
<a class="l" name="3837" href="#3837">3837</a>```
<a class="l" name="3838" href="#3838">3838</a>
<a class="l" name="3839" href="#3839">3839</a>Note that you don't need to specify the types of the mock function arguments.
<a class="hl" name="3840" href="#3840">3840</a>Rest assured that your code is type-safe though: you'll get a compiler error if
<a class="l" name="3841" href="#3841">3841</a>`*arg1` doesn't support the `++` operator, or if the type of `++(*arg1)` isn't
<a class="l" name="3842" href="#3842">3842</a>compatible with the mock function's return type.
<a class="l" name="3843" href="#3843">3843</a>
<a class="l" name="3844" href="#3844">3844</a>Another example:
<a class="l" name="3845" href="#3845">3845</a>
<a class="l" name="3846" href="#3846">3846</a>```cpp
<a class="l" name="3847" href="#3847">3847</a>ACTION(Foo) {
<a class="l" name="3848" href="#3848">3848</a>  (*arg2)(5);
<a class="l" name="3849" href="#3849">3849</a>  Blah();
<a class="hl" name="3850" href="#3850">3850</a>  *arg1 = 0;
<a class="l" name="3851" href="#3851">3851</a>  return arg0;
<a class="l" name="3852" href="#3852">3852</a>}
<a class="l" name="3853" href="#3853">3853</a>```
<a class="l" name="3854" href="#3854">3854</a>
<a class="l" name="3855" href="#3855">3855</a>defines an action `Foo()` that invokes argument #2 (a function pointer) with 5,
<a class="l" name="3856" href="#3856">3856</a>calls function `Blah()`, sets the value pointed to by argument #1 to 0, and
<a class="l" name="3857" href="#3857">3857</a>returns argument #0.
<a class="l" name="3858" href="#3858">3858</a>
<a class="l" name="3859" href="#3859">3859</a>For more convenience and flexibility, you can also use the following pre-defined
<a class="hl" name="3860" href="#3860">3860</a>symbols in the body of `ACTION`:
<a class="l" name="3861" href="#3861">3861</a>
<a class="l" name="3862" href="#3862">3862</a>`argK_type`     | The type of the K-th (0-based) argument of the mock function
<a class="l" name="3863" href="#3863">3863</a>:-------------- | :-----------------------------------------------------------
<a class="l" name="3864" href="#3864">3864</a>`args`          | All arguments of the mock function as a tuple
<a class="l" name="3865" href="#3865">3865</a>`args_type`     | The type of all arguments of the mock function as a tuple
<a class="l" name="3866" href="#3866">3866</a>`return_type`   | The return type of the mock function
<a class="l" name="3867" href="#3867">3867</a>`function_type` | The type of the mock function
<a class="l" name="3868" href="#3868">3868</a>
<a class="l" name="3869" href="#3869">3869</a>For example, when using an `ACTION` as a stub action for mock function:
<a class="hl" name="3870" href="#3870">3870</a>
<a class="l" name="3871" href="#3871">3871</a>```cpp
<a class="l" name="3872" href="#3872">3872</a>int DoSomething(bool flag, int* ptr);
<a class="l" name="3873" href="#3873">3873</a>```
<a class="l" name="3874" href="#3874">3874</a>
<a class="l" name="3875" href="#3875">3875</a>we have:
<a class="l" name="3876" href="#3876">3876</a>
<a class="l" name="3877" href="#3877">3877</a>Pre-defined Symbol | Is Bound To
<a class="l" name="3878" href="#3878">3878</a>------------------ | ---------------------------------
<a class="l" name="3879" href="#3879">3879</a>`arg0`             | the value of `flag`
<a class="hl" name="3880" href="#3880">3880</a>`arg0_type`        | the type `bool`
<a class="l" name="3881" href="#3881">3881</a>`arg1`             | the value of `ptr`
<a class="l" name="3882" href="#3882">3882</a>`arg1_type`        | the type `int*`
<a class="l" name="3883" href="#3883">3883</a>`args`             | the tuple `(flag, ptr)`
<a class="l" name="3884" href="#3884">3884</a>`args_type`        | the type `std::tuple&lt;bool, int*&gt;`
<a class="l" name="3885" href="#3885">3885</a>`return_type`      | the type `int`
<a class="l" name="3886" href="#3886">3886</a>`function_type`    | the type `int(bool, int*)`
<a class="l" name="3887" href="#3887">3887</a>
<a class="l" name="3888" href="#3888">3888</a>#### Legacy macro-based parameterized Actions
<a class="l" name="3889" href="#3889">3889</a>
<a class="hl" name="3890" href="#3890">3890</a>Sometimes you'll want to parameterize an action you define. For that we have
<a class="l" name="3891" href="#3891">3891</a>another macro
<a class="l" name="3892" href="#3892">3892</a>
<a class="l" name="3893" href="#3893">3893</a>```cpp
<a class="l" name="3894" href="#3894">3894</a>ACTION_P(name, param) { statements; }
<a class="l" name="3895" href="#3895">3895</a>```
<a class="l" name="3896" href="#3896">3896</a>
<a class="l" name="3897" href="#3897">3897</a>For example,
<a class="l" name="3898" href="#3898">3898</a>
<a class="l" name="3899" href="#3899">3899</a>```cpp
<a class="hl" name="3900" href="#3900">3900</a>ACTION_P(Add, n) { return arg0 + n; }
<a class="l" name="3901" href="#3901">3901</a>```
<a class="l" name="3902" href="#3902">3902</a>
<a class="l" name="3903" href="#3903">3903</a>will allow you to write
<a class="l" name="3904" href="#3904">3904</a>
<a class="l" name="3905" href="#3905">3905</a>```cpp
<a class="l" name="3906" href="#3906">3906</a>// Returns argument #0 + 5.
<a class="l" name="3907" href="#3907">3907</a>... WillOnce(Add(5));
<a class="l" name="3908" href="#3908">3908</a>```
<a class="l" name="3909" href="#3909">3909</a>
<a class="hl" name="3910" href="#3910">3910</a>For convenience, we use the term *arguments* for the values used to invoke the
<a class="l" name="3911" href="#3911">3911</a>mock function, and the term *parameters* for the values used to instantiate an
<a class="l" name="3912" href="#3912">3912</a>action.
<a class="l" name="3913" href="#3913">3913</a>
<a class="l" name="3914" href="#3914">3914</a>Note that you don't need to provide the type of the parameter either. Suppose
<a class="l" name="3915" href="#3915">3915</a>the parameter is named `param`, you can also use the gMock-defined symbol
<a class="l" name="3916" href="#3916">3916</a>`param_type` to refer to the type of the parameter as inferred by the compiler.
<a class="l" name="3917" href="#3917">3917</a>For example, in the body of `ACTION_P(Add, n)` above, you can write `n_type` for
<a class="l" name="3918" href="#3918">3918</a>the type of `n`.
<a class="l" name="3919" href="#3919">3919</a>
<a class="hl" name="3920" href="#3920">3920</a>gMock also provides `ACTION_P2`, `ACTION_P3`, and etc to support multi-parameter
<a class="l" name="3921" href="#3921">3921</a>actions. For example,
<a class="l" name="3922" href="#3922">3922</a>
<a class="l" name="3923" href="#3923">3923</a>```cpp
<a class="l" name="3924" href="#3924">3924</a>ACTION_P2(ReturnDistanceTo, x, y) {
<a class="l" name="3925" href="#3925">3925</a>  double dx = arg0 - x;
<a class="l" name="3926" href="#3926">3926</a>  double dy = arg1 - y;
<a class="l" name="3927" href="#3927">3927</a>  return sqrt(dx*dx + dy*dy);
<a class="l" name="3928" href="#3928">3928</a>}
<a class="l" name="3929" href="#3929">3929</a>```
<a class="hl" name="3930" href="#3930">3930</a>
<a class="l" name="3931" href="#3931">3931</a>lets you write
<a class="l" name="3932" href="#3932">3932</a>
<a class="l" name="3933" href="#3933">3933</a>```cpp
<a class="l" name="3934" href="#3934">3934</a>... WillOnce(ReturnDistanceTo(5.0, 26.5));
<a class="l" name="3935" href="#3935">3935</a>```
<a class="l" name="3936" href="#3936">3936</a>
<a class="l" name="3937" href="#3937">3937</a>You can view `ACTION` as a degenerated parameterized action where the number of
<a class="l" name="3938" href="#3938">3938</a>parameters is 0.
<a class="l" name="3939" href="#3939">3939</a>
<a class="hl" name="3940" href="#3940">3940</a>You can also easily define actions overloaded on the number of parameters:
<a class="l" name="3941" href="#3941">3941</a>
<a class="l" name="3942" href="#3942">3942</a>```cpp
<a class="l" name="3943" href="#3943">3943</a>ACTION_P(Plus, a) { ... }
<a class="l" name="3944" href="#3944">3944</a>ACTION_P2(Plus, a, b) { ... }
<a class="l" name="3945" href="#3945">3945</a>```
<a class="l" name="3946" href="#3946">3946</a>
<a class="l" name="3947" href="#3947">3947</a>### Restricting the Type of an Argument or Parameter in an ACTION
<a class="l" name="3948" href="#3948">3948</a>
<a class="l" name="3949" href="#3949">3949</a>For maximum brevity and reusability, the `ACTION*` macros don't ask you to
<a class="hl" name="3950" href="#3950">3950</a>provide the types of the mock function arguments and the action parameters.
<a class="l" name="3951" href="#3951">3951</a>Instead, we let the compiler infer the types for us.
<a class="l" name="3952" href="#3952">3952</a>
<a class="l" name="3953" href="#3953">3953</a>Sometimes, however, we may want to be more explicit about the types. There are
<a class="l" name="3954" href="#3954">3954</a>several tricks to do that. For example:
<a class="l" name="3955" href="#3955">3955</a>
<a class="l" name="3956" href="#3956">3956</a>```cpp
<a class="l" name="3957" href="#3957">3957</a>ACTION(Foo) {
<a class="l" name="3958" href="#3958">3958</a>  // Makes sure arg0 can be converted to int.
<a class="l" name="3959" href="#3959">3959</a>  int n = arg0;
<a class="hl" name="3960" href="#3960">3960</a>  ... use n instead of arg0 here ...
<a class="l" name="3961" href="#3961">3961</a>}
<a class="l" name="3962" href="#3962">3962</a>
<a class="l" name="3963" href="#3963">3963</a>ACTION_P(Bar, param) {
<a class="l" name="3964" href="#3964">3964</a>  // Makes sure the type of arg1 is const char*.
<a class="l" name="3965" href="#3965">3965</a>  ::testing::StaticAssertTypeEq&lt;const char*, arg1_type&gt;();
<a class="l" name="3966" href="#3966">3966</a>
<a class="l" name="3967" href="#3967">3967</a>  // Makes sure param can be converted to bool.
<a class="l" name="3968" href="#3968">3968</a>  bool flag = param;
<a class="l" name="3969" href="#3969">3969</a>}
<a class="hl" name="3970" href="#3970">3970</a>```
<a class="l" name="3971" href="#3971">3971</a>
<a class="l" name="3972" href="#3972">3972</a>where `StaticAssertTypeEq` is a compile-time assertion in googletest that
<a class="l" name="3973" href="#3973">3973</a>verifies two types are the same.
<a class="l" name="3974" href="#3974">3974</a>
<a class="l" name="3975" href="#3975">3975</a>### Writing New Action Templates Quickly
<a class="l" name="3976" href="#3976">3976</a>
<a class="l" name="3977" href="#3977">3977</a>Sometimes you want to give an action explicit template parameters that cannot be
<a class="l" name="3978" href="#3978">3978</a>inferred from its value parameters. `ACTION_TEMPLATE()` supports that and can be
<a class="l" name="3979" href="#3979">3979</a>viewed as an extension to `ACTION()` and `ACTION_P*()`.
<a class="hl" name="3980" href="#3980">3980</a>
<a class="l" name="3981" href="#3981">3981</a>The syntax:
<a class="l" name="3982" href="#3982">3982</a>
<a class="l" name="3983" href="#3983">3983</a>```cpp
<a class="l" name="3984" href="#3984">3984</a>ACTION_TEMPLATE(ActionName,
<a class="l" name="3985" href="#3985">3985</a>                HAS_m_TEMPLATE_PARAMS(kind1, name1, ..., kind_m, name_m),
<a class="l" name="3986" href="#3986">3986</a>                AND_n_VALUE_PARAMS(p1, ..., p_n)) { statements; }
<a class="l" name="3987" href="#3987">3987</a>```
<a class="l" name="3988" href="#3988">3988</a>
<a class="l" name="3989" href="#3989">3989</a>defines an action template that takes *m* explicit template parameters and *n*
<a class="hl" name="3990" href="#3990">3990</a>value parameters, where *m* is in [1, 10] and *n* is in [0, 10]. `name_i` is the
<a class="l" name="3991" href="#3991">3991</a>name of the *i*-th template parameter, and `kind_i` specifies whether it's a
<a class="l" name="3992" href="#3992">3992</a>`typename`, an integral constant, or a template. `p_i` is the name of the *i*-th
<a class="l" name="3993" href="#3993">3993</a>value parameter.
<a class="l" name="3994" href="#3994">3994</a>
<a class="l" name="3995" href="#3995">3995</a>Example:
<a class="l" name="3996" href="#3996">3996</a>
<a class="l" name="3997" href="#3997">3997</a>```cpp
<a class="l" name="3998" href="#3998">3998</a>// DuplicateArg&lt;k, T&gt;(output) converts the k-th argument of the mock
<a class="l" name="3999" href="#3999">3999</a>// function to type T and copies it to *output.
<a class="hl" name="4000" href="#4000">4000</a>ACTION_TEMPLATE(DuplicateArg,
<a class="l" name="4001" href="#4001">4001</a>                // Note the comma between int and k:
<a class="l" name="4002" href="#4002">4002</a>                HAS_2_TEMPLATE_PARAMS(int, k, typename, T),
<a class="l" name="4003" href="#4003">4003</a>                AND_1_VALUE_PARAMS(output)) {
<a class="l" name="4004" href="#4004">4004</a>  *output = T(std::get&lt;k&gt;(args));
<a class="l" name="4005" href="#4005">4005</a>}
<a class="l" name="4006" href="#4006">4006</a>```
<a class="l" name="4007" href="#4007">4007</a>
<a class="l" name="4008" href="#4008">4008</a>To create an instance of an action template, write:
<a class="l" name="4009" href="#4009">4009</a>
<a class="hl" name="4010" href="#4010">4010</a>```cpp
<a class="l" name="4011" href="#4011">4011</a>ActionName&lt;t1, ..., t_m&gt;(v1, ..., v_n)
<a class="l" name="4012" href="#4012">4012</a>```
<a class="l" name="4013" href="#4013">4013</a>
<a class="l" name="4014" href="#4014">4014</a>where the `t`s are the template arguments and the `v`s are the value arguments.
<a class="l" name="4015" href="#4015">4015</a>The value argument types are inferred by the compiler. For example:
<a class="l" name="4016" href="#4016">4016</a>
<a class="l" name="4017" href="#4017">4017</a>```cpp
<a class="l" name="4018" href="#4018">4018</a>using ::testing::_;
<a class="l" name="4019" href="#4019">4019</a>...
<a class="hl" name="4020" href="#4020">4020</a>  int n;
<a class="l" name="4021" href="#4021">4021</a>  EXPECT_CALL(mock, Foo).WillOnce(DuplicateArg&lt;1, unsigned char&gt;(&amp;n));
<a class="l" name="4022" href="#4022">4022</a>```
<a class="l" name="4023" href="#4023">4023</a>
<a class="l" name="4024" href="#4024">4024</a>If you want to explicitly specify the value argument types, you can provide
<a class="l" name="4025" href="#4025">4025</a>additional template arguments:
<a class="l" name="4026" href="#4026">4026</a>
<a class="l" name="4027" href="#4027">4027</a>```cpp
<a class="l" name="4028" href="#4028">4028</a>ActionName&lt;t1, ..., t_m, u1, ..., u_k&gt;(v1, ..., v_n)
<a class="l" name="4029" href="#4029">4029</a>```
<a class="hl" name="4030" href="#4030">4030</a>
<a class="l" name="4031" href="#4031">4031</a>where `u_i` is the desired type of `v_i`.
<a class="l" name="4032" href="#4032">4032</a>
<a class="l" name="4033" href="#4033">4033</a>`ACTION_TEMPLATE` and `ACTION`/`ACTION_P*` can be overloaded on the number of
<a class="l" name="4034" href="#4034">4034</a>value parameters, but not on the number of template parameters. Without the
<a class="l" name="4035" href="#4035">4035</a>restriction, the meaning of the following is unclear:
<a class="l" name="4036" href="#4036">4036</a>
<a class="l" name="4037" href="#4037">4037</a>```cpp
<a class="l" name="4038" href="#4038">4038</a>  OverloadedAction&lt;int, bool&gt;(x);
<a class="l" name="4039" href="#4039">4039</a>```
<a class="hl" name="4040" href="#4040">4040</a>
<a class="l" name="4041" href="#4041">4041</a>Are we using a single-template-parameter action where `bool` refers to the type
<a class="l" name="4042" href="#4042">4042</a>of `x`, or a two-template-parameter action where the compiler is asked to infer
<a class="l" name="4043" href="#4043">4043</a>the type of `x`?
<a class="l" name="4044" href="#4044">4044</a>
<a class="l" name="4045" href="#4045">4045</a>### Using the ACTION Object's Type
<a class="l" name="4046" href="#4046">4046</a>
<a class="l" name="4047" href="#4047">4047</a>If you are writing a function that returns an `ACTION` object, you'll need to
<a class="l" name="4048" href="#4048">4048</a>know its type. The type depends on the macro used to define the action and the
<a class="l" name="4049" href="#4049">4049</a>parameter types. The rule is relatively simple:
<a class="hl" name="4050" href="#4050">4050</a>
<a class="l" name="4051" href="#4051">4051</a>| Given Definition              | Expression          | Has Type              |
<a class="l" name="4052" href="#4052">4052</a>| ----------------------------- | ------------------- | --------------------- |
<a class="l" name="4053" href="#4053">4053</a>| `ACTION(Foo)`                 | `Foo()`             | `FooAction`           |
<a class="l" name="4054" href="#4054">4054</a>| `ACTION_TEMPLATE(Foo,`        | `Foo&lt;t1, ...,       | `FooAction&lt;t1, ...,   |
<a class="l" name="4055" href="#4055">4055</a>: `HAS_m_TEMPLATE_PARAMS(...),` : t_m&gt;()`             : t_m&gt;`                 :
<a class="l" name="4056" href="#4056">4056</a>: `AND_0_VALUE_PARAMS())`       :                     :                       :
<a class="l" name="4057" href="#4057">4057</a>| `ACTION_P(Bar, param)`        | `Bar(int_value)`    | `BarActionP&lt;int&gt;`     |
<a class="l" name="4058" href="#4058">4058</a>| `ACTION_TEMPLATE(Bar,`        | `Bar&lt;t1, ..., t_m&gt;` | `FooActionP&lt;t1, ...,  |
<a class="l" name="4059" href="#4059">4059</a>: `HAS_m_TEMPLATE_PARAMS(...),` : `(int_value)`       : t_m, int&gt;`            :
<a class="hl" name="4060" href="#4060">4060</a>: `AND_1_VALUE_PARAMS(p1))`     :                     :                       :
<a class="l" name="4061" href="#4061">4061</a>| `ACTION_P2(Baz, p1, p2)`      | `Baz(bool_value,`   | `BazActionP2&lt;bool,    |
<a class="l" name="4062" href="#4062">4062</a>:                               : `int_value)`        : int&gt;`                 :
<a class="l" name="4063" href="#4063">4063</a>| `ACTION_TEMPLATE(Baz,`        | `Baz&lt;t1, ..., t_m&gt;` | `FooActionP2&lt;t1, ..., |
<a class="l" name="4064" href="#4064">4064</a>: `HAS_m_TEMPLATE_PARAMS(...),` : `(bool_value,`      : t_m,` `bool, int&gt;`    :
<a class="l" name="4065" href="#4065">4065</a>: `AND_2_VALUE_PARAMS(p1, p2))` : `int_value)`        :                       :
<a class="l" name="4066" href="#4066">4066</a>| ...                           | ...                 | ...                   |
<a class="l" name="4067" href="#4067">4067</a>
<a class="l" name="4068" href="#4068">4068</a>Note that we have to pick different suffixes (`Action`, `ActionP`, `ActionP2`,
<a class="l" name="4069" href="#4069">4069</a>and etc) for actions with different numbers of value parameters, or the action
<a class="hl" name="4070" href="#4070">4070</a>definitions cannot be overloaded on the number of them.
<a class="l" name="4071" href="#4071">4071</a>
<a class="l" name="4072" href="#4072">4072</a>### Writing New Monomorphic Actions {#NewMonoActions}
<a class="l" name="4073" href="#4073">4073</a>
<a class="l" name="4074" href="#4074">4074</a>While the `ACTION*` macros are very convenient, sometimes they are
<a class="l" name="4075" href="#4075">4075</a>inappropriate. For example, despite the tricks shown in the previous recipes,
<a class="l" name="4076" href="#4076">4076</a>they don't let you directly specify the types of the mock function arguments and
<a class="l" name="4077" href="#4077">4077</a>the action parameters, which in general leads to unoptimized compiler error
<a class="l" name="4078" href="#4078">4078</a>messages that can baffle unfamiliar users. They also don't allow overloading
<a class="l" name="4079" href="#4079">4079</a>actions based on parameter types without jumping through some hoops.
<a class="hl" name="4080" href="#4080">4080</a>
<a class="l" name="4081" href="#4081">4081</a>An alternative to the `ACTION*` macros is to implement
<a class="l" name="4082" href="#4082">4082</a>`::testing::ActionInterface&lt;F&gt;`, where `F` is the type of the mock function in
<a class="l" name="4083" href="#4083">4083</a>which the action will be used. For example:
<a class="l" name="4084" href="#4084">4084</a>
<a class="l" name="4085" href="#4085">4085</a>```cpp
<a class="l" name="4086" href="#4086">4086</a>template &lt;typename F&gt;
<a class="l" name="4087" href="#4087">4087</a>class ActionInterface {
<a class="l" name="4088" href="#4088">4088</a> public:
<a class="l" name="4089" href="#4089">4089</a>  virtual ~ActionInterface();
<a class="hl" name="4090" href="#4090">4090</a>
<a class="l" name="4091" href="#4091">4091</a>  // Performs the action.  Result is the return type of function type
<a class="l" name="4092" href="#4092">4092</a>  // F, and ArgumentTuple is the tuple of arguments of F.
<a class="l" name="4093" href="#4093">4093</a>  //
<a class="l" name="4094" href="#4094">4094</a>
<a class="l" name="4095" href="#4095">4095</a>  // For example, if F is int(bool, const string&amp;), then Result would
<a class="l" name="4096" href="#4096">4096</a>  // be int, and ArgumentTuple would be std::tuple&lt;bool, const string&amp;&gt;.
<a class="l" name="4097" href="#4097">4097</a>  virtual Result Perform(const ArgumentTuple&amp; args) = 0;
<a class="l" name="4098" href="#4098">4098</a>};
<a class="l" name="4099" href="#4099">4099</a>```
<a class="hl" name="4100" href="#4100">4100</a>
<a class="l" name="4101" href="#4101">4101</a>```cpp
<a class="l" name="4102" href="#4102">4102</a>using ::testing::_;
<a class="l" name="4103" href="#4103">4103</a>using ::testing::Action;
<a class="l" name="4104" href="#4104">4104</a>using ::testing::ActionInterface;
<a class="l" name="4105" href="#4105">4105</a>using ::testing::MakeAction;
<a class="l" name="4106" href="#4106">4106</a>
<a class="l" name="4107" href="#4107">4107</a>typedef int IncrementMethod(int*);
<a class="l" name="4108" href="#4108">4108</a>
<a class="l" name="4109" href="#4109">4109</a>class IncrementArgumentAction : public ActionInterface&lt;IncrementMethod&gt; {
<a class="hl" name="4110" href="#4110">4110</a> public:
<a class="l" name="4111" href="#4111">4111</a>  int Perform(const std::tuple&lt;int*&gt;&amp; args) override {
<a class="l" name="4112" href="#4112">4112</a>    int* p = std::get&lt;0&gt;(args);  // Grabs the first argument.
<a class="l" name="4113" href="#4113">4113</a>    return *p++;
<a class="l" name="4114" href="#4114">4114</a>  }
<a class="l" name="4115" href="#4115">4115</a>};
<a class="l" name="4116" href="#4116">4116</a>
<a class="l" name="4117" href="#4117">4117</a>Action&lt;IncrementMethod&gt; IncrementArgument() {
<a class="l" name="4118" href="#4118">4118</a>  return MakeAction(new IncrementArgumentAction);
<a class="l" name="4119" href="#4119">4119</a>}
<a class="hl" name="4120" href="#4120">4120</a>
<a class="l" name="4121" href="#4121">4121</a>...
<a class="l" name="4122" href="#4122">4122</a>  EXPECT_CALL(foo, Baz(_))
<a class="l" name="4123" href="#4123">4123</a>      .WillOnce(IncrementArgument());
<a class="l" name="4124" href="#4124">4124</a>
<a class="l" name="4125" href="#4125">4125</a>  int n = 5;
<a class="l" name="4126" href="#4126">4126</a>  <a href="/googletest/s?path=foo.Baz&amp;project=googletest">foo.Baz</a>(&amp;n);  // Should return 5 and change n to 6.
<a class="l" name="4127" href="#4127">4127</a>```
<a class="l" name="4128" href="#4128">4128</a>
<a class="l" name="4129" href="#4129">4129</a>### Writing New Polymorphic Actions {#NewPolyActions}
<a class="hl" name="4130" href="#4130">4130</a>
<a class="l" name="4131" href="#4131">4131</a>The previous recipe showed you how to define your own action. This is all good,
<a class="l" name="4132" href="#4132">4132</a>except that you need to know the type of the function in which the action will
<a class="l" name="4133" href="#4133">4133</a>be used. Sometimes that can be a problem. For example, if you want to use the
<a class="l" name="4134" href="#4134">4134</a>action in functions with *different* types (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> like `Return()` and
<a class="l" name="4135" href="#4135">4135</a>`SetArgPointee()`).
<a class="l" name="4136" href="#4136">4136</a>
<a class="l" name="4137" href="#4137">4137</a>If an action can be used in several types of mock functions, we say it's
<a class="l" name="4138" href="#4138">4138</a>*polymorphic*. The `MakePolymorphicAction()` function template makes it easy to
<a class="l" name="4139" href="#4139">4139</a>define such an action:
<a class="hl" name="4140" href="#4140">4140</a>
<a class="l" name="4141" href="#4141">4141</a>```cpp
<a class="l" name="4142" href="#4142">4142</a>namespace testing {
<a class="l" name="4143" href="#4143">4143</a>template &lt;typename Impl&gt;
<a class="l" name="4144" href="#4144">4144</a>PolymorphicAction&lt;Impl&gt; MakePolymorphicAction(const Impl&amp; impl);
<a class="l" name="4145" href="#4145">4145</a>}  // namespace testing
<a class="l" name="4146" href="#4146">4146</a>```
<a class="l" name="4147" href="#4147">4147</a>
<a class="l" name="4148" href="#4148">4148</a>As an example, let's define an action that returns the second argument in the
<a class="l" name="4149" href="#4149">4149</a>mock function's argument list. The first step is to define an implementation
<a class="hl" name="4150" href="#4150">4150</a>class:
<a class="l" name="4151" href="#4151">4151</a>
<a class="l" name="4152" href="#4152">4152</a>```cpp
<a class="l" name="4153" href="#4153">4153</a>class ReturnSecondArgumentAction {
<a class="l" name="4154" href="#4154">4154</a> public:
<a class="l" name="4155" href="#4155">4155</a>  template &lt;typename Result, typename ArgumentTuple&gt;
<a class="l" name="4156" href="#4156">4156</a>  Result Perform(const ArgumentTuple&amp; args) const {
<a class="l" name="4157" href="#4157">4157</a>    // To get the i-th (0-based) argument, use std::get(args).
<a class="l" name="4158" href="#4158">4158</a>    return std::get&lt;1&gt;(args);
<a class="l" name="4159" href="#4159">4159</a>  }
<a class="hl" name="4160" href="#4160">4160</a>};
<a class="l" name="4161" href="#4161">4161</a>```
<a class="l" name="4162" href="#4162">4162</a>
<a class="l" name="4163" href="#4163">4163</a>This implementation class does *not* need to inherit from any particular class.
<a class="l" name="4164" href="#4164">4164</a>What matters is that it must have a `Perform()` method template. This method
<a class="l" name="4165" href="#4165">4165</a>template takes the mock function's arguments as a tuple in a **single**
<a class="l" name="4166" href="#4166">4166</a>argument, and returns the result of the action. It can be either `const` or not,
<a class="l" name="4167" href="#4167">4167</a>but must be invokable with exactly one template argument, which is the result
<a class="l" name="4168" href="#4168">4168</a>type. In other words, you must be able to call `Perform&lt;R&gt;(args)` where `R` is
<a class="l" name="4169" href="#4169">4169</a>the mock function's return type and `args` is its arguments in a tuple.
<a class="hl" name="4170" href="#4170">4170</a>
<a class="l" name="4171" href="#4171">4171</a>Next, we use `MakePolymorphicAction()` to turn an instance of the implementation
<a class="l" name="4172" href="#4172">4172</a>class into the polymorphic action we need. It will be convenient to have a
<a class="l" name="4173" href="#4173">4173</a>wrapper for this:
<a class="l" name="4174" href="#4174">4174</a>
<a class="l" name="4175" href="#4175">4175</a>```cpp
<a class="l" name="4176" href="#4176">4176</a>using ::testing::MakePolymorphicAction;
<a class="l" name="4177" href="#4177">4177</a>using ::testing::PolymorphicAction;
<a class="l" name="4178" href="#4178">4178</a>
<a class="l" name="4179" href="#4179">4179</a>PolymorphicAction&lt;ReturnSecondArgumentAction&gt; ReturnSecondArgument() {
<a class="hl" name="4180" href="#4180">4180</a>  return MakePolymorphicAction(ReturnSecondArgumentAction());
<a class="l" name="4181" href="#4181">4181</a>}
<a class="l" name="4182" href="#4182">4182</a>```
<a class="l" name="4183" href="#4183">4183</a>
<a class="l" name="4184" href="#4184">4184</a>Now, you can use this polymorphic action the same way you use the built-in ones:
<a class="l" name="4185" href="#4185">4185</a>
<a class="l" name="4186" href="#4186">4186</a>```cpp
<a class="l" name="4187" href="#4187">4187</a>using ::testing::_;
<a class="l" name="4188" href="#4188">4188</a>
<a class="l" name="4189" href="#4189">4189</a>class MockFoo : public Foo {
<a class="hl" name="4190" href="#4190">4190</a> public:
<a class="l" name="4191" href="#4191">4191</a>  MOCK_METHOD(int, DoThis, (bool flag, int n), (override));
<a class="l" name="4192" href="#4192">4192</a>  MOCK_METHOD(string, DoThat, (int x, const char* str1, const char* str2),
<a class="l" name="4193" href="#4193">4193</a>              (override));
<a class="l" name="4194" href="#4194">4194</a>};
<a class="l" name="4195" href="#4195">4195</a>
<a class="l" name="4196" href="#4196">4196</a>  ...
<a class="l" name="4197" href="#4197">4197</a>  MockFoo foo;
<a class="l" name="4198" href="#4198">4198</a>  EXPECT_CALL(foo, DoThis).WillOnce(ReturnSecondArgument());
<a class="l" name="4199" href="#4199">4199</a>  EXPECT_CALL(foo, DoThat).WillOnce(ReturnSecondArgument());
<a class="hl" name="4200" href="#4200">4200</a>  ...
<a class="l" name="4201" href="#4201">4201</a>  <a href="/googletest/s?path=foo.DoThis&amp;project=googletest">foo.DoThis</a>(true, 5);  // Will return 5.
<a class="l" name="4202" href="#4202">4202</a>  <a href="/googletest/s?path=foo.DoThat&amp;project=googletest">foo.DoThat</a>(1, "Hi", "Bye");  // Will return "Hi".
<a class="l" name="4203" href="#4203">4203</a>```
<a class="l" name="4204" href="#4204">4204</a>
<a class="l" name="4205" href="#4205">4205</a>### Teaching gMock How to Print Your Values
<a class="l" name="4206" href="#4206">4206</a>
<a class="l" name="4207" href="#4207">4207</a>When an uninteresting or unexpected call occurs, gMock prints the argument
<a class="l" name="4208" href="#4208">4208</a>values and the stack trace to help you debug. Assertion macros like
<a class="l" name="4209" href="#4209">4209</a>`EXPECT_THAT` and `EXPECT_EQ` also print the values in question when the
<a class="hl" name="4210" href="#4210">4210</a>assertion fails. gMock and googletest do this using googletest's user-extensible
<a class="l" name="4211" href="#4211">4211</a>value printer.
<a class="l" name="4212" href="#4212">4212</a>
<a class="l" name="4213" href="#4213">4213</a>This printer knows how to print built-in C++ types, native arrays, STL
<a class="l" name="4214" href="#4214">4214</a>containers, and any type that supports the `&lt;&lt;` operator. For other types, it
<a class="l" name="4215" href="#4215">4215</a>prints the raw bytes in the value and hopes that you the user can figure it out.
<a class="l" name="4216" href="#4216">4216</a>[googletest's advanced guide](../..<a href="/googletest/s?path=/googletest/docs/advanced.md&amp;project=googletest">/googletest/docs/advanced.md</a>#teaching-googletest-how-to-print-your-values)
<a class="l" name="4217" href="#4217">4217</a>explains how to extend the printer to do a better job at printing your
<a class="l" name="4218" href="#4218">4218</a>particular type than to dump the bytes.
<a class="l" name="4219" href="#4219">4219</a>
<a class="hl" name="4220" href="#4220">4220</a>## Useful Mocks Created Using gMock
<a class="l" name="4221" href="#4221">4221</a>
<a class="l" name="4222" href="#4222">4222</a>&lt;!--#include file="<a href="/googletest/s?path=includes/g3_testing_LOGs.md&amp;project=googletest">includes/g3_testing_LOGs.md</a>"--&gt;
<a class="l" name="4223" href="#4223">4223</a>&lt;!--#include file="<a href="/googletest/s?path=includes/g3_mock_callbacks.md&amp;project=googletest">includes/g3_mock_callbacks.md</a>"--&gt;
<a class="l" name="4224" href="#4224">4224</a>
<a class="l" name="4225" href="#4225">4225</a>### Mock std::function {#MockFunction}
<a class="l" name="4226" href="#4226">4226</a>
<a class="l" name="4227" href="#4227">4227</a>`std::function` is a general function type introduced in C++11. It is a
<a class="l" name="4228" href="#4228">4228</a>preferred way of passing callbacks to new interfaces. Functions are copiable,
<a class="l" name="4229" href="#4229">4229</a>and are not usually passed around by pointer, which makes them tricky to mock.
<a class="hl" name="4230" href="#4230">4230</a>But fear not - `MockFunction` can help you with that.
<a class="l" name="4231" href="#4231">4231</a>
<a class="l" name="4232" href="#4232">4232</a>`MockFunction&lt;R(T1, ..., Tn)&gt;` has a mock method `Call()` with the signature:
<a class="l" name="4233" href="#4233">4233</a>
<a class="l" name="4234" href="#4234">4234</a>```cpp
<a class="l" name="4235" href="#4235">4235</a>  R Call(T1, ..., Tn);
<a class="l" name="4236" href="#4236">4236</a>```
<a class="l" name="4237" href="#4237">4237</a>
<a class="l" name="4238" href="#4238">4238</a>It also has a `AsStdFunction()` method, which creates a `std::function` proxy
<a class="l" name="4239" href="#4239">4239</a>forwarding to Call:
<a class="hl" name="4240" href="#4240">4240</a>
<a class="l" name="4241" href="#4241">4241</a>```cpp
<a class="l" name="4242" href="#4242">4242</a>  std::function&lt;R(T1, ..., Tn)&gt; AsStdFunction();
<a class="l" name="4243" href="#4243">4243</a>```
<a class="l" name="4244" href="#4244">4244</a>
<a class="l" name="4245" href="#4245">4245</a>To use `MockFunction`, first create `MockFunction` object and set up
<a class="l" name="4246" href="#4246">4246</a>expectations on its `Call` method. Then pass proxy obtained from
<a class="l" name="4247" href="#4247">4247</a>`AsStdFunction()` to the code you are testing. For example:
<a class="l" name="4248" href="#4248">4248</a>
<a class="l" name="4249" href="#4249">4249</a>```cpp
<a class="hl" name="4250" href="#4250">4250</a>TEST(FooTest, RunsCallbackWithBarArgument) {
<a class="l" name="4251" href="#4251">4251</a>  // 1. Create a mock object.
<a class="l" name="4252" href="#4252">4252</a>  MockFunction&lt;int(string)&gt; mock_function;
<a class="l" name="4253" href="#4253">4253</a>
<a class="l" name="4254" href="#4254">4254</a>  // 2. Set expectations on Call() method.
<a class="l" name="4255" href="#4255">4255</a>  EXPECT_CALL(mock_function, Call("bar")).WillOnce(Return(1));
<a class="l" name="4256" href="#4256">4256</a>
<a class="l" name="4257" href="#4257">4257</a>  // 3. Exercise code that uses std::function.
<a class="l" name="4258" href="#4258">4258</a>  Foo(<a href="/googletest/s?path=mock_function.AsStdFunction&amp;project=googletest">mock_function.AsStdFunction</a>());
<a class="l" name="4259" href="#4259">4259</a>  // Foo's signature can be either of:
<a class="hl" name="4260" href="#4260">4260</a>  // void Foo(const std::function&lt;int(string)&gt;&amp; fun);
<a class="l" name="4261" href="#4261">4261</a>  // void Foo(std::function&lt;int(string)&gt; fun);
<a class="l" name="4262" href="#4262">4262</a>
<a class="l" name="4263" href="#4263">4263</a>  // 4. All expectations will be verified when mock_function
<a class="l" name="4264" href="#4264">4264</a>  //     goes out of scope and is destroyed.
<a class="l" name="4265" href="#4265">4265</a>}
<a class="l" name="4266" href="#4266">4266</a>```
<a class="l" name="4267" href="#4267">4267</a>
<a class="l" name="4268" href="#4268">4268</a>Remember that function objects created with `AsStdFunction()` are just
<a class="l" name="4269" href="#4269">4269</a>forwarders. If you create multiple of them, they will share the same set of
<a class="hl" name="4270" href="#4270">4270</a>expectations.
<a class="l" name="4271" href="#4271">4271</a>
<a class="l" name="4272" href="#4272">4272</a>Although `std::function` supports unlimited number of arguments, `MockFunction`
<a class="l" name="4273" href="#4273">4273</a>implementation is limited to ten. If you ever hit that limit... well, your
<a class="l" name="4274" href="#4274">4274</a>callback has bigger problems than being mockable. :-)
<a class="l" name="4275" href="#4275">4275</a>
<a class="l" name="4276" href="#4276">4276</a>&lt;!-- GOOGLETEST_CM0034 DO NOT DELETE --&gt;
<a class="l" name="4277" href="#4277">4277</a>