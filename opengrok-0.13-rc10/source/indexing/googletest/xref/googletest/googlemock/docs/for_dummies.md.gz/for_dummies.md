<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># gMock for Dummies {#GMockForDummies}
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>&lt;!-- GOOGLETEST_CM0013 DO NOT DELETE --&gt;
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>&lt;!-- GOOGLETEST_CM0035 DO NOT DELETE --&gt;
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>## What Is gMock?
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>When you write a prototype or test, often it's not feasible or wise to rely on
<a class="hl" name="10" href="#10">10</a>real objects entirely. A **mock object** implements the same interface as a real
<a class="l" name="11" href="#11">11</a>object (so it can be used as one), but lets you specify at run time how it will
<a class="l" name="12" href="#12">12</a>be used and what it should do (which methods will be called? in which order? how
<a class="l" name="13" href="#13">13</a>many times? with what arguments? what will they return? etc).
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a>**Note:** It is easy to confuse the term *fake objects* with mock objects. Fakes
<a class="l" name="16" href="#16">16</a>and mocks actually mean very different things in the Test-Driven Development
<a class="l" name="17" href="#17">17</a>(TDD) community:
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a>*   **Fake** objects have working implementations, but usually take some
<a class="hl" name="20" href="#20">20</a>    shortcut (perhaps to make the operations less expensive), which makes them
<a class="l" name="21" href="#21">21</a>    not suitable for production. An in-memory file system would be an example of
<a class="l" name="22" href="#22">22</a>    a fake.
<a class="l" name="23" href="#23">23</a>*   **Mocks** are objects pre-programmed with *expectations*, which form a
<a class="l" name="24" href="#24">24</a>    specification of the calls they are expected to receive.
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a>If all this seems too abstract for you, don't worry - the most important thing
<a class="l" name="27" href="#27">27</a>to remember is that a mock allows you to check the *interaction* between itself
<a class="l" name="28" href="#28">28</a>and code that uses it. The difference between fakes and mocks shall become much
<a class="l" name="29" href="#29">29</a>clearer once you start to use mocks.
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a>**gMock** is a library (sometimes we also call it a "framework" to make it sound
<a class="l" name="32" href="#32">32</a>cool) for creating mock classes and using them. It does to C++ what
<a class="l" name="33" href="#33">33</a><a href="/googletest/s?path=jMock/EasyMock&amp;project=googletest">jMock/EasyMock</a> does to Java (well, more or less).
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>When using gMock,
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>1.  first, you use some simple macros to describe the interface you want to
<a class="l" name="38" href="#38">38</a>    mock, and they will expand to the implementation of your mock class;
<a class="l" name="39" href="#39">39</a>2.  next, you create some mock objects and specify its expectations and behavior
<a class="hl" name="40" href="#40">40</a>    using an intuitive syntax;
<a class="l" name="41" href="#41">41</a>3.  then you exercise code that uses the mock objects. gMock will catch any
<a class="l" name="42" href="#42">42</a>    violation to the expectations as soon as it arises.
<a class="l" name="43" href="#43">43</a>
<a class="l" name="44" href="#44">44</a>## Why gMock?
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>While mock objects help you remove unnecessary dependencies in tests and make
<a class="l" name="47" href="#47">47</a>them fast and reliable, using mocks manually in C++ is *hard*:
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>*   Someone has to implement the mocks. The job is usually tedious and
<a class="hl" name="50" href="#50">50</a>    error-prone. No wonder people go great distance to avoid it.
<a class="l" name="51" href="#51">51</a>*   The quality of those manually written mocks is a bit, uh, unpredictable. You
<a class="l" name="52" href="#52">52</a>    may see some really polished ones, but you may also see some that were
<a class="l" name="53" href="#53">53</a>    hacked up in a hurry and have all sorts of ad hoc restrictions.
<a class="l" name="54" href="#54">54</a>*   The knowledge you gained from using one mock doesn't transfer to the next
<a class="l" name="55" href="#55">55</a>    one.
<a class="l" name="56" href="#56">56</a>
<a class="l" name="57" href="#57">57</a>In contrast, Java and Python programmers have some fine mock frameworks (jMock,
<a class="l" name="58" href="#58">58</a>EasyMock, [Mox](<a href="http://wtf/mox">http://wtf/mox</a>), etc), which automate the creation of mocks. As
<a class="l" name="59" href="#59">59</a>a result, mocking is a proven effective technique and widely adopted practice in
<a class="hl" name="60" href="#60">60</a>those communities. Having the right tool absolutely makes the difference.
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>gMock was built to help C++ programmers. It was inspired by jMock and EasyMock,
<a class="l" name="63" href="#63">63</a>but designed with C++'s specifics in mind. It is your friend if any of the
<a class="l" name="64" href="#64">64</a>following problems is bothering you:
<a class="l" name="65" href="#65">65</a>
<a class="l" name="66" href="#66">66</a>*   You are stuck with a sub-optimal design and wish you had done more
<a class="l" name="67" href="#67">67</a>    prototyping before it was too late, but prototyping in C++ is by no means
<a class="l" name="68" href="#68">68</a>    "rapid".
<a class="l" name="69" href="#69">69</a>*   Your tests are slow as they depend on too many libraries or use expensive
<a class="hl" name="70" href="#70">70</a>    resources (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> a database).
<a class="l" name="71" href="#71">71</a>*   Your tests are brittle as some resources they use are unreliable (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> the
<a class="l" name="72" href="#72">72</a>    network).
<a class="l" name="73" href="#73">73</a>*   You want to test how your code handles a failure (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> a file checksum
<a class="l" name="74" href="#74">74</a>    error), but it's not easy to cause one.
<a class="l" name="75" href="#75">75</a>*   You need to make sure that your module interacts with other modules in the
<a class="l" name="76" href="#76">76</a>    right way, but it's hard to observe the interaction; therefore you resort to
<a class="l" name="77" href="#77">77</a>    observing the side effects at the end of the action, but it's awkward at
<a class="l" name="78" href="#78">78</a>    best.
<a class="l" name="79" href="#79">79</a>*   You want to "mock out" your dependencies, except that they don't have mock
<a class="hl" name="80" href="#80">80</a>    implementations yet; and, frankly, you aren't thrilled by some of those
<a class="l" name="81" href="#81">81</a>    hand-written mocks.
<a class="l" name="82" href="#82">82</a>
<a class="l" name="83" href="#83">83</a>We encourage you to use gMock as
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>*   a *design* tool, for it lets you experiment with your interface design early
<a class="l" name="86" href="#86">86</a>    and often. More iterations lead to better designs!
<a class="l" name="87" href="#87">87</a>*   a *testing* tool to cut your tests' outbound dependencies and probe the
<a class="l" name="88" href="#88">88</a>    interaction between your module and its collaborators.
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>## Getting Started
<a class="l" name="91" href="#91">91</a>
<a class="l" name="92" href="#92">92</a>gMock is bundled with googletest.
<a class="l" name="93" href="#93">93</a>
<a class="l" name="94" href="#94">94</a>## A Case for Mock Turtles
<a class="l" name="95" href="#95">95</a>
<a class="l" name="96" href="#96">96</a>Let's look at an example. Suppose you are developing a graphics program that
<a class="l" name="97" href="#97">97</a>relies on a [LOGO](<a href="http://en.wikipedia.org/wiki/Logo_programming_language">http://en.wikipedia.org/wiki/Logo_programming_language</a>)-like
<a class="l" name="98" href="#98">98</a>API for drawing. How would you test that it does the right thing? Well, you can
<a class="l" name="99" href="#99">99</a>run it and compare the screen with a golden screen snapshot, but let's admit it:
<a class="hl" name="100" href="#100">100</a>tests like this are expensive to run and fragile (What if you just upgraded to a
<a class="l" name="101" href="#101">101</a>shiny new graphics card that has better anti-aliasing? Suddenly you have to
<a class="l" name="102" href="#102">102</a>update all your golden images.). It would be too painful if all your tests are
<a class="l" name="103" href="#103">103</a>like this. Fortunately, you learned about
<a class="l" name="104" href="#104">104</a>[Dependency Injection](<a href="http://en.wikipedia.org/wiki/Dependency_injection">http://en.wikipedia.org/wiki/Dependency_injection</a>) and know the right thing
<a class="l" name="105" href="#105">105</a>to do: instead of having your application talk to the system API directly, wrap
<a class="l" name="106" href="#106">106</a>the API in an interface (say, `Turtle`) and code to that interface:
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>```cpp
<a class="l" name="109" href="#109">109</a>class Turtle {
<a class="hl" name="110" href="#110">110</a>  ...
<a class="l" name="111" href="#111">111</a>  virtual ~Turtle() {}
<a class="l" name="112" href="#112">112</a>  virtual void PenUp() = 0;
<a class="l" name="113" href="#113">113</a>  virtual void PenDown() = 0;
<a class="l" name="114" href="#114">114</a>  virtual void Forward(int distance) = 0;
<a class="l" name="115" href="#115">115</a>  virtual void Turn(int degrees) = 0;
<a class="l" name="116" href="#116">116</a>  virtual void GoTo(int x, int y) = 0;
<a class="l" name="117" href="#117">117</a>  virtual int GetX() const = 0;
<a class="l" name="118" href="#118">118</a>  virtual int GetY() const = 0;
<a class="l" name="119" href="#119">119</a>};
<a class="hl" name="120" href="#120">120</a>```
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>(Note that the destructor of `Turtle` **must** be virtual, as is the case for
<a class="l" name="123" href="#123">123</a>**all** classes you intend to inherit from - otherwise the destructor of the
<a class="l" name="124" href="#124">124</a>derived class will not be called when you delete an object through a base
<a class="l" name="125" href="#125">125</a>pointer, and you'll get corrupted program states like memory leaks.)
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>You can control whether the turtle's movement will leave a trace using `PenUp()`
<a class="l" name="128" href="#128">128</a>and `PenDown()`, and control its movement using `Forward()`, `Turn()`, and
<a class="l" name="129" href="#129">129</a>`GoTo()`. Finally, `GetX()` and `GetY()` tell you the current position of the
<a class="hl" name="130" href="#130">130</a>turtle.
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>Your program will normally use a real implementation of this interface. In
<a class="l" name="133" href="#133">133</a>tests, you can use a mock implementation instead. This allows you to easily
<a class="l" name="134" href="#134">134</a>check what drawing primitives your program is calling, with what arguments, and
<a class="l" name="135" href="#135">135</a>in which order. Tests written this way are much more robust (they won't break
<a class="l" name="136" href="#136">136</a>because your new machine does anti-aliasing differently), easier to read and
<a class="l" name="137" href="#137">137</a>maintain (the intent of a test is expressed in the code, not in some binary
<a class="l" name="138" href="#138">138</a>images), and run *much, much faster*.
<a class="l" name="139" href="#139">139</a>
<a class="hl" name="140" href="#140">140</a>## Writing the Mock Class
<a class="l" name="141" href="#141">141</a>
<a class="l" name="142" href="#142">142</a>If you are lucky, the mocks you need to use have already been implemented by
<a class="l" name="143" href="#143">143</a>some nice people. If, however, you find yourself in the position to write a mock
<a class="l" name="144" href="#144">144</a>class, relax - gMock turns this task into a fun game! (Well, almost.)
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>### How to Define It
<a class="l" name="147" href="#147">147</a>
<a class="l" name="148" href="#148">148</a>Using the `Turtle` interface as example, here are the simple steps you need to
<a class="l" name="149" href="#149">149</a>follow:
<a class="hl" name="150" href="#150">150</a>
<a class="l" name="151" href="#151">151</a>*   Derive a class `MockTurtle` from `Turtle`.
<a class="l" name="152" href="#152">152</a>*   Take a *virtual* function of `Turtle` (while it's possible to
<a class="l" name="153" href="#153">153</a>    [mock non-virtual methods using templates](<a href="/googletest/s?path=cook_book.md&amp;project=googletest">cook_book.md</a>#MockingNonVirtualMethods),
<a class="l" name="154" href="#154">154</a>    it's much more involved).
<a class="l" name="155" href="#155">155</a>*   In the `public:` section of the child class, write `MOCK_METHOD();`
<a class="l" name="156" href="#156">156</a>*   Now comes the fun part: you take the function signature, cut-and-paste it
<a class="l" name="157" href="#157">157</a>    into the macro, and add two commas - one between the return type and the
<a class="l" name="158" href="#158">158</a>    name, another between the name and the argument list.
<a class="l" name="159" href="#159">159</a>*   If you're mocking a const method, add a 4th parameter containing `(const)`
<a class="hl" name="160" href="#160">160</a>    (the parentheses are required).
<a class="l" name="161" href="#161">161</a>*   Since you're overriding a virtual method, we suggest adding the `override`
<a class="l" name="162" href="#162">162</a>    keyword. For const methods the 4th parameter becomes `(const, override)`,
<a class="l" name="163" href="#163">163</a>    for non-const methods just `(override)`. This isn't mandatory.
<a class="l" name="164" href="#164">164</a>*   Repeat until all virtual functions you want to mock are done. (It goes
<a class="l" name="165" href="#165">165</a>    without saying that *all* pure virtual methods in your abstract class must
<a class="l" name="166" href="#166">166</a>    be either mocked or overridden.)
<a class="l" name="167" href="#167">167</a>
<a class="l" name="168" href="#168">168</a>After the process, you should have something like:
<a class="l" name="169" href="#169">169</a>
<a class="hl" name="170" href="#170">170</a>```cpp
<a class="l" name="171" href="#171">171</a>#include "<a href="/googletest/s?path=gmock/gmock.h&amp;project=googletest">gmock/gmock.h</a>"  // Brings in gMock.
<a class="l" name="172" href="#172">172</a>
<a class="l" name="173" href="#173">173</a>class MockTurtle : public Turtle {
<a class="l" name="174" href="#174">174</a> public:
<a class="l" name="175" href="#175">175</a>  ...
<a class="l" name="176" href="#176">176</a>  MOCK_METHOD(void, PenUp, (), (override));
<a class="l" name="177" href="#177">177</a>  MOCK_METHOD(void, PenDown, (), (override));
<a class="l" name="178" href="#178">178</a>  MOCK_METHOD(void, Forward, (int distance), (override));
<a class="l" name="179" href="#179">179</a>  MOCK_METHOD(void, Turn, (int degrees), (override));
<a class="hl" name="180" href="#180">180</a>  MOCK_METHOD(void, GoTo, (int x, int y), (override));
<a class="l" name="181" href="#181">181</a>  MOCK_METHOD(int, GetX, (), (const, override));
<a class="l" name="182" href="#182">182</a>  MOCK_METHOD(int, GetY, (), (const, override));
<a class="l" name="183" href="#183">183</a>};
<a class="l" name="184" href="#184">184</a>```
<a class="l" name="185" href="#185">185</a>
<a class="l" name="186" href="#186">186</a>You don't need to define these mock methods somewhere else - the `MOCK_METHOD`
<a class="l" name="187" href="#187">187</a>macro will generate the definitions for you. It's that simple!
<a class="l" name="188" href="#188">188</a>
<a class="l" name="189" href="#189">189</a>### Where to Put It
<a class="hl" name="190" href="#190">190</a>
<a class="l" name="191" href="#191">191</a>When you define a mock class, you need to decide where to put its definition.
<a class="l" name="192" href="#192">192</a>Some people put it in a `<a href="/googletest/s?path=_test.cc&amp;project=googletest">_test.cc</a>`. This is fine when the interface being mocked
<a class="l" name="193" href="#193">193</a>(say, `Foo`) is owned by the same person or team. Otherwise, when the owner of
<a class="l" name="194" href="#194">194</a>`Foo` changes it, your test could break. (You can't really expect `Foo`'s
<a class="l" name="195" href="#195">195</a>maintainer to fix every test that uses `Foo`, can you?)
<a class="l" name="196" href="#196">196</a>
<a class="l" name="197" href="#197">197</a>So, the rule of thumb is: if you need to mock `Foo` and it's owned by others,
<a class="l" name="198" href="#198">198</a>define the mock class in `Foo`'s package (better, in a `testing` sub-package
<a class="l" name="199" href="#199">199</a>such that you can clearly separate production code and testing utilities), put
<a class="hl" name="200" href="#200">200</a>it in a `.h` and a `cc_library`. Then everyone can reference them from their
<a class="l" name="201" href="#201">201</a>tests. If `Foo` ever changes, there is only one copy of `MockFoo` to change, and
<a class="l" name="202" href="#202">202</a>only tests that depend on the changed methods need to be fixed.
<a class="l" name="203" href="#203">203</a>
<a class="l" name="204" href="#204">204</a>Another way to do it: you can introduce a thin layer `FooAdaptor` on top of
<a class="l" name="205" href="#205">205</a>`Foo` and code to this new interface. Since you own `FooAdaptor`, you can absorb
<a class="l" name="206" href="#206">206</a>changes in `Foo` much more easily. While this is more work initially, carefully
<a class="l" name="207" href="#207">207</a>choosing the adaptor interface can make your code easier to write and more
<a class="l" name="208" href="#208">208</a>readable (a net win in the long run), as you can choose `FooAdaptor` to fit your
<a class="l" name="209" href="#209">209</a>specific domain much better than `Foo` does.
<a class="hl" name="210" href="#210">210</a>
<a class="l" name="211" href="#211">211</a>&lt;!-- GOOGLETEST_CM0029 DO NOT DELETE --&gt;
<a class="l" name="212" href="#212">212</a>
<a class="l" name="213" href="#213">213</a>## Using Mocks in Tests
<a class="l" name="214" href="#214">214</a>
<a class="l" name="215" href="#215">215</a>Once you have a mock class, using it is easy. The typical work flow is:
<a class="l" name="216" href="#216">216</a>
<a class="l" name="217" href="#217">217</a>1.  Import the gMock names from the `testing` namespace such that you can use
<a class="l" name="218" href="#218">218</a>    them unqualified (You only have to do it once per file). Remember that
<a class="l" name="219" href="#219">219</a>    namespaces are a good idea.
<a class="hl" name="220" href="#220">220</a>2.  Create some mock objects.
<a class="l" name="221" href="#221">221</a>3.  Specify your expectations on them (How many times will a method be called?
<a class="l" name="222" href="#222">222</a>    With what arguments? What should it do? etc.).
<a class="l" name="223" href="#223">223</a>4.  Exercise some code that uses the mocks; optionally, check the result using
<a class="l" name="224" href="#224">224</a>    googletest assertions. If a mock method is called more than expected or with
<a class="l" name="225" href="#225">225</a>    wrong arguments, you'll get an error immediately.
<a class="l" name="226" href="#226">226</a>5.  When a mock is destructed, gMock will automatically check whether all
<a class="l" name="227" href="#227">227</a>    expectations on it have been satisfied.
<a class="l" name="228" href="#228">228</a>
<a class="l" name="229" href="#229">229</a>Here's an example:
<a class="hl" name="230" href="#230">230</a>
<a class="l" name="231" href="#231">231</a>```cpp
<a class="l" name="232" href="#232">232</a>#include "<a href="/googletest/s?path=path/to/mock-turtle.h&amp;project=googletest">path/to/mock-turtle.h</a>"
<a class="l" name="233" href="#233">233</a>#include "<a href="/googletest/s?path=gmock/gmock.h&amp;project=googletest">gmock/gmock.h</a>"
<a class="l" name="234" href="#234">234</a>#include "<a href="/googletest/s?path=gtest/gtest.h&amp;project=googletest">gtest/gtest.h</a>"
<a class="l" name="235" href="#235">235</a>
<a class="l" name="236" href="#236">236</a>using ::testing::AtLeast;                         // #1
<a class="l" name="237" href="#237">237</a>
<a class="l" name="238" href="#238">238</a>TEST(PainterTest, CanDrawSomething) {
<a class="l" name="239" href="#239">239</a>  MockTurtle turtle;                              // #2
<a class="hl" name="240" href="#240">240</a>  EXPECT_CALL(turtle, PenDown())                  // #3
<a class="l" name="241" href="#241">241</a>      .Times(AtLeast(1));
<a class="l" name="242" href="#242">242</a>
<a class="l" name="243" href="#243">243</a>  Painter painter(&amp;turtle);                       // #4
<a class="l" name="244" href="#244">244</a>
<a class="l" name="245" href="#245">245</a>  EXPECT_TRUE(<a href="/googletest/s?path=painter.DrawCircle&amp;project=googletest">painter.DrawCircle</a>(0, 0, 10));      // #5
<a class="l" name="246" href="#246">246</a>}
<a class="l" name="247" href="#247">247</a>```
<a class="l" name="248" href="#248">248</a>
<a class="l" name="249" href="#249">249</a>As you might have guessed, this test checks that `PenDown()` is called at least
<a class="hl" name="250" href="#250">250</a>once. If the `painter` object didn't call this method, your test will fail with
<a class="l" name="251" href="#251">251</a>a message like this:
<a class="l" name="252" href="#252">252</a>
<a class="l" name="253" href="#253">253</a>```text
<a class="l" name="254" href="#254">254</a><a href="/googletest/s?path=path/to/my_test.cc&amp;project=googletest">path/to/my_test.cc</a>:119: Failure
<a class="l" name="255" href="#255">255</a>Actual function call count doesn't match this expectation:
<a class="l" name="256" href="#256">256</a>Actually: never called;
<a class="l" name="257" href="#257">257</a>Expected: called at least once.
<a class="l" name="258" href="#258">258</a>Stack trace:
<a class="l" name="259" href="#259">259</a>...
<a class="hl" name="260" href="#260">260</a>```
<a class="l" name="261" href="#261">261</a>
<a class="l" name="262" href="#262">262</a>**Tip 1:** If you run the test from an Emacs buffer, you can hit `&lt;Enter&gt;` on
<a class="l" name="263" href="#263">263</a>the line number to jump right to the failed expectation.
<a class="l" name="264" href="#264">264</a>
<a class="l" name="265" href="#265">265</a>**Tip 2:** If your mock objects are never deleted, the final verification won't
<a class="l" name="266" href="#266">266</a>happen. Therefore it's a good idea to turn on the heap checker in your tests
<a class="l" name="267" href="#267">267</a>when you allocate mocks on the heap. You get that automatically if you use the
<a class="l" name="268" href="#268">268</a>`gtest_main` library already.
<a class="l" name="269" href="#269">269</a>
<a class="hl" name="270" href="#270">270</a>**Important note:** gMock requires expectations to be set **before** the mock
<a class="l" name="271" href="#271">271</a>functions are called, otherwise the behavior is **undefined**. In particular,
<a class="l" name="272" href="#272">272</a>you mustn't interleave `EXPECT_CALL()s` and calls to the mock functions.
<a class="l" name="273" href="#273">273</a>
<a class="l" name="274" href="#274">274</a>This means `EXPECT_CALL()` should be read as expecting that a call will occur
<a class="l" name="275" href="#275">275</a>*in the future*, not that a call has occurred. Why does gMock work like that?
<a class="l" name="276" href="#276">276</a>Well, specifying the expectation beforehand allows gMock to report a violation
<a class="l" name="277" href="#277">277</a>as soon as it rises, when the context (stack trace, etc) is still available.
<a class="l" name="278" href="#278">278</a>This makes debugging much easier.
<a class="l" name="279" href="#279">279</a>
<a class="hl" name="280" href="#280">280</a>Admittedly, this test is contrived and doesn't do much. You can easily achieve
<a class="l" name="281" href="#281">281</a>the same effect without using gMock. However, as we shall reveal soon, gMock
<a class="l" name="282" href="#282">282</a>allows you to do *so much more* with the mocks.
<a class="l" name="283" href="#283">283</a>
<a class="l" name="284" href="#284">284</a>## Setting Expectations
<a class="l" name="285" href="#285">285</a>
<a class="l" name="286" href="#286">286</a>The key to using a mock object successfully is to set the *right expectations*
<a class="l" name="287" href="#287">287</a>on it. If you set the expectations too strict, your test will fail as the result
<a class="l" name="288" href="#288">288</a>of unrelated changes. If you set them too loose, bugs can slip through. You want
<a class="l" name="289" href="#289">289</a>to do it just right such that your test can catch exactly the kind of bugs you
<a class="hl" name="290" href="#290">290</a>intend it to catch. gMock provides the necessary means for you to do it "just
<a class="l" name="291" href="#291">291</a>right."
<a class="l" name="292" href="#292">292</a>
<a class="l" name="293" href="#293">293</a>### General Syntax
<a class="l" name="294" href="#294">294</a>
<a class="l" name="295" href="#295">295</a>In gMock we use the `EXPECT_CALL()` macro to set an expectation on a mock
<a class="l" name="296" href="#296">296</a>method. The general syntax is:
<a class="l" name="297" href="#297">297</a>
<a class="l" name="298" href="#298">298</a>```cpp
<a class="l" name="299" href="#299">299</a>EXPECT_CALL(mock_object, method(matchers))
<a class="hl" name="300" href="#300">300</a>    .Times(cardinality)
<a class="l" name="301" href="#301">301</a>    .WillOnce(action)
<a class="l" name="302" href="#302">302</a>    .WillRepeatedly(action);
<a class="l" name="303" href="#303">303</a>```
<a class="l" name="304" href="#304">304</a>
<a class="l" name="305" href="#305">305</a>The macro has two arguments: first the mock object, and then the method and its
<a class="l" name="306" href="#306">306</a>arguments. Note that the two are separated by a comma (`,`), not a period (`.`).
<a class="l" name="307" href="#307">307</a>(Why using a comma? The answer is that it was necessary for technical reasons.)
<a class="l" name="308" href="#308">308</a>If the method is not overloaded, the macro can also be called without matchers:
<a class="l" name="309" href="#309">309</a>
<a class="hl" name="310" href="#310">310</a>```cpp
<a class="l" name="311" href="#311">311</a>EXPECT_CALL(mock_object, non-overloaded-method)
<a class="l" name="312" href="#312">312</a>    .Times(cardinality)
<a class="l" name="313" href="#313">313</a>    .WillOnce(action)
<a class="l" name="314" href="#314">314</a>    .WillRepeatedly(action);
<a class="l" name="315" href="#315">315</a>```
<a class="l" name="316" href="#316">316</a>
<a class="l" name="317" href="#317">317</a>This syntax allows the test writer to specify "called with any arguments"
<a class="l" name="318" href="#318">318</a>without explicitly specifying the number or types of arguments. To avoid
<a class="l" name="319" href="#319">319</a>unintended ambiguity, this syntax may only be used for methods which are not
<a class="hl" name="320" href="#320">320</a>overloaded
<a class="l" name="321" href="#321">321</a>
<a class="l" name="322" href="#322">322</a>Either form of the macro can be followed by some optional *clauses* that provide
<a class="l" name="323" href="#323">323</a>more information about the expectation. We'll discuss how each clause works in
<a class="l" name="324" href="#324">324</a>the coming sections.
<a class="l" name="325" href="#325">325</a>
<a class="l" name="326" href="#326">326</a>This syntax is designed to make an expectation read like English. For example,
<a class="l" name="327" href="#327">327</a>you can probably guess that
<a class="l" name="328" href="#328">328</a>
<a class="l" name="329" href="#329">329</a>```cpp
<a class="hl" name="330" href="#330">330</a>using ::testing::Return;
<a class="l" name="331" href="#331">331</a>...
<a class="l" name="332" href="#332">332</a>EXPECT_CALL(turtle, GetX())
<a class="l" name="333" href="#333">333</a>    .Times(5)
<a class="l" name="334" href="#334">334</a>    .WillOnce(Return(100))
<a class="l" name="335" href="#335">335</a>    .WillOnce(Return(150))
<a class="l" name="336" href="#336">336</a>    .WillRepeatedly(Return(200));
<a class="l" name="337" href="#337">337</a>```
<a class="l" name="338" href="#338">338</a>
<a class="l" name="339" href="#339">339</a>says that the `turtle` object's `GetX()` method will be called five times, it
<a class="hl" name="340" href="#340">340</a>will return 100 the first time, 150 the second time, and then 200 every time.
<a class="l" name="341" href="#341">341</a>Some people like to call this style of syntax a Domain-Specific Language (DSL).
<a class="l" name="342" href="#342">342</a>
<a class="l" name="343" href="#343">343</a>**Note:** Why do we use a macro to do this? Well it serves two purposes: first
<a class="l" name="344" href="#344">344</a>it makes expectations easily identifiable (either by `gsearch` or by a human
<a class="l" name="345" href="#345">345</a>reader), and second it allows gMock to include the source file location of a
<a class="l" name="346" href="#346">346</a>failed expectation in messages, making debugging easier.
<a class="l" name="347" href="#347">347</a>
<a class="l" name="348" href="#348">348</a>### Matchers: What Arguments Do We Expect?
<a class="l" name="349" href="#349">349</a>
<a class="hl" name="350" href="#350">350</a>When a mock function takes arguments, we may specify what arguments we are
<a class="l" name="351" href="#351">351</a>expecting, for example:
<a class="l" name="352" href="#352">352</a>
<a class="l" name="353" href="#353">353</a>```cpp
<a class="l" name="354" href="#354">354</a>// Expects the turtle to move forward by 100 units.
<a class="l" name="355" href="#355">355</a>EXPECT_CALL(turtle, Forward(100));
<a class="l" name="356" href="#356">356</a>```
<a class="l" name="357" href="#357">357</a>
<a class="l" name="358" href="#358">358</a>Oftentimes you do not want to be too specific. Remember that talk about tests
<a class="l" name="359" href="#359">359</a>being too rigid? Over specification leads to brittle tests and obscures the
<a class="hl" name="360" href="#360">360</a>intent of tests. Therefore we encourage you to specify only what's necessary&#8212;no
<a class="l" name="361" href="#361">361</a>more, no less. If you aren't interested in the value of an argument, write `_`
<a class="l" name="362" href="#362">362</a>as the argument, which means "anything goes":
<a class="l" name="363" href="#363">363</a>
<a class="l" name="364" href="#364">364</a>```cpp
<a class="l" name="365" href="#365">365</a>using ::testing::_;
<a class="l" name="366" href="#366">366</a>...
<a class="l" name="367" href="#367">367</a>// Expects that the turtle jumps to somewhere on the x=50 line.
<a class="l" name="368" href="#368">368</a>EXPECT_CALL(turtle, GoTo(50, _));
<a class="l" name="369" href="#369">369</a>```
<a class="hl" name="370" href="#370">370</a>
<a class="l" name="371" href="#371">371</a>`_` is an instance of what we call **matchers**. A matcher is like a predicate
<a class="l" name="372" href="#372">372</a>and can test whether an argument is what we'd expect. You can use a matcher
<a class="l" name="373" href="#373">373</a>inside `EXPECT_CALL()` wherever a function argument is expected. `_` is a
<a class="l" name="374" href="#374">374</a>convenient way of saying "any value".
<a class="l" name="375" href="#375">375</a>
<a class="l" name="376" href="#376">376</a>In the above examples, `100` and `50` are also matchers; implicitly, they are
<a class="l" name="377" href="#377">377</a>the same as `Eq(100)` and `Eq(50)`, which specify that the argument must be
<a class="l" name="378" href="#378">378</a>equal (using `operator==`) to the matcher argument. There are many
<a class="l" name="379" href="#379">379</a>[built-in matchers](<a href="/googletest/s?path=cheat_sheet.md&amp;project=googletest">cheat_sheet.md</a>#MatcherList) for common types (as well as
<a class="hl" name="380" href="#380">380</a>[custom matchers](<a href="/googletest/s?path=cook_book.md&amp;project=googletest">cook_book.md</a>#NewMatchers)); for example:
<a class="l" name="381" href="#381">381</a>
<a class="l" name="382" href="#382">382</a>```cpp
<a class="l" name="383" href="#383">383</a>using ::testing::Ge;
<a class="l" name="384" href="#384">384</a>...
<a class="l" name="385" href="#385">385</a>// Expects the turtle moves forward by at least 100.
<a class="l" name="386" href="#386">386</a>EXPECT_CALL(turtle, Forward(Ge(100)));
<a class="l" name="387" href="#387">387</a>```
<a class="l" name="388" href="#388">388</a>
<a class="l" name="389" href="#389">389</a>If you don't care about *any* arguments, rather than specify `_` for each of
<a class="hl" name="390" href="#390">390</a>them you may instead omit the parameter list:
<a class="l" name="391" href="#391">391</a>
<a class="l" name="392" href="#392">392</a>```cpp
<a class="l" name="393" href="#393">393</a>// Expects the turtle to move forward.
<a class="l" name="394" href="#394">394</a>EXPECT_CALL(turtle, Forward);
<a class="l" name="395" href="#395">395</a>// Expects the turtle to jump somewhere.
<a class="l" name="396" href="#396">396</a>EXPECT_CALL(turtle, GoTo);
<a class="l" name="397" href="#397">397</a>```
<a class="l" name="398" href="#398">398</a>
<a class="l" name="399" href="#399">399</a>This works for all non-overloaded methods; if a method is overloaded, you need
<a class="hl" name="400" href="#400">400</a>to help gMock resolve which overload is expected by specifying the number of
<a class="l" name="401" href="#401">401</a>arguments and possibly also the
<a class="l" name="402" href="#402">402</a>[types of the arguments](<a href="/googletest/s?path=cook_book.md&amp;project=googletest">cook_book.md</a>#SelectOverload).
<a class="l" name="403" href="#403">403</a>
<a class="l" name="404" href="#404">404</a>### Cardinalities: How Many Times Will It Be Called?
<a class="l" name="405" href="#405">405</a>
<a class="l" name="406" href="#406">406</a>The first clause we can specify following an `EXPECT_CALL()` is `Times()`. We
<a class="l" name="407" href="#407">407</a>call its argument a **cardinality** as it tells *how many times* the call should
<a class="l" name="408" href="#408">408</a>occur. It allows us to repeat an expectation many times without actually writing
<a class="l" name="409" href="#409">409</a>it as many times. More importantly, a cardinality can be "fuzzy", just like a
<a class="hl" name="410" href="#410">410</a>matcher can be. This allows a user to express the intent of a test exactly.
<a class="l" name="411" href="#411">411</a>
<a class="l" name="412" href="#412">412</a>An interesting special case is when we say `Times(0)`. You may have guessed - it
<a class="l" name="413" href="#413">413</a>means that the function shouldn't be called with the given arguments at all, and
<a class="l" name="414" href="#414">414</a>gMock will report a googletest failure whenever the function is (wrongfully)
<a class="l" name="415" href="#415">415</a>called.
<a class="l" name="416" href="#416">416</a>
<a class="l" name="417" href="#417">417</a>We've seen `AtLeast(n)` as an example of fuzzy cardinalities earlier. For the
<a class="l" name="418" href="#418">418</a>list of built-in cardinalities you can use, see
<a class="l" name="419" href="#419">419</a>[here](<a href="/googletest/s?path=cheat_sheet.md&amp;project=googletest">cheat_sheet.md</a>#CardinalityList).
<a class="hl" name="420" href="#420">420</a>
<a class="l" name="421" href="#421">421</a>The `Times()` clause can be omitted. **If you omit `Times()`, gMock will infer
<a class="l" name="422" href="#422">422</a>the cardinality for you.** The rules are easy to remember:
<a class="l" name="423" href="#423">423</a>
<a class="l" name="424" href="#424">424</a>*   If **neither** `WillOnce()` **nor** `WillRepeatedly()` is in the
<a class="l" name="425" href="#425">425</a>    `EXPECT_CALL()`, the inferred cardinality is `Times(1)`.
<a class="l" name="426" href="#426">426</a>*   If there are *n* `WillOnce()`'s but **no** `WillRepeatedly()`, where *n* &gt;=
<a class="l" name="427" href="#427">427</a>    1, the cardinality is `Times(n)`.
<a class="l" name="428" href="#428">428</a>*   If there are *n* `WillOnce()`'s and **one** `WillRepeatedly()`, where *n* &gt;=
<a class="l" name="429" href="#429">429</a>    0, the cardinality is `Times(AtLeast(n))`.
<a class="hl" name="430" href="#430">430</a>
<a class="l" name="431" href="#431">431</a>**Quick quiz:** what do you think will happen if a function is expected to be
<a class="l" name="432" href="#432">432</a>called twice but actually called four times?
<a class="l" name="433" href="#433">433</a>
<a class="l" name="434" href="#434">434</a>### Actions: What Should It Do?
<a class="l" name="435" href="#435">435</a>
<a class="l" name="436" href="#436">436</a>Remember that a mock object doesn't really have a working implementation? We as
<a class="l" name="437" href="#437">437</a>users have to tell it what to do when a method is invoked. This is easy in
<a class="l" name="438" href="#438">438</a>gMock.
<a class="l" name="439" href="#439">439</a>
<a class="hl" name="440" href="#440">440</a>First, if the return type of a mock function is a built-in type or a pointer,
<a class="l" name="441" href="#441">441</a>the function has a **default action** (a `void` function will just return, a
<a class="l" name="442" href="#442">442</a>`bool` function will return `false`, and other functions will return 0). In
<a class="l" name="443" href="#443">443</a>addition, in C++ 11 and above, a mock function whose return type is
<a class="l" name="444" href="#444">444</a>default-constructible (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> has a default constructor) has a default action of
<a class="l" name="445" href="#445">445</a>returning a default-constructed value. If you don't say anything, this behavior
<a class="l" name="446" href="#446">446</a>will be used.
<a class="l" name="447" href="#447">447</a>
<a class="l" name="448" href="#448">448</a>Second, if a mock function doesn't have a default action, or the default action
<a class="l" name="449" href="#449">449</a>doesn't suit you, you can specify the action to be taken each time the
<a class="hl" name="450" href="#450">450</a>expectation matches using a series of `WillOnce()` clauses followed by an
<a class="l" name="451" href="#451">451</a>optional `WillRepeatedly()`. For example,
<a class="l" name="452" href="#452">452</a>
<a class="l" name="453" href="#453">453</a>```cpp
<a class="l" name="454" href="#454">454</a>using ::testing::Return;
<a class="l" name="455" href="#455">455</a>...
<a class="l" name="456" href="#456">456</a>EXPECT_CALL(turtle, GetX())
<a class="l" name="457" href="#457">457</a>     .WillOnce(Return(100))
<a class="l" name="458" href="#458">458</a>     .WillOnce(Return(200))
<a class="l" name="459" href="#459">459</a>     .WillOnce(Return(300));
<a class="hl" name="460" href="#460">460</a>```
<a class="l" name="461" href="#461">461</a>
<a class="l" name="462" href="#462">462</a>says that `<a href="/googletest/s?path=turtle.GetX&amp;project=googletest">turtle.GetX</a>()` will be called *exactly three times* (gMock inferred
<a class="l" name="463" href="#463">463</a>this from how many `WillOnce()` clauses we've written, since we didn't
<a class="l" name="464" href="#464">464</a>explicitly write `Times()`), and will return 100, 200, and 300 respectively.
<a class="l" name="465" href="#465">465</a>
<a class="l" name="466" href="#466">466</a>```cpp
<a class="l" name="467" href="#467">467</a>using ::testing::Return;
<a class="l" name="468" href="#468">468</a>...
<a class="l" name="469" href="#469">469</a>EXPECT_CALL(turtle, GetY())
<a class="hl" name="470" href="#470">470</a>     .WillOnce(Return(100))
<a class="l" name="471" href="#471">471</a>     .WillOnce(Return(200))
<a class="l" name="472" href="#472">472</a>     .WillRepeatedly(Return(300));
<a class="l" name="473" href="#473">473</a>```
<a class="l" name="474" href="#474">474</a>
<a class="l" name="475" href="#475">475</a>says that `<a href="/googletest/s?path=turtle.GetY&amp;project=googletest">turtle.GetY</a>()` will be called *at least twice* (gMock knows this as
<a class="l" name="476" href="#476">476</a>we've written two `WillOnce()` clauses and a `WillRepeatedly()` while having no
<a class="l" name="477" href="#477">477</a>explicit `Times()`), will return 100 and 200 respectively the first two times,
<a class="l" name="478" href="#478">478</a>and 300 from the third time on.
<a class="l" name="479" href="#479">479</a>
<a class="hl" name="480" href="#480">480</a>Of course, if you explicitly write a `Times()`, gMock will not try to infer the
<a class="l" name="481" href="#481">481</a>cardinality itself. What if the number you specified is larger than there are
<a class="l" name="482" href="#482">482</a>`WillOnce()` clauses? Well, after all `WillOnce()`s are used up, gMock will do
<a class="l" name="483" href="#483">483</a>the *default* action for the function every time (unless, of course, you have a
<a class="l" name="484" href="#484">484</a>`WillRepeatedly()`.).
<a class="l" name="485" href="#485">485</a>
<a class="l" name="486" href="#486">486</a>What can we do inside `WillOnce()` besides `Return()`? You can return a
<a class="l" name="487" href="#487">487</a>reference using `ReturnRef(*variable*)`, or invoke a pre-defined function, among
<a class="l" name="488" href="#488">488</a>[others](<a href="/googletest/s?path=cook_book.md&amp;project=googletest">cook_book.md</a>#using-actions).
<a class="l" name="489" href="#489">489</a>
<a class="hl" name="490" href="#490">490</a>**Important note:** The `EXPECT_CALL()` statement evaluates the action clause
<a class="l" name="491" href="#491">491</a>only once, even though the action may be performed many times. Therefore you
<a class="l" name="492" href="#492">492</a>must be careful about side effects. The following may not do what you want:
<a class="l" name="493" href="#493">493</a>
<a class="l" name="494" href="#494">494</a>```cpp
<a class="l" name="495" href="#495">495</a>using ::testing::Return;
<a class="l" name="496" href="#496">496</a>...
<a class="l" name="497" href="#497">497</a>int n = 100;
<a class="l" name="498" href="#498">498</a>EXPECT_CALL(turtle, GetX())
<a class="l" name="499" href="#499">499</a>    .Times(4)
<a class="hl" name="500" href="#500">500</a>    .WillRepeatedly(Return(n++));
<a class="l" name="501" href="#501">501</a>```
<a class="l" name="502" href="#502">502</a>
<a class="l" name="503" href="#503">503</a>Instead of returning 100, 101, 102, ..., consecutively, this mock function will
<a class="l" name="504" href="#504">504</a>always return 100 as `n++` is only evaluated once. Similarly, `Return(new Foo)`
<a class="l" name="505" href="#505">505</a>will create a new `Foo` object when the `EXPECT_CALL()` is executed, and will
<a class="l" name="506" href="#506">506</a>return the same pointer every time. If you want the side effect to happen every
<a class="l" name="507" href="#507">507</a>time, you need to define a custom action, which we'll teach in the
<a class="l" name="508" href="#508">508</a>[cook book](http://&lt;!-- GOOGLETEST_CM0012 DO NOT DELETE --&gt;).
<a class="l" name="509" href="#509">509</a>
<a class="hl" name="510" href="#510">510</a>Time for another quiz! What do you think the following means?
<a class="l" name="511" href="#511">511</a>
<a class="l" name="512" href="#512">512</a>```cpp
<a class="l" name="513" href="#513">513</a>using ::testing::Return;
<a class="l" name="514" href="#514">514</a>...
<a class="l" name="515" href="#515">515</a>EXPECT_CALL(turtle, GetY())
<a class="l" name="516" href="#516">516</a>    .Times(4)
<a class="l" name="517" href="#517">517</a>    .WillOnce(Return(100));
<a class="l" name="518" href="#518">518</a>```
<a class="l" name="519" href="#519">519</a>
<a class="hl" name="520" href="#520">520</a>Obviously `<a href="/googletest/s?path=turtle.GetY&amp;project=googletest">turtle.GetY</a>()` is expected to be called four times. But if you think
<a class="l" name="521" href="#521">521</a>it will return 100 every time, think twice! Remember that one `WillOnce()`
<a class="l" name="522" href="#522">522</a>clause will be consumed each time the function is invoked and the default action
<a class="l" name="523" href="#523">523</a>will be taken afterwards. So the right answer is that `<a href="/googletest/s?path=turtle.GetY&amp;project=googletest">turtle.GetY</a>()` will
<a class="l" name="524" href="#524">524</a>return 100 the first time, but **return 0 from the second time on**, as
<a class="l" name="525" href="#525">525</a>returning 0 is the default action for `int` functions.
<a class="l" name="526" href="#526">526</a>
<a class="l" name="527" href="#527">527</a>### Using Multiple Expectations {#MultiExpectations}
<a class="l" name="528" href="#528">528</a>
<a class="l" name="529" href="#529">529</a>So far we've only shown examples where you have a single expectation. More
<a class="hl" name="530" href="#530">530</a>realistically, you'll specify expectations on multiple mock methods which may be
<a class="l" name="531" href="#531">531</a>from multiple mock objects.
<a class="l" name="532" href="#532">532</a>
<a class="l" name="533" href="#533">533</a>By default, when a mock method is invoked, gMock will search the expectations in
<a class="l" name="534" href="#534">534</a>the **reverse order** they are defined, and stop when an active expectation that
<a class="l" name="535" href="#535">535</a>matches the arguments is found (you can think of it as "newer rules override
<a class="l" name="536" href="#536">536</a>older ones."). If the matching expectation cannot take any more calls, you will
<a class="l" name="537" href="#537">537</a>get an upper-bound-violated failure. Here's an example:
<a class="l" name="538" href="#538">538</a>
<a class="l" name="539" href="#539">539</a>```cpp
<a class="hl" name="540" href="#540">540</a>using ::testing::_;
<a class="l" name="541" href="#541">541</a>...
<a class="l" name="542" href="#542">542</a>EXPECT_CALL(turtle, Forward(_));  // #1
<a class="l" name="543" href="#543">543</a>EXPECT_CALL(turtle, Forward(10))  // #2
<a class="l" name="544" href="#544">544</a>    .Times(2);
<a class="l" name="545" href="#545">545</a>```
<a class="l" name="546" href="#546">546</a>
<a class="l" name="547" href="#547">547</a>If `Forward(10)` is called three times in a row, the third time it will be an
<a class="l" name="548" href="#548">548</a>error, as the last matching expectation (#2) has been saturated. If, however,
<a class="l" name="549" href="#549">549</a>the third `Forward(10)` call is replaced by `Forward(20)`, then it would be OK,
<a class="hl" name="550" href="#550">550</a>as now #1 will be the matching expectation.
<a class="l" name="551" href="#551">551</a>
<a class="l" name="552" href="#552">552</a>**Note:** Why does gMock search for a match in the *reverse* order of the
<a class="l" name="553" href="#553">553</a>expectations? The reason is that this allows a user to set up the default
<a class="l" name="554" href="#554">554</a>expectations in a mock object's constructor or the test fixture's set-up phase
<a class="l" name="555" href="#555">555</a>and then customize the mock by writing more specific expectations in the test
<a class="l" name="556" href="#556">556</a>body. So, if you have two expectations on the same method, you want to put the
<a class="l" name="557" href="#557">557</a>one with more specific matchers **after** the other, or the more specific rule
<a class="l" name="558" href="#558">558</a>would be shadowed by the more general one that comes after it.
<a class="l" name="559" href="#559">559</a>
<a class="hl" name="560" href="#560">560</a>**Tip:** It is very common to start with a catch-all expectation for a method
<a class="l" name="561" href="#561">561</a>and `Times(AnyNumber())` (omitting arguments, or with `_` for all arguments, if
<a class="l" name="562" href="#562">562</a>overloaded). This makes any calls to the method expected. This is not necessary
<a class="l" name="563" href="#563">563</a>for methods that are not mentioned at all (these are "uninteresting"), but is
<a class="l" name="564" href="#564">564</a>useful for methods that have some expectations, but for which other calls are
<a class="l" name="565" href="#565">565</a>ok. See
<a class="l" name="566" href="#566">566</a>[Understanding Uninteresting vs Unexpected Calls](<a href="/googletest/s?path=cook_book.md&amp;project=googletest">cook_book.md</a>#uninteresting-vs-unexpected).
<a class="l" name="567" href="#567">567</a>
<a class="l" name="568" href="#568">568</a>### Ordered vs Unordered Calls {#OrderedCalls}
<a class="l" name="569" href="#569">569</a>
<a class="hl" name="570" href="#570">570</a>By default, an expectation can match a call even though an earlier expectation
<a class="l" name="571" href="#571">571</a>hasn't been satisfied. In other words, the calls don't have to occur in the
<a class="l" name="572" href="#572">572</a>order the expectations are specified.
<a class="l" name="573" href="#573">573</a>
<a class="l" name="574" href="#574">574</a>Sometimes, you may want all the expected calls to occur in a strict order. To
<a class="l" name="575" href="#575">575</a>say this in gMock is easy:
<a class="l" name="576" href="#576">576</a>
<a class="l" name="577" href="#577">577</a>```cpp
<a class="l" name="578" href="#578">578</a>using ::testing::InSequence;
<a class="l" name="579" href="#579">579</a>...
<a class="hl" name="580" href="#580">580</a>TEST(FooTest, DrawsLineSegment) {
<a class="l" name="581" href="#581">581</a>  ...
<a class="l" name="582" href="#582">582</a>  {
<a class="l" name="583" href="#583">583</a>    InSequence seq;
<a class="l" name="584" href="#584">584</a>
<a class="l" name="585" href="#585">585</a>    EXPECT_CALL(turtle, PenDown());
<a class="l" name="586" href="#586">586</a>    EXPECT_CALL(turtle, Forward(100));
<a class="l" name="587" href="#587">587</a>    EXPECT_CALL(turtle, PenUp());
<a class="l" name="588" href="#588">588</a>  }
<a class="l" name="589" href="#589">589</a>  Foo();
<a class="hl" name="590" href="#590">590</a>}
<a class="l" name="591" href="#591">591</a>```
<a class="l" name="592" href="#592">592</a>
<a class="l" name="593" href="#593">593</a>By creating an object of type `InSequence`, all expectations in its scope are
<a class="l" name="594" href="#594">594</a>put into a *sequence* and have to occur *sequentially*. Since we are just
<a class="l" name="595" href="#595">595</a>relying on the constructor and destructor of this object to do the actual work,
<a class="l" name="596" href="#596">596</a>its name is really irrelevant.
<a class="l" name="597" href="#597">597</a>
<a class="l" name="598" href="#598">598</a>In this example, we test that `Foo()` calls the three expected functions in the
<a class="l" name="599" href="#599">599</a>order as written. If a call is made out-of-order, it will be an error.
<a class="hl" name="600" href="#600">600</a>
<a class="l" name="601" href="#601">601</a>(What if you care about the relative order of some of the calls, but not all of
<a class="l" name="602" href="#602">602</a>them? Can you specify an arbitrary partial order? The answer is ... yes! The
<a class="l" name="603" href="#603">603</a>details can be found [here](<a href="/googletest/s?path=cook_book.md&amp;project=googletest">cook_book.md</a>#OrderedCalls).)
<a class="l" name="604" href="#604">604</a>
<a class="l" name="605" href="#605">605</a>### All Expectations Are Sticky (Unless Said Otherwise) {#StickyExpectations}
<a class="l" name="606" href="#606">606</a>
<a class="l" name="607" href="#607">607</a>Now let's do a quick quiz to see how well you can use this mock stuff already.
<a class="l" name="608" href="#608">608</a>How would you test that the turtle is asked to go to the origin *exactly twice*
<a class="l" name="609" href="#609">609</a>(you want to ignore any other instructions it receives)?
<a class="hl" name="610" href="#610">610</a>
<a class="l" name="611" href="#611">611</a>After you've come up with your answer, take a look at ours and compare notes
<a class="l" name="612" href="#612">612</a>(solve it yourself first - don't cheat!):
<a class="l" name="613" href="#613">613</a>
<a class="l" name="614" href="#614">614</a>```cpp
<a class="l" name="615" href="#615">615</a>using ::testing::_;
<a class="l" name="616" href="#616">616</a>using ::testing::AnyNumber;
<a class="l" name="617" href="#617">617</a>...
<a class="l" name="618" href="#618">618</a>EXPECT_CALL(turtle, GoTo(_, _))  // #1
<a class="l" name="619" href="#619">619</a>     .Times(AnyNumber());
<a class="hl" name="620" href="#620">620</a>EXPECT_CALL(turtle, GoTo(0, 0))  // #2
<a class="l" name="621" href="#621">621</a>     .Times(2);
<a class="l" name="622" href="#622">622</a>```
<a class="l" name="623" href="#623">623</a>
<a class="l" name="624" href="#624">624</a>Suppose `<a href="/googletest/s?path=turtle.GoTo&amp;project=googletest">turtle.GoTo</a>(0, 0)` is called three times. In the third time, gMock will
<a class="l" name="625" href="#625">625</a>see that the arguments match expectation #2 (remember that we always pick the
<a class="l" name="626" href="#626">626</a>last matching expectation). Now, since we said that there should be only two
<a class="l" name="627" href="#627">627</a>such calls, gMock will report an error immediately. This is basically what we've
<a class="l" name="628" href="#628">628</a>told you in the [Using Multiple Expectations](#MultiExpectations) section above.
<a class="l" name="629" href="#629">629</a>
<a class="hl" name="630" href="#630">630</a>This example shows that **expectations in gMock are "sticky" by default**, in
<a class="l" name="631" href="#631">631</a>the sense that they remain active even after we have reached their invocation
<a class="l" name="632" href="#632">632</a>upper bounds. This is an important rule to remember, as it affects the meaning
<a class="l" name="633" href="#633">633</a>of the spec, and is **different** to how it's done in many other mocking
<a class="l" name="634" href="#634">634</a>frameworks (Why'd we do that? Because we think our rule makes the common cases
<a class="l" name="635" href="#635">635</a>easier to express and understand.).
<a class="l" name="636" href="#636">636</a>
<a class="l" name="637" href="#637">637</a>Simple? Let's see if you've really understood it: what does the following code
<a class="l" name="638" href="#638">638</a>say?
<a class="l" name="639" href="#639">639</a>
<a class="hl" name="640" href="#640">640</a>```cpp
<a class="l" name="641" href="#641">641</a>using ::testing::Return;
<a class="l" name="642" href="#642">642</a>...
<a class="l" name="643" href="#643">643</a>for (int i = n; i &gt; 0; i--) {
<a class="l" name="644" href="#644">644</a>  EXPECT_CALL(turtle, GetX())
<a class="l" name="645" href="#645">645</a>      .WillOnce(Return(10*i));
<a class="l" name="646" href="#646">646</a>}
<a class="l" name="647" href="#647">647</a>```
<a class="l" name="648" href="#648">648</a>
<a class="l" name="649" href="#649">649</a>If you think it says that `<a href="/googletest/s?path=turtle.GetX&amp;project=googletest">turtle.GetX</a>()` will be called `n` times and will
<a class="hl" name="650" href="#650">650</a>return 10, 20, 30, ..., consecutively, think twice! The problem is that, as we
<a class="l" name="651" href="#651">651</a>said, expectations are sticky. So, the second time `<a href="/googletest/s?path=turtle.GetX&amp;project=googletest">turtle.GetX</a>()` is called,
<a class="l" name="652" href="#652">652</a>the last (latest) `EXPECT_CALL()` statement will match, and will immediately
<a class="l" name="653" href="#653">653</a>lead to an "upper bound violated" error - this piece of code is not very useful!
<a class="l" name="654" href="#654">654</a>
<a class="l" name="655" href="#655">655</a>One correct way of saying that `<a href="/googletest/s?path=turtle.GetX&amp;project=googletest">turtle.GetX</a>()` will return 10, 20, 30, ..., is
<a class="l" name="656" href="#656">656</a>to explicitly say that the expectations are *not* sticky. In other words, they
<a class="l" name="657" href="#657">657</a>should *retire* as soon as they are saturated:
<a class="l" name="658" href="#658">658</a>
<a class="l" name="659" href="#659">659</a>```cpp
<a class="hl" name="660" href="#660">660</a>using ::testing::Return;
<a class="l" name="661" href="#661">661</a>...
<a class="l" name="662" href="#662">662</a>for (int i = n; i &gt; 0; i--) {
<a class="l" name="663" href="#663">663</a>  EXPECT_CALL(turtle, GetX())
<a class="l" name="664" href="#664">664</a>      .WillOnce(Return(10*i))
<a class="l" name="665" href="#665">665</a>      .RetiresOnSaturation();
<a class="l" name="666" href="#666">666</a>}
<a class="l" name="667" href="#667">667</a>```
<a class="l" name="668" href="#668">668</a>
<a class="l" name="669" href="#669">669</a>And, there's a better way to do it: in this case, we expect the calls to occur
<a class="hl" name="670" href="#670">670</a>in a specific order, and we line up the actions to match the order. Since the
<a class="l" name="671" href="#671">671</a>order is important here, we should make it explicit using a sequence:
<a class="l" name="672" href="#672">672</a>
<a class="l" name="673" href="#673">673</a>```cpp
<a class="l" name="674" href="#674">674</a>using ::testing::InSequence;
<a class="l" name="675" href="#675">675</a>using ::testing::Return;
<a class="l" name="676" href="#676">676</a>...
<a class="l" name="677" href="#677">677</a>{
<a class="l" name="678" href="#678">678</a>  InSequence s;
<a class="l" name="679" href="#679">679</a>
<a class="hl" name="680" href="#680">680</a>  for (int i = 1; i &lt;= n; i++) {
<a class="l" name="681" href="#681">681</a>    EXPECT_CALL(turtle, GetX())
<a class="l" name="682" href="#682">682</a>        .WillOnce(Return(10*i))
<a class="l" name="683" href="#683">683</a>        .RetiresOnSaturation();
<a class="l" name="684" href="#684">684</a>  }
<a class="l" name="685" href="#685">685</a>}
<a class="l" name="686" href="#686">686</a>```
<a class="l" name="687" href="#687">687</a>
<a class="l" name="688" href="#688">688</a>By the way, the other situation where an expectation may *not* be sticky is when
<a class="l" name="689" href="#689">689</a>it's in a sequence - as soon as another expectation that comes after it in the
<a class="hl" name="690" href="#690">690</a>sequence has been used, it automatically retires (and will never be used to
<a class="l" name="691" href="#691">691</a>match any call).
<a class="l" name="692" href="#692">692</a>
<a class="l" name="693" href="#693">693</a>### Uninteresting Calls
<a class="l" name="694" href="#694">694</a>
<a class="l" name="695" href="#695">695</a>A mock object may have many methods, and not all of them are that interesting.
<a class="l" name="696" href="#696">696</a>For example, in some tests we may not care about how many times `GetX()` and
<a class="l" name="697" href="#697">697</a>`GetY()` get called.
<a class="l" name="698" href="#698">698</a>
<a class="l" name="699" href="#699">699</a>In gMock, if you are not interested in a method, just don't say anything about
<a class="hl" name="700" href="#700">700</a>it. If a call to this method occurs, you'll see a warning in the test output,
<a class="l" name="701" href="#701">701</a>but it won't be a failure. This is called "naggy" behavior; to change, see
<a class="l" name="702" href="#702">702</a>[The Nice, the Strict, and the Naggy](<a href="/googletest/s?path=cook_book.md&amp;project=googletest">cook_book.md</a>#NiceStrictNaggy).
<a class="l" name="703" href="#703">703</a>