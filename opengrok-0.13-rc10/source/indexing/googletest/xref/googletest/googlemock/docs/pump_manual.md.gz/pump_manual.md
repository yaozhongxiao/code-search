<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>&lt;b&gt;P&lt;/b&gt;ump is &lt;b&gt;U&lt;/b&gt;seful for &lt;b&gt;M&lt;/b&gt;eta &lt;b&gt;P&lt;/b&gt;rogramming.
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>&lt;!-- GOOGLETEST_CM0035 DO NOT DELETE --&gt;
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a># The Problem
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>Template and macro libraries often need to define many classes, functions, or
<a class="l" name="8" href="#8">8</a>macros that vary only (or almost only) in the number of arguments they take.
<a class="l" name="9" href="#9">9</a>It's a lot of repetitive, mechanical, and error-prone work.
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a>Our experience is that it's tedious to write custom scripts, which tend to
<a class="l" name="12" href="#12">12</a>reflect the structure of the generated code poorly and are often hard to read
<a class="l" name="13" href="#13">13</a>and edit. For example, a small change needed in the generated code may require
<a class="l" name="14" href="#14">14</a>some non-intuitive, non-trivial changes in the script. This is especially
<a class="l" name="15" href="#15">15</a>painful when experimenting with the code.
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a>This script may be useful for generating meta code, for example a series of
<a class="l" name="18" href="#18">18</a>macros of FOO1, FOO2, etc. Nevertheless, please make it your last resort
<a class="l" name="19" href="#19">19</a>technique by favouring C++ template metaprogramming or variadic macros.
<a class="hl" name="20" href="#20">20</a>
<a class="l" name="21" href="#21">21</a># Our Solution
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a>Pump (for Pump is Useful for Meta Programming, Pretty Useful for Meta
<a class="l" name="24" href="#24">24</a>Programming, or Practical Utility for Meta Programming, whichever you prefer) is
<a class="l" name="25" href="#25">25</a>a simple meta-programming tool for C++. The idea is that a programmer writes a
<a class="l" name="26" href="#26">26</a>`<a href="/googletest/s?path=foo.pump&amp;project=googletest">foo.pump</a>` file which contains C++ code plus meta code that manipulates the C++
<a class="l" name="27" href="#27">27</a>code. The meta code can handle iterations over a range, nested iterations, local
<a class="l" name="28" href="#28">28</a>meta variable definitions, simple arithmetic, and conditional expressions. You
<a class="l" name="29" href="#29">29</a>can view it as a small Domain-Specific Language. The meta language is designed
<a class="hl" name="30" href="#30">30</a>to be non-intrusive (<a href="/googletest/s?path=s.t.&amp;project=googletest">s.t.</a> it won't confuse Emacs' C++ mode, for example) and
<a class="l" name="31" href="#31">31</a>concise, making Pump code intuitive and easy to maintain.
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>## Highlights
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>*   The implementation is in a single Python script and thus ultra portable: no
<a class="l" name="36" href="#36">36</a>    build or installation is needed and it works cross platforms.
<a class="l" name="37" href="#37">37</a>*   Pump tries to be smart with respect to
<a class="l" name="38" href="#38">38</a>    [Google's style guide](<a href="https://github.com/google/styleguide">https://github.com/google/styleguide</a>): it breaks long
<a class="l" name="39" href="#39">39</a>    lines (easy to have when they are generated) at acceptable places to fit
<a class="hl" name="40" href="#40">40</a>    within 80 columns and indent the continuation lines correctly.
<a class="l" name="41" href="#41">41</a>*   The format is human-readable and more concise than XML.
<a class="l" name="42" href="#42">42</a>*   The format works relatively well with Emacs' C++ mode.
<a class="l" name="43" href="#43">43</a>
<a class="l" name="44" href="#44">44</a>## Examples
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>The following Pump code (where meta keywords start with `$`, `[[` and `]]` are
<a class="l" name="47" href="#47">47</a>meta brackets, and `$$` starts a meta comment that ends with the line):
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>```
<a class="hl" name="50" href="#50">50</a>$var n = 3     $$ Defines a meta variable n.
<a class="l" name="51" href="#51">51</a>$range i <a href="/googletest/s?path=0..n&amp;project=googletest">0..n</a>  $$ Declares the range of meta iterator i (inclusive).
<a class="l" name="52" href="#52">52</a>$for i [[
<a class="l" name="53" href="#53">53</a>               $$ Meta loop.
<a class="l" name="54" href="#54">54</a>// Foo$i does blah for $i-ary predicates.
<a class="l" name="55" href="#55">55</a>$range j <a href="/googletest/s?path=1..i&amp;project=googletest">1..i</a>
<a class="l" name="56" href="#56">56</a>template &lt;size_t N $for j [[, typename A$j]]&gt;
<a class="l" name="57" href="#57">57</a>class Foo$i {
<a class="l" name="58" href="#58">58</a>$if i == 0 [[
<a class="l" name="59" href="#59">59</a>  blah a;
<a class="hl" name="60" href="#60">60</a>]] $elif i &lt;= 2 [[
<a class="l" name="61" href="#61">61</a>  blah b;
<a class="l" name="62" href="#62">62</a>]] $else [[
<a class="l" name="63" href="#63">63</a>  blah c;
<a class="l" name="64" href="#64">64</a>]]
<a class="l" name="65" href="#65">65</a>};
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>]]
<a class="l" name="68" href="#68">68</a>```
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>will be translated by the Pump compiler to:
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a>```cpp
<a class="l" name="73" href="#73">73</a>// Foo0 does blah for 0-ary predicates.
<a class="l" name="74" href="#74">74</a>template &lt;size_t N&gt;
<a class="l" name="75" href="#75">75</a>class Foo0 {
<a class="l" name="76" href="#76">76</a>  blah a;
<a class="l" name="77" href="#77">77</a>};
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>// Foo1 does blah for 1-ary predicates.
<a class="hl" name="80" href="#80">80</a>template &lt;size_t N, typename A1&gt;
<a class="l" name="81" href="#81">81</a>class Foo1 {
<a class="l" name="82" href="#82">82</a>  blah b;
<a class="l" name="83" href="#83">83</a>};
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>// Foo2 does blah for 2-ary predicates.
<a class="l" name="86" href="#86">86</a>template &lt;size_t N, typename A1, typename A2&gt;
<a class="l" name="87" href="#87">87</a>class Foo2 {
<a class="l" name="88" href="#88">88</a>  blah b;
<a class="l" name="89" href="#89">89</a>};
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>// Foo3 does blah for 3-ary predicates.
<a class="l" name="92" href="#92">92</a>template &lt;size_t N, typename A1, typename A2, typename A3&gt;
<a class="l" name="93" href="#93">93</a>class Foo3 {
<a class="l" name="94" href="#94">94</a>  blah c;
<a class="l" name="95" href="#95">95</a>};
<a class="l" name="96" href="#96">96</a>```
<a class="l" name="97" href="#97">97</a>
<a class="l" name="98" href="#98">98</a>In another example,
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>```
<a class="l" name="101" href="#101">101</a>$range i <a href="/googletest/s?path=1..n&amp;project=googletest">1..n</a>
<a class="l" name="102" href="#102">102</a>Func($for i + [[a$i]]);
<a class="l" name="103" href="#103">103</a>$$ The text between i and [[ is the separator between iterations.
<a class="l" name="104" href="#104">104</a>```
<a class="l" name="105" href="#105">105</a>
<a class="l" name="106" href="#106">106</a>will generate one of the following lines (without the comments), depending on
<a class="l" name="107" href="#107">107</a>the value of `n`:
<a class="l" name="108" href="#108">108</a>
<a class="l" name="109" href="#109">109</a>```cpp
<a class="hl" name="110" href="#110">110</a>Func();              // If n is 0.
<a class="l" name="111" href="#111">111</a>Func(a1);            // If n is 1.
<a class="l" name="112" href="#112">112</a>Func(a1 + a2);       // If n is 2.
<a class="l" name="113" href="#113">113</a>Func(a1 + a2 + a3);  // If n is 3.
<a class="l" name="114" href="#114">114</a>// And so on...
<a class="l" name="115" href="#115">115</a>```
<a class="l" name="116" href="#116">116</a>
<a class="l" name="117" href="#117">117</a>## Constructs
<a class="l" name="118" href="#118">118</a>
<a class="l" name="119" href="#119">119</a>We support the following meta programming constructs:
<a class="hl" name="120" href="#120">120</a>
<a class="l" name="121" href="#121">121</a>| `$var id = exp`                  | Defines a named constant value. `$id` is |
<a class="l" name="122" href="#122">122</a>:                                  : valid until the end of the current meta  :
<a class="l" name="123" href="#123">123</a>:                                  : lexical block.                           :
<a class="l" name="124" href="#124">124</a>| :------------------------------- | :--------------------------------------- |
<a class="l" name="125" href="#125">125</a>| `$range id <a href="/googletest/s?path=exp..exp&amp;project=googletest">exp..exp</a>`             | Sets the range of an iteration variable, |
<a class="l" name="126" href="#126">126</a>:                                  : which can be reused in multiple loops    :
<a class="l" name="127" href="#127">127</a>:                                  : later.                                   :
<a class="l" name="128" href="#128">128</a>| `$for id sep [[ code ]]`         | Iteration. The range of `id` must have   |
<a class="l" name="129" href="#129">129</a>:                                  : been defined earlier. `$id` is valid in  :
<a class="hl" name="130" href="#130">130</a>:                                  : `code`.                                  :
<a class="l" name="131" href="#131">131</a>| `$($)`                           | Generates a single `$` character.        |
<a class="l" name="132" href="#132">132</a>| `$id`                            | Value of the named constant or iteration |
<a class="l" name="133" href="#133">133</a>:                                  : variable.                                :
<a class="l" name="134" href="#134">134</a>| `$(exp)`                         | Value of the expression.                 |
<a class="l" name="135" href="#135">135</a>| `$if exp [[ code ]] else_branch` | Conditional.                             |
<a class="l" name="136" href="#136">136</a>| `[[ code ]]`                     | Meta lexical block.                      |
<a class="l" name="137" href="#137">137</a>| `cpp_code`                       | Raw C++ code.                            |
<a class="l" name="138" href="#138">138</a>| `$$ comment`                     | Meta comment.                            |
<a class="l" name="139" href="#139">139</a>
<a class="hl" name="140" href="#140">140</a>**Note:** To give the user some freedom in formatting the Pump source code, Pump
<a class="l" name="141" href="#141">141</a>ignores a new-line character if it's right after `$for foo` or next to `[[` or
<a class="l" name="142" href="#142">142</a>`]]`. Without this rule you'll often be forced to write very long lines to get
<a class="l" name="143" href="#143">143</a>the desired output. Therefore sometimes you may need to insert an extra new-line
<a class="l" name="144" href="#144">144</a>in such places for a new-line to show up in your output.
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>## Grammar
<a class="l" name="147" href="#147">147</a>
<a class="l" name="148" href="#148">148</a>```ebnf
<a class="l" name="149" href="#149">149</a>code ::= atomic_code*
<a class="hl" name="150" href="#150">150</a>atomic_code ::= $var id = exp
<a class="l" name="151" href="#151">151</a>    | $var id = [[ code ]]
<a class="l" name="152" href="#152">152</a>    | $range id <a href="/googletest/s?path=exp..exp&amp;project=googletest">exp..exp</a>
<a class="l" name="153" href="#153">153</a>    | $for id sep [[ code ]]
<a class="l" name="154" href="#154">154</a>    | $($)
<a class="l" name="155" href="#155">155</a>    | $id
<a class="l" name="156" href="#156">156</a>    | $(exp)
<a class="l" name="157" href="#157">157</a>    | $if exp [[ code ]] else_branch
<a class="l" name="158" href="#158">158</a>    | [[ code ]]
<a class="l" name="159" href="#159">159</a>    | cpp_code
<a class="hl" name="160" href="#160">160</a>sep ::= cpp_code | empty_string
<a class="l" name="161" href="#161">161</a>else_branch ::= $else [[ code ]]
<a class="l" name="162" href="#162">162</a>    | $elif exp [[ code ]] else_branch
<a class="l" name="163" href="#163">163</a>    | empty_string
<a class="l" name="164" href="#164">164</a>exp ::= simple_expression_in_Python_syntax
<a class="l" name="165" href="#165">165</a>```
<a class="l" name="166" href="#166">166</a>
<a class="l" name="167" href="#167">167</a>## Code
<a class="l" name="168" href="#168">168</a>
<a class="l" name="169" href="#169">169</a>You can find the source code of Pump in [<a href="/googletest/s?path=scripts/pump.py&amp;project=googletest">scripts/pump.py</a>](..<a href="/googletest/s?path=/scripts/pump.py&amp;project=googletest">/scripts/pump.py</a>).
<a class="hl" name="170" href="#170">170</a>It is still very unpolished and lacks automated tests, although it has been
<a class="l" name="171" href="#171">171</a>successfully used many times. If you find a chance to use it in your project,
<a class="l" name="172" href="#172">172</a>please let us know what you think! We also welcome help on improving Pump.
<a class="l" name="173" href="#173">173</a>
<a class="l" name="174" href="#174">174</a>## Real Examples
<a class="l" name="175" href="#175">175</a>
<a class="l" name="176" href="#176">176</a>You can find real-world applications of Pump in
<a class="l" name="177" href="#177">177</a>[Google Test](<a href="https://github.com/google/googletest/tree/master/googletest">https://github.com/google/googletest/tree/master/googletest</a>) and
<a class="l" name="178" href="#178">178</a>[Google Mock](<a href="https://github.com/google/googletest/tree/master/googlemock">https://github.com/google/googletest/tree/master/googlemock</a>). The
<a class="l" name="179" href="#179">179</a>source file `<a href="/googletest/s?path=foo.h.pump&amp;project=googletest">foo.h.pump</a>` generates `<a href="/googletest/s?path=foo.h&amp;project=googletest">foo.h</a>`.
<a class="hl" name="180" href="#180">180</a>
<a class="l" name="181" href="#181">181</a>## Tips
<a class="l" name="182" href="#182">182</a>
<a class="l" name="183" href="#183">183</a>*   If a meta variable is followed by a letter or digit, you can separate them
<a class="l" name="184" href="#184">184</a>    using `[[]]`, which inserts an empty string. For example `Foo$j[[]]Helper`
<a class="l" name="185" href="#185">185</a>    generate `Foo1Helper` when `j` is 1.
<a class="l" name="186" href="#186">186</a>*   To avoid extra-long Pump source lines, you can break a line anywhere you
<a class="l" name="187" href="#187">187</a>    want by inserting `[[]]` followed by a new line. Since any new-line
<a class="l" name="188" href="#188">188</a>    character next to `[[` or `]]` is ignored, the generated code won't contain
<a class="l" name="189" href="#189">189</a>    this new line.
<a class="hl" name="190" href="#190">190</a>