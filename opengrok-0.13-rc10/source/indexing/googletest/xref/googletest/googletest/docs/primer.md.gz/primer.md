<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># Googletest Primer
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>&lt;!-- GOOGLETEST_CM0036 DO NOT DELETE --&gt;
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>&lt;!-- GOOGLETEST_CM0035 DO NOT DELETE --&gt;
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>## Introduction: Why googletest?
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>*googletest* helps you write better C++ tests.
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a>googletest is a testing framework developed by the Testing Technology team with
<a class="l" name="12" href="#12">12</a>Google's specific requirements and constraints in mind. Whether you work on
<a class="l" name="13" href="#13">13</a>Linux, Windows, or a Mac, if you write C++ code, googletest can help you. And it
<a class="l" name="14" href="#14">14</a>supports *any* kind of tests, not just unit tests.
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a>So what makes a good test, and how does googletest fit in? We believe:
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a>1.  Tests should be *independent* and *repeatable*. It's a pain to debug a test
<a class="l" name="19" href="#19">19</a>    that succeeds or fails as a result of other tests. googletest isolates the
<a class="hl" name="20" href="#20">20</a>    tests by running each of them on a different object. When a test fails,
<a class="l" name="21" href="#21">21</a>    googletest allows you to run it in isolation for quick debugging.
<a class="l" name="22" href="#22">22</a>2.  Tests should be well *organized* and reflect the structure of the tested
<a class="l" name="23" href="#23">23</a>    code. googletest groups related tests into test suites that can share data
<a class="l" name="24" href="#24">24</a>    and subroutines. This common pattern is easy to recognize and makes tests
<a class="l" name="25" href="#25">25</a>    easy to maintain. Such consistency is especially helpful when people switch
<a class="l" name="26" href="#26">26</a>    projects and start to work on a new code base.
<a class="l" name="27" href="#27">27</a>3.  Tests should be *portable* and *reusable*. Google has a lot of code that is
<a class="l" name="28" href="#28">28</a>    platform-neutral; its tests should also be platform-neutral. googletest
<a class="l" name="29" href="#29">29</a>    works on different OSes, with different compilers, with or without
<a class="hl" name="30" href="#30">30</a>    exceptions, so googletest tests can work with a variety of configurations.
<a class="l" name="31" href="#31">31</a>4.  When tests fail, they should provide as much *information* about the problem
<a class="l" name="32" href="#32">32</a>    as possible. googletest doesn't stop at the first test failure. Instead, it
<a class="l" name="33" href="#33">33</a>    only stops the current test and continues with the next. You can also set up
<a class="l" name="34" href="#34">34</a>    tests that report non-fatal failures after which the current test continues.
<a class="l" name="35" href="#35">35</a>    Thus, you can detect and fix multiple bugs in a single run-edit-compile
<a class="l" name="36" href="#36">36</a>    cycle.
<a class="l" name="37" href="#37">37</a>5.  The testing framework should liberate test writers from housekeeping chores
<a class="l" name="38" href="#38">38</a>    and let them focus on the test *content*. googletest automatically keeps
<a class="l" name="39" href="#39">39</a>    track of all tests defined, and doesn't require the user to enumerate them
<a class="hl" name="40" href="#40">40</a>    in order to run them.
<a class="l" name="41" href="#41">41</a>6.  Tests should be *fast*. With googletest, you can reuse shared resources
<a class="l" name="42" href="#42">42</a>    across tests and pay for the <a href="/googletest/s?path=set-up/tear-down&amp;project=googletest">set-up/tear-down</a> only once, without making
<a class="l" name="43" href="#43">43</a>    tests depend on each other.
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>Since googletest is based on the popular xUnit architecture, you'll feel right
<a class="l" name="46" href="#46">46</a>at home if you've used JUnit or PyUnit before. If not, it will take you about 10
<a class="l" name="47" href="#47">47</a>minutes to learn the basics and get started. So let's go!
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>## Beware of the nomenclature
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>_Note:_ There might be some confusion arising from different definitions of the
<a class="l" name="52" href="#52">52</a>terms _Test_, _Test Case_ and _Test Suite_, so beware of misunderstanding these.
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>Historically, googletest started to use the term _Test Case_ for grouping
<a class="l" name="55" href="#55">55</a>related tests, whereas current publications, including International Software
<a class="l" name="56" href="#56">56</a>Testing Qualifications Board ([ISTQB](<a href="http://www.istqb.org/">http://www.istqb.org/</a>)) materials and
<a class="l" name="57" href="#57">57</a>various textbooks on software quality, use the term
<a class="l" name="58" href="#58">58</a>_[Test Suite][istqb test suite]_ for this.
<a class="l" name="59" href="#59">59</a>
<a class="hl" name="60" href="#60">60</a>The related term _Test_, as it is used in googletest, corresponds to the term
<a class="l" name="61" href="#61">61</a>_[Test Case][istqb test case]_ of ISTQB and others.
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>The term _Test_ is commonly of broad enough sense, including ISTQB's definition
<a class="l" name="64" href="#64">64</a>of _Test Case_, so it's not much of a problem here. But the term _Test Case_ as
<a class="l" name="65" href="#65">65</a>was used in Google Test is of contradictory sense and thus confusing.
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>googletest recently started replacing the term _Test Case_ with _Test Suite_.
<a class="l" name="68" href="#68">68</a>The preferred API is *TestSuite*. The older TestCase API is being slowly
<a class="l" name="69" href="#69">69</a>deprecated and refactored away.
<a class="hl" name="70" href="#70">70</a>
<a class="l" name="71" href="#71">71</a>So please be aware of the different definitions of the terms:
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>&lt;!-- mdformat off(github rendering does not support multiline tables) --&gt;
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>Meaning                                                                              | googletest Term         | [ISTQB](<a href="http://www.istqb.org/">http://www.istqb.org/</a>) Term
<a class="l" name="76" href="#76">76</a>:----------------------------------------------------------------------------------- | :---------------------- | :----------------------------------
<a class="l" name="77" href="#77">77</a>Exercise a particular program path with specific input values and verify the results | [TEST()](#simple-tests) | [Test Case][istqb test case]
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>&lt;!-- mdformat on --&gt;
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a>[istqb test case]: <a href="http://glossary.istqb.org/en/search/test%20case">http://glossary.istqb.org/en/search/test%20case</a>
<a class="l" name="82" href="#82">82</a>[istqb test suite]: <a href="http://glossary.istqb.org/en/search/test%20suite">http://glossary.istqb.org/en/search/test%20suite</a>
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>## Basic Concepts
<a class="l" name="85" href="#85">85</a>
<a class="l" name="86" href="#86">86</a>When using googletest, you start by writing *assertions*, which are statements
<a class="l" name="87" href="#87">87</a>that check whether a condition is true. An assertion's result can be *success*,
<a class="l" name="88" href="#88">88</a>*nonfatal failure*, or *fatal failure*. If a fatal failure occurs, it aborts the
<a class="l" name="89" href="#89">89</a>current function; otherwise the program continues normally.
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>*Tests* use assertions to verify the tested code's behavior. If a test crashes
<a class="l" name="92" href="#92">92</a>or has a failed assertion, then it *fails*; otherwise it *succeeds*.
<a class="l" name="93" href="#93">93</a>
<a class="l" name="94" href="#94">94</a>A *test suite* contains one or many tests. You should group your tests into test
<a class="l" name="95" href="#95">95</a>suites that reflect the structure of the tested code. When multiple tests in a
<a class="l" name="96" href="#96">96</a>test suite need to share common objects and subroutines, you can put them into a
<a class="l" name="97" href="#97">97</a>*test fixture* class.
<a class="l" name="98" href="#98">98</a>
<a class="l" name="99" href="#99">99</a>A *test program* can contain multiple test suites.
<a class="hl" name="100" href="#100">100</a>
<a class="l" name="101" href="#101">101</a>We'll now explain how to write a test program, starting at the individual
<a class="l" name="102" href="#102">102</a>assertion level and building up to tests and test suites.
<a class="l" name="103" href="#103">103</a>
<a class="l" name="104" href="#104">104</a>## Assertions
<a class="l" name="105" href="#105">105</a>
<a class="l" name="106" href="#106">106</a>googletest assertions are macros that resemble function calls. You test a class
<a class="l" name="107" href="#107">107</a>or function by making assertions about its behavior. When an assertion fails,
<a class="l" name="108" href="#108">108</a>googletest prints the assertion's source file and line number location, along
<a class="l" name="109" href="#109">109</a>with a failure message. You may also supply a custom failure message which will
<a class="hl" name="110" href="#110">110</a>be appended to googletest's message.
<a class="l" name="111" href="#111">111</a>
<a class="l" name="112" href="#112">112</a>The assertions come in pairs that test the same thing but have different effects
<a class="l" name="113" href="#113">113</a>on the current function. `ASSERT_*` versions generate fatal failures when they
<a class="l" name="114" href="#114">114</a>fail, and **abort the current function**. `EXPECT_*` versions generate nonfatal
<a class="l" name="115" href="#115">115</a>failures, which don't abort the current function. Usually `EXPECT_*` are
<a class="l" name="116" href="#116">116</a>preferred, as they allow more than one failure to be reported in a test.
<a class="l" name="117" href="#117">117</a>However, you should use `ASSERT_*` if it doesn't make sense to continue when the
<a class="l" name="118" href="#118">118</a>assertion in question fails.
<a class="l" name="119" href="#119">119</a>
<a class="hl" name="120" href="#120">120</a>Since a failed `ASSERT_*` returns from the current function immediately,
<a class="l" name="121" href="#121">121</a>possibly skipping clean-up code that comes after it, it may cause a space leak.
<a class="l" name="122" href="#122">122</a>Depending on the nature of the leak, it may or may not be worth fixing - so keep
<a class="l" name="123" href="#123">123</a>this in mind if you get a heap checker error in addition to assertion errors.
<a class="l" name="124" href="#124">124</a>
<a class="l" name="125" href="#125">125</a>To provide a custom failure message, simply stream it into the macro using the
<a class="l" name="126" href="#126">126</a>`&lt;&lt;` operator or a sequence of such operators. An example:
<a class="l" name="127" href="#127">127</a>
<a class="l" name="128" href="#128">128</a>```c++
<a class="l" name="129" href="#129">129</a>ASSERT_EQ(<a href="/googletest/s?path=x.size&amp;project=googletest">x.size</a>(), <a href="/googletest/s?path=y.size&amp;project=googletest">y.size</a>()) &lt;&lt; "Vectors x and y are of unequal length";
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a>for (int i = 0; i &lt; <a href="/googletest/s?path=x.size&amp;project=googletest">x.size</a>(); ++i) {
<a class="l" name="132" href="#132">132</a>  EXPECT_EQ(x[i], y[i]) &lt;&lt; "Vectors x and y differ at index " &lt;&lt; i;
<a class="l" name="133" href="#133">133</a>}
<a class="l" name="134" href="#134">134</a>```
<a class="l" name="135" href="#135">135</a>
<a class="l" name="136" href="#136">136</a>Anything that can be streamed to an `ostream` can be streamed to an assertion
<a class="l" name="137" href="#137">137</a>macro--in particular, C strings and `string` objects. If a wide string
<a class="l" name="138" href="#138">138</a>(`wchar_t*`, `TCHAR*` in `UNICODE` mode on Windows, or `std::wstring`) is
<a class="l" name="139" href="#139">139</a>streamed to an assertion, it will be translated to UTF-8 when printed.
<a class="hl" name="140" href="#140">140</a>
<a class="l" name="141" href="#141">141</a>### Basic Assertions
<a class="l" name="142" href="#142">142</a>
<a class="l" name="143" href="#143">143</a>These assertions do basic <a href="/googletest/s?path=true/false&amp;project=googletest">true/false</a> condition testing.
<a class="l" name="144" href="#144">144</a>
<a class="l" name="145" href="#145">145</a>Fatal assertion            | Nonfatal assertion         | Verifies
<a class="l" name="146" href="#146">146</a>-------------------------- | -------------------------- | --------------------
<a class="l" name="147" href="#147">147</a>`ASSERT_TRUE(condition);`  | `EXPECT_TRUE(condition);`  | `condition` is true
<a class="l" name="148" href="#148">148</a>`ASSERT_FALSE(condition);` | `EXPECT_FALSE(condition);` | `condition` is false
<a class="l" name="149" href="#149">149</a>
<a class="hl" name="150" href="#150">150</a>Remember, when they fail, `ASSERT_*` yields a fatal failure and returns from the
<a class="l" name="151" href="#151">151</a>current function, while `EXPECT_*` yields a nonfatal failure, allowing the
<a class="l" name="152" href="#152">152</a>function to continue running. In either case, an assertion failure means its
<a class="l" name="153" href="#153">153</a>containing test fails.
<a class="l" name="154" href="#154">154</a>
<a class="l" name="155" href="#155">155</a>**Availability**: Linux, Windows, Mac.
<a class="l" name="156" href="#156">156</a>
<a class="l" name="157" href="#157">157</a>### Binary Comparison
<a class="l" name="158" href="#158">158</a>
<a class="l" name="159" href="#159">159</a>This section describes assertions that compare two values.
<a class="hl" name="160" href="#160">160</a>
<a class="l" name="161" href="#161">161</a>Fatal assertion          | Nonfatal assertion       | Verifies
<a class="l" name="162" href="#162">162</a>------------------------ | ------------------------ | --------------
<a class="l" name="163" href="#163">163</a>`ASSERT_EQ(val1, val2);` | `EXPECT_EQ(val1, val2);` | `val1 == val2`
<a class="l" name="164" href="#164">164</a>`ASSERT_NE(val1, val2);` | `EXPECT_NE(val1, val2);` | `val1 != val2`
<a class="l" name="165" href="#165">165</a>`ASSERT_LT(val1, val2);` | `EXPECT_LT(val1, val2);` | `val1 &lt; val2`
<a class="l" name="166" href="#166">166</a>`ASSERT_LE(val1, val2);` | `EXPECT_LE(val1, val2);` | `val1 &lt;= val2`
<a class="l" name="167" href="#167">167</a>`ASSERT_GT(val1, val2);` | `EXPECT_GT(val1, val2);` | `val1 &gt; val2`
<a class="l" name="168" href="#168">168</a>`ASSERT_GE(val1, val2);` | `EXPECT_GE(val1, val2);` | `val1 &gt;= val2`
<a class="l" name="169" href="#169">169</a>
<a class="hl" name="170" href="#170">170</a>Value arguments must be comparable by the assertion's comparison operator or
<a class="l" name="171" href="#171">171</a>you'll get a compiler error. We used to require the arguments to support the
<a class="l" name="172" href="#172">172</a>`&lt;&lt;` operator for streaming to an `ostream`, but this is no longer necessary. If
<a class="l" name="173" href="#173">173</a>`&lt;&lt;` is supported, it will be called to print the arguments when the assertion
<a class="l" name="174" href="#174">174</a>fails; otherwise googletest will attempt to print them in the best way it can.
<a class="l" name="175" href="#175">175</a>For more details and how to customize the printing of the arguments, see the
<a class="l" name="176" href="#176">176</a>[documentation](./<a href="/googletest/s?path=advanced.md&amp;project=googletest">advanced.md</a>#teaching-googletest-how-to-print-your-values).
<a class="l" name="177" href="#177">177</a>
<a class="l" name="178" href="#178">178</a>These assertions can work with a user-defined type, but only if you define the
<a class="l" name="179" href="#179">179</a>corresponding comparison operator (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>, `==` or `&lt;`). Since this is discouraged
<a class="hl" name="180" href="#180">180</a>by the Google
<a class="l" name="181" href="#181">181</a>[C++ Style Guide](<a href="https://google.github.io/styleguide/cppguide.html">https://google.github.io/styleguide/cppguide.html</a>#Operator_Overloading),
<a class="l" name="182" href="#182">182</a>you may need to use `ASSERT_TRUE()` or `EXPECT_TRUE()` to assert the equality of
<a class="l" name="183" href="#183">183</a>two objects of a user-defined type.
<a class="l" name="184" href="#184">184</a>
<a class="l" name="185" href="#185">185</a>However, when possible, `ASSERT_EQ(actual, expected)` is preferred to
<a class="l" name="186" href="#186">186</a>`ASSERT_TRUE(actual == expected)`, since it tells you `actual` and `expected`'s
<a class="l" name="187" href="#187">187</a>values on failure.
<a class="l" name="188" href="#188">188</a>
<a class="l" name="189" href="#189">189</a>Arguments are always evaluated exactly once. Therefore, it's OK for the
<a class="hl" name="190" href="#190">190</a>arguments to have side effects. However, as with any ordinary C/C++ function,
<a class="l" name="191" href="#191">191</a>the arguments' evaluation order is undefined (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a>, the compiler is free to
<a class="l" name="192" href="#192">192</a>choose any order), and your code should not depend on any particular argument
<a class="l" name="193" href="#193">193</a>evaluation order.
<a class="l" name="194" href="#194">194</a>
<a class="l" name="195" href="#195">195</a>`ASSERT_EQ()` does pointer equality on pointers. If used on two C strings, it
<a class="l" name="196" href="#196">196</a>tests if they are in the same memory location, not if they have the same value.
<a class="l" name="197" href="#197">197</a>Therefore, if you want to compare C strings (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `const char*`) by value, use
<a class="l" name="198" href="#198">198</a>`ASSERT_STREQ()`, which will be described later on. In particular, to assert
<a class="l" name="199" href="#199">199</a>that a C string is `NULL`, use `ASSERT_STREQ(c_string, NULL)`. Consider using
<a class="hl" name="200" href="#200">200</a>`ASSERT_EQ(c_string, nullptr)` if c++11 is supported. To compare two `string`
<a class="l" name="201" href="#201">201</a>objects, you should use `ASSERT_EQ`.
<a class="l" name="202" href="#202">202</a>
<a class="l" name="203" href="#203">203</a>When doing pointer comparisons use `*_EQ(ptr, nullptr)` and `*_NE(ptr, nullptr)`
<a class="l" name="204" href="#204">204</a>instead of `*_EQ(ptr, NULL)` and `*_NE(ptr, NULL)`. This is because `nullptr` is
<a class="l" name="205" href="#205">205</a>typed, while `NULL` is not. See the [FAQ](<a href="/googletest/s?path=faq.md&amp;project=googletest">faq.md</a>) for more details.
<a class="l" name="206" href="#206">206</a>
<a class="l" name="207" href="#207">207</a>If you're working with floating point numbers, you may want to use the floating
<a class="l" name="208" href="#208">208</a>point variations of some of these macros in order to avoid problems caused by
<a class="l" name="209" href="#209">209</a>rounding. See [Advanced googletest Topics](<a href="/googletest/s?path=advanced.md&amp;project=googletest">advanced.md</a>) for details.
<a class="hl" name="210" href="#210">210</a>
<a class="l" name="211" href="#211">211</a>Macros in this section work with both narrow and wide string objects (`string`
<a class="l" name="212" href="#212">212</a>and `wstring`).
<a class="l" name="213" href="#213">213</a>
<a class="l" name="214" href="#214">214</a>**Availability**: Linux, Windows, Mac.
<a class="l" name="215" href="#215">215</a>
<a class="l" name="216" href="#216">216</a>**Historical note**: Before February 2016 `*_EQ` had a convention of calling it
<a class="l" name="217" href="#217">217</a>as `ASSERT_EQ(expected, actual)`, so lots of existing code uses this order. Now
<a class="l" name="218" href="#218">218</a>`*_EQ` treats both parameters in the same way.
<a class="l" name="219" href="#219">219</a>
<a class="hl" name="220" href="#220">220</a>### String Comparison
<a class="l" name="221" href="#221">221</a>
<a class="l" name="222" href="#222">222</a>The assertions in this group compare two **C strings**. If you want to compare
<a class="l" name="223" href="#223">223</a>two `string` objects, use `EXPECT_EQ`, `EXPECT_NE`, and etc instead.
<a class="l" name="224" href="#224">224</a>
<a class="l" name="225" href="#225">225</a>&lt;!-- mdformat off(github rendering does not support multiline tables) --&gt;
<a class="l" name="226" href="#226">226</a>
<a class="l" name="227" href="#227">227</a>| Fatal assertion                | Nonfatal assertion             | Verifies                                                 |
<a class="l" name="228" href="#228">228</a>| --------------------------     | ------------------------------ | -------------------------------------------------------- |
<a class="l" name="229" href="#229">229</a>| `ASSERT_STREQ(str1,str2);`     | `EXPECT_STREQ(str1,str2);`     | the two C strings have the same content   		     |
<a class="hl" name="230" href="#230">230</a>| `ASSERT_STRNE(str1,str2);`     | `EXPECT_STRNE(str1,str2);`     | the two C strings have different contents 		     |
<a class="l" name="231" href="#231">231</a>| `ASSERT_STRCASEEQ(str1,str2);` | `EXPECT_STRCASEEQ(str1,str2);` | the two C strings have the same content, ignoring case   |
<a class="l" name="232" href="#232">232</a>| `ASSERT_STRCASENE(str1,str2);` | `EXPECT_STRCASENE(str1,str2);` | the two C strings have different contents, ignoring case |
<a class="l" name="233" href="#233">233</a>
<a class="l" name="234" href="#234">234</a>&lt;!-- mdformat on--&gt;
<a class="l" name="235" href="#235">235</a>
<a class="l" name="236" href="#236">236</a>Note that "CASE" in an assertion name means that case is ignored. A `NULL`
<a class="l" name="237" href="#237">237</a>pointer and an empty string are considered *different*.
<a class="l" name="238" href="#238">238</a>
<a class="l" name="239" href="#239">239</a>`*STREQ*` and `*STRNE*` also accept wide C strings (`wchar_t*`). If a comparison
<a class="hl" name="240" href="#240">240</a>of two wide strings fails, their values will be printed as UTF-8 narrow strings.
<a class="l" name="241" href="#241">241</a>
<a class="l" name="242" href="#242">242</a>**Availability**: Linux, Windows, Mac.
<a class="l" name="243" href="#243">243</a>
<a class="l" name="244" href="#244">244</a>**See also**: For more string comparison tricks (substring, prefix, suffix, and
<a class="l" name="245" href="#245">245</a>regular expression matching, for example), see [this](<a href="/googletest/s?path=advanced.md&amp;project=googletest">advanced.md</a>) in the
<a class="l" name="246" href="#246">246</a>Advanced googletest Guide.
<a class="l" name="247" href="#247">247</a>
<a class="l" name="248" href="#248">248</a>## Simple Tests
<a class="l" name="249" href="#249">249</a>
<a class="hl" name="250" href="#250">250</a>To create a test:
<a class="l" name="251" href="#251">251</a>
<a class="l" name="252" href="#252">252</a>1.  Use the `TEST()` macro to define and name a test function. These are
<a class="l" name="253" href="#253">253</a>    ordinary C++ functions that don't return a value.
<a class="l" name="254" href="#254">254</a>2.  In this function, along with any valid C++ statements you want to include,
<a class="l" name="255" href="#255">255</a>    use the various googletest assertions to check values.
<a class="l" name="256" href="#256">256</a>3.  The test's result is determined by the assertions; if any assertion in the
<a class="l" name="257" href="#257">257</a>    test fails (either fatally or non-fatally), or if the test crashes, the
<a class="l" name="258" href="#258">258</a>    entire test fails. Otherwise, it succeeds.
<a class="l" name="259" href="#259">259</a>
<a class="hl" name="260" href="#260">260</a>```c++
<a class="l" name="261" href="#261">261</a>TEST(TestSuiteName, TestName) {
<a class="l" name="262" href="#262">262</a>  ... test body ...
<a class="l" name="263" href="#263">263</a>}
<a class="l" name="264" href="#264">264</a>```
<a class="l" name="265" href="#265">265</a>
<a class="l" name="266" href="#266">266</a>`TEST()` arguments go from general to specific. The *first* argument is the name
<a class="l" name="267" href="#267">267</a>of the test suite, and the *second* argument is the test's name within the test
<a class="l" name="268" href="#268">268</a>suite. Both names must be valid C++ identifiers, and they should not contain
<a class="l" name="269" href="#269">269</a>any underscores (`_`). A test's *full name* consists of its containing test suite and
<a class="hl" name="270" href="#270">270</a>its individual name. Tests from different test suites can have the same
<a class="l" name="271" href="#271">271</a>individual name.
<a class="l" name="272" href="#272">272</a>
<a class="l" name="273" href="#273">273</a>For example, let's take a simple integer function:
<a class="l" name="274" href="#274">274</a>
<a class="l" name="275" href="#275">275</a>```c++
<a class="l" name="276" href="#276">276</a>int Factorial(int n);  // Returns the factorial of n
<a class="l" name="277" href="#277">277</a>```
<a class="l" name="278" href="#278">278</a>
<a class="l" name="279" href="#279">279</a>A test suite for this function might look like:
<a class="hl" name="280" href="#280">280</a>
<a class="l" name="281" href="#281">281</a>```c++
<a class="l" name="282" href="#282">282</a>// Tests factorial of 0.
<a class="l" name="283" href="#283">283</a>TEST(FactorialTest, HandlesZeroInput) {
<a class="l" name="284" href="#284">284</a>  EXPECT_EQ(Factorial(0), 1);
<a class="l" name="285" href="#285">285</a>}
<a class="l" name="286" href="#286">286</a>
<a class="l" name="287" href="#287">287</a>// Tests factorial of positive numbers.
<a class="l" name="288" href="#288">288</a>TEST(FactorialTest, HandlesPositiveInput) {
<a class="l" name="289" href="#289">289</a>  EXPECT_EQ(Factorial(1), 1);
<a class="hl" name="290" href="#290">290</a>  EXPECT_EQ(Factorial(2), 2);
<a class="l" name="291" href="#291">291</a>  EXPECT_EQ(Factorial(3), 6);
<a class="l" name="292" href="#292">292</a>  EXPECT_EQ(Factorial(8), 40320);
<a class="l" name="293" href="#293">293</a>}
<a class="l" name="294" href="#294">294</a>```
<a class="l" name="295" href="#295">295</a>
<a class="l" name="296" href="#296">296</a>googletest groups the test results by test suites, so logically related tests
<a class="l" name="297" href="#297">297</a>should be in the same test suite; in other words, the first argument to their
<a class="l" name="298" href="#298">298</a>`TEST()` should be the same. In the above example, we have two tests,
<a class="l" name="299" href="#299">299</a>`HandlesZeroInput` and `HandlesPositiveInput`, that belong to the same test
<a class="hl" name="300" href="#300">300</a>suite `FactorialTest`.
<a class="l" name="301" href="#301">301</a>
<a class="l" name="302" href="#302">302</a>When naming your test suites and tests, you should follow the same convention as
<a class="l" name="303" href="#303">303</a>for
<a class="l" name="304" href="#304">304</a>[naming functions and classes](<a href="https://google.github.io/styleguide/cppguide.html">https://google.github.io/styleguide/cppguide.html</a>#Function_Names).
<a class="l" name="305" href="#305">305</a>
<a class="l" name="306" href="#306">306</a>**Availability**: Linux, Windows, Mac.
<a class="l" name="307" href="#307">307</a>
<a class="l" name="308" href="#308">308</a>## Test Fixtures: Using the Same Data Configuration for Multiple Tests {#same-data-multiple-tests}
<a class="l" name="309" href="#309">309</a>
<a class="hl" name="310" href="#310">310</a>If you find yourself writing two or more tests that operate on similar data, you
<a class="l" name="311" href="#311">311</a>can use a *test fixture*. This allows you to reuse the same configuration of
<a class="l" name="312" href="#312">312</a>objects for several different tests.
<a class="l" name="313" href="#313">313</a>
<a class="l" name="314" href="#314">314</a>To create a fixture:
<a class="l" name="315" href="#315">315</a>
<a class="l" name="316" href="#316">316</a>1.  Derive a class from `::testing::Test` . Start its body with `protected:`, as
<a class="l" name="317" href="#317">317</a>    we'll want to access fixture members from sub-classes.
<a class="l" name="318" href="#318">318</a>2.  Inside the class, declare any objects you plan to use.
<a class="l" name="319" href="#319">319</a>3.  If necessary, write a default constructor or `SetUp()` function to prepare
<a class="hl" name="320" href="#320">320</a>    the objects for each test. A common mistake is to spell `SetUp()` as
<a class="l" name="321" href="#321">321</a>    **`Setup()`** with a small `u` - Use `override` in C++11 to make sure you
<a class="l" name="322" href="#322">322</a>    spelled it correctly.
<a class="l" name="323" href="#323">323</a>4.  If necessary, write a destructor or `TearDown()` function to release any
<a class="l" name="324" href="#324">324</a>    resources you allocated in `SetUp()` . To learn when you should use the
<a class="l" name="325" href="#325">325</a>    <a href="/googletest/s?path=constructor/destructor&amp;project=googletest">constructor/destructor</a> and when you should use `SetUp()/TearDown()`, read
<a class="l" name="326" href="#326">326</a>    the [FAQ](<a href="/googletest/s?path=faq.md&amp;project=googletest">faq.md</a>#CtorVsSetUp).
<a class="l" name="327" href="#327">327</a>5.  If needed, define subroutines for your tests to share.
<a class="l" name="328" href="#328">328</a>
<a class="l" name="329" href="#329">329</a>When using a fixture, use `TEST_F()` instead of `TEST()` as it allows you to
<a class="hl" name="330" href="#330">330</a>access objects and subroutines in the test fixture:
<a class="l" name="331" href="#331">331</a>
<a class="l" name="332" href="#332">332</a>```c++
<a class="l" name="333" href="#333">333</a>TEST_F(TestFixtureName, TestName) {
<a class="l" name="334" href="#334">334</a>  ... test body ...
<a class="l" name="335" href="#335">335</a>}
<a class="l" name="336" href="#336">336</a>```
<a class="l" name="337" href="#337">337</a>
<a class="l" name="338" href="#338">338</a>Like `TEST()`, the first argument is the test suite name, but for `TEST_F()`
<a class="l" name="339" href="#339">339</a>this must be the name of the test fixture class. You've probably guessed: `_F`
<a class="hl" name="340" href="#340">340</a>is for fixture.
<a class="l" name="341" href="#341">341</a>
<a class="l" name="342" href="#342">342</a>Unfortunately, the C++ macro system does not allow us to create a single macro
<a class="l" name="343" href="#343">343</a>that can handle both types of tests. Using the wrong macro causes a compiler
<a class="l" name="344" href="#344">344</a>error.
<a class="l" name="345" href="#345">345</a>
<a class="l" name="346" href="#346">346</a>Also, you must first define a test fixture class before using it in a
<a class="l" name="347" href="#347">347</a>`TEST_F()`, or you'll get the compiler error "`virtual outside class
<a class="l" name="348" href="#348">348</a>declaration`".
<a class="l" name="349" href="#349">349</a>
<a class="hl" name="350" href="#350">350</a>For each test defined with `TEST_F()`, googletest will create a *fresh* test
<a class="l" name="351" href="#351">351</a>fixture at runtime, immediately initialize it via `SetUp()`, run the test,
<a class="l" name="352" href="#352">352</a>clean up by calling `TearDown()`, and then delete the test fixture. Note that
<a class="l" name="353" href="#353">353</a>different tests in the same test suite have different test fixture objects, and
<a class="l" name="354" href="#354">354</a>googletest always deletes a test fixture before it creates the next one.
<a class="l" name="355" href="#355">355</a>googletest does **not** reuse the same test fixture for multiple tests. Any
<a class="l" name="356" href="#356">356</a>changes one test makes to the fixture do not affect other tests.
<a class="l" name="357" href="#357">357</a>
<a class="l" name="358" href="#358">358</a>As an example, let's write tests for a FIFO queue class named `Queue`, which has
<a class="l" name="359" href="#359">359</a>the following interface:
<a class="hl" name="360" href="#360">360</a>
<a class="l" name="361" href="#361">361</a>```c++
<a class="l" name="362" href="#362">362</a>template &lt;typename E&gt;  // E is the element type.
<a class="l" name="363" href="#363">363</a>class Queue {
<a class="l" name="364" href="#364">364</a> public:
<a class="l" name="365" href="#365">365</a>  Queue();
<a class="l" name="366" href="#366">366</a>  void Enqueue(const E&amp; element);
<a class="l" name="367" href="#367">367</a>  E* Dequeue();  // Returns NULL if the queue is empty.
<a class="l" name="368" href="#368">368</a>  size_t size() const;
<a class="l" name="369" href="#369">369</a>  ...
<a class="hl" name="370" href="#370">370</a>};
<a class="l" name="371" href="#371">371</a>```
<a class="l" name="372" href="#372">372</a>
<a class="l" name="373" href="#373">373</a>First, define a fixture class. By convention, you should give it the name
<a class="l" name="374" href="#374">374</a>`FooTest` where `Foo` is the class being tested.
<a class="l" name="375" href="#375">375</a>
<a class="l" name="376" href="#376">376</a>```c++
<a class="l" name="377" href="#377">377</a>class QueueTest : public ::testing::Test {
<a class="l" name="378" href="#378">378</a> protected:
<a class="l" name="379" href="#379">379</a>  void SetUp() override {
<a class="hl" name="380" href="#380">380</a>     <a href="/googletest/s?path=q1_.Enqueue&amp;project=googletest">q1_.Enqueue</a>(1);
<a class="l" name="381" href="#381">381</a>     <a href="/googletest/s?path=q2_.Enqueue&amp;project=googletest">q2_.Enqueue</a>(2);
<a class="l" name="382" href="#382">382</a>     <a href="/googletest/s?path=q2_.Enqueue&amp;project=googletest">q2_.Enqueue</a>(3);
<a class="l" name="383" href="#383">383</a>  }
<a class="l" name="384" href="#384">384</a>
<a class="l" name="385" href="#385">385</a>  // void TearDown() override {}
<a class="l" name="386" href="#386">386</a>
<a class="l" name="387" href="#387">387</a>  Queue&lt;int&gt; q0_;
<a class="l" name="388" href="#388">388</a>  Queue&lt;int&gt; q1_;
<a class="l" name="389" href="#389">389</a>  Queue&lt;int&gt; q2_;
<a class="hl" name="390" href="#390">390</a>};
<a class="l" name="391" href="#391">391</a>```
<a class="l" name="392" href="#392">392</a>
<a class="l" name="393" href="#393">393</a>In this case, `TearDown()` is not needed since we don't have to clean up after
<a class="l" name="394" href="#394">394</a>each test, other than what's already done by the destructor.
<a class="l" name="395" href="#395">395</a>
<a class="l" name="396" href="#396">396</a>Now we'll write tests using `TEST_F()` and this fixture.
<a class="l" name="397" href="#397">397</a>
<a class="l" name="398" href="#398">398</a>```c++
<a class="l" name="399" href="#399">399</a>TEST_F(QueueTest, IsEmptyInitially) {
<a class="hl" name="400" href="#400">400</a>  EXPECT_EQ(<a href="/googletest/s?path=q0_.size&amp;project=googletest">q0_.size</a>(), 0);
<a class="l" name="401" href="#401">401</a>}
<a class="l" name="402" href="#402">402</a>
<a class="l" name="403" href="#403">403</a>TEST_F(QueueTest, DequeueWorks) {
<a class="l" name="404" href="#404">404</a>  int* n = <a href="/googletest/s?path=q0_.Dequeue&amp;project=googletest">q0_.Dequeue</a>();
<a class="l" name="405" href="#405">405</a>  EXPECT_EQ(n, nullptr);
<a class="l" name="406" href="#406">406</a>
<a class="l" name="407" href="#407">407</a>  n = <a href="/googletest/s?path=q1_.Dequeue&amp;project=googletest">q1_.Dequeue</a>();
<a class="l" name="408" href="#408">408</a>  ASSERT_NE(n, nullptr);
<a class="l" name="409" href="#409">409</a>  EXPECT_EQ(*n, 1);
<a class="hl" name="410" href="#410">410</a>  EXPECT_EQ(<a href="/googletest/s?path=q1_.size&amp;project=googletest">q1_.size</a>(), 0);
<a class="l" name="411" href="#411">411</a>  delete n;
<a class="l" name="412" href="#412">412</a>
<a class="l" name="413" href="#413">413</a>  n = <a href="/googletest/s?path=q2_.Dequeue&amp;project=googletest">q2_.Dequeue</a>();
<a class="l" name="414" href="#414">414</a>  ASSERT_NE(n, nullptr);
<a class="l" name="415" href="#415">415</a>  EXPECT_EQ(*n, 2);
<a class="l" name="416" href="#416">416</a>  EXPECT_EQ(<a href="/googletest/s?path=q2_.size&amp;project=googletest">q2_.size</a>(), 1);
<a class="l" name="417" href="#417">417</a>  delete n;
<a class="l" name="418" href="#418">418</a>}
<a class="l" name="419" href="#419">419</a>```
<a class="hl" name="420" href="#420">420</a>
<a class="l" name="421" href="#421">421</a>The above uses both `ASSERT_*` and `EXPECT_*` assertions. The rule of thumb is
<a class="l" name="422" href="#422">422</a>to use `EXPECT_*` when you want the test to continue to reveal more errors after
<a class="l" name="423" href="#423">423</a>the assertion failure, and use `ASSERT_*` when continuing after failure doesn't
<a class="l" name="424" href="#424">424</a>make sense. For example, the second assertion in the `Dequeue` test is
<a class="l" name="425" href="#425">425</a>`ASSERT_NE(nullptr, n)`, as we need to dereference the pointer `n` later, which
<a class="l" name="426" href="#426">426</a>would lead to a segfault when `n` is `NULL`.
<a class="l" name="427" href="#427">427</a>
<a class="l" name="428" href="#428">428</a>When these tests run, the following happens:
<a class="l" name="429" href="#429">429</a>
<a class="hl" name="430" href="#430">430</a>1.  googletest constructs a `QueueTest` object (let's call it `t1`).
<a class="l" name="431" href="#431">431</a>2.  `<a href="/googletest/s?path=t1.SetUp&amp;project=googletest">t1.SetUp</a>()` initializes `t1`.
<a class="l" name="432" href="#432">432</a>3.  The first test (`IsEmptyInitially`) runs on `t1`.
<a class="l" name="433" href="#433">433</a>4.  `<a href="/googletest/s?path=t1.TearDown&amp;project=googletest">t1.TearDown</a>()` cleans up after the test finishes.
<a class="l" name="434" href="#434">434</a>5.  `t1` is destructed.
<a class="l" name="435" href="#435">435</a>6.  The above steps are repeated on another `QueueTest` object, this time
<a class="l" name="436" href="#436">436</a>    running the `DequeueWorks` test.
<a class="l" name="437" href="#437">437</a>
<a class="l" name="438" href="#438">438</a>**Availability**: Linux, Windows, Mac.
<a class="l" name="439" href="#439">439</a>
<a class="hl" name="440" href="#440">440</a>## Invoking the Tests
<a class="l" name="441" href="#441">441</a>
<a class="l" name="442" href="#442">442</a>`TEST()` and `TEST_F()` implicitly register their tests with googletest. So,
<a class="l" name="443" href="#443">443</a>unlike with many other C++ testing frameworks, you don't have to re-list all
<a class="l" name="444" href="#444">444</a>your defined tests in order to run them.
<a class="l" name="445" href="#445">445</a>
<a class="l" name="446" href="#446">446</a>After defining your tests, you can run them with `RUN_ALL_TESTS()`, which
<a class="l" name="447" href="#447">447</a>returns `0` if all the tests are successful, or `1` otherwise. Note that
<a class="l" name="448" href="#448">448</a>`RUN_ALL_TESTS()` runs *all tests* in your link unit--they can be from
<a class="l" name="449" href="#449">449</a>different test suites, or even different source files.
<a class="hl" name="450" href="#450">450</a>
<a class="l" name="451" href="#451">451</a>When invoked, the `RUN_ALL_TESTS()` macro:
<a class="l" name="452" href="#452">452</a>
<a class="l" name="453" href="#453">453</a>*   Saves the state of all googletest flags.
<a class="l" name="454" href="#454">454</a>
<a class="l" name="455" href="#455">455</a>*   Creates a test fixture object for the first test.
<a class="l" name="456" href="#456">456</a>
<a class="l" name="457" href="#457">457</a>*   Initializes it via `SetUp()`.
<a class="l" name="458" href="#458">458</a>
<a class="l" name="459" href="#459">459</a>*   Runs the test on the fixture object.
<a class="hl" name="460" href="#460">460</a>
<a class="l" name="461" href="#461">461</a>*   Cleans up the fixture via `TearDown()`.
<a class="l" name="462" href="#462">462</a>
<a class="l" name="463" href="#463">463</a>*   Deletes the fixture.
<a class="l" name="464" href="#464">464</a>
<a class="l" name="465" href="#465">465</a>*   Restores the state of all googletest flags.
<a class="l" name="466" href="#466">466</a>
<a class="l" name="467" href="#467">467</a>*   Repeats the above steps for the next test, until all tests have run.
<a class="l" name="468" href="#468">468</a>
<a class="l" name="469" href="#469">469</a>If a fatal failure happens the subsequent steps will be skipped.
<a class="hl" name="470" href="#470">470</a>
<a class="l" name="471" href="#471">471</a>&gt; IMPORTANT: You must **not** ignore the return value of `RUN_ALL_TESTS()`, or
<a class="l" name="472" href="#472">472</a>&gt; you will get a compiler error. The rationale for this design is that the
<a class="l" name="473" href="#473">473</a>&gt; automated testing service determines whether a test has passed based on its
<a class="l" name="474" href="#474">474</a>&gt; exit code, not on its <a href="/googletest/s?path=stdout/stderr&amp;project=googletest">stdout/stderr</a> output; thus your `main()` function must
<a class="l" name="475" href="#475">475</a>&gt; return the value of `RUN_ALL_TESTS()`.
<a class="l" name="476" href="#476">476</a>&gt;
<a class="l" name="477" href="#477">477</a>&gt; Also, you should call `RUN_ALL_TESTS()` only **once**. Calling it more than
<a class="l" name="478" href="#478">478</a>&gt; once conflicts with some advanced googletest features (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>, thread-safe
<a class="l" name="479" href="#479">479</a>&gt; [death tests](<a href="/googletest/s?path=advanced.md&amp;project=googletest">advanced.md</a>#death-tests)) and thus is not supported.
<a class="hl" name="480" href="#480">480</a>
<a class="l" name="481" href="#481">481</a>**Availability**: Linux, Windows, Mac.
<a class="l" name="482" href="#482">482</a>
<a class="l" name="483" href="#483">483</a>## Writing the main() Function
<a class="l" name="484" href="#484">484</a>
<a class="l" name="485" href="#485">485</a>Most users should _not_ need to write their own `main` function and instead link
<a class="l" name="486" href="#486">486</a>with `gtest_main` (as opposed to with `gtest`), which defines a suitable entry
<a class="l" name="487" href="#487">487</a>point. See the end of this section for details. The remainder of this section
<a class="l" name="488" href="#488">488</a>should only apply when you need to do something custom before the tests run that
<a class="l" name="489" href="#489">489</a>cannot be expressed within the framework of fixtures and test suites.
<a class="hl" name="490" href="#490">490</a>
<a class="l" name="491" href="#491">491</a>If you write your own `main` function, it should return the value of
<a class="l" name="492" href="#492">492</a>`RUN_ALL_TESTS()`.
<a class="l" name="493" href="#493">493</a>
<a class="l" name="494" href="#494">494</a>You can start from this boilerplate:
<a class="l" name="495" href="#495">495</a>
<a class="l" name="496" href="#496">496</a>```c++
<a class="l" name="497" href="#497">497</a>#include "<a href="/googletest/s?path=this/package/foo.h&amp;project=googletest">this/package/foo.h</a>"
<a class="l" name="498" href="#498">498</a>
<a class="l" name="499" href="#499">499</a>#include "<a href="/googletest/s?path=gtest/gtest.h&amp;project=googletest">gtest/gtest.h</a>"
<a class="hl" name="500" href="#500">500</a>
<a class="l" name="501" href="#501">501</a>namespace my {
<a class="l" name="502" href="#502">502</a>namespace project {
<a class="l" name="503" href="#503">503</a>namespace {
<a class="l" name="504" href="#504">504</a>
<a class="l" name="505" href="#505">505</a>// The fixture for testing class Foo.
<a class="l" name="506" href="#506">506</a>class FooTest : public ::testing::Test {
<a class="l" name="507" href="#507">507</a> protected:
<a class="l" name="508" href="#508">508</a>  // You can remove any or all of the following functions if their bodies would
<a class="l" name="509" href="#509">509</a>  // be empty.
<a class="hl" name="510" href="#510">510</a>
<a class="l" name="511" href="#511">511</a>  FooTest() {
<a class="l" name="512" href="#512">512</a>     // You can do set-up work for each test here.
<a class="l" name="513" href="#513">513</a>  }
<a class="l" name="514" href="#514">514</a>
<a class="l" name="515" href="#515">515</a>  ~FooTest() override {
<a class="l" name="516" href="#516">516</a>     // You can do clean-up work that doesn't throw exceptions here.
<a class="l" name="517" href="#517">517</a>  }
<a class="l" name="518" href="#518">518</a>
<a class="l" name="519" href="#519">519</a>  // If the constructor and destructor are not enough for setting up
<a class="hl" name="520" href="#520">520</a>  // and cleaning up each test, you can define the following methods:
<a class="l" name="521" href="#521">521</a>
<a class="l" name="522" href="#522">522</a>  void SetUp() override {
<a class="l" name="523" href="#523">523</a>     // Code here will be called immediately after the constructor (right
<a class="l" name="524" href="#524">524</a>     // before each test).
<a class="l" name="525" href="#525">525</a>  }
<a class="l" name="526" href="#526">526</a>
<a class="l" name="527" href="#527">527</a>  void TearDown() override {
<a class="l" name="528" href="#528">528</a>     // Code here will be called immediately after each test (right
<a class="l" name="529" href="#529">529</a>     // before the destructor).
<a class="hl" name="530" href="#530">530</a>  }
<a class="l" name="531" href="#531">531</a>
<a class="l" name="532" href="#532">532</a>  // Class members declared here can be used by all tests in the test suite
<a class="l" name="533" href="#533">533</a>  // for Foo.
<a class="l" name="534" href="#534">534</a>};
<a class="l" name="535" href="#535">535</a>
<a class="l" name="536" href="#536">536</a>// Tests that the Foo::Bar() method does Abc.
<a class="l" name="537" href="#537">537</a>TEST_F(FooTest, MethodBarDoesAbc) {
<a class="l" name="538" href="#538">538</a>  const std::string input_filepath = "<a href="/googletest/s?path=this/package/testdata/myinputfile.dat&amp;project=googletest">this/package/testdata/myinputfile.dat</a>";
<a class="l" name="539" href="#539">539</a>  const std::string output_filepath = "<a href="/googletest/s?path=this/package/testdata/myoutputfile.dat&amp;project=googletest">this/package/testdata/myoutputfile.dat</a>";
<a class="hl" name="540" href="#540">540</a>  Foo f;
<a class="l" name="541" href="#541">541</a>  EXPECT_EQ(<a href="/googletest/s?path=f.Bar&amp;project=googletest">f.Bar</a>(input_filepath, output_filepath), 0);
<a class="l" name="542" href="#542">542</a>}
<a class="l" name="543" href="#543">543</a>
<a class="l" name="544" href="#544">544</a>// Tests that Foo does Xyz.
<a class="l" name="545" href="#545">545</a>TEST_F(FooTest, DoesXyz) {
<a class="l" name="546" href="#546">546</a>  // Exercises the Xyz feature of Foo.
<a class="l" name="547" href="#547">547</a>}
<a class="l" name="548" href="#548">548</a>
<a class="l" name="549" href="#549">549</a>}  // namespace
<a class="hl" name="550" href="#550">550</a>}  // namespace project
<a class="l" name="551" href="#551">551</a>}  // namespace my
<a class="l" name="552" href="#552">552</a>
<a class="l" name="553" href="#553">553</a>int main(int argc, char **argv) {
<a class="l" name="554" href="#554">554</a>  ::testing::InitGoogleTest(&amp;argc, argv);
<a class="l" name="555" href="#555">555</a>  return RUN_ALL_TESTS();
<a class="l" name="556" href="#556">556</a>}
<a class="l" name="557" href="#557">557</a>```
<a class="l" name="558" href="#558">558</a>
<a class="l" name="559" href="#559">559</a>The `::testing::InitGoogleTest()` function parses the command line for
<a class="hl" name="560" href="#560">560</a>googletest flags, and removes all recognized flags. This allows the user to
<a class="l" name="561" href="#561">561</a>control a test program's behavior via various flags, which we'll cover in
<a class="l" name="562" href="#562">562</a>the [AdvancedGuide](<a href="/googletest/s?path=advanced.md&amp;project=googletest">advanced.md</a>). You **must** call this function before calling
<a class="l" name="563" href="#563">563</a>`RUN_ALL_TESTS()`, or the flags won't be properly initialized.
<a class="l" name="564" href="#564">564</a>
<a class="l" name="565" href="#565">565</a>On Windows, `InitGoogleTest()` also works with wide strings, so it can be used
<a class="l" name="566" href="#566">566</a>in programs compiled in `UNICODE` mode as well.
<a class="l" name="567" href="#567">567</a>
<a class="l" name="568" href="#568">568</a>But maybe you think that writing all those `main` functions is too much work? We
<a class="l" name="569" href="#569">569</a>agree with you completely, and that's why Google Test provides a basic
<a class="hl" name="570" href="#570">570</a>implementation of main(). If it fits your needs, then just link your test with
<a class="l" name="571" href="#571">571</a>the `gtest_main` library and you are good to go.
<a class="l" name="572" href="#572">572</a>
<a class="l" name="573" href="#573">573</a>NOTE: `ParseGUnitFlags()` is deprecated in favor of `InitGoogleTest()`.
<a class="l" name="574" href="#574">574</a>
<a class="l" name="575" href="#575">575</a>## Known Limitations
<a class="l" name="576" href="#576">576</a>
<a class="l" name="577" href="#577">577</a>*   Google Test is designed to be thread-safe. The implementation is thread-safe
<a class="l" name="578" href="#578">578</a>    on systems where the `pthreads` library is available. It is currently
<a class="l" name="579" href="#579">579</a>    _unsafe_ to use Google Test assertions from two threads concurrently on
<a class="hl" name="580" href="#580">580</a>    other systems (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> Windows). In most tests this is not an issue as usually
<a class="l" name="581" href="#581">581</a>    the assertions are done in the main thread. If you want to help, you can
<a class="l" name="582" href="#582">582</a>    volunteer to implement the necessary synchronization primitives in
<a class="l" name="583" href="#583">583</a>    `<a href="/googletest/s?path=gtest-port.h&amp;project=googletest">gtest-port.h</a>` for your platform.
<a class="l" name="584" href="#584">584</a>