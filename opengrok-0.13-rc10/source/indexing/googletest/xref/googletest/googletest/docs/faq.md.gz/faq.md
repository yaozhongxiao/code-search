<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># Googletest FAQ
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>&lt;!-- GOOGLETEST_CM0014 DO NOT DELETE --&gt;
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>&lt;!-- GOOGLETEST_CM0035 DO NOT DELETE --&gt;
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>## Why should test suite names and test names not contain underscore?
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>Note: Googletest reserves underscore (`_`) for special purpose keywords, such as
<a class="hl" name="10" href="#10">10</a>[the `DISABLED_` prefix](<a href="/googletest/s?path=advanced.md&amp;project=googletest">advanced.md</a>#temporarily-disabling-tests), in addition
<a class="l" name="11" href="#11">11</a>to the following rationale.
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a>Underscore (`_`) is special, as C++ reserves the following to be used by the
<a class="l" name="14" href="#14">14</a>compiler and the standard library:
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a>1.  any identifier that starts with an `_` followed by an upper-case letter, and
<a class="l" name="17" href="#17">17</a>2.  any identifier that contains two consecutive underscores (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> `__`)
<a class="l" name="18" href="#18">18</a>    *anywhere* in its name.
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a>User code is *prohibited* from using such identifiers.
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a>Now let's look at what this means for `TEST` and `TEST_F`.
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a>Currently `TEST(TestSuiteName, TestName)` generates a class named
<a class="l" name="25" href="#25">25</a>`TestSuiteName_TestName_Test`. What happens if `TestSuiteName` or `TestName`
<a class="l" name="26" href="#26">26</a>contains `_`?
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a>1.  If `TestSuiteName` starts with an `_` followed by an upper-case letter (say,
<a class="l" name="29" href="#29">29</a>    `_Foo`), we end up with `_Foo_TestName_Test`, which is reserved and thus
<a class="hl" name="30" href="#30">30</a>    invalid.
<a class="l" name="31" href="#31">31</a>2.  If `TestSuiteName` ends with an `_` (say, `Foo_`), we get
<a class="l" name="32" href="#32">32</a>    `Foo__TestName_Test`, which is invalid.
<a class="l" name="33" href="#33">33</a>3.  If `TestName` starts with an `_` (say, `_Bar`), we get
<a class="l" name="34" href="#34">34</a>    `TestSuiteName__Bar_Test`, which is invalid.
<a class="l" name="35" href="#35">35</a>4.  If `TestName` ends with an `_` (say, `Bar_`), we get
<a class="l" name="36" href="#36">36</a>    `TestSuiteName_Bar__Test`, which is invalid.
<a class="l" name="37" href="#37">37</a>
<a class="l" name="38" href="#38">38</a>So clearly `TestSuiteName` and `TestName` cannot start or end with `_`
<a class="l" name="39" href="#39">39</a>(Actually, `TestSuiteName` can start with `_` -- as long as the `_` isn't
<a class="hl" name="40" href="#40">40</a>followed by an upper-case letter. But that's getting complicated. So for
<a class="l" name="41" href="#41">41</a>simplicity we just say that it cannot start with `_`.).
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>It may seem fine for `TestSuiteName` and `TestName` to contain `_` in the
<a class="l" name="44" href="#44">44</a>middle. However, consider this:
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>```c++
<a class="l" name="47" href="#47">47</a>TEST(Time, Flies_Like_An_Arrow) { ... }
<a class="l" name="48" href="#48">48</a>TEST(Time_Flies, Like_An_Arrow) { ... }
<a class="l" name="49" href="#49">49</a>```
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>Now, the two `TEST`s will both generate the same class
<a class="l" name="52" href="#52">52</a>(`Time_Flies_Like_An_Arrow_Test`). That's not good.
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>So for simplicity, we just ask the users to avoid `_` in `TestSuiteName` and
<a class="l" name="55" href="#55">55</a>`TestName`. The rule is more constraining than necessary, but it's simple and
<a class="l" name="56" href="#56">56</a>easy to remember. It also gives googletest some wiggle room in case its
<a class="l" name="57" href="#57">57</a>implementation needs to change in the future.
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>If you violate the rule, there may not be immediate consequences, but your test
<a class="hl" name="60" href="#60">60</a>may (just may) break with a new compiler (or a new version of the compiler you
<a class="l" name="61" href="#61">61</a>are using) or with a new version of googletest. Therefore it's best to follow
<a class="l" name="62" href="#62">62</a>the rule.
<a class="l" name="63" href="#63">63</a>
<a class="l" name="64" href="#64">64</a>## Why does googletest support `EXPECT_EQ(NULL, ptr)` and `ASSERT_EQ(NULL, ptr)` but not `EXPECT_NE(NULL, ptr)` and `ASSERT_NE(NULL, ptr)`?
<a class="l" name="65" href="#65">65</a>
<a class="l" name="66" href="#66">66</a>First of all you can use `EXPECT_NE(nullptr, ptr)` and `ASSERT_NE(nullptr,
<a class="l" name="67" href="#67">67</a>ptr)`. This is the preferred syntax in the style guide because nullptr does not
<a class="l" name="68" href="#68">68</a>have the type problems that NULL does. Which is why NULL does not work.
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>Due to some peculiarity of C++, it requires some non-trivial template meta
<a class="l" name="71" href="#71">71</a>programming tricks to support using `NULL` as an argument of the `EXPECT_XX()`
<a class="l" name="72" href="#72">72</a>and `ASSERT_XX()` macros. Therefore we only do it where it's most needed
<a class="l" name="73" href="#73">73</a>(otherwise we make the implementation of googletest harder to maintain and more
<a class="l" name="74" href="#74">74</a>error-prone than necessary).
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a>The `EXPECT_EQ()` macro takes the *expected* value as its first argument and the
<a class="l" name="77" href="#77">77</a>*actual* value as the second. It's reasonable that someone wants to write
<a class="l" name="78" href="#78">78</a>`EXPECT_EQ(NULL, some_expression)`, and this indeed was requested several times.
<a class="l" name="79" href="#79">79</a>Therefore we implemented it.
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a>The need for `EXPECT_NE(NULL, ptr)` isn't nearly as strong. When the assertion
<a class="l" name="82" href="#82">82</a>fails, you already know that `ptr` must be `NULL`, so it doesn't add any
<a class="l" name="83" href="#83">83</a>information to print `ptr` in this case. That means `EXPECT_TRUE(ptr != NULL)`
<a class="l" name="84" href="#84">84</a>works just as well.
<a class="l" name="85" href="#85">85</a>
<a class="l" name="86" href="#86">86</a>If we were to support `EXPECT_NE(NULL, ptr)`, for consistency we'll have to
<a class="l" name="87" href="#87">87</a>support `EXPECT_NE(ptr, NULL)` as well, as unlike `EXPECT_EQ`, we don't have a
<a class="l" name="88" href="#88">88</a>convention on the order of the two arguments for `EXPECT_NE`. This means using
<a class="l" name="89" href="#89">89</a>the template meta programming tricks twice in the implementation, making it even
<a class="hl" name="90" href="#90">90</a>harder to understand and maintain. We believe the benefit doesn't justify the
<a class="l" name="91" href="#91">91</a>cost.
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>Finally, with the growth of the gMock matcher library, we are encouraging people
<a class="l" name="94" href="#94">94</a>to use the unified `EXPECT_THAT(value, matcher)` syntax more often in tests. One
<a class="l" name="95" href="#95">95</a>significant advantage of the matcher approach is that matchers can be easily
<a class="l" name="96" href="#96">96</a>combined to form new matchers, while the `EXPECT_NE`, etc, macros cannot be
<a class="l" name="97" href="#97">97</a>easily combined. Therefore we want to invest more in the matchers than in the
<a class="l" name="98" href="#98">98</a>`EXPECT_XX()` macros.
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>## I need to test that different implementations of an interface satisfy some common requirements. Should I use typed tests or value-parameterized tests?
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>For testing various implementations of the same interface, either typed tests or
<a class="l" name="103" href="#103">103</a>value-parameterized tests can get it done. It's really up to you the user to
<a class="l" name="104" href="#104">104</a>decide which is more convenient for you, depending on your particular case. Some
<a class="l" name="105" href="#105">105</a>rough guidelines:
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>*   Typed tests can be easier to write if instances of the different
<a class="l" name="108" href="#108">108</a>    implementations can be created the same way, modulo the type. For example,
<a class="l" name="109" href="#109">109</a>    if all these implementations have a public default constructor (such that
<a class="hl" name="110" href="#110">110</a>    you can write `new TypeParam`), or if their factory functions have the same
<a class="l" name="111" href="#111">111</a>    form (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `CreateInstance&lt;TypeParam&gt;()`).
<a class="l" name="112" href="#112">112</a>*   Value-parameterized tests can be easier to write if you need different code
<a class="l" name="113" href="#113">113</a>    patterns to create different implementations' instances, <a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `new Foo` vs
<a class="l" name="114" href="#114">114</a>    `new Bar(5)`. To accommodate for the differences, you can write factory
<a class="l" name="115" href="#115">115</a>    function wrappers and pass these function pointers to the tests as their
<a class="l" name="116" href="#116">116</a>    parameters.
<a class="l" name="117" href="#117">117</a>*   When a typed test fails, the default output includes the name of the type,
<a class="l" name="118" href="#118">118</a>    which can help you quickly identify which implementation is wrong.
<a class="l" name="119" href="#119">119</a>    Value-parameterized tests only show the number of the failed iteration by
<a class="hl" name="120" href="#120">120</a>    default. You will need to define a function that returns the iteration name
<a class="l" name="121" href="#121">121</a>    and pass it as the third parameter to INSTANTIATE_TEST_SUITE_P to have more
<a class="l" name="122" href="#122">122</a>    useful output.
<a class="l" name="123" href="#123">123</a>*   When using typed tests, you need to make sure you are testing against the
<a class="l" name="124" href="#124">124</a>    interface type, not the concrete types (in other words, you want to make
<a class="l" name="125" href="#125">125</a>    sure `implicit_cast&lt;MyInterface*&gt;(my_concrete_impl)` works, not just that
<a class="l" name="126" href="#126">126</a>    `my_concrete_impl` works). It's less likely to make mistakes in this area
<a class="l" name="127" href="#127">127</a>    when using value-parameterized tests.
<a class="l" name="128" href="#128">128</a>
<a class="l" name="129" href="#129">129</a>I hope I didn't confuse you more. :-) If you don't mind, I'd suggest you to give
<a class="hl" name="130" href="#130">130</a>both approaches a try. Practice is a much better way to grasp the subtle
<a class="l" name="131" href="#131">131</a>differences between the two tools. Once you have some concrete experience, you
<a class="l" name="132" href="#132">132</a>can much more easily decide which one to use the next time.
<a class="l" name="133" href="#133">133</a>
<a class="l" name="134" href="#134">134</a>## I got some run-time errors about invalid proto descriptors when using `ProtocolMessageEquals`. Help!
<a class="l" name="135" href="#135">135</a>
<a class="l" name="136" href="#136">136</a>**Note:** `ProtocolMessageEquals` and `ProtocolMessageEquiv` are *deprecated*
<a class="l" name="137" href="#137">137</a>now. Please use `EqualsProto`, etc instead.
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>`ProtocolMessageEquals` and `ProtocolMessageEquiv` were redefined recently and
<a class="hl" name="140" href="#140">140</a>are now less tolerant of invalid protocol buffer definitions. In particular, if
<a class="l" name="141" href="#141">141</a>you have a `<a href="/googletest/s?path=foo.proto&amp;project=googletest">foo.proto</a>` that doesn't fully qualify the type of a protocol message
<a class="l" name="142" href="#142">142</a>it references (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `message&lt;Bar&gt;` where it should be `message&lt;<a href="/googletest/s?path=blah.Bar&amp;project=googletest">blah.Bar</a>&gt;`), you
<a class="l" name="143" href="#143">143</a>will now get run-time errors like:
<a class="l" name="144" href="#144">144</a>
<a class="l" name="145" href="#145">145</a>```
<a class="l" name="146" href="#146">146</a>... <a href="/googletest/s?path=descriptor.cc&amp;project=googletest">descriptor.cc</a>:...] Invalid proto descriptor for file "<a href="/googletest/s?path=path/to/foo.proto&amp;project=googletest">path/to/foo.proto</a>":
<a class="l" name="147" href="#147">147</a>... <a href="/googletest/s?path=descriptor.cc&amp;project=googletest">descriptor.cc</a>:...]  <a href="/googletest/s?path=blah.MyMessage.my_field&amp;project=googletest">blah.MyMessage.my_field</a>: ".Bar" is not defined.
<a class="l" name="148" href="#148">148</a>```
<a class="l" name="149" href="#149">149</a>
<a class="hl" name="150" href="#150">150</a>If you see this, your `.proto` file is broken and needs to be fixed by making
<a class="l" name="151" href="#151">151</a>the types fully qualified. The new definition of `ProtocolMessageEquals` and
<a class="l" name="152" href="#152">152</a>`ProtocolMessageEquiv` just happen to reveal your bug.
<a class="l" name="153" href="#153">153</a>
<a class="l" name="154" href="#154">154</a>## My death test modifies some state, but the change seems lost after the death test finishes. Why?
<a class="l" name="155" href="#155">155</a>
<a class="l" name="156" href="#156">156</a>Death tests (`EXPECT_DEATH`, etc) are executed in a sub-process <a href="/googletest/s?path=s.t.&amp;project=googletest">s.t.</a> the
<a class="l" name="157" href="#157">157</a>expected crash won't kill the test program (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> the parent process). As a
<a class="l" name="158" href="#158">158</a>result, any in-memory side effects they incur are observable in their respective
<a class="l" name="159" href="#159">159</a>sub-processes, but not in the parent process. You can think of them as running
<a class="hl" name="160" href="#160">160</a>in a parallel universe, more or less.
<a class="l" name="161" href="#161">161</a>
<a class="l" name="162" href="#162">162</a>In particular, if you use mocking and the death test statement invokes some mock
<a class="l" name="163" href="#163">163</a>methods, the parent process will think the calls have never occurred. Therefore,
<a class="l" name="164" href="#164">164</a>you may want to move your `EXPECT_CALL` statements inside the `EXPECT_DEATH`
<a class="l" name="165" href="#165">165</a>macro.
<a class="l" name="166" href="#166">166</a>
<a class="l" name="167" href="#167">167</a>## EXPECT_EQ(htonl(blah), blah_blah) generates weird compiler errors in opt mode. Is this a googletest bug?
<a class="l" name="168" href="#168">168</a>
<a class="l" name="169" href="#169">169</a>Actually, the bug is in `htonl()`.
<a class="hl" name="170" href="#170">170</a>
<a class="l" name="171" href="#171">171</a>According to `'man htonl'`, `htonl()` is a *function*, which means it's valid to
<a class="l" name="172" href="#172">172</a>use `htonl` as a function pointer. However, in opt mode `htonl()` is defined as
<a class="l" name="173" href="#173">173</a>a *macro*, which breaks this usage.
<a class="l" name="174" href="#174">174</a>
<a class="l" name="175" href="#175">175</a>Worse, the macro definition of `htonl()` uses a `gcc` extension and is *not*
<a class="l" name="176" href="#176">176</a>standard C++. That hacky implementation has some ad hoc limitations. In
<a class="l" name="177" href="#177">177</a>particular, it prevents you from writing `Foo&lt;sizeof(htonl(x))&gt;()`, where `Foo`
<a class="l" name="178" href="#178">178</a>is a template that has an integral argument.
<a class="l" name="179" href="#179">179</a>
<a class="hl" name="180" href="#180">180</a>The implementation of `EXPECT_EQ(a, b)` uses `sizeof(... a ...)` inside a
<a class="l" name="181" href="#181">181</a>template argument, and thus doesn't compile in opt mode when `a` contains a call
<a class="l" name="182" href="#182">182</a>to `htonl()`. It is difficult to make `EXPECT_EQ` bypass the `htonl()` bug, as
<a class="l" name="183" href="#183">183</a>the solution must work with different compilers on various platforms.
<a class="l" name="184" href="#184">184</a>
<a class="l" name="185" href="#185">185</a>`htonl()` has some other problems as described in `/<a href="/googletest/s?path=/util/endian/endian.h&amp;project=googletest">/util/endian/endian.h</a>`,
<a class="l" name="186" href="#186">186</a>which defines `ghtonl()` to replace it. `ghtonl()` does the same thing `htonl()`
<a class="l" name="187" href="#187">187</a>does, only without its problems. We suggest you to use `ghtonl()` instead of
<a class="l" name="188" href="#188">188</a>`htonl()`, both in your tests and production code.
<a class="l" name="189" href="#189">189</a>
<a class="hl" name="190" href="#190">190</a>`/<a href="/googletest/s?path=/util/endian/endian.h&amp;project=googletest">/util/endian/endian.h</a>` also defines `ghtons()`, which solves similar problems
<a class="l" name="191" href="#191">191</a>in `htons()`.
<a class="l" name="192" href="#192">192</a>
<a class="l" name="193" href="#193">193</a>Don't forget to add `/<a href="/googletest/s?path=/util/endian&amp;project=googletest">/util/endian</a>` to the list of dependencies in the `BUILD`
<a class="l" name="194" href="#194">194</a>file wherever `ghtonl()` and `ghtons()` are used. The library consists of a
<a class="l" name="195" href="#195">195</a>single header file and will not bloat your binary.
<a class="l" name="196" href="#196">196</a>
<a class="l" name="197" href="#197">197</a>## The compiler complains about "undefined references" to some static const member variables, but I did define them in the class body. What's wrong?
<a class="l" name="198" href="#198">198</a>
<a class="l" name="199" href="#199">199</a>If your class has a static data member:
<a class="hl" name="200" href="#200">200</a>
<a class="l" name="201" href="#201">201</a>```c++
<a class="l" name="202" href="#202">202</a>// <a href="/googletest/s?path=foo.h&amp;project=googletest">foo.h</a>
<a class="l" name="203" href="#203">203</a>class Foo {
<a class="l" name="204" href="#204">204</a>  ...
<a class="l" name="205" href="#205">205</a>  static const int kBar = 100;
<a class="l" name="206" href="#206">206</a>};
<a class="l" name="207" href="#207">207</a>```
<a class="l" name="208" href="#208">208</a>
<a class="l" name="209" href="#209">209</a>You also need to define it *outside* of the class body in `<a href="/googletest/s?path=foo.cc&amp;project=googletest">foo.cc</a>`:
<a class="hl" name="210" href="#210">210</a>
<a class="l" name="211" href="#211">211</a>```c++
<a class="l" name="212" href="#212">212</a>const int Foo::kBar;  // No initializer here.
<a class="l" name="213" href="#213">213</a>```
<a class="l" name="214" href="#214">214</a>
<a class="l" name="215" href="#215">215</a>Otherwise your code is **invalid C++**, and may break in unexpected ways. In
<a class="l" name="216" href="#216">216</a>particular, using it in googletest comparison assertions (`EXPECT_EQ`, etc) will
<a class="l" name="217" href="#217">217</a>generate an "undefined reference" linker error. The fact that "it used to work"
<a class="l" name="218" href="#218">218</a>doesn't mean it's valid. It just means that you were lucky. :-)
<a class="l" name="219" href="#219">219</a>
<a class="hl" name="220" href="#220">220</a>If the declaration of the static data member is `constexpr` then it is
<a class="l" name="221" href="#221">221</a>implicitly an `inline` definition, and a separate definition in `<a href="/googletest/s?path=foo.cc&amp;project=googletest">foo.cc</a>` is not
<a class="l" name="222" href="#222">222</a>needed:
<a class="l" name="223" href="#223">223</a>
<a class="l" name="224" href="#224">224</a>```c++
<a class="l" name="225" href="#225">225</a>// <a href="/googletest/s?path=foo.h&amp;project=googletest">foo.h</a>
<a class="l" name="226" href="#226">226</a>class Foo {
<a class="l" name="227" href="#227">227</a>  ...
<a class="l" name="228" href="#228">228</a>  static constexpr int kBar = 100;  // Defines kBar, no need to do it in <a href="/googletest/s?path=foo.cc.&amp;project=googletest">foo.cc.</a>
<a class="l" name="229" href="#229">229</a>};
<a class="hl" name="230" href="#230">230</a>```
<a class="l" name="231" href="#231">231</a>
<a class="l" name="232" href="#232">232</a>## Can I derive a test fixture from another?
<a class="l" name="233" href="#233">233</a>
<a class="l" name="234" href="#234">234</a>Yes.
<a class="l" name="235" href="#235">235</a>
<a class="l" name="236" href="#236">236</a>Each test fixture has a corresponding and same named test suite. This means only
<a class="l" name="237" href="#237">237</a>one test suite can use a particular fixture. Sometimes, however, multiple test
<a class="l" name="238" href="#238">238</a>cases may want to use the same or slightly different fixtures. For example, you
<a class="l" name="239" href="#239">239</a>may want to make sure that all of a GUI library's test suites don't leak
<a class="hl" name="240" href="#240">240</a>important system resources like fonts and brushes.
<a class="l" name="241" href="#241">241</a>
<a class="l" name="242" href="#242">242</a>In googletest, you share a fixture among test suites by putting the shared logic
<a class="l" name="243" href="#243">243</a>in a base test fixture, then deriving from that base a separate fixture for each
<a class="l" name="244" href="#244">244</a>test suite that wants to use this common logic. You then use `TEST_F()` to write
<a class="l" name="245" href="#245">245</a>tests using each derived fixture.
<a class="l" name="246" href="#246">246</a>
<a class="l" name="247" href="#247">247</a>Typically, your code looks like this:
<a class="l" name="248" href="#248">248</a>
<a class="l" name="249" href="#249">249</a>```c++
<a class="hl" name="250" href="#250">250</a>// Defines a base test fixture.
<a class="l" name="251" href="#251">251</a>class BaseTest : public ::testing::Test {
<a class="l" name="252" href="#252">252</a> protected:
<a class="l" name="253" href="#253">253</a>  ...
<a class="l" name="254" href="#254">254</a>};
<a class="l" name="255" href="#255">255</a>
<a class="l" name="256" href="#256">256</a>// Derives a fixture FooTest from BaseTest.
<a class="l" name="257" href="#257">257</a>class FooTest : public BaseTest {
<a class="l" name="258" href="#258">258</a> protected:
<a class="l" name="259" href="#259">259</a>  void SetUp() override {
<a class="hl" name="260" href="#260">260</a>    BaseTest::SetUp();  // Sets up the base fixture first.
<a class="l" name="261" href="#261">261</a>    ... additional set-up work ...
<a class="l" name="262" href="#262">262</a>  }
<a class="l" name="263" href="#263">263</a>
<a class="l" name="264" href="#264">264</a>  void TearDown() override {
<a class="l" name="265" href="#265">265</a>    ... clean-up work for FooTest ...
<a class="l" name="266" href="#266">266</a>    BaseTest::TearDown();  // Remember to tear down the base fixture
<a class="l" name="267" href="#267">267</a>                           // after cleaning up FooTest!
<a class="l" name="268" href="#268">268</a>  }
<a class="l" name="269" href="#269">269</a>
<a class="hl" name="270" href="#270">270</a>  ... functions and variables for FooTest ...
<a class="l" name="271" href="#271">271</a>};
<a class="l" name="272" href="#272">272</a>
<a class="l" name="273" href="#273">273</a>// Tests that use the fixture FooTest.
<a class="l" name="274" href="#274">274</a>TEST_F(FooTest, Bar) { ... }
<a class="l" name="275" href="#275">275</a>TEST_F(FooTest, Baz) { ... }
<a class="l" name="276" href="#276">276</a>
<a class="l" name="277" href="#277">277</a>... additional fixtures derived from BaseTest ...
<a class="l" name="278" href="#278">278</a>```
<a class="l" name="279" href="#279">279</a>
<a class="hl" name="280" href="#280">280</a>If necessary, you can continue to derive test fixtures from a derived fixture.
<a class="l" name="281" href="#281">281</a>googletest has no limit on how deep the hierarchy can be.
<a class="l" name="282" href="#282">282</a>
<a class="l" name="283" href="#283">283</a>For a complete example using derived test fixtures, see
<a class="l" name="284" href="#284">284</a>[<a href="/googletest/s?path=sample5_unittest.cc&amp;project=googletest">sample5_unittest.cc</a>](..<a href="/googletest/s?path=/samples/sample5_unittest.cc&amp;project=googletest">/samples/sample5_unittest.cc</a>).
<a class="l" name="285" href="#285">285</a>
<a class="l" name="286" href="#286">286</a>## My compiler complains "void value not ignored as it ought to be." What does this mean?
<a class="l" name="287" href="#287">287</a>
<a class="l" name="288" href="#288">288</a>You're probably using an `ASSERT_*()` in a function that doesn't return `void`.
<a class="l" name="289" href="#289">289</a>`ASSERT_*()` can only be used in `void` functions, due to exceptions being
<a class="hl" name="290" href="#290">290</a>disabled by our build system. Please see more details
<a class="l" name="291" href="#291">291</a>[here](<a href="/googletest/s?path=advanced.md&amp;project=googletest">advanced.md</a>#assertion-placement).
<a class="l" name="292" href="#292">292</a>
<a class="l" name="293" href="#293">293</a>## My death test hangs (or seg-faults). How do I fix it?
<a class="l" name="294" href="#294">294</a>
<a class="l" name="295" href="#295">295</a>In googletest, death tests are run in a child process and the way they work is
<a class="l" name="296" href="#296">296</a>delicate. To write death tests you really need to understand how they work.
<a class="l" name="297" href="#297">297</a>Please make sure you have read [this](<a href="/googletest/s?path=advanced.md&amp;project=googletest">advanced.md</a>#how-it-works).
<a class="l" name="298" href="#298">298</a>
<a class="l" name="299" href="#299">299</a>In particular, death tests don't like having multiple threads in the parent
<a class="hl" name="300" href="#300">300</a>process. So the first thing you can try is to eliminate creating threads outside
<a class="l" name="301" href="#301">301</a>of `EXPECT_DEATH()`. For example, you may want to use mocks or fake objects
<a class="l" name="302" href="#302">302</a>instead of real ones in your tests.
<a class="l" name="303" href="#303">303</a>
<a class="l" name="304" href="#304">304</a>Sometimes this is impossible as some library you must use may be creating
<a class="l" name="305" href="#305">305</a>threads before `main()` is even reached. In this case, you can try to minimize
<a class="l" name="306" href="#306">306</a>the chance of conflicts by either moving as many activities as possible inside
<a class="l" name="307" href="#307">307</a>`EXPECT_DEATH()` (in the extreme case, you want to move everything inside), or
<a class="l" name="308" href="#308">308</a>leaving as few things as possible in it. Also, you can try to set the death test
<a class="l" name="309" href="#309">309</a>style to `"threadsafe"`, which is safer but slower, and see if it helps.
<a class="hl" name="310" href="#310">310</a>
<a class="l" name="311" href="#311">311</a>If you go with thread-safe death tests, remember that they rerun the test
<a class="l" name="312" href="#312">312</a>program from the beginning in the child process. Therefore make sure your
<a class="l" name="313" href="#313">313</a>program can run side-by-side with itself and is deterministic.
<a class="l" name="314" href="#314">314</a>
<a class="l" name="315" href="#315">315</a>In the end, this boils down to good concurrent programming. You have to make
<a class="l" name="316" href="#316">316</a>sure that there are no race conditions or deadlocks in your program. No silver
<a class="l" name="317" href="#317">317</a>bullet - sorry!
<a class="l" name="318" href="#318">318</a>
<a class="l" name="319" href="#319">319</a>## Should I use the <a href="/googletest/s?path=constructor/destructor&amp;project=googletest">constructor/destructor</a> of the test fixture or SetUp()/TearDown()? {#CtorVsSetUp}
<a class="hl" name="320" href="#320">320</a>
<a class="l" name="321" href="#321">321</a>The first thing to remember is that googletest does **not** reuse the same test
<a class="l" name="322" href="#322">322</a>fixture object across multiple tests. For each `TEST_F`, googletest will create
<a class="l" name="323" href="#323">323</a>a **fresh** test fixture object, immediately call `SetUp()`, run the test body,
<a class="l" name="324" href="#324">324</a>call `TearDown()`, and then delete the test fixture object.
<a class="l" name="325" href="#325">325</a>
<a class="l" name="326" href="#326">326</a>When you need to write per-test set-up and tear-down logic, you have the choice
<a class="l" name="327" href="#327">327</a>between using the test fixture <a href="/googletest/s?path=constructor/destructor&amp;project=googletest">constructor/destructor</a> or `SetUp()/TearDown()`.
<a class="l" name="328" href="#328">328</a>The former is usually preferred, as it has the following benefits:
<a class="l" name="329" href="#329">329</a>
<a class="hl" name="330" href="#330">330</a>*   By initializing a member variable in the constructor, we have the option to
<a class="l" name="331" href="#331">331</a>    make it `const`, which helps prevent accidental changes to its value and
<a class="l" name="332" href="#332">332</a>    makes the tests more obviously correct.
<a class="l" name="333" href="#333">333</a>*   In case we need to subclass the test fixture class, the subclass'
<a class="l" name="334" href="#334">334</a>    constructor is guaranteed to call the base class' constructor *first*, and
<a class="l" name="335" href="#335">335</a>    the subclass' destructor is guaranteed to call the base class' destructor
<a class="l" name="336" href="#336">336</a>    *afterward*. With `SetUp()/TearDown()`, a subclass may make the mistake of
<a class="l" name="337" href="#337">337</a>    forgetting to call the base class' `SetUp()/TearDown()` or call them at the
<a class="l" name="338" href="#338">338</a>    wrong time.
<a class="l" name="339" href="#339">339</a>
<a class="hl" name="340" href="#340">340</a>You may still want to use `SetUp()/TearDown()` in the following cases:
<a class="l" name="341" href="#341">341</a>
<a class="l" name="342" href="#342">342</a>*   C++ does not allow virtual function calls in constructors and destructors.
<a class="l" name="343" href="#343">343</a>    You can call a method declared as virtual, but it will not use dynamic
<a class="l" name="344" href="#344">344</a>    dispatch, it will use the definition from the class the constructor of which
<a class="l" name="345" href="#345">345</a>    is currently executing. This is because calling a virtual method before the
<a class="l" name="346" href="#346">346</a>    derived class constructor has a chance to run is very dangerous - the
<a class="l" name="347" href="#347">347</a>    virtual method might operate on uninitialized data. Therefore, if you need
<a class="l" name="348" href="#348">348</a>    to call a method that will be overridden in a derived class, you have to use
<a class="l" name="349" href="#349">349</a>    `SetUp()/TearDown()`.
<a class="hl" name="350" href="#350">350</a>*   In the body of a constructor (or destructor), it's not possible to use the
<a class="l" name="351" href="#351">351</a>    `ASSERT_xx` macros. Therefore, if the set-up operation could cause a fatal
<a class="l" name="352" href="#352">352</a>    test failure that should prevent the test from running, it's necessary to
<a class="l" name="353" href="#353">353</a>    use `abort` &lt;!-- GOOGLETEST_CM0015 DO NOT DELETE --&gt; and abort the whole test executable,
<a class="l" name="354" href="#354">354</a>    or to use `SetUp()` instead of a constructor.
<a class="l" name="355" href="#355">355</a>*   If the tear-down operation could throw an exception, you must use
<a class="l" name="356" href="#356">356</a>    `TearDown()` as opposed to the destructor, as throwing in a destructor leads
<a class="l" name="357" href="#357">357</a>    to undefined behavior and usually will kill your program right away. Note
<a class="l" name="358" href="#358">358</a>    that many standard libraries (like STL) may throw when exceptions are
<a class="l" name="359" href="#359">359</a>    enabled in the compiler. Therefore you should prefer `TearDown()` if you
<a class="hl" name="360" href="#360">360</a>    want to write portable tests that work with or without exceptions.
<a class="l" name="361" href="#361">361</a>*   The googletest team is considering making the assertion macros throw on
<a class="l" name="362" href="#362">362</a>    platforms where exceptions are enabled (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> Windows, Mac OS, and Linux
<a class="l" name="363" href="#363">363</a>    client-side), which will eliminate the need for the user to propagate
<a class="l" name="364" href="#364">364</a>    failures from a subroutine to its caller. Therefore, you shouldn't use
<a class="l" name="365" href="#365">365</a>    googletest assertions in a destructor if your code could run on such a
<a class="l" name="366" href="#366">366</a>    platform.
<a class="l" name="367" href="#367">367</a>
<a class="l" name="368" href="#368">368</a>## The compiler complains "no matching function to call" when I use ASSERT_PRED*. How do I fix it?
<a class="l" name="369" href="#369">369</a>
<a class="hl" name="370" href="#370">370</a>If the predicate function you use in `ASSERT_PRED*` or `EXPECT_PRED*` is
<a class="l" name="371" href="#371">371</a>overloaded or a template, the compiler will have trouble figuring out which
<a class="l" name="372" href="#372">372</a>overloaded version it should use. `ASSERT_PRED_FORMAT*` and
<a class="l" name="373" href="#373">373</a>`EXPECT_PRED_FORMAT*` don't have this problem.
<a class="l" name="374" href="#374">374</a>
<a class="l" name="375" href="#375">375</a>If you see this error, you might want to switch to
<a class="l" name="376" href="#376">376</a>`(ASSERT|EXPECT)_PRED_FORMAT*`, which will also give you a better failure
<a class="l" name="377" href="#377">377</a>message. If, however, that is not an option, you can resolve the problem by
<a class="l" name="378" href="#378">378</a>explicitly telling the compiler which version to pick.
<a class="l" name="379" href="#379">379</a>
<a class="hl" name="380" href="#380">380</a>For example, suppose you have
<a class="l" name="381" href="#381">381</a>
<a class="l" name="382" href="#382">382</a>```c++
<a class="l" name="383" href="#383">383</a>bool IsPositive(int n) {
<a class="l" name="384" href="#384">384</a>  return n &gt; 0;
<a class="l" name="385" href="#385">385</a>}
<a class="l" name="386" href="#386">386</a>
<a class="l" name="387" href="#387">387</a>bool IsPositive(double x) {
<a class="l" name="388" href="#388">388</a>  return x &gt; 0;
<a class="l" name="389" href="#389">389</a>}
<a class="hl" name="390" href="#390">390</a>```
<a class="l" name="391" href="#391">391</a>
<a class="l" name="392" href="#392">392</a>you will get a compiler error if you write
<a class="l" name="393" href="#393">393</a>
<a class="l" name="394" href="#394">394</a>```c++
<a class="l" name="395" href="#395">395</a>EXPECT_PRED1(IsPositive, 5);
<a class="l" name="396" href="#396">396</a>```
<a class="l" name="397" href="#397">397</a>
<a class="l" name="398" href="#398">398</a>However, this will work:
<a class="l" name="399" href="#399">399</a>
<a class="hl" name="400" href="#400">400</a>```c++
<a class="l" name="401" href="#401">401</a>EXPECT_PRED1(static_cast&lt;bool (*)(int)&gt;(IsPositive), 5);
<a class="l" name="402" href="#402">402</a>```
<a class="l" name="403" href="#403">403</a>
<a class="l" name="404" href="#404">404</a>(The stuff inside the angled brackets for the `static_cast` operator is the type
<a class="l" name="405" href="#405">405</a>of the function pointer for the `int`-version of `IsPositive()`.)
<a class="l" name="406" href="#406">406</a>
<a class="l" name="407" href="#407">407</a>As another example, when you have a template function
<a class="l" name="408" href="#408">408</a>
<a class="l" name="409" href="#409">409</a>```c++
<a class="hl" name="410" href="#410">410</a>template &lt;typename T&gt;
<a class="l" name="411" href="#411">411</a>bool IsNegative(T x) {
<a class="l" name="412" href="#412">412</a>  return x &lt; 0;
<a class="l" name="413" href="#413">413</a>}
<a class="l" name="414" href="#414">414</a>```
<a class="l" name="415" href="#415">415</a>
<a class="l" name="416" href="#416">416</a>you can use it in a predicate assertion like this:
<a class="l" name="417" href="#417">417</a>
<a class="l" name="418" href="#418">418</a>```c++
<a class="l" name="419" href="#419">419</a>ASSERT_PRED1(IsNegative&lt;int&gt;, -5);
<a class="hl" name="420" href="#420">420</a>```
<a class="l" name="421" href="#421">421</a>
<a class="l" name="422" href="#422">422</a>Things are more interesting if your template has more than one parameter. The
<a class="l" name="423" href="#423">423</a>following won't compile:
<a class="l" name="424" href="#424">424</a>
<a class="l" name="425" href="#425">425</a>```c++
<a class="l" name="426" href="#426">426</a>ASSERT_PRED2(GreaterThan&lt;int, int&gt;, 5, 0);
<a class="l" name="427" href="#427">427</a>```
<a class="l" name="428" href="#428">428</a>
<a class="l" name="429" href="#429">429</a>as the C++ pre-processor thinks you are giving `ASSERT_PRED2` 4 arguments, which
<a class="hl" name="430" href="#430">430</a>is one more than expected. The workaround is to wrap the predicate function in
<a class="l" name="431" href="#431">431</a>parentheses:
<a class="l" name="432" href="#432">432</a>
<a class="l" name="433" href="#433">433</a>```c++
<a class="l" name="434" href="#434">434</a>ASSERT_PRED2((GreaterThan&lt;int, int&gt;), 5, 0);
<a class="l" name="435" href="#435">435</a>```
<a class="l" name="436" href="#436">436</a>
<a class="l" name="437" href="#437">437</a>## My compiler complains about "ignoring return value" when I call RUN_ALL_TESTS(). Why?
<a class="l" name="438" href="#438">438</a>
<a class="l" name="439" href="#439">439</a>Some people had been ignoring the return value of `RUN_ALL_TESTS()`. That is,
<a class="hl" name="440" href="#440">440</a>instead of
<a class="l" name="441" href="#441">441</a>
<a class="l" name="442" href="#442">442</a>```c++
<a class="l" name="443" href="#443">443</a>  return RUN_ALL_TESTS();
<a class="l" name="444" href="#444">444</a>```
<a class="l" name="445" href="#445">445</a>
<a class="l" name="446" href="#446">446</a>they write
<a class="l" name="447" href="#447">447</a>
<a class="l" name="448" href="#448">448</a>```c++
<a class="l" name="449" href="#449">449</a>  RUN_ALL_TESTS();
<a class="hl" name="450" href="#450">450</a>```
<a class="l" name="451" href="#451">451</a>
<a class="l" name="452" href="#452">452</a>This is **wrong and dangerous**. The testing services needs to see the return
<a class="l" name="453" href="#453">453</a>value of `RUN_ALL_TESTS()` in order to determine if a test has passed. If your
<a class="l" name="454" href="#454">454</a>`main()` function ignores it, your test will be considered successful even if it
<a class="l" name="455" href="#455">455</a>has a googletest assertion failure. Very bad.
<a class="l" name="456" href="#456">456</a>
<a class="l" name="457" href="#457">457</a>We have decided to fix this (thanks to Michael Chastain for the idea). Now, your
<a class="l" name="458" href="#458">458</a>code will no longer be able to ignore `RUN_ALL_TESTS()` when compiled with
<a class="l" name="459" href="#459">459</a>`gcc`. If you do so, you'll get a compiler error.
<a class="hl" name="460" href="#460">460</a>
<a class="l" name="461" href="#461">461</a>If you see the compiler complaining about you ignoring the return value of
<a class="l" name="462" href="#462">462</a>`RUN_ALL_TESTS()`, the fix is simple: just make sure its value is used as the
<a class="l" name="463" href="#463">463</a>return value of `main()`.
<a class="l" name="464" href="#464">464</a>
<a class="l" name="465" href="#465">465</a>But how could we introduce a change that breaks existing tests? Well, in this
<a class="l" name="466" href="#466">466</a>case, the code was already broken in the first place, so we didn't break it. :-)
<a class="l" name="467" href="#467">467</a>
<a class="l" name="468" href="#468">468</a>## My compiler complains that a constructor (or destructor) cannot return a value. What's going on?
<a class="l" name="469" href="#469">469</a>
<a class="hl" name="470" href="#470">470</a>Due to a peculiarity of C++, in order to support the syntax for streaming
<a class="l" name="471" href="#471">471</a>messages to an `ASSERT_*`, <a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="l" name="472" href="#472">472</a>
<a class="l" name="473" href="#473">473</a>```c++
<a class="l" name="474" href="#474">474</a>  ASSERT_EQ(1, Foo()) &lt;&lt; "blah blah" &lt;&lt; foo;
<a class="l" name="475" href="#475">475</a>```
<a class="l" name="476" href="#476">476</a>
<a class="l" name="477" href="#477">477</a>we had to give up using `ASSERT*` and `FAIL*` (but not `EXPECT*` and
<a class="l" name="478" href="#478">478</a>`ADD_FAILURE*`) in constructors and destructors. The workaround is to move the
<a class="l" name="479" href="#479">479</a>content of your <a href="/googletest/s?path=constructor/destructor&amp;project=googletest">constructor/destructor</a> to a private void member function, or
<a class="hl" name="480" href="#480">480</a>switch to `EXPECT_*()` if that works. This
<a class="l" name="481" href="#481">481</a>[section](<a href="/googletest/s?path=advanced.md&amp;project=googletest">advanced.md</a>#assertion-placement) in the user's guide explains it.
<a class="l" name="482" href="#482">482</a>
<a class="l" name="483" href="#483">483</a>## My SetUp() function is not called. Why?
<a class="l" name="484" href="#484">484</a>
<a class="l" name="485" href="#485">485</a>C++ is case-sensitive. Did you spell it as `Setup()`?
<a class="l" name="486" href="#486">486</a>
<a class="l" name="487" href="#487">487</a>Similarly, sometimes people spell `SetUpTestSuite()` as `SetupTestSuite()` and
<a class="l" name="488" href="#488">488</a>wonder why it's never called.
<a class="l" name="489" href="#489">489</a>
<a class="hl" name="490" href="#490">490</a>
<a class="l" name="491" href="#491">491</a>## I have several test suites which share the same test fixture logic, do I have to define a new test fixture class for each of them? This seems pretty tedious.
<a class="l" name="492" href="#492">492</a>
<a class="l" name="493" href="#493">493</a>You don't have to. Instead of
<a class="l" name="494" href="#494">494</a>
<a class="l" name="495" href="#495">495</a>```c++
<a class="l" name="496" href="#496">496</a>class FooTest : public BaseTest {};
<a class="l" name="497" href="#497">497</a>
<a class="l" name="498" href="#498">498</a>TEST_F(FooTest, Abc) { ... }
<a class="l" name="499" href="#499">499</a>TEST_F(FooTest, Def) { ... }
<a class="hl" name="500" href="#500">500</a>
<a class="l" name="501" href="#501">501</a>class BarTest : public BaseTest {};
<a class="l" name="502" href="#502">502</a>
<a class="l" name="503" href="#503">503</a>TEST_F(BarTest, Abc) { ... }
<a class="l" name="504" href="#504">504</a>TEST_F(BarTest, Def) { ... }
<a class="l" name="505" href="#505">505</a>```
<a class="l" name="506" href="#506">506</a>
<a class="l" name="507" href="#507">507</a>you can simply `typedef` the test fixtures:
<a class="l" name="508" href="#508">508</a>
<a class="l" name="509" href="#509">509</a>```c++
<a class="hl" name="510" href="#510">510</a>typedef BaseTest FooTest;
<a class="l" name="511" href="#511">511</a>
<a class="l" name="512" href="#512">512</a>TEST_F(FooTest, Abc) { ... }
<a class="l" name="513" href="#513">513</a>TEST_F(FooTest, Def) { ... }
<a class="l" name="514" href="#514">514</a>
<a class="l" name="515" href="#515">515</a>typedef BaseTest BarTest;
<a class="l" name="516" href="#516">516</a>
<a class="l" name="517" href="#517">517</a>TEST_F(BarTest, Abc) { ... }
<a class="l" name="518" href="#518">518</a>TEST_F(BarTest, Def) { ... }
<a class="l" name="519" href="#519">519</a>```
<a class="hl" name="520" href="#520">520</a>
<a class="l" name="521" href="#521">521</a>## googletest output is buried in a whole bunch of LOG messages. What do I do?
<a class="l" name="522" href="#522">522</a>
<a class="l" name="523" href="#523">523</a>The googletest output is meant to be a concise and human-friendly report. If
<a class="l" name="524" href="#524">524</a>your test generates textual output itself, it will mix with the googletest
<a class="l" name="525" href="#525">525</a>output, making it hard to read. However, there is an easy solution to this
<a class="l" name="526" href="#526">526</a>problem.
<a class="l" name="527" href="#527">527</a>
<a class="l" name="528" href="#528">528</a>Since `LOG` messages go to stderr, we decided to let googletest output go to
<a class="l" name="529" href="#529">529</a>stdout. This way, you can easily separate the two using redirection. For
<a class="hl" name="530" href="#530">530</a>example:
<a class="l" name="531" href="#531">531</a>
<a class="l" name="532" href="#532">532</a>```shell
<a class="l" name="533" href="#533">533</a>$ ./my_test &gt; <a href="/googletest/s?path=gtest_output.txt&amp;project=googletest">gtest_output.txt</a>
<a class="l" name="534" href="#534">534</a>```
<a class="l" name="535" href="#535">535</a>
<a class="l" name="536" href="#536">536</a>## Why should I prefer test fixtures over global variables?
<a class="l" name="537" href="#537">537</a>
<a class="l" name="538" href="#538">538</a>There are several good reasons:
<a class="l" name="539" href="#539">539</a>
<a class="hl" name="540" href="#540">540</a>1.  It's likely your test needs to change the states of its global variables.
<a class="l" name="541" href="#541">541</a>    This makes it difficult to keep side effects from escaping one test and
<a class="l" name="542" href="#542">542</a>    contaminating others, making debugging difficult. By using fixtures, each
<a class="l" name="543" href="#543">543</a>    test has a fresh set of variables that's different (but with the same
<a class="l" name="544" href="#544">544</a>    names). Thus, tests are kept independent of each other.
<a class="l" name="545" href="#545">545</a>2.  Global variables pollute the global namespace.
<a class="l" name="546" href="#546">546</a>3.  Test fixtures can be reused via subclassing, which cannot be done easily
<a class="l" name="547" href="#547">547</a>    with global variables. This is useful if many test suites have something in
<a class="l" name="548" href="#548">548</a>    common.
<a class="l" name="549" href="#549">549</a>
<a class="hl" name="550" href="#550">550</a>## What can the statement argument in ASSERT_DEATH() be?
<a class="l" name="551" href="#551">551</a>
<a class="l" name="552" href="#552">552</a>`ASSERT_DEATH(statement, matcher)` (or any death assertion macro) can be used
<a class="l" name="553" href="#553">553</a>wherever *`statement`* is valid. So basically *`statement`* can be any C++
<a class="l" name="554" href="#554">554</a>statement that makes sense in the current context. In particular, it can
<a class="l" name="555" href="#555">555</a>reference global <a href="/googletest/s?path=and/or&amp;project=googletest">and/or</a> local variables, and can be:
<a class="l" name="556" href="#556">556</a>
<a class="l" name="557" href="#557">557</a>*   a simple function call (often the case),
<a class="l" name="558" href="#558">558</a>*   a complex expression, or
<a class="l" name="559" href="#559">559</a>*   a compound statement.
<a class="hl" name="560" href="#560">560</a>
<a class="l" name="561" href="#561">561</a>Some examples are shown here:
<a class="l" name="562" href="#562">562</a>
<a class="l" name="563" href="#563">563</a>```c++
<a class="l" name="564" href="#564">564</a>// A death test can be a simple function call.
<a class="l" name="565" href="#565">565</a>TEST(MyDeathTest, FunctionCall) {
<a class="l" name="566" href="#566">566</a>  ASSERT_DEATH(Xyz(5), "Xyz failed");
<a class="l" name="567" href="#567">567</a>}
<a class="l" name="568" href="#568">568</a>
<a class="l" name="569" href="#569">569</a>// Or a complex expression that references variables and functions.
<a class="hl" name="570" href="#570">570</a>TEST(MyDeathTest, ComplexExpression) {
<a class="l" name="571" href="#571">571</a>  const bool c = Condition();
<a class="l" name="572" href="#572">572</a>  ASSERT_DEATH((c ? Func1(0) : <a href="/googletest/s?path=object2.Method&amp;project=googletest">object2.Method</a>("test")),
<a class="l" name="573" href="#573">573</a>               "(Func1|Method) failed");
<a class="l" name="574" href="#574">574</a>}
<a class="l" name="575" href="#575">575</a>
<a class="l" name="576" href="#576">576</a>// Death assertions can be used anywhere in a function.  In
<a class="l" name="577" href="#577">577</a>// particular, they can be inside a loop.
<a class="l" name="578" href="#578">578</a>TEST(MyDeathTest, InsideLoop) {
<a class="l" name="579" href="#579">579</a>  // Verifies that Foo(0), Foo(1), ..., and Foo(4) all die.
<a class="hl" name="580" href="#580">580</a>  for (int i = 0; i &lt; 5; i++) {
<a class="l" name="581" href="#581">581</a>    EXPECT_DEATH_M(Foo(i), "Foo has \\d+ errors",
<a class="l" name="582" href="#582">582</a>                   ::testing::Message() &lt;&lt; "where i is " &lt;&lt; i);
<a class="l" name="583" href="#583">583</a>  }
<a class="l" name="584" href="#584">584</a>}
<a class="l" name="585" href="#585">585</a>
<a class="l" name="586" href="#586">586</a>// A death assertion can contain a compound statement.
<a class="l" name="587" href="#587">587</a>TEST(MyDeathTest, CompoundStatement) {
<a class="l" name="588" href="#588">588</a>  // Verifies that at lease one of Bar(0), Bar(1), ..., and
<a class="l" name="589" href="#589">589</a>  // Bar(4) dies.
<a class="hl" name="590" href="#590">590</a>  ASSERT_DEATH({
<a class="l" name="591" href="#591">591</a>    for (int i = 0; i &lt; 5; i++) {
<a class="l" name="592" href="#592">592</a>      Bar(i);
<a class="l" name="593" href="#593">593</a>    }
<a class="l" name="594" href="#594">594</a>  },
<a class="l" name="595" href="#595">595</a>  "Bar has \\d+ errors");
<a class="l" name="596" href="#596">596</a>}
<a class="l" name="597" href="#597">597</a>```
<a class="l" name="598" href="#598">598</a>
<a class="l" name="599" href="#599">599</a><a href="/googletest/s?path=gtest-death-test_test.cc&amp;project=googletest">gtest-death-test_test.cc</a> contains more examples if you are interested.
<a class="hl" name="600" href="#600">600</a>
<a class="l" name="601" href="#601">601</a>## I have a fixture class `FooTest`, but `TEST_F(FooTest, Bar)` gives me error ``"no matching function for call to `FooTest::FooTest()'"``. Why?
<a class="l" name="602" href="#602">602</a>
<a class="l" name="603" href="#603">603</a>Googletest needs to be able to create objects of your test fixture class, so it
<a class="l" name="604" href="#604">604</a>must have a default constructor. Normally the compiler will define one for you.
<a class="l" name="605" href="#605">605</a>However, there are cases where you have to define your own:
<a class="l" name="606" href="#606">606</a>
<a class="l" name="607" href="#607">607</a>*   If you explicitly declare a non-default constructor for class `FooTest`
<a class="l" name="608" href="#608">608</a>    (`DISALLOW_EVIL_CONSTRUCTORS()` does this), then you need to define a
<a class="l" name="609" href="#609">609</a>    default constructor, even if it would be empty.
<a class="hl" name="610" href="#610">610</a>*   If `FooTest` has a const non-static data member, then you have to define the
<a class="l" name="611" href="#611">611</a>    default constructor *and* initialize the const member in the initializer
<a class="l" name="612" href="#612">612</a>    list of the constructor. (Early versions of `gcc` doesn't force you to
<a class="l" name="613" href="#613">613</a>    initialize the const member. It's a bug that has been fixed in `gcc 4`.)
<a class="l" name="614" href="#614">614</a>
<a class="l" name="615" href="#615">615</a>## Why does ASSERT_DEATH complain about previous threads that were already joined?
<a class="l" name="616" href="#616">616</a>
<a class="l" name="617" href="#617">617</a>With the Linux pthread library, there is no turning back once you cross the line
<a class="l" name="618" href="#618">618</a>from a single thread to multiple threads. The first time you create a thread, a
<a class="l" name="619" href="#619">619</a>manager thread is created in addition, so you get 3, not 2, threads. Later when
<a class="hl" name="620" href="#620">620</a>the thread you create joins the main thread, the thread count decrements by 1,
<a class="l" name="621" href="#621">621</a>but the manager thread will never be killed, so you still have 2 threads, which
<a class="l" name="622" href="#622">622</a>means you cannot safely run a death test.
<a class="l" name="623" href="#623">623</a>
<a class="l" name="624" href="#624">624</a>The new NPTL thread library doesn't suffer from this problem, as it doesn't
<a class="l" name="625" href="#625">625</a>create a manager thread. However, if you don't control which machine your test
<a class="l" name="626" href="#626">626</a>runs on, you shouldn't depend on this.
<a class="l" name="627" href="#627">627</a>
<a class="l" name="628" href="#628">628</a>## Why does googletest require the entire test suite, instead of individual tests, to be named *DeathTest when it uses ASSERT_DEATH?
<a class="l" name="629" href="#629">629</a>
<a class="hl" name="630" href="#630">630</a>googletest does not interleave tests from different test suites. That is, it
<a class="l" name="631" href="#631">631</a>runs all tests in one test suite first, and then runs all tests in the next test
<a class="l" name="632" href="#632">632</a>suite, and so on. googletest does this because it needs to set up a test suite
<a class="l" name="633" href="#633">633</a>before the first test in it is run, and tear it down afterwards. Splitting up
<a class="l" name="634" href="#634">634</a>the test case would require multiple set-up and tear-down processes, which is
<a class="l" name="635" href="#635">635</a>inefficient and makes the semantics unclean.
<a class="l" name="636" href="#636">636</a>
<a class="l" name="637" href="#637">637</a>If we were to determine the order of tests based on test name instead of test
<a class="l" name="638" href="#638">638</a>case name, then we would have a problem with the following situation:
<a class="l" name="639" href="#639">639</a>
<a class="hl" name="640" href="#640">640</a>```c++
<a class="l" name="641" href="#641">641</a>TEST_F(FooTest, AbcDeathTest) { ... }
<a class="l" name="642" href="#642">642</a>TEST_F(FooTest, Uvw) { ... }
<a class="l" name="643" href="#643">643</a>
<a class="l" name="644" href="#644">644</a>TEST_F(BarTest, DefDeathTest) { ... }
<a class="l" name="645" href="#645">645</a>TEST_F(BarTest, Xyz) { ... }
<a class="l" name="646" href="#646">646</a>```
<a class="l" name="647" href="#647">647</a>
<a class="l" name="648" href="#648">648</a>Since `<a href="/googletest/s?path=FooTest.AbcDeathTest&amp;project=googletest">FooTest.AbcDeathTest</a>` needs to run before `<a href="/googletest/s?path=BarTest.Xyz&amp;project=googletest">BarTest.Xyz</a>`, and we don't
<a class="l" name="649" href="#649">649</a>interleave tests from different test suites, we need to run all tests in the
<a class="hl" name="650" href="#650">650</a>`FooTest` case before running any test in the `BarTest` case. This contradicts
<a class="l" name="651" href="#651">651</a>with the requirement to run `<a href="/googletest/s?path=BarTest.DefDeathTest&amp;project=googletest">BarTest.DefDeathTest</a>` before `<a href="/googletest/s?path=FooTest.Uvw&amp;project=googletest">FooTest.Uvw</a>`.
<a class="l" name="652" href="#652">652</a>
<a class="l" name="653" href="#653">653</a>## But I don't like calling my entire test suite \*DeathTest when it contains both death tests and non-death tests. What do I do?
<a class="l" name="654" href="#654">654</a>
<a class="l" name="655" href="#655">655</a>You don't have to, but if you like, you may split up the test suite into
<a class="l" name="656" href="#656">656</a>`FooTest` and `FooDeathTest`, where the names make it clear that they are
<a class="l" name="657" href="#657">657</a>related:
<a class="l" name="658" href="#658">658</a>
<a class="l" name="659" href="#659">659</a>```c++
<a class="hl" name="660" href="#660">660</a>class FooTest : public ::testing::Test { ... };
<a class="l" name="661" href="#661">661</a>
<a class="l" name="662" href="#662">662</a>TEST_F(FooTest, Abc) { ... }
<a class="l" name="663" href="#663">663</a>TEST_F(FooTest, Def) { ... }
<a class="l" name="664" href="#664">664</a>
<a class="l" name="665" href="#665">665</a>using FooDeathTest = FooTest;
<a class="l" name="666" href="#666">666</a>
<a class="l" name="667" href="#667">667</a>TEST_F(FooDeathTest, Uvw) { ... EXPECT_DEATH(...) ... }
<a class="l" name="668" href="#668">668</a>TEST_F(FooDeathTest, Xyz) { ... ASSERT_DEATH(...) ... }
<a class="l" name="669" href="#669">669</a>```
<a class="hl" name="670" href="#670">670</a>
<a class="l" name="671" href="#671">671</a>## googletest prints the LOG messages in a death test's child process only when the test fails. How can I see the LOG messages when the death test succeeds?
<a class="l" name="672" href="#672">672</a>
<a class="l" name="673" href="#673">673</a>Printing the LOG messages generated by the statement inside `EXPECT_DEATH()`
<a class="l" name="674" href="#674">674</a>makes it harder to search for real problems in the parent's log. Therefore,
<a class="l" name="675" href="#675">675</a>googletest only prints them when the death test has failed.
<a class="l" name="676" href="#676">676</a>
<a class="l" name="677" href="#677">677</a>If you really need to see such LOG messages, a workaround is to temporarily
<a class="l" name="678" href="#678">678</a>break the death test (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> by changing the regex pattern it is expected to
<a class="l" name="679" href="#679">679</a>match). Admittedly, this is a hack. We'll consider a more permanent solution
<a class="hl" name="680" href="#680">680</a>after the fork-and-exec-style death tests are implemented.
<a class="l" name="681" href="#681">681</a>
<a class="l" name="682" href="#682">682</a>## The compiler complains about "no match for 'operator&lt;&lt;'" when I use an assertion. What gives?
<a class="l" name="683" href="#683">683</a>
<a class="l" name="684" href="#684">684</a>If you use a user-defined type `FooType` in an assertion, you must make sure
<a class="l" name="685" href="#685">685</a>there is an `std::ostream&amp; operator&lt;&lt;(std::ostream&amp;, const FooType&amp;)` function
<a class="l" name="686" href="#686">686</a>defined such that we can print a value of `FooType`.
<a class="l" name="687" href="#687">687</a>
<a class="l" name="688" href="#688">688</a>In addition, if `FooType` is declared in a name space, the `&lt;&lt;` operator also
<a class="l" name="689" href="#689">689</a>needs to be defined in the *same* name space. See <a href="https://abseil.io/tips/49">https://abseil.io/tips/49</a> for details.
<a class="hl" name="690" href="#690">690</a>
<a class="l" name="691" href="#691">691</a>## How do I suppress the memory leak messages on Windows?
<a class="l" name="692" href="#692">692</a>
<a class="l" name="693" href="#693">693</a>Since the statically initialized googletest singleton requires allocations on
<a class="l" name="694" href="#694">694</a>the heap, the Visual C++ memory leak detector will report memory leaks at the
<a class="l" name="695" href="#695">695</a>end of the program run. The easiest way to avoid this is to use the
<a class="l" name="696" href="#696">696</a>`_CrtMemCheckpoint` and `_CrtMemDumpAllObjectsSince` calls to not report any
<a class="l" name="697" href="#697">697</a>statically initialized heap objects. See MSDN for more details and additional
<a class="l" name="698" href="#698">698</a>heap <a href="/googletest/s?path=check/debug&amp;project=googletest">check/debug</a> routines.
<a class="l" name="699" href="#699">699</a>
<a class="hl" name="700" href="#700">700</a>## How can my code detect if it is running in a test?
<a class="l" name="701" href="#701">701</a>
<a class="l" name="702" href="#702">702</a>If you write code that sniffs whether it's running in a test and does different
<a class="l" name="703" href="#703">703</a>things accordingly, you are leaking test-only logic into production code and
<a class="l" name="704" href="#704">704</a>there is no easy way to ensure that the test-only code paths aren't run by
<a class="l" name="705" href="#705">705</a>mistake in production. Such cleverness also leads to
<a class="l" name="706" href="#706">706</a>[Heisenbugs](<a href="https://en.wikipedia.org/wiki/Heisenbug">https://en.wikipedia.org/wiki/Heisenbug</a>). Therefore we strongly
<a class="l" name="707" href="#707">707</a>advise against the practice, and googletest doesn't provide a way to do it.
<a class="l" name="708" href="#708">708</a>
<a class="l" name="709" href="#709">709</a>In general, the recommended way to cause the code to behave differently under
<a class="hl" name="710" href="#710">710</a>test is [Dependency Injection](<a href="https://en.wikipedia.org/wiki/Dependency_injection">https://en.wikipedia.org/wiki/Dependency_injection</a>). You can inject
<a class="l" name="711" href="#711">711</a>different functionality from the test and from the production code. Since your
<a class="l" name="712" href="#712">712</a>production code doesn't link in the for-test logic at all (the
<a class="l" name="713" href="#713">713</a>[`testonly`](<a href="https://docs.bazel.build/versions/master/be/common-definitions.html">https://docs.bazel.build/versions/master/be/common-definitions.html</a>#<a href="/googletest/s?path=common.testonly&amp;project=googletest">common.testonly</a>) attribute for BUILD targets helps to ensure
<a class="l" name="714" href="#714">714</a>that), there is no danger in accidentally running it.
<a class="l" name="715" href="#715">715</a>
<a class="l" name="716" href="#716">716</a>However, if you *really*, *really*, *really* have no choice, and if you follow
<a class="l" name="717" href="#717">717</a>the rule of ending your test program names with `_test`, you can use the
<a class="l" name="718" href="#718">718</a>*horrible* hack of sniffing your executable name (`argv[0]` in `main()`) to know
<a class="l" name="719" href="#719">719</a>whether the code is under test.
<a class="hl" name="720" href="#720">720</a>
<a class="l" name="721" href="#721">721</a>## How do I temporarily disable a test?
<a class="l" name="722" href="#722">722</a>
<a class="l" name="723" href="#723">723</a>If you have a broken test that you cannot fix right away, you can add the
<a class="l" name="724" href="#724">724</a>DISABLED_ prefix to its name. This will exclude it from execution. This is
<a class="l" name="725" href="#725">725</a>better than commenting out the code or using #if 0, as disabled tests are still
<a class="l" name="726" href="#726">726</a>compiled (and thus won't rot).
<a class="l" name="727" href="#727">727</a>
<a class="l" name="728" href="#728">728</a>To include disabled tests in test execution, just invoke the test program with
<a class="l" name="729" href="#729">729</a>the --gtest_also_run_disabled_tests flag.
<a class="hl" name="730" href="#730">730</a>
<a class="l" name="731" href="#731">731</a>## Is it OK if I have two separate `TEST(Foo, Bar)` test methods defined in different namespaces?
<a class="l" name="732" href="#732">732</a>
<a class="l" name="733" href="#733">733</a>Yes.
<a class="l" name="734" href="#734">734</a>
<a class="l" name="735" href="#735">735</a>The rule is **all test methods in the same test suite must use the same fixture
<a class="l" name="736" href="#736">736</a>class.** This means that the following is **allowed** because both tests use the
<a class="l" name="737" href="#737">737</a>same fixture class (`::testing::Test`).
<a class="l" name="738" href="#738">738</a>
<a class="l" name="739" href="#739">739</a>```c++
<a class="hl" name="740" href="#740">740</a>namespace foo {
<a class="l" name="741" href="#741">741</a>TEST(CoolTest, DoSomething) {
<a class="l" name="742" href="#742">742</a>  SUCCEED();
<a class="l" name="743" href="#743">743</a>}
<a class="l" name="744" href="#744">744</a>}  // namespace foo
<a class="l" name="745" href="#745">745</a>
<a class="l" name="746" href="#746">746</a>namespace bar {
<a class="l" name="747" href="#747">747</a>TEST(CoolTest, DoSomething) {
<a class="l" name="748" href="#748">748</a>  SUCCEED();
<a class="l" name="749" href="#749">749</a>}
<a class="hl" name="750" href="#750">750</a>}  // namespace bar
<a class="l" name="751" href="#751">751</a>```
<a class="l" name="752" href="#752">752</a>
<a class="l" name="753" href="#753">753</a>However, the following code is **not allowed** and will produce a runtime error
<a class="l" name="754" href="#754">754</a>from googletest because the test methods are using different test fixture
<a class="l" name="755" href="#755">755</a>classes with the same test suite name.
<a class="l" name="756" href="#756">756</a>
<a class="l" name="757" href="#757">757</a>```c++
<a class="l" name="758" href="#758">758</a>namespace foo {
<a class="l" name="759" href="#759">759</a>class CoolTest : public ::testing::Test {};  // Fixture foo::CoolTest
<a class="hl" name="760" href="#760">760</a>TEST_F(CoolTest, DoSomething) {
<a class="l" name="761" href="#761">761</a>  SUCCEED();
<a class="l" name="762" href="#762">762</a>}
<a class="l" name="763" href="#763">763</a>}  // namespace foo
<a class="l" name="764" href="#764">764</a>
<a class="l" name="765" href="#765">765</a>namespace bar {
<a class="l" name="766" href="#766">766</a>class CoolTest : public ::testing::Test {};  // Fixture: bar::CoolTest
<a class="l" name="767" href="#767">767</a>TEST_F(CoolTest, DoSomething) {
<a class="l" name="768" href="#768">768</a>  SUCCEED();
<a class="l" name="769" href="#769">769</a>}
<a class="hl" name="770" href="#770">770</a>}  // namespace bar
<a class="l" name="771" href="#771">771</a>```
<a class="l" name="772" href="#772">772</a>