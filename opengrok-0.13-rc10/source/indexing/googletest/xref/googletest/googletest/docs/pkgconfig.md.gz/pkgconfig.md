<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>## Using GoogleTest from various build systems
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>&lt;!-- GOOGLETEST_CM0035 DO NOT DELETE --&gt;
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>GoogleTest comes with pkg-config files that can be used to determine all
<a class="l" name="6" href="#6">6</a>necessary flags for compiling and linking to GoogleTest (and GoogleMock).
<a class="l" name="7" href="#7">7</a>Pkg-config is a standardised plain-text format containing
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>*   the includedir (-I) path
<a class="hl" name="10" href="#10">10</a>*   necessary macro (-D) definitions
<a class="l" name="11" href="#11">11</a>*   further required flags (-pthread)
<a class="l" name="12" href="#12">12</a>*   the library (-L) path
<a class="l" name="13" href="#13">13</a>*   the library (-l) to link to
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a>All current build systems support pkg-config in one way or another. For all
<a class="l" name="16" href="#16">16</a>examples here we assume you want to compile the sample
<a class="l" name="17" href="#17">17</a>`<a href="/googletest/s?path=samples/sample3_unittest.cc&amp;project=googletest">samples/sample3_unittest.cc</a>`.
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a>### CMake
<a class="hl" name="20" href="#20">20</a>
<a class="l" name="21" href="#21">21</a>Using `pkg-config` in CMake is fairly easy:
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a>```cmake
<a class="l" name="24" href="#24">24</a>cmake_minimum_required(VERSION 3.0)
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a>cmake_policy(SET CMP0048 NEW)
<a class="l" name="27" href="#27">27</a>project(my_gtest_pkgconfig VERSION 0.0.1 LANGUAGES CXX)
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a>find_package(PkgConfig)
<a class="hl" name="30" href="#30">30</a>pkg_search_module(GTEST REQUIRED gtest_main)
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a>add_executable(testapp <a href="/googletest/s?path=samples/sample3_unittest.cc&amp;project=googletest">samples/sample3_unittest.cc</a>)
<a class="l" name="33" href="#33">33</a>target_link_libraries(testapp ${GTEST_LDFLAGS})
<a class="l" name="34" href="#34">34</a>target_compile_options(testapp PUBLIC ${GTEST_CFLAGS})
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a>include(CTest)
<a class="l" name="37" href="#37">37</a>add_test(first_and_only_test testapp)
<a class="l" name="38" href="#38">38</a>```
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a>It is generally recommended that you use `target_compile_options` + `_CFLAGS`
<a class="l" name="41" href="#41">41</a>over `target_include_directories` + `_INCLUDE_DIRS` as the former includes not
<a class="l" name="42" href="#42">42</a>just -I flags (GoogleTest might require a macro indicating to internal headers
<a class="l" name="43" href="#43">43</a>that all libraries have been compiled with threading enabled. In addition,
<a class="l" name="44" href="#44">44</a>GoogleTest might also require `-pthread` in the compiling step, and as such
<a class="l" name="45" href="#45">45</a>splitting the pkg-config `Cflags` variable into include dirs and macros for
<a class="l" name="46" href="#46">46</a>`target_compile_definitions()` might still miss this). The same recommendation
<a class="l" name="47" href="#47">47</a>goes for using `_LDFLAGS` over the more commonplace `_LIBRARIES`, which happens
<a class="l" name="48" href="#48">48</a>to discard `-L` flags and `-pthread`.
<a class="l" name="49" href="#49">49</a>
<a class="hl" name="50" href="#50">50</a>### Help! pkg-config can't find GoogleTest!
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a>Let's say you have a `<a href="/googletest/s?path=CMakeLists.txt&amp;project=googletest">CMakeLists.txt</a>` along the lines of the one in this
<a class="l" name="53" href="#53">53</a>tutorial and you try to run `cmake`. It is very possible that you get a failure
<a class="l" name="54" href="#54">54</a>along the lines of:
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>```
<a class="l" name="57" href="#57">57</a>-- Checking for one of the modules 'gtest_main'
<a class="l" name="58" href="#58">58</a>CMake Error at <a href="/googletest/s?path=/usr/share/cmake/Modules/FindPkgConfig.cmake&amp;project=googletest">/usr/share/cmake/Modules/FindPkgConfig.cmake</a>:640 (message):
<a class="l" name="59" href="#59">59</a>  None of the required 'gtest_main' found
<a class="hl" name="60" href="#60">60</a>```
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>These failures are common if you installed GoogleTest yourself and have not
<a class="l" name="63" href="#63">63</a>sourced it from a distro or other package manager. If so, you need to tell
<a class="l" name="64" href="#64">64</a>pkg-config where it can find the `.pc` files containing the information. Say you
<a class="l" name="65" href="#65">65</a>installed GoogleTest to `<a href="/googletest/s?path=/usr/local&amp;project=googletest">/usr/local</a>`, then it might be that the `.pc` files are
<a class="l" name="66" href="#66">66</a>installed under `<a href="/googletest/s?path=/usr/local/lib64/pkgconfig&amp;project=googletest">/usr/local/lib64/pkgconfig</a>`. If you set
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>```
<a class="l" name="69" href="#69">69</a>export PKG_CONFIG_PATH=<a href="/googletest/s?path=/usr/local/lib64/pkgconfig&amp;project=googletest">/usr/local/lib64/pkgconfig</a>
<a class="hl" name="70" href="#70">70</a>```
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a>pkg-config will also try to look in `PKG_CONFIG_PATH` to find `<a href="/googletest/s?path=gtest_main.pc&amp;project=googletest">gtest_main.pc</a>`.
<a class="l" name="73" href="#73">73</a>
<a class="l" name="74" href="#74">74</a>### Using pkg-config in a cross-compilation setting
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a>Pkg-config can be used in a cross-compilation setting too. To do this, let's
<a class="l" name="77" href="#77">77</a>assume the final prefix of the cross-compiled installation will be `/usr`, and
<a class="l" name="78" href="#78">78</a>your sysroot is `<a href="/googletest/s?path=/home/MYUSER/sysroot&amp;project=googletest">/home/MYUSER/sysroot</a>`. Configure and install GTest using
<a class="l" name="79" href="#79">79</a>
<a class="hl" name="80" href="#80">80</a>```
<a class="l" name="81" href="#81">81</a>mkdir build &amp;&amp; cmake -DCMAKE_INSTALL_PREFIX=/usr ..
<a class="l" name="82" href="#82">82</a>```
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>Install into the sysroot using `DESTDIR`:
<a class="l" name="85" href="#85">85</a>
<a class="l" name="86" href="#86">86</a>```
<a class="l" name="87" href="#87">87</a>make -j install DESTDIR=<a href="/googletest/s?path=/home/MYUSER/sysroot&amp;project=googletest">/home/MYUSER/sysroot</a>
<a class="l" name="88" href="#88">88</a>```
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>Before we continue, it is recommended to **always** define the following two
<a class="l" name="91" href="#91">91</a>variables for pkg-config in a cross-compilation setting:
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>```
<a class="l" name="94" href="#94">94</a>export PKG_CONFIG_ALLOW_SYSTEM_CFLAGS=yes
<a class="l" name="95" href="#95">95</a>export PKG_CONFIG_ALLOW_SYSTEM_LIBS=yes
<a class="l" name="96" href="#96">96</a>```
<a class="l" name="97" href="#97">97</a>
<a class="l" name="98" href="#98">98</a>otherwise `pkg-config` will filter `-I` and `-L` flags against standard prefixes
<a class="l" name="99" href="#99">99</a>such as `/usr` (see <a href="https://bugs.freedesktop.org/show_bug.cgi?id=28264">https://bugs.freedesktop.org/show_bug.cgi?id=28264</a>#c3 for
<a class="hl" name="100" href="#100">100</a>reasons why this stripping needs to occur usually).
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>If you look at the generated pkg-config file, it will look something like
<a class="l" name="103" href="#103">103</a>
<a class="l" name="104" href="#104">104</a>```
<a class="l" name="105" href="#105">105</a>libdir=<a href="/googletest/s?path=/usr/lib64&amp;project=googletest">/usr/lib64</a>
<a class="l" name="106" href="#106">106</a>includedir=<a href="/googletest/s?path=/usr/include&amp;project=googletest">/usr/include</a>
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>Name: gtest
<a class="l" name="109" href="#109">109</a>Description: GoogleTest (without main() function)
<a class="hl" name="110" href="#110">110</a>Version: 1.10.0
<a class="l" name="111" href="#111">111</a>URL: <a href="https://github.com/google/googletest">https://github.com/google/googletest</a>
<a class="l" name="112" href="#112">112</a>Libs: -L${libdir} -lgtest -lpthread
<a class="l" name="113" href="#113">113</a>Cflags: -I${includedir} -DGTEST_HAS_PTHREAD=1 -lpthread
<a class="l" name="114" href="#114">114</a>```
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>Notice that the sysroot is not included in `libdir` and `includedir`! If you try
<a class="l" name="117" href="#117">117</a>to run `pkg-config` with the correct
<a class="l" name="118" href="#118">118</a>`PKG_CONFIG_LIBDIR=<a href="/googletest/s?path=/home/MYUSER/sysroot/usr/lib64/pkgconfig&amp;project=googletest">/home/MYUSER/sysroot/usr/lib64/pkgconfig</a>` against this `.pc`
<a class="l" name="119" href="#119">119</a>file, you will get
<a class="hl" name="120" href="#120">120</a>
<a class="l" name="121" href="#121">121</a>```
<a class="l" name="122" href="#122">122</a>$ pkg-config --cflags gtest
<a class="l" name="123" href="#123">123</a>-DGTEST_HAS_PTHREAD=1 -lpthread -I<a href="/googletest/s?path=/usr/include&amp;project=googletest">/usr/include</a>
<a class="l" name="124" href="#124">124</a>$ pkg-config --libs gtest
<a class="l" name="125" href="#125">125</a>-L<a href="/googletest/s?path=/usr/lib64&amp;project=googletest">/usr/lib64</a> -lgtest -lpthread
<a class="l" name="126" href="#126">126</a>```
<a class="l" name="127" href="#127">127</a>
<a class="l" name="128" href="#128">128</a>which is obviously wrong and points to the `CBUILD` and not `CHOST` root. In
<a class="l" name="129" href="#129">129</a>order to use this in a cross-compilation setting, we need to tell pkg-config to
<a class="hl" name="130" href="#130">130</a>inject the actual sysroot into `-I` and `-L` variables. Let us now tell
<a class="l" name="131" href="#131">131</a>pkg-config about the actual sysroot
<a class="l" name="132" href="#132">132</a>
<a class="l" name="133" href="#133">133</a>```
<a class="l" name="134" href="#134">134</a>export PKG_CONFIG_DIR=
<a class="l" name="135" href="#135">135</a>export PKG_CONFIG_SYSROOT_DIR=<a href="/googletest/s?path=/home/MYUSER/sysroot&amp;project=googletest">/home/MYUSER/sysroot</a>
<a class="l" name="136" href="#136">136</a>export PKG_CONFIG_LIBDIR=${PKG_CONFIG_SYSROOT_DIR}<a href="/googletest/s?path=/usr/lib64/pkgconfig&amp;project=googletest">/usr/lib64/pkgconfig</a>
<a class="l" name="137" href="#137">137</a>```
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>and running `pkg-config` again we get
<a class="hl" name="140" href="#140">140</a>
<a class="l" name="141" href="#141">141</a>```
<a class="l" name="142" href="#142">142</a>$ pkg-config --cflags gtest
<a class="l" name="143" href="#143">143</a>-DGTEST_HAS_PTHREAD=1 -lpthread -I<a href="/googletest/s?path=/home/MYUSER/sysroot/usr/include&amp;project=googletest">/home/MYUSER/sysroot/usr/include</a>
<a class="l" name="144" href="#144">144</a>$ pkg-config --libs gtest
<a class="l" name="145" href="#145">145</a>-L<a href="/googletest/s?path=/home/MYUSER/sysroot/usr/lib64&amp;project=googletest">/home/MYUSER/sysroot/usr/lib64</a> -lgtest -lpthread
<a class="l" name="146" href="#146">146</a>```
<a class="l" name="147" href="#147">147</a>
<a class="l" name="148" href="#148">148</a>which contains the correct sysroot now. For a more comprehensive guide to also
<a class="l" name="149" href="#149">149</a>including `${CHOST}` in build system calls, see the excellent tutorial by Diego
<a class="hl" name="150" href="#150">150</a>Elio Petten&#242;: <a href="https://autotools.io/pkgconfig/cross-compiling.html">https://autotools.io/pkgconfig/cross-compiling.html</a>
<a class="l" name="151" href="#151">151</a>