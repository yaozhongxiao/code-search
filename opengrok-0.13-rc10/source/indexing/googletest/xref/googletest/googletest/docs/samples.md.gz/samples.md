<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># Googletest Samples {#samples}
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>If you're like us, you'd like to look at
<a class="l" name="4" href="#4">4</a>[googletest samples.](<a href="https://github.com/google/googletest/tree/master/googletest/samples">https://github.com/google/googletest/tree/master/googletest/samples</a>)
<a class="l" name="5" href="#5">5</a>The sample directory has a number of well-commented samples showing how to use a
<a class="l" name="6" href="#6">6</a>variety of googletest features.
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>*   Sample #1 shows the basic steps of using googletest to test C++ functions.
<a class="l" name="9" href="#9">9</a>*   Sample #2 shows a more complex unit test for a class with multiple member
<a class="hl" name="10" href="#10">10</a>    functions.
<a class="l" name="11" href="#11">11</a>*   Sample #3 uses a test fixture.
<a class="l" name="12" href="#12">12</a>*   Sample #4 teaches you how to use googletest and `<a href="/googletest/s?path=googletest.h&amp;project=googletest">googletest.h</a>` together to
<a class="l" name="13" href="#13">13</a>    get the best of both libraries.
<a class="l" name="14" href="#14">14</a>*   Sample #5 puts shared testing logic in a base test fixture, and reuses it in
<a class="l" name="15" href="#15">15</a>    derived fixtures.
<a class="l" name="16" href="#16">16</a>*   Sample #6 demonstrates type-parameterized tests.
<a class="l" name="17" href="#17">17</a>*   Sample #7 teaches the basics of value-parameterized tests.
<a class="l" name="18" href="#18">18</a>*   Sample #8 shows using `Combine()` in value-parameterized tests.
<a class="l" name="19" href="#19">19</a>*   Sample #9 shows use of the listener API to modify Google Test's console
<a class="hl" name="20" href="#20">20</a>    output and the use of its reflection API to inspect test results.
<a class="l" name="21" href="#21">21</a>*   Sample #10 shows use of the listener API to implement a primitive memory
<a class="l" name="22" href="#22">22</a>    leak checker.
<a class="l" name="23" href="#23">23</a>