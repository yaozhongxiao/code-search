<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># Advanced googletest Topics
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>&lt;!-- GOOGLETEST_CM0016 DO NOT DELETE --&gt;
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>&lt;!-- GOOGLETEST_CM0035 DO NOT DELETE --&gt;
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>## Introduction
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>Now that you have read the [googletest Primer](<a href="/googletest/s?path=primer.md&amp;project=googletest">primer.md</a>) and learned how to
<a class="hl" name="10" href="#10">10</a>write tests using googletest, it's time to learn some new tricks. This document
<a class="l" name="11" href="#11">11</a>will show you more assertions as well as how to construct complex failure
<a class="l" name="12" href="#12">12</a>messages, propagate fatal failures, reuse and speed up your test fixtures, and
<a class="l" name="13" href="#13">13</a>use various flags with your tests.
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a>## More Assertions
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a>This section covers some less frequently used, but still significant,
<a class="l" name="18" href="#18">18</a>assertions.
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a>### Explicit Success and Failure
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a>These three assertions do not actually test a value or expression. Instead, they
<a class="l" name="23" href="#23">23</a>generate a success or failure directly. Like the macros that actually perform a
<a class="l" name="24" href="#24">24</a>test, you may stream a custom failure message into them.
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a>```c++
<a class="l" name="27" href="#27">27</a>SUCCEED();
<a class="l" name="28" href="#28">28</a>```
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a>Generates a success. This does **NOT** make the overall test succeed. A test is
<a class="l" name="31" href="#31">31</a>considered successful only if none of its assertions fail during its execution.
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>NOTE: `SUCCEED()` is purely documentary and currently doesn't generate any
<a class="l" name="34" href="#34">34</a>user-visible output. However, we may add `SUCCEED()` messages to googletest's
<a class="l" name="35" href="#35">35</a>output in the future.
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>```c++
<a class="l" name="38" href="#38">38</a>FAIL();
<a class="l" name="39" href="#39">39</a>ADD_FAILURE();
<a class="hl" name="40" href="#40">40</a>ADD_FAILURE_AT("file_path", line_number);
<a class="l" name="41" href="#41">41</a>```
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>`FAIL()` generates a fatal failure, while `ADD_FAILURE()` and `ADD_FAILURE_AT()`
<a class="l" name="44" href="#44">44</a>generate a nonfatal failure. These are useful when control flow, rather than a
<a class="l" name="45" href="#45">45</a>Boolean expression, determines the test's success or failure. For example, you
<a class="l" name="46" href="#46">46</a>might want to write something like:
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>```c++
<a class="l" name="49" href="#49">49</a>switch(expression) {
<a class="hl" name="50" href="#50">50</a>  case 1:
<a class="l" name="51" href="#51">51</a>     ... some checks ...
<a class="l" name="52" href="#52">52</a>  case 2:
<a class="l" name="53" href="#53">53</a>     ... some other checks ...
<a class="l" name="54" href="#54">54</a>  default:
<a class="l" name="55" href="#55">55</a>     FAIL() &lt;&lt; "We shouldn't get here.";
<a class="l" name="56" href="#56">56</a>}
<a class="l" name="57" href="#57">57</a>```
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>NOTE: you can only use `FAIL()` in functions that return `void`. See the
<a class="hl" name="60" href="#60">60</a>[Assertion Placement section](#assertion-placement) for more information.
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>### Exception Assertions
<a class="l" name="63" href="#63">63</a>
<a class="l" name="64" href="#64">64</a>These are for verifying that a piece of code throws (or does not throw) an
<a class="l" name="65" href="#65">65</a>exception of the given type:
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>Fatal assertion                            | Nonfatal assertion                         | Verifies
<a class="l" name="68" href="#68">68</a>------------------------------------------ | ------------------------------------------ | --------
<a class="l" name="69" href="#69">69</a>`ASSERT_THROW(statement, exception_type);` | `EXPECT_THROW(statement, exception_type);` | `statement` throws an exception of the given type
<a class="hl" name="70" href="#70">70</a>`ASSERT_ANY_THROW(statement);`             | `EXPECT_ANY_THROW(statement);`             | `statement` throws an exception of any type
<a class="l" name="71" href="#71">71</a>`ASSERT_NO_THROW(statement);`              | `EXPECT_NO_THROW(statement);`              | `statement` doesn't throw any exception
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>Examples:
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>```c++
<a class="l" name="76" href="#76">76</a>ASSERT_THROW(Foo(5), bar_exception);
<a class="l" name="77" href="#77">77</a>
<a class="l" name="78" href="#78">78</a>EXPECT_NO_THROW({
<a class="l" name="79" href="#79">79</a>  int n = 5;
<a class="hl" name="80" href="#80">80</a>  Bar(&amp;n);
<a class="l" name="81" href="#81">81</a>});
<a class="l" name="82" href="#82">82</a>```
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>**Availability**: requires exceptions to be enabled in the build environment
<a class="l" name="85" href="#85">85</a>
<a class="l" name="86" href="#86">86</a>### Predicate Assertions for Better Error Messages
<a class="l" name="87" href="#87">87</a>
<a class="l" name="88" href="#88">88</a>Even though googletest has a rich set of assertions, they can never be complete,
<a class="l" name="89" href="#89">89</a>as it's impossible (nor a good idea) to anticipate all scenarios a user might
<a class="hl" name="90" href="#90">90</a>run into. Therefore, sometimes a user has to use `EXPECT_TRUE()` to check a
<a class="l" name="91" href="#91">91</a>complex expression, for lack of a better macro. This has the problem of not
<a class="l" name="92" href="#92">92</a>showing you the values of the parts of the expression, making it hard to
<a class="l" name="93" href="#93">93</a>understand what went wrong. As a workaround, some users choose to construct the
<a class="l" name="94" href="#94">94</a>failure message by themselves, streaming it into `EXPECT_TRUE()`. However, this
<a class="l" name="95" href="#95">95</a>is awkward especially when the expression has side-effects or is expensive to
<a class="l" name="96" href="#96">96</a>evaluate.
<a class="l" name="97" href="#97">97</a>
<a class="l" name="98" href="#98">98</a>googletest gives you three different options to solve this problem:
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>#### Using an Existing Boolean Function
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>If you already have a function or functor that returns `bool` (or a type that
<a class="l" name="103" href="#103">103</a>can be implicitly converted to `bool`), you can use it in a *predicate
<a class="l" name="104" href="#104">104</a>assertion* to get the function arguments printed for free:
<a class="l" name="105" href="#105">105</a>
<a class="l" name="106" href="#106">106</a>&lt;!-- mdformat off(github rendering does not support multiline tables) --&gt;
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>| Fatal assertion                   | Nonfatal assertion                | Verifies                    |
<a class="l" name="109" href="#109">109</a>| --------------------------------- | --------------------------------- | --------------------------- |
<a class="hl" name="110" href="#110">110</a>| `ASSERT_PRED1(pred1, val1)`       | `EXPECT_PRED1(pred1, val1)`       | `pred1(val1)` is true       |
<a class="l" name="111" href="#111">111</a>| `ASSERT_PRED2(pred2, val1, val2)` | `EXPECT_PRED2(pred2, val1, val2)` | `pred2(val1, val2)` is true |
<a class="l" name="112" href="#112">112</a>| `...`                             | `...`                             | `...`                       |
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>&lt;!-- mdformat on--&gt;
<a class="l" name="115" href="#115">115</a>In the above, `predn` is an `n`-ary predicate function or functor, where `val1`,
<a class="l" name="116" href="#116">116</a>`val2`, ..., and `valn` are its arguments. The assertion succeeds if the
<a class="l" name="117" href="#117">117</a>predicate returns `true` when applied to the given arguments, and fails
<a class="l" name="118" href="#118">118</a>otherwise. When the assertion fails, it prints the value of each argument. In
<a class="l" name="119" href="#119">119</a>either case, the arguments are evaluated exactly once.
<a class="hl" name="120" href="#120">120</a>
<a class="l" name="121" href="#121">121</a>Here's an example. Given
<a class="l" name="122" href="#122">122</a>
<a class="l" name="123" href="#123">123</a>```c++
<a class="l" name="124" href="#124">124</a>// Returns true if m and n have no common divisors except 1.
<a class="l" name="125" href="#125">125</a>bool MutuallyPrime(int m, int n) { ... }
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>const int a = 3;
<a class="l" name="128" href="#128">128</a>const int b = 4;
<a class="l" name="129" href="#129">129</a>const int c = 10;
<a class="hl" name="130" href="#130">130</a>```
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>the assertion
<a class="l" name="133" href="#133">133</a>
<a class="l" name="134" href="#134">134</a>```c++
<a class="l" name="135" href="#135">135</a>  EXPECT_PRED2(MutuallyPrime, a, b);
<a class="l" name="136" href="#136">136</a>```
<a class="l" name="137" href="#137">137</a>
<a class="l" name="138" href="#138">138</a>will succeed, while the assertion
<a class="l" name="139" href="#139">139</a>
<a class="hl" name="140" href="#140">140</a>```c++
<a class="l" name="141" href="#141">141</a>  EXPECT_PRED2(MutuallyPrime, b, c);
<a class="l" name="142" href="#142">142</a>```
<a class="l" name="143" href="#143">143</a>
<a class="l" name="144" href="#144">144</a>will fail with the message
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>```none
<a class="l" name="147" href="#147">147</a>MutuallyPrime(b, c) is false, where
<a class="l" name="148" href="#148">148</a>b is 4
<a class="l" name="149" href="#149">149</a>c is 10
<a class="hl" name="150" href="#150">150</a>```
<a class="l" name="151" href="#151">151</a>
<a class="l" name="152" href="#152">152</a>&gt; NOTE:
<a class="l" name="153" href="#153">153</a>&gt;
<a class="l" name="154" href="#154">154</a>&gt; 1.  If you see a compiler error "no matching function to call" when using
<a class="l" name="155" href="#155">155</a>&gt;     `ASSERT_PRED*` or `EXPECT_PRED*`, please see
<a class="l" name="156" href="#156">156</a>&gt;     [this](<a href="/googletest/s?path=faq.md&amp;project=googletest">faq.md</a>#the-compiler-complains-no-matching-function-to-call-when-i-use-assert-pred-how-do-i-fix-it)
<a class="l" name="157" href="#157">157</a>&gt;     for how to resolve it.
<a class="l" name="158" href="#158">158</a>
<a class="l" name="159" href="#159">159</a>#### Using a Function That Returns an AssertionResult
<a class="hl" name="160" href="#160">160</a>
<a class="l" name="161" href="#161">161</a>While `EXPECT_PRED*()` and friends are handy for a quick job, the syntax is not
<a class="l" name="162" href="#162">162</a>satisfactory: you have to use different macros for different arities, and it
<a class="l" name="163" href="#163">163</a>feels more like Lisp than C++. The `::testing::AssertionResult` class solves
<a class="l" name="164" href="#164">164</a>this problem.
<a class="l" name="165" href="#165">165</a>
<a class="l" name="166" href="#166">166</a>An `AssertionResult` object represents the result of an assertion (whether it's
<a class="l" name="167" href="#167">167</a>a success or a failure, and an associated message). You can create an
<a class="l" name="168" href="#168">168</a>`AssertionResult` using one of these factory functions:
<a class="l" name="169" href="#169">169</a>
<a class="hl" name="170" href="#170">170</a>```c++
<a class="l" name="171" href="#171">171</a>namespace testing {
<a class="l" name="172" href="#172">172</a>
<a class="l" name="173" href="#173">173</a>// Returns an AssertionResult object to indicate that an assertion has
<a class="l" name="174" href="#174">174</a>// succeeded.
<a class="l" name="175" href="#175">175</a>AssertionResult AssertionSuccess();
<a class="l" name="176" href="#176">176</a>
<a class="l" name="177" href="#177">177</a>// Returns an AssertionResult object to indicate that an assertion has
<a class="l" name="178" href="#178">178</a>// failed.
<a class="l" name="179" href="#179">179</a>AssertionResult AssertionFailure();
<a class="hl" name="180" href="#180">180</a>
<a class="l" name="181" href="#181">181</a>}
<a class="l" name="182" href="#182">182</a>```
<a class="l" name="183" href="#183">183</a>
<a class="l" name="184" href="#184">184</a>You can then use the `&lt;&lt;` operator to stream messages to the `AssertionResult`
<a class="l" name="185" href="#185">185</a>object.
<a class="l" name="186" href="#186">186</a>
<a class="l" name="187" href="#187">187</a>To provide more readable messages in Boolean assertions (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `EXPECT_TRUE()`),
<a class="l" name="188" href="#188">188</a>write a predicate function that returns `AssertionResult` instead of `bool`. For
<a class="l" name="189" href="#189">189</a>example, if you define `IsEven()` as:
<a class="hl" name="190" href="#190">190</a>
<a class="l" name="191" href="#191">191</a>```c++
<a class="l" name="192" href="#192">192</a>testing::AssertionResult IsEven(int n) {
<a class="l" name="193" href="#193">193</a>  if ((n % 2) == 0)
<a class="l" name="194" href="#194">194</a>    return testing::AssertionSuccess();
<a class="l" name="195" href="#195">195</a>  else
<a class="l" name="196" href="#196">196</a>    return testing::AssertionFailure() &lt;&lt; n &lt;&lt; " is odd";
<a class="l" name="197" href="#197">197</a>}
<a class="l" name="198" href="#198">198</a>```
<a class="l" name="199" href="#199">199</a>
<a class="hl" name="200" href="#200">200</a>instead of:
<a class="l" name="201" href="#201">201</a>
<a class="l" name="202" href="#202">202</a>```c++
<a class="l" name="203" href="#203">203</a>bool IsEven(int n) {
<a class="l" name="204" href="#204">204</a>  return (n % 2) == 0;
<a class="l" name="205" href="#205">205</a>}
<a class="l" name="206" href="#206">206</a>```
<a class="l" name="207" href="#207">207</a>
<a class="l" name="208" href="#208">208</a>the failed assertion `EXPECT_TRUE(IsEven(Fib(4)))` will print:
<a class="l" name="209" href="#209">209</a>
<a class="hl" name="210" href="#210">210</a>```none
<a class="l" name="211" href="#211">211</a>Value of: IsEven(Fib(4))
<a class="l" name="212" href="#212">212</a>  Actual: false (3 is odd)
<a class="l" name="213" href="#213">213</a>Expected: true
<a class="l" name="214" href="#214">214</a>```
<a class="l" name="215" href="#215">215</a>
<a class="l" name="216" href="#216">216</a>instead of a more opaque
<a class="l" name="217" href="#217">217</a>
<a class="l" name="218" href="#218">218</a>```none
<a class="l" name="219" href="#219">219</a>Value of: IsEven(Fib(4))
<a class="hl" name="220" href="#220">220</a>  Actual: false
<a class="l" name="221" href="#221">221</a>Expected: true
<a class="l" name="222" href="#222">222</a>```
<a class="l" name="223" href="#223">223</a>
<a class="l" name="224" href="#224">224</a>If you want informative messages in `EXPECT_FALSE` and `ASSERT_FALSE` as well
<a class="l" name="225" href="#225">225</a>(one third of Boolean assertions in the Google code base are negative ones), and
<a class="l" name="226" href="#226">226</a>are fine with making the predicate slower in the success case, you can supply a
<a class="l" name="227" href="#227">227</a>success message:
<a class="l" name="228" href="#228">228</a>
<a class="l" name="229" href="#229">229</a>```c++
<a class="hl" name="230" href="#230">230</a>testing::AssertionResult IsEven(int n) {
<a class="l" name="231" href="#231">231</a>  if ((n % 2) == 0)
<a class="l" name="232" href="#232">232</a>    return testing::AssertionSuccess() &lt;&lt; n &lt;&lt; " is even";
<a class="l" name="233" href="#233">233</a>  else
<a class="l" name="234" href="#234">234</a>    return testing::AssertionFailure() &lt;&lt; n &lt;&lt; " is odd";
<a class="l" name="235" href="#235">235</a>}
<a class="l" name="236" href="#236">236</a>```
<a class="l" name="237" href="#237">237</a>
<a class="l" name="238" href="#238">238</a>Then the statement `EXPECT_FALSE(IsEven(Fib(6)))` will print
<a class="l" name="239" href="#239">239</a>
<a class="hl" name="240" href="#240">240</a>```none
<a class="l" name="241" href="#241">241</a>  Value of: IsEven(Fib(6))
<a class="l" name="242" href="#242">242</a>     Actual: true (8 is even)
<a class="l" name="243" href="#243">243</a>  Expected: false
<a class="l" name="244" href="#244">244</a>```
<a class="l" name="245" href="#245">245</a>
<a class="l" name="246" href="#246">246</a>#### Using a Predicate-Formatter
<a class="l" name="247" href="#247">247</a>
<a class="l" name="248" href="#248">248</a>If you find the default message generated by `(ASSERT|EXPECT)_PRED*` and
<a class="l" name="249" href="#249">249</a>`(ASSERT|EXPECT)_(TRUE|FALSE)` unsatisfactory, or some arguments to your
<a class="hl" name="250" href="#250">250</a>predicate do not support streaming to `ostream`, you can instead use the
<a class="l" name="251" href="#251">251</a>following *predicate-formatter assertions* to *fully* customize how the message
<a class="l" name="252" href="#252">252</a>is formatted:
<a class="l" name="253" href="#253">253</a>
<a class="l" name="254" href="#254">254</a>Fatal assertion                                  | Nonfatal assertion                               | Verifies
<a class="l" name="255" href="#255">255</a>------------------------------------------------ | ------------------------------------------------ | --------
<a class="l" name="256" href="#256">256</a>`ASSERT_PRED_FORMAT1(pred_format1, val1);`       | `EXPECT_PRED_FORMAT1(pred_format1, val1);`       | `pred_format1(val1)` is successful
<a class="l" name="257" href="#257">257</a>`ASSERT_PRED_FORMAT2(pred_format2, val1, val2);` | `EXPECT_PRED_FORMAT2(pred_format2, val1, val2);` | `pred_format2(val1, val2)` is successful
<a class="l" name="258" href="#258">258</a>`...`                                            | `...`                                            | ...
<a class="l" name="259" href="#259">259</a>
<a class="hl" name="260" href="#260">260</a>The difference between this and the previous group of macros is that instead of
<a class="l" name="261" href="#261">261</a>a predicate, `(ASSERT|EXPECT)_PRED_FORMAT*` take a *predicate-formatter*
<a class="l" name="262" href="#262">262</a>(`pred_formatn`), which is a function or functor with the signature:
<a class="l" name="263" href="#263">263</a>
<a class="l" name="264" href="#264">264</a>```c++
<a class="l" name="265" href="#265">265</a>testing::AssertionResult PredicateFormattern(const char* expr1,
<a class="l" name="266" href="#266">266</a>                                             const char* expr2,
<a class="l" name="267" href="#267">267</a>                                             ...
<a class="l" name="268" href="#268">268</a>                                             const char* exprn,
<a class="l" name="269" href="#269">269</a>                                             T1 val1,
<a class="hl" name="270" href="#270">270</a>                                             T2 val2,
<a class="l" name="271" href="#271">271</a>                                             ...
<a class="l" name="272" href="#272">272</a>                                             Tn valn);
<a class="l" name="273" href="#273">273</a>```
<a class="l" name="274" href="#274">274</a>
<a class="l" name="275" href="#275">275</a>where `val1`, `val2`, ..., and `valn` are the values of the predicate arguments,
<a class="l" name="276" href="#276">276</a>and `expr1`, `expr2`, ..., and `exprn` are the corresponding expressions as they
<a class="l" name="277" href="#277">277</a>appear in the source code. The types `T1`, `T2`, ..., and `Tn` can be either
<a class="l" name="278" href="#278">278</a>value types or reference types. For example, if an argument has type `Foo`, you
<a class="l" name="279" href="#279">279</a>can declare it as either `Foo` or `const Foo&amp;`, whichever is appropriate.
<a class="hl" name="280" href="#280">280</a>
<a class="l" name="281" href="#281">281</a>As an example, let's improve the failure message in `MutuallyPrime()`, which was
<a class="l" name="282" href="#282">282</a>used with `EXPECT_PRED2()`:
<a class="l" name="283" href="#283">283</a>
<a class="l" name="284" href="#284">284</a>```c++
<a class="l" name="285" href="#285">285</a>// Returns the smallest prime common divisor of m and n,
<a class="l" name="286" href="#286">286</a>// or 1 when m and n are mutually prime.
<a class="l" name="287" href="#287">287</a>int SmallestPrimeCommonDivisor(int m, int n) { ... }
<a class="l" name="288" href="#288">288</a>
<a class="l" name="289" href="#289">289</a>// A predicate-formatter for asserting that two integers are mutually prime.
<a class="hl" name="290" href="#290">290</a>testing::AssertionResult AssertMutuallyPrime(const char* m_expr,
<a class="l" name="291" href="#291">291</a>                                             const char* n_expr,
<a class="l" name="292" href="#292">292</a>                                             int m,
<a class="l" name="293" href="#293">293</a>                                             int n) {
<a class="l" name="294" href="#294">294</a>  if (MutuallyPrime(m, n)) return testing::AssertionSuccess();
<a class="l" name="295" href="#295">295</a>
<a class="l" name="296" href="#296">296</a>  return testing::AssertionFailure() &lt;&lt; m_expr &lt;&lt; " and " &lt;&lt; n_expr
<a class="l" name="297" href="#297">297</a>      &lt;&lt; " (" &lt;&lt; m &lt;&lt; " and " &lt;&lt; n &lt;&lt; ") are not mutually prime, "
<a class="l" name="298" href="#298">298</a>      &lt;&lt; "as they have a common divisor " &lt;&lt; SmallestPrimeCommonDivisor(m, n);
<a class="l" name="299" href="#299">299</a>}
<a class="hl" name="300" href="#300">300</a>```
<a class="l" name="301" href="#301">301</a>
<a class="l" name="302" href="#302">302</a>With this predicate-formatter, we can use
<a class="l" name="303" href="#303">303</a>
<a class="l" name="304" href="#304">304</a>```c++
<a class="l" name="305" href="#305">305</a>  EXPECT_PRED_FORMAT2(AssertMutuallyPrime, b, c);
<a class="l" name="306" href="#306">306</a>```
<a class="l" name="307" href="#307">307</a>
<a class="l" name="308" href="#308">308</a>to generate the message
<a class="l" name="309" href="#309">309</a>
<a class="hl" name="310" href="#310">310</a>```none
<a class="l" name="311" href="#311">311</a>b and c (4 and 10) are not mutually prime, as they have a common divisor 2.
<a class="l" name="312" href="#312">312</a>```
<a class="l" name="313" href="#313">313</a>
<a class="l" name="314" href="#314">314</a>As you may have realized, many of the built-in assertions we introduced earlier
<a class="l" name="315" href="#315">315</a>are special cases of `(EXPECT|ASSERT)_PRED_FORMAT*`. In fact, most of them are
<a class="l" name="316" href="#316">316</a>indeed defined using `(EXPECT|ASSERT)_PRED_FORMAT*`.
<a class="l" name="317" href="#317">317</a>
<a class="l" name="318" href="#318">318</a>### Floating-Point Comparison
<a class="l" name="319" href="#319">319</a>
<a class="hl" name="320" href="#320">320</a>Comparing floating-point numbers is tricky. Due to round-off errors, it is very
<a class="l" name="321" href="#321">321</a>unlikely that two floating-points will match exactly. Therefore, `ASSERT_EQ` 's
<a class="l" name="322" href="#322">322</a>naive comparison usually doesn't work. And since floating-points can have a wide
<a class="l" name="323" href="#323">323</a>value range, no single fixed error bound works. It's better to compare by a
<a class="l" name="324" href="#324">324</a>fixed relative error bound, except for values close to 0 due to the loss of
<a class="l" name="325" href="#325">325</a>precision there.
<a class="l" name="326" href="#326">326</a>
<a class="l" name="327" href="#327">327</a>In general, for floating-point comparison to make sense, the user needs to
<a class="l" name="328" href="#328">328</a>carefully choose the error bound. If they don't want or care to, comparing in
<a class="l" name="329" href="#329">329</a>terms of Units in the Last Place (ULPs) is a good default, and googletest
<a class="hl" name="330" href="#330">330</a>provides assertions to do this. Full details about ULPs are quite long; if you
<a class="l" name="331" href="#331">331</a>want to learn more, see
<a class="l" name="332" href="#332">332</a>[here](<a href="https://randomascii.wordpress.com/2012/02/25/comparing-floating-point-numbers-2012-edition/">https://randomascii.wordpress.com/2012/02/25/comparing-floating-point-numbers-2012-edition/</a>).
<a class="l" name="333" href="#333">333</a>
<a class="l" name="334" href="#334">334</a>#### Floating-Point Macros
<a class="l" name="335" href="#335">335</a>
<a class="l" name="336" href="#336">336</a>&lt;!-- mdformat off(github rendering does not support multiline tables) --&gt;
<a class="l" name="337" href="#337">337</a>
<a class="l" name="338" href="#338">338</a>| Fatal assertion                 | Nonfatal assertion              | Verifies                                 |
<a class="l" name="339" href="#339">339</a>| ------------------------------- | ------------------------------- | ---------------------------------------- |
<a class="hl" name="340" href="#340">340</a>| `ASSERT_FLOAT_EQ(val1, val2);`  | `EXPECT_FLOAT_EQ(val1, val2);`  | the two `float` values are almost equal  |
<a class="l" name="341" href="#341">341</a>| `ASSERT_DOUBLE_EQ(val1, val2);` | `EXPECT_DOUBLE_EQ(val1, val2);` | the two `double` values are almost equal |
<a class="l" name="342" href="#342">342</a>
<a class="l" name="343" href="#343">343</a>&lt;!-- mdformat on--&gt;
<a class="l" name="344" href="#344">344</a>
<a class="l" name="345" href="#345">345</a>By "almost equal" we mean the values are within 4 ULP's from each other.
<a class="l" name="346" href="#346">346</a>
<a class="l" name="347" href="#347">347</a>The following assertions allow you to choose the acceptable error bound:
<a class="l" name="348" href="#348">348</a>
<a class="l" name="349" href="#349">349</a>&lt;!-- mdformat off(github rendering does not support multiline tables) --&gt;
<a class="hl" name="350" href="#350">350</a>
<a class="l" name="351" href="#351">351</a>| Fatal assertion                       | Nonfatal assertion                    | Verifies                                                                         |
<a class="l" name="352" href="#352">352</a>| ------------------------------------- | ------------------------------------- | -------------------------------------------------------------------------------- |
<a class="l" name="353" href="#353">353</a>| `ASSERT_NEAR(val1, val2, abs_error);` | `EXPECT_NEAR(val1, val2, abs_error);` | the difference between `val1` and `val2` doesn't exceed the given absolute error |
<a class="l" name="354" href="#354">354</a>
<a class="l" name="355" href="#355">355</a>&lt;!-- mdformat on--&gt;
<a class="l" name="356" href="#356">356</a>
<a class="l" name="357" href="#357">357</a>#### Floating-Point Predicate-Format Functions
<a class="l" name="358" href="#358">358</a>
<a class="l" name="359" href="#359">359</a>Some floating-point operations are useful, but not that often used. In order to
<a class="hl" name="360" href="#360">360</a>avoid an explosion of new macros, we provide them as predicate-format functions
<a class="l" name="361" href="#361">361</a>that can be used in predicate assertion macros (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `EXPECT_PRED_FORMAT2`,
<a class="l" name="362" href="#362">362</a>etc).
<a class="l" name="363" href="#363">363</a>
<a class="l" name="364" href="#364">364</a>```c++
<a class="l" name="365" href="#365">365</a>EXPECT_PRED_FORMAT2(testing::FloatLE, val1, val2);
<a class="l" name="366" href="#366">366</a>EXPECT_PRED_FORMAT2(testing::DoubleLE, val1, val2);
<a class="l" name="367" href="#367">367</a>```
<a class="l" name="368" href="#368">368</a>
<a class="l" name="369" href="#369">369</a>Verifies that `val1` is less than, or almost equal to, `val2`. You can replace
<a class="hl" name="370" href="#370">370</a>`EXPECT_PRED_FORMAT2` in the above table with `ASSERT_PRED_FORMAT2`.
<a class="l" name="371" href="#371">371</a>
<a class="l" name="372" href="#372">372</a>### Asserting Using gMock Matchers
<a class="l" name="373" href="#373">373</a>
<a class="l" name="374" href="#374">374</a>[gMock](../../googlemock) comes with
<a class="l" name="375" href="#375">375</a>[a library of matchers](../..<a href="/googletest/s?path=/googlemock/docs/cheat_sheet.md&amp;project=googletest">/googlemock/docs/cheat_sheet.md</a>#MatcherList) for
<a class="l" name="376" href="#376">376</a>validating arguments passed to mock objects. A gMock *matcher* is basically a
<a class="l" name="377" href="#377">377</a>predicate that knows how to describe itself. It can be used in these assertion
<a class="l" name="378" href="#378">378</a>macros:
<a class="l" name="379" href="#379">379</a>
<a class="hl" name="380" href="#380">380</a>&lt;!-- mdformat off(github rendering does not support multiline tables) --&gt;
<a class="l" name="381" href="#381">381</a>
<a class="l" name="382" href="#382">382</a>| Fatal assertion                | Nonfatal assertion             | Verifies              |
<a class="l" name="383" href="#383">383</a>| ------------------------------ | ------------------------------ | --------------------- |
<a class="l" name="384" href="#384">384</a>| `ASSERT_THAT(value, matcher);` | `EXPECT_THAT(value, matcher);` | value matches matcher |
<a class="l" name="385" href="#385">385</a>
<a class="l" name="386" href="#386">386</a>&lt;!-- mdformat on--&gt;
<a class="l" name="387" href="#387">387</a>
<a class="l" name="388" href="#388">388</a>For example, `StartsWith(prefix)` is a matcher that matches a string starting
<a class="l" name="389" href="#389">389</a>with `prefix`, and you can write:
<a class="hl" name="390" href="#390">390</a>
<a class="l" name="391" href="#391">391</a>```c++
<a class="l" name="392" href="#392">392</a>using ::testing::StartsWith;
<a class="l" name="393" href="#393">393</a>...
<a class="l" name="394" href="#394">394</a>    // Verifies that Foo() returns a string starting with "Hello".
<a class="l" name="395" href="#395">395</a>    EXPECT_THAT(Foo(), StartsWith("Hello"));
<a class="l" name="396" href="#396">396</a>```
<a class="l" name="397" href="#397">397</a>
<a class="l" name="398" href="#398">398</a>Read this
<a class="l" name="399" href="#399">399</a>[recipe](../..<a href="/googletest/s?path=/googlemock/docs/cook_book.md&amp;project=googletest">/googlemock/docs/cook_book.md</a>#using-matchers-in-googletest-assertions)
<a class="hl" name="400" href="#400">400</a>in the gMock Cookbook for more details.
<a class="l" name="401" href="#401">401</a>
<a class="l" name="402" href="#402">402</a>gMock has a rich set of matchers. You can do many things googletest cannot do
<a class="l" name="403" href="#403">403</a>alone with them. For a list of matchers gMock provides, read
<a class="l" name="404" href="#404">404</a>[this](../..<a href="/googletest/s?path=/googlemock/docs/cook_book.md&amp;project=googletest">/googlemock/docs/cook_book.md</a>##using-matchers). It's easy to write
<a class="l" name="405" href="#405">405</a>your [own matchers](../..<a href="/googletest/s?path=/googlemock/docs/cook_book.md&amp;project=googletest">/googlemock/docs/cook_book.md</a>#NewMatchers) too.
<a class="l" name="406" href="#406">406</a>
<a class="l" name="407" href="#407">407</a>gMock is bundled with googletest, so you don't need to add any build dependency
<a class="l" name="408" href="#408">408</a>in order to take advantage of this. Just include `"<a href="/googletest/s?path=gmock/gmock.h&amp;project=googletest">gmock/gmock.h</a>"`
<a class="l" name="409" href="#409">409</a>and you're ready to go.
<a class="hl" name="410" href="#410">410</a>
<a class="l" name="411" href="#411">411</a>### More String Assertions
<a class="l" name="412" href="#412">412</a>
<a class="l" name="413" href="#413">413</a>(Please read the [previous](#asserting-using-gmock-matchers) section first if
<a class="l" name="414" href="#414">414</a>you haven't.)
<a class="l" name="415" href="#415">415</a>
<a class="l" name="416" href="#416">416</a>You can use the gMock
<a class="l" name="417" href="#417">417</a>[string matchers](../..<a href="/googletest/s?path=/googlemock/docs/cheat_sheet.md&amp;project=googletest">/googlemock/docs/cheat_sheet.md</a>#string-matchers) with
<a class="l" name="418" href="#418">418</a>`EXPECT_THAT()` or `ASSERT_THAT()` to do more string comparison tricks
<a class="l" name="419" href="#419">419</a>(sub-string, prefix, suffix, regular expression, and etc). For example,
<a class="hl" name="420" href="#420">420</a>
<a class="l" name="421" href="#421">421</a>```c++
<a class="l" name="422" href="#422">422</a>using ::testing::HasSubstr;
<a class="l" name="423" href="#423">423</a>using ::testing::MatchesRegex;
<a class="l" name="424" href="#424">424</a>...
<a class="l" name="425" href="#425">425</a>  ASSERT_THAT(foo_string, HasSubstr("needle"));
<a class="l" name="426" href="#426">426</a>  EXPECT_THAT(bar_string, MatchesRegex("\\w*\\d+"));
<a class="l" name="427" href="#427">427</a>```
<a class="l" name="428" href="#428">428</a>
<a class="l" name="429" href="#429">429</a>If the string contains a well-formed HTML or XML document, you can check whether
<a class="hl" name="430" href="#430">430</a>its DOM tree matches an
<a class="l" name="431" href="#431">431</a>[XPath expression](<a href="http://www.w3.org/TR/xpath/">http://www.w3.org/TR/xpath/</a>#contents):
<a class="l" name="432" href="#432">432</a>
<a class="l" name="433" href="#433">433</a>```c++
<a class="l" name="434" href="#434">434</a>// Currently still in /<a href="/googletest/s?path=/template/prototemplate/testing&amp;project=googletest">/template/prototemplate/testing</a>:xpath_matcher
<a class="l" name="435" href="#435">435</a>#include "<a href="/googletest/s?path=template/prototemplate/testing/xpath_matcher.h&amp;project=googletest">template/prototemplate/testing/xpath_matcher.h</a>"
<a class="l" name="436" href="#436">436</a>using ::prototemplate::testing::MatchesXPath;
<a class="l" name="437" href="#437">437</a>EXPECT_THAT(html_string, MatchesXPath("//a[text()='click here']"));
<a class="l" name="438" href="#438">438</a>```
<a class="l" name="439" href="#439">439</a>
<a class="hl" name="440" href="#440">440</a>### Windows HRESULT assertions
<a class="l" name="441" href="#441">441</a>
<a class="l" name="442" href="#442">442</a>These assertions test for `HRESULT` success or failure.
<a class="l" name="443" href="#443">443</a>
<a class="l" name="444" href="#444">444</a>Fatal assertion                        | Nonfatal assertion                     | Verifies
<a class="l" name="445" href="#445">445</a>-------------------------------------- | -------------------------------------- | --------
<a class="l" name="446" href="#446">446</a>`ASSERT_HRESULT_SUCCEEDED(expression)` | `EXPECT_HRESULT_SUCCEEDED(expression)` | `expression` is a success `HRESULT`
<a class="l" name="447" href="#447">447</a>`ASSERT_HRESULT_FAILED(expression)`    | `EXPECT_HRESULT_FAILED(expression)`    | `expression` is a failure `HRESULT`
<a class="l" name="448" href="#448">448</a>
<a class="l" name="449" href="#449">449</a>The generated output contains the human-readable error message associated with
<a class="hl" name="450" href="#450">450</a>the `HRESULT` code returned by `expression`.
<a class="l" name="451" href="#451">451</a>
<a class="l" name="452" href="#452">452</a>You might use them like this:
<a class="l" name="453" href="#453">453</a>
<a class="l" name="454" href="#454">454</a>```c++
<a class="l" name="455" href="#455">455</a>CComPtr&lt;IShellDispatch2&gt; shell;
<a class="l" name="456" href="#456">456</a>ASSERT_HRESULT_SUCCEEDED(<a href="/googletest/s?path=shell.CoCreateInstance&amp;project=googletest">shell.CoCreateInstance</a>(L"<a href="/googletest/s?path=Shell.Application&amp;project=googletest">Shell.Application</a>"));
<a class="l" name="457" href="#457">457</a>CComVariant empty;
<a class="l" name="458" href="#458">458</a>ASSERT_HRESULT_SUCCEEDED(shell-&gt;ShellExecute(CComBSTR(url), empty, empty, empty, empty));
<a class="l" name="459" href="#459">459</a>```
<a class="hl" name="460" href="#460">460</a>
<a class="l" name="461" href="#461">461</a>### Type Assertions
<a class="l" name="462" href="#462">462</a>
<a class="l" name="463" href="#463">463</a>You can call the function
<a class="l" name="464" href="#464">464</a>
<a class="l" name="465" href="#465">465</a>```c++
<a class="l" name="466" href="#466">466</a>::testing::StaticAssertTypeEq&lt;T1, T2&gt;();
<a class="l" name="467" href="#467">467</a>```
<a class="l" name="468" href="#468">468</a>
<a class="l" name="469" href="#469">469</a>to assert that types `T1` and `T2` are the same. The function does nothing if
<a class="hl" name="470" href="#470">470</a>the assertion is satisfied. If the types are different, the function call will
<a class="l" name="471" href="#471">471</a>fail to compile, the compiler error message will say that
<a class="l" name="472" href="#472">472</a>`T1 and T2 are not the same type` and most likely (depending on the compiler)
<a class="l" name="473" href="#473">473</a>show you the actual values of `T1` and `T2`. This is mainly useful inside
<a class="l" name="474" href="#474">474</a>template code.
<a class="l" name="475" href="#475">475</a>
<a class="l" name="476" href="#476">476</a>**Caveat**: When used inside a member function of a class template or a function
<a class="l" name="477" href="#477">477</a>template, `StaticAssertTypeEq&lt;T1, T2&gt;()` is effective only if the function is
<a class="l" name="478" href="#478">478</a>instantiated. For example, given:
<a class="l" name="479" href="#479">479</a>
<a class="hl" name="480" href="#480">480</a>```c++
<a class="l" name="481" href="#481">481</a>template &lt;typename T&gt; class Foo {
<a class="l" name="482" href="#482">482</a> public:
<a class="l" name="483" href="#483">483</a>  void Bar() { testing::StaticAssertTypeEq&lt;int, T&gt;(); }
<a class="l" name="484" href="#484">484</a>};
<a class="l" name="485" href="#485">485</a>```
<a class="l" name="486" href="#486">486</a>
<a class="l" name="487" href="#487">487</a>the code:
<a class="l" name="488" href="#488">488</a>
<a class="l" name="489" href="#489">489</a>```c++
<a class="hl" name="490" href="#490">490</a>void Test1() { Foo&lt;bool&gt; foo; }
<a class="l" name="491" href="#491">491</a>```
<a class="l" name="492" href="#492">492</a>
<a class="l" name="493" href="#493">493</a>will not generate a compiler error, as `Foo&lt;bool&gt;::Bar()` is never actually
<a class="l" name="494" href="#494">494</a>instantiated. Instead, you need:
<a class="l" name="495" href="#495">495</a>
<a class="l" name="496" href="#496">496</a>```c++
<a class="l" name="497" href="#497">497</a>void Test2() { Foo&lt;bool&gt; foo; <a href="/googletest/s?path=foo.Bar&amp;project=googletest">foo.Bar</a>(); }
<a class="l" name="498" href="#498">498</a>```
<a class="l" name="499" href="#499">499</a>
<a class="hl" name="500" href="#500">500</a>to cause a compiler error.
<a class="l" name="501" href="#501">501</a>
<a class="l" name="502" href="#502">502</a>### Assertion Placement
<a class="l" name="503" href="#503">503</a>
<a class="l" name="504" href="#504">504</a>You can use assertions in any C++ function. In particular, it doesn't have to be
<a class="l" name="505" href="#505">505</a>a method of the test fixture class. The one constraint is that assertions that
<a class="l" name="506" href="#506">506</a>generate a fatal failure (`FAIL*` and `ASSERT_*`) can only be used in
<a class="l" name="507" href="#507">507</a>void-returning functions. This is a consequence of Google's not using
<a class="l" name="508" href="#508">508</a>exceptions. By placing it in a non-void function you'll get a confusing compile
<a class="l" name="509" href="#509">509</a>error like `"error: void value not ignored as it ought to be"` or `"cannot
<a class="hl" name="510" href="#510">510</a>initialize return object of type 'bool' with an rvalue of type 'void'"` or
<a class="l" name="511" href="#511">511</a>`"error: no viable conversion from 'void' to 'string'"`.
<a class="l" name="512" href="#512">512</a>
<a class="l" name="513" href="#513">513</a>If you need to use fatal assertions in a function that returns non-void, one
<a class="l" name="514" href="#514">514</a>option is to make the function return the value in an out parameter instead. For
<a class="l" name="515" href="#515">515</a>example, you can rewrite `T2 Foo(T1 x)` to `void Foo(T1 x, T2* result)`. You
<a class="l" name="516" href="#516">516</a>need to make sure that `*result` contains some sensible value even when the
<a class="l" name="517" href="#517">517</a>function returns prematurely. As the function now returns `void`, you can use
<a class="l" name="518" href="#518">518</a>any assertion inside of it.
<a class="l" name="519" href="#519">519</a>
<a class="hl" name="520" href="#520">520</a>If changing the function's type is not an option, you should just use assertions
<a class="l" name="521" href="#521">521</a>that generate non-fatal failures, such as `ADD_FAILURE*` and `EXPECT_*`.
<a class="l" name="522" href="#522">522</a>
<a class="l" name="523" href="#523">523</a>NOTE: Constructors and destructors are not considered void-returning functions,
<a class="l" name="524" href="#524">524</a>according to the C++ language specification, and so you may not use fatal
<a class="l" name="525" href="#525">525</a>assertions in them; you'll get a compilation error if you try. Instead, either
<a class="l" name="526" href="#526">526</a>call `abort` and crash the entire test executable, or put the fatal assertion in
<a class="l" name="527" href="#527">527</a>a `SetUp`/`TearDown` function; see
<a class="l" name="528" href="#528">528</a>[<a href="/googletest/s?path=constructor/destructor&amp;project=googletest">constructor/destructor</a> vs. `SetUp`/`TearDown`](<a href="/googletest/s?path=faq.md&amp;project=googletest">faq.md</a>#CtorVsSetUp)
<a class="l" name="529" href="#529">529</a>
<a class="hl" name="530" href="#530">530</a>WARNING: A fatal assertion in a helper function (private void-returning method)
<a class="l" name="531" href="#531">531</a>called from a constructor or destructor does not terminate the current test, as
<a class="l" name="532" href="#532">532</a>your intuition might suggest: it merely returns from the constructor or
<a class="l" name="533" href="#533">533</a>destructor early, possibly leaving your object in a partially-constructed or
<a class="l" name="534" href="#534">534</a>partially-destructed state! You almost certainly want to `abort` or use
<a class="l" name="535" href="#535">535</a>`SetUp`/`TearDown` instead.
<a class="l" name="536" href="#536">536</a>
<a class="l" name="537" href="#537">537</a>## Teaching googletest How to Print Your Values
<a class="l" name="538" href="#538">538</a>
<a class="l" name="539" href="#539">539</a>When a test assertion such as `EXPECT_EQ` fails, googletest prints the argument
<a class="hl" name="540" href="#540">540</a>values to help you debug. It does this using a user-extensible value printer.
<a class="l" name="541" href="#541">541</a>
<a class="l" name="542" href="#542">542</a>This printer knows how to print built-in C++ types, native arrays, STL
<a class="l" name="543" href="#543">543</a>containers, and any type that supports the `&lt;&lt;` operator. For other types, it
<a class="l" name="544" href="#544">544</a>prints the raw bytes in the value and hopes that you the user can figure it out.
<a class="l" name="545" href="#545">545</a>
<a class="l" name="546" href="#546">546</a>As mentioned earlier, the printer is *extensible*. That means you can teach it
<a class="l" name="547" href="#547">547</a>to do a better job at printing your particular type than to dump the bytes. To
<a class="l" name="548" href="#548">548</a>do that, define `&lt;&lt;` for your type:
<a class="l" name="549" href="#549">549</a>
<a class="hl" name="550" href="#550">550</a>```c++
<a class="l" name="551" href="#551">551</a>#include &lt;ostream&gt;
<a class="l" name="552" href="#552">552</a>
<a class="l" name="553" href="#553">553</a>namespace foo {
<a class="l" name="554" href="#554">554</a>
<a class="l" name="555" href="#555">555</a>class Bar {  // We want googletest to be able to print instances of this.
<a class="l" name="556" href="#556">556</a>...
<a class="l" name="557" href="#557">557</a>  // Create a free inline friend function.
<a class="l" name="558" href="#558">558</a>  friend std::ostream&amp; operator&lt;&lt;(std::ostream&amp; os, const Bar&amp; bar) {
<a class="l" name="559" href="#559">559</a>    return os &lt;&lt; <a href="/googletest/s?path=bar.DebugString&amp;project=googletest">bar.DebugString</a>();  // whatever needed to print bar to os
<a class="hl" name="560" href="#560">560</a>  }
<a class="l" name="561" href="#561">561</a>};
<a class="l" name="562" href="#562">562</a>
<a class="l" name="563" href="#563">563</a>// If you can't declare the function in the class it's important that the
<a class="l" name="564" href="#564">564</a>// &lt;&lt; operator is defined in the SAME namespace that defines Bar.  C++'s look-up
<a class="l" name="565" href="#565">565</a>// rules rely on that.
<a class="l" name="566" href="#566">566</a>std::ostream&amp; operator&lt;&lt;(std::ostream&amp; os, const Bar&amp; bar) {
<a class="l" name="567" href="#567">567</a>  return os &lt;&lt; <a href="/googletest/s?path=bar.DebugString&amp;project=googletest">bar.DebugString</a>();  // whatever needed to print bar to os
<a class="l" name="568" href="#568">568</a>}
<a class="l" name="569" href="#569">569</a>
<a class="hl" name="570" href="#570">570</a>}  // namespace foo
<a class="l" name="571" href="#571">571</a>```
<a class="l" name="572" href="#572">572</a>
<a class="l" name="573" href="#573">573</a>Sometimes, this might not be an option: your team may consider it bad style to
<a class="l" name="574" href="#574">574</a>have a `&lt;&lt;` operator for `Bar`, or `Bar` may already have a `&lt;&lt;` operator that
<a class="l" name="575" href="#575">575</a>doesn't do what you want (and you cannot change it). If so, you can instead
<a class="l" name="576" href="#576">576</a>define a `PrintTo()` function like this:
<a class="l" name="577" href="#577">577</a>
<a class="l" name="578" href="#578">578</a>```c++
<a class="l" name="579" href="#579">579</a>#include &lt;ostream&gt;
<a class="hl" name="580" href="#580">580</a>
<a class="l" name="581" href="#581">581</a>namespace foo {
<a class="l" name="582" href="#582">582</a>
<a class="l" name="583" href="#583">583</a>class Bar {
<a class="l" name="584" href="#584">584</a>  ...
<a class="l" name="585" href="#585">585</a>  friend void PrintTo(const Bar&amp; bar, std::ostream* os) {
<a class="l" name="586" href="#586">586</a>    *os &lt;&lt; <a href="/googletest/s?path=bar.DebugString&amp;project=googletest">bar.DebugString</a>();  // whatever needed to print bar to os
<a class="l" name="587" href="#587">587</a>  }
<a class="l" name="588" href="#588">588</a>};
<a class="l" name="589" href="#589">589</a>
<a class="hl" name="590" href="#590">590</a>// If you can't declare the function in the class it's important that PrintTo()
<a class="l" name="591" href="#591">591</a>// is defined in the SAME namespace that defines Bar.  C++'s look-up rules rely
<a class="l" name="592" href="#592">592</a>// on that.
<a class="l" name="593" href="#593">593</a>void PrintTo(const Bar&amp; bar, std::ostream* os) {
<a class="l" name="594" href="#594">594</a>  *os &lt;&lt; <a href="/googletest/s?path=bar.DebugString&amp;project=googletest">bar.DebugString</a>();  // whatever needed to print bar to os
<a class="l" name="595" href="#595">595</a>}
<a class="l" name="596" href="#596">596</a>
<a class="l" name="597" href="#597">597</a>}  // namespace foo
<a class="l" name="598" href="#598">598</a>```
<a class="l" name="599" href="#599">599</a>
<a class="hl" name="600" href="#600">600</a>If you have defined both `&lt;&lt;` and `PrintTo()`, the latter will be used when
<a class="l" name="601" href="#601">601</a>googletest is concerned. This allows you to customize how the value appears in
<a class="l" name="602" href="#602">602</a>googletest's output without affecting code that relies on the behavior of its
<a class="l" name="603" href="#603">603</a>`&lt;&lt;` operator.
<a class="l" name="604" href="#604">604</a>
<a class="l" name="605" href="#605">605</a>If you want to print a value `x` using googletest's value printer yourself, just
<a class="l" name="606" href="#606">606</a>call `::testing::PrintToString(x)`, which returns an `std::string`:
<a class="l" name="607" href="#607">607</a>
<a class="l" name="608" href="#608">608</a>```c++
<a class="l" name="609" href="#609">609</a>vector&lt;pair&lt;Bar, int&gt; &gt; bar_ints = GetBarIntVector();
<a class="hl" name="610" href="#610">610</a>
<a class="l" name="611" href="#611">611</a>EXPECT_TRUE(IsCorrectBarIntVector(bar_ints))
<a class="l" name="612" href="#612">612</a>    &lt;&lt; "bar_ints = " &lt;&lt; testing::PrintToString(bar_ints);
<a class="l" name="613" href="#613">613</a>```
<a class="l" name="614" href="#614">614</a>
<a class="l" name="615" href="#615">615</a>## Death Tests
<a class="l" name="616" href="#616">616</a>
<a class="l" name="617" href="#617">617</a>In many applications, there are assertions that can cause application failure if
<a class="l" name="618" href="#618">618</a>a condition is not met. These sanity checks, which ensure that the program is in
<a class="l" name="619" href="#619">619</a>a known good state, are there to fail at the earliest possible time after some
<a class="hl" name="620" href="#620">620</a>program state is corrupted. If the assertion checks the wrong condition, then
<a class="l" name="621" href="#621">621</a>the program may proceed in an erroneous state, which could lead to memory
<a class="l" name="622" href="#622">622</a>corruption, security holes, or worse. Hence it is vitally important to test that
<a class="l" name="623" href="#623">623</a>such assertion statements work as expected.
<a class="l" name="624" href="#624">624</a>
<a class="l" name="625" href="#625">625</a>Since these precondition checks cause the processes to die, we call such tests
<a class="l" name="626" href="#626">626</a>_death tests_. More generally, any test that checks that a program terminates
<a class="l" name="627" href="#627">627</a>(except by throwing an exception) in an expected fashion is also a death test.
<a class="l" name="628" href="#628">628</a>
<a class="l" name="629" href="#629">629</a>Note that if a piece of code throws an exception, we don't consider it "death"
<a class="hl" name="630" href="#630">630</a>for the purpose of death tests, as the caller of the code could catch the
<a class="l" name="631" href="#631">631</a>exception and avoid the crash. If you want to verify exceptions thrown by your
<a class="l" name="632" href="#632">632</a>code, see [Exception Assertions](#ExceptionAssertions).
<a class="l" name="633" href="#633">633</a>
<a class="l" name="634" href="#634">634</a>If you want to test `EXPECT_*()/ASSERT_*()` failures in your test code, see
<a class="l" name="635" href="#635">635</a>Catching Failures
<a class="l" name="636" href="#636">636</a>
<a class="l" name="637" href="#637">637</a>### How to Write a Death Test
<a class="l" name="638" href="#638">638</a>
<a class="l" name="639" href="#639">639</a>googletest has the following macros to support death tests:
<a class="hl" name="640" href="#640">640</a>
<a class="l" name="641" href="#641">641</a>Fatal assertion                                  | Nonfatal assertion                               | Verifies
<a class="l" name="642" href="#642">642</a>------------------------------------------------ | ------------------------------------------------ | --------
<a class="l" name="643" href="#643">643</a>`ASSERT_DEATH(statement, matcher);`              | `EXPECT_DEATH(statement, matcher);`              | `statement` crashes with the given error
<a class="l" name="644" href="#644">644</a>`ASSERT_DEATH_IF_SUPPORTED(statement, matcher);` | `EXPECT_DEATH_IF_SUPPORTED(statement, matcher);` | if death tests are supported, verifies that `statement` crashes with the given error; otherwise verifies nothing
<a class="l" name="645" href="#645">645</a>`ASSERT_DEBUG_DEATH(statement, matcher);`        | `EXPECT_DEBUG_DEATH(statement, matcher);`        | `statement` crashes with the given error **in debug mode**. When not in debug (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> `NDEBUG` is defined), this just executes `statement`
<a class="l" name="646" href="#646">646</a>`ASSERT_EXIT(statement, predicate, matcher);`    | `EXPECT_EXIT(statement, predicate, matcher);`    | `statement` exits with the given error, and its exit code matches `predicate`
<a class="l" name="647" href="#647">647</a>
<a class="l" name="648" href="#648">648</a>where `statement` is a statement that is expected to cause the process to die,
<a class="l" name="649" href="#649">649</a>`predicate` is a function or function object that evaluates an integer exit
<a class="hl" name="650" href="#650">650</a>status, and `matcher` is either a gMock matcher matching a `const std::string&amp;`
<a class="l" name="651" href="#651">651</a>or a (Perl) regular expression - either of which is matched against the stderr
<a class="l" name="652" href="#652">652</a>output of `statement`. For legacy reasons, a bare string (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> with no matcher)
<a class="l" name="653" href="#653">653</a>is interpreted as `ContainsRegex(str)`, **not** `Eq(str)`. Note that `statement`
<a class="l" name="654" href="#654">654</a>can be *any valid statement* (including *compound statement*) and doesn't have
<a class="l" name="655" href="#655">655</a>to be an expression.
<a class="l" name="656" href="#656">656</a>
<a class="l" name="657" href="#657">657</a>As usual, the `ASSERT` variants abort the current test function, while the
<a class="l" name="658" href="#658">658</a>`EXPECT` variants do not.
<a class="l" name="659" href="#659">659</a>
<a class="hl" name="660" href="#660">660</a>&gt; NOTE: We use the word "crash" here to mean that the process terminates with a
<a class="l" name="661" href="#661">661</a>&gt; *non-zero* exit status code. There are two possibilities: either the process
<a class="l" name="662" href="#662">662</a>&gt; has called `exit()` or `_exit()` with a non-zero value, or it may be killed by
<a class="l" name="663" href="#663">663</a>&gt; a signal.
<a class="l" name="664" href="#664">664</a>&gt;
<a class="l" name="665" href="#665">665</a>&gt; This means that if *`statement`* terminates the process with a 0 exit code, it
<a class="l" name="666" href="#666">666</a>&gt; is *not* considered a crash by `EXPECT_DEATH`. Use `EXPECT_EXIT` instead if
<a class="l" name="667" href="#667">667</a>&gt; this is the case, or if you want to restrict the exit code more precisely.
<a class="l" name="668" href="#668">668</a>
<a class="l" name="669" href="#669">669</a>A predicate here must accept an `int` and return a `bool`. The death test
<a class="hl" name="670" href="#670">670</a>succeeds only if the predicate returns `true`. googletest defines a few
<a class="l" name="671" href="#671">671</a>predicates that handle the most common cases:
<a class="l" name="672" href="#672">672</a>
<a class="l" name="673" href="#673">673</a>```c++
<a class="l" name="674" href="#674">674</a>::testing::ExitedWithCode(exit_code)
<a class="l" name="675" href="#675">675</a>```
<a class="l" name="676" href="#676">676</a>
<a class="l" name="677" href="#677">677</a>This expression is `true` if the program exited normally with the given exit
<a class="l" name="678" href="#678">678</a>code.
<a class="l" name="679" href="#679">679</a>
<a class="hl" name="680" href="#680">680</a>```c++
<a class="l" name="681" href="#681">681</a>testing::KilledBySignal(signal_number)  // Not available on Windows.
<a class="l" name="682" href="#682">682</a>```
<a class="l" name="683" href="#683">683</a>
<a class="l" name="684" href="#684">684</a>This expression is `true` if the program was killed by the given signal.
<a class="l" name="685" href="#685">685</a>
<a class="l" name="686" href="#686">686</a>The `*_DEATH` macros are convenient wrappers for `*_EXIT` that use a predicate
<a class="l" name="687" href="#687">687</a>that verifies the process' exit code is non-zero.
<a class="l" name="688" href="#688">688</a>
<a class="l" name="689" href="#689">689</a>Note that a death test only cares about three things:
<a class="hl" name="690" href="#690">690</a>
<a class="l" name="691" href="#691">691</a>1.  does `statement` abort or exit the process?
<a class="l" name="692" href="#692">692</a>2.  (in the case of `ASSERT_EXIT` and `EXPECT_EXIT`) does the exit status
<a class="l" name="693" href="#693">693</a>    satisfy `predicate`? Or (in the case of `ASSERT_DEATH` and `EXPECT_DEATH`)
<a class="l" name="694" href="#694">694</a>    is the exit status non-zero? And
<a class="l" name="695" href="#695">695</a>3.  does the stderr output match `matcher`?
<a class="l" name="696" href="#696">696</a>
<a class="l" name="697" href="#697">697</a>In particular, if `statement` generates an `ASSERT_*` or `EXPECT_*` failure, it
<a class="l" name="698" href="#698">698</a>will **not** cause the death test to fail, as googletest assertions don't abort
<a class="l" name="699" href="#699">699</a>the process.
<a class="hl" name="700" href="#700">700</a>
<a class="l" name="701" href="#701">701</a>To write a death test, simply use one of the above macros inside your test
<a class="l" name="702" href="#702">702</a>function. For example,
<a class="l" name="703" href="#703">703</a>
<a class="l" name="704" href="#704">704</a>```c++
<a class="l" name="705" href="#705">705</a>TEST(MyDeathTest, Foo) {
<a class="l" name="706" href="#706">706</a>  // This death test uses a compound statement.
<a class="l" name="707" href="#707">707</a>  ASSERT_DEATH({
<a class="l" name="708" href="#708">708</a>    int n = 5;
<a class="l" name="709" href="#709">709</a>    Foo(&amp;n);
<a class="hl" name="710" href="#710">710</a>  }, "Error on line .* of Foo()");
<a class="l" name="711" href="#711">711</a>}
<a class="l" name="712" href="#712">712</a>
<a class="l" name="713" href="#713">713</a>TEST(MyDeathTest, NormalExit) {
<a class="l" name="714" href="#714">714</a>  EXPECT_EXIT(NormalExit(), testing::ExitedWithCode(0), "Success");
<a class="l" name="715" href="#715">715</a>}
<a class="l" name="716" href="#716">716</a>
<a class="l" name="717" href="#717">717</a>TEST(MyDeathTest, KillMyself) {
<a class="l" name="718" href="#718">718</a>  EXPECT_EXIT(KillMyself(), testing::KilledBySignal(SIGKILL),
<a class="l" name="719" href="#719">719</a>              "Sending myself unblockable signal");
<a class="hl" name="720" href="#720">720</a>}
<a class="l" name="721" href="#721">721</a>```
<a class="l" name="722" href="#722">722</a>
<a class="l" name="723" href="#723">723</a>verifies that:
<a class="l" name="724" href="#724">724</a>
<a class="l" name="725" href="#725">725</a>*   calling `Foo(5)` causes the process to die with the given error message,
<a class="l" name="726" href="#726">726</a>*   calling `NormalExit()` causes the process to print `"Success"` to stderr and
<a class="l" name="727" href="#727">727</a>    exit with exit code 0, and
<a class="l" name="728" href="#728">728</a>*   calling `KillMyself()` kills the process with signal `SIGKILL`.
<a class="l" name="729" href="#729">729</a>
<a class="hl" name="730" href="#730">730</a>The test function body may contain other assertions and statements as well, if
<a class="l" name="731" href="#731">731</a>necessary.
<a class="l" name="732" href="#732">732</a>
<a class="l" name="733" href="#733">733</a>### Death Test Naming
<a class="l" name="734" href="#734">734</a>
<a class="l" name="735" href="#735">735</a>IMPORTANT: We strongly recommend you to follow the convention of naming your
<a class="l" name="736" href="#736">736</a>**test suite** (not test) `*DeathTest` when it contains a death test, as
<a class="l" name="737" href="#737">737</a>demonstrated in the above example. The
<a class="l" name="738" href="#738">738</a>[Death Tests And Threads](#death-tests-and-threads) section below explains why.
<a class="l" name="739" href="#739">739</a>
<a class="hl" name="740" href="#740">740</a>If a test fixture class is shared by normal tests and death tests, you can use
<a class="l" name="741" href="#741">741</a>`using` or `typedef` to introduce an alias for the fixture class and avoid
<a class="l" name="742" href="#742">742</a>duplicating its code:
<a class="l" name="743" href="#743">743</a>
<a class="l" name="744" href="#744">744</a>```c++
<a class="l" name="745" href="#745">745</a>class FooTest : public testing::Test { ... };
<a class="l" name="746" href="#746">746</a>
<a class="l" name="747" href="#747">747</a>using FooDeathTest = FooTest;
<a class="l" name="748" href="#748">748</a>
<a class="l" name="749" href="#749">749</a>TEST_F(FooTest, DoesThis) {
<a class="hl" name="750" href="#750">750</a>  // normal test
<a class="l" name="751" href="#751">751</a>}
<a class="l" name="752" href="#752">752</a>
<a class="l" name="753" href="#753">753</a>TEST_F(FooDeathTest, DoesThat) {
<a class="l" name="754" href="#754">754</a>  // death test
<a class="l" name="755" href="#755">755</a>}
<a class="l" name="756" href="#756">756</a>```
<a class="l" name="757" href="#757">757</a>
<a class="l" name="758" href="#758">758</a>### Regular Expression Syntax
<a class="l" name="759" href="#759">759</a>
<a class="hl" name="760" href="#760">760</a>On POSIX systems (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> Linux, Cygwin, and Mac), googletest uses the
<a class="l" name="761" href="#761">761</a>[POSIX extended regular expression](<a href="http://www.opengroup.org/onlinepubs/009695399/basedefs/xbd_chap09.html">http://www.opengroup.org/onlinepubs/009695399/basedefs/xbd_chap09.html</a>#tag_09_04)
<a class="l" name="762" href="#762">762</a>syntax. To learn about this syntax, you may want to read this
<a class="l" name="763" href="#763">763</a>[Wikipedia entry](<a href="http://en.wikipedia.org/wiki/Regular_expression">http://en.wikipedia.org/wiki/Regular_expression</a>#POSIX_Extended_Regular_Expressions).
<a class="l" name="764" href="#764">764</a>
<a class="l" name="765" href="#765">765</a>On Windows, googletest uses its own simple regular expression implementation. It
<a class="l" name="766" href="#766">766</a>lacks many features. For example, we don't support union (`"x|y"`), grouping
<a class="l" name="767" href="#767">767</a>(`"(xy)"`), brackets (`"[xy]"`), and repetition count (`"x{5,7}"`), among
<a class="l" name="768" href="#768">768</a>others. Below is what we do support (`A` denotes a literal character, period
<a class="l" name="769" href="#769">769</a>(`.`), or a single `\\ ` escape sequence; `x` and `y` denote regular
<a class="hl" name="770" href="#770">770</a>expressions.):
<a class="l" name="771" href="#771">771</a>
<a class="l" name="772" href="#772">772</a>Expression | Meaning
<a class="l" name="773" href="#773">773</a>---------- | --------------------------------------------------------------
<a class="l" name="774" href="#774">774</a>`c`        | matches any literal character `c`
<a class="l" name="775" href="#775">775</a>`\\d`      | matches any decimal digit
<a class="l" name="776" href="#776">776</a>`\\D`      | matches any character that's not a decimal digit
<a class="l" name="777" href="#777">777</a>`\\f`      | matches `\f`
<a class="l" name="778" href="#778">778</a>`\\n`      | matches `\n`
<a class="l" name="779" href="#779">779</a>`\\r`      | matches `\r`
<a class="hl" name="780" href="#780">780</a>`\\s`      | matches any ASCII whitespace, including `\n`
<a class="l" name="781" href="#781">781</a>`\\S`      | matches any character that's not a whitespace
<a class="l" name="782" href="#782">782</a>`\\t`      | matches `\t`
<a class="l" name="783" href="#783">783</a>`\\v`      | matches `\v`
<a class="l" name="784" href="#784">784</a>`\\w`      | matches any letter, `_`, or decimal digit
<a class="l" name="785" href="#785">785</a>`\\W`      | matches any character that `\\w` doesn't match
<a class="l" name="786" href="#786">786</a>`\\c`      | matches any literal character `c`, which must be a punctuation
<a class="l" name="787" href="#787">787</a>`.`        | matches any single character except `\n`
<a class="l" name="788" href="#788">788</a>`A?`       | matches 0 or 1 occurrences of `A`
<a class="l" name="789" href="#789">789</a>`A*`       | matches 0 or many occurrences of `A`
<a class="hl" name="790" href="#790">790</a>`A+`       | matches 1 or many occurrences of `A`
<a class="l" name="791" href="#791">791</a>`^`        | matches the beginning of a string (not that of each line)
<a class="l" name="792" href="#792">792</a>`$`        | matches the end of a string (not that of each line)
<a class="l" name="793" href="#793">793</a>`xy`       | matches `x` followed by `y`
<a class="l" name="794" href="#794">794</a>
<a class="l" name="795" href="#795">795</a>To help you determine which capability is available on your system, googletest
<a class="l" name="796" href="#796">796</a>defines macros to govern which regular expression it is using. The macros are:
<a class="l" name="797" href="#797">797</a>`GTEST_USES_SIMPLE_RE=1` or `GTEST_USES_POSIX_RE=1`. If you want your death
<a class="l" name="798" href="#798">798</a>tests to work in all cases, you can either `#if` on these macros or use the more
<a class="l" name="799" href="#799">799</a>limited syntax only.
<a class="hl" name="800" href="#800">800</a>
<a class="l" name="801" href="#801">801</a>### How It Works
<a class="l" name="802" href="#802">802</a>
<a class="l" name="803" href="#803">803</a>Under the hood, `ASSERT_EXIT()` spawns a new process and executes the death test
<a class="l" name="804" href="#804">804</a>statement in that process. The details of how precisely that happens depend on
<a class="l" name="805" href="#805">805</a>the platform and the variable `::testing::GTEST_FLAG(death_test_style)` (which is
<a class="l" name="806" href="#806">806</a>initialized from the command-line flag `--gtest_death_test_style`).
<a class="l" name="807" href="#807">807</a>
<a class="l" name="808" href="#808">808</a>*   On POSIX systems, `fork()` (or `clone()` on Linux) is used to spawn the
<a class="l" name="809" href="#809">809</a>    child, after which:
<a class="hl" name="810" href="#810">810</a>    *   If the variable's value is `"fast"`, the death test statement is
<a class="l" name="811" href="#811">811</a>        immediately executed.
<a class="l" name="812" href="#812">812</a>    *   If the variable's value is `"threadsafe"`, the child process re-executes
<a class="l" name="813" href="#813">813</a>        the unit test binary just as it was originally invoked, but with some
<a class="l" name="814" href="#814">814</a>        extra flags to cause just the single death test under consideration to
<a class="l" name="815" href="#815">815</a>        be run.
<a class="l" name="816" href="#816">816</a>*   On Windows, the child is spawned using the `CreateProcess()` API, and
<a class="l" name="817" href="#817">817</a>    re-executes the binary to cause just the single death test under
<a class="l" name="818" href="#818">818</a>    consideration to be run - much like the `threadsafe` mode on POSIX.
<a class="l" name="819" href="#819">819</a>
<a class="hl" name="820" href="#820">820</a>Other values for the variable are illegal and will cause the death test to fail.
<a class="l" name="821" href="#821">821</a>Currently, the flag's default value is **"fast"**
<a class="l" name="822" href="#822">822</a>
<a class="l" name="823" href="#823">823</a>1.  the child's exit status satisfies the predicate, and
<a class="l" name="824" href="#824">824</a>2.  the child's stderr matches the regular expression.
<a class="l" name="825" href="#825">825</a>
<a class="l" name="826" href="#826">826</a>If the death test statement runs to completion without dying, the child process
<a class="l" name="827" href="#827">827</a>will nonetheless terminate, and the assertion fails.
<a class="l" name="828" href="#828">828</a>
<a class="l" name="829" href="#829">829</a>### Death Tests And Threads
<a class="hl" name="830" href="#830">830</a>
<a class="l" name="831" href="#831">831</a>The reason for the two death test styles has to do with thread safety. Due to
<a class="l" name="832" href="#832">832</a>well-known problems with forking in the presence of threads, death tests should
<a class="l" name="833" href="#833">833</a>be run in a single-threaded context. Sometimes, however, it isn't feasible to
<a class="l" name="834" href="#834">834</a>arrange that kind of environment. For example, statically-initialized modules
<a class="l" name="835" href="#835">835</a>may start threads before main is ever reached. Once threads have been created,
<a class="l" name="836" href="#836">836</a>it may be difficult or impossible to clean them up.
<a class="l" name="837" href="#837">837</a>
<a class="l" name="838" href="#838">838</a>googletest has three features intended to raise awareness of threading issues.
<a class="l" name="839" href="#839">839</a>
<a class="hl" name="840" href="#840">840</a>1.  A warning is emitted if multiple threads are running when a death test is
<a class="l" name="841" href="#841">841</a>    encountered.
<a class="l" name="842" href="#842">842</a>2.  Test suites with a name ending in "DeathTest" are run before all other
<a class="l" name="843" href="#843">843</a>    tests.
<a class="l" name="844" href="#844">844</a>3.  It uses `clone()` instead of `fork()` to spawn the child process on Linux
<a class="l" name="845" href="#845">845</a>    (`clone()` is not available on Cygwin and Mac), as `fork()` is more likely
<a class="l" name="846" href="#846">846</a>    to cause the child to hang when the parent process has multiple threads.
<a class="l" name="847" href="#847">847</a>
<a class="l" name="848" href="#848">848</a>It's perfectly fine to create threads inside a death test statement; they are
<a class="l" name="849" href="#849">849</a>executed in a separate process and cannot affect the parent.
<a class="hl" name="850" href="#850">850</a>
<a class="l" name="851" href="#851">851</a>### Death Test Styles
<a class="l" name="852" href="#852">852</a>
<a class="l" name="853" href="#853">853</a>The "threadsafe" death test style was introduced in order to help mitigate the
<a class="l" name="854" href="#854">854</a>risks of testing in a possibly multithreaded environment. It trades increased
<a class="l" name="855" href="#855">855</a>test execution time (potentially dramatically so) for improved thread safety.
<a class="l" name="856" href="#856">856</a>
<a class="l" name="857" href="#857">857</a>The automated testing framework does not set the style flag. You can choose a
<a class="l" name="858" href="#858">858</a>particular style of death tests by setting the flag programmatically:
<a class="l" name="859" href="#859">859</a>
<a class="hl" name="860" href="#860">860</a>```c++
<a class="l" name="861" href="#861">861</a>testing::FLAGS_gtest_death_test_style="threadsafe"
<a class="l" name="862" href="#862">862</a>```
<a class="l" name="863" href="#863">863</a>
<a class="l" name="864" href="#864">864</a>You can do this in `main()` to set the style for all death tests in the binary,
<a class="l" name="865" href="#865">865</a>or in individual tests. Recall that flags are saved before running each test and
<a class="l" name="866" href="#866">866</a>restored afterwards, so you need not do that yourself. For example:
<a class="l" name="867" href="#867">867</a>
<a class="l" name="868" href="#868">868</a>```c++
<a class="l" name="869" href="#869">869</a>int main(int argc, char** argv) {
<a class="hl" name="870" href="#870">870</a>  testing::InitGoogleTest(&amp;argc, argv);
<a class="l" name="871" href="#871">871</a>  testing::FLAGS_gtest_death_test_style = "fast";
<a class="l" name="872" href="#872">872</a>  return RUN_ALL_TESTS();
<a class="l" name="873" href="#873">873</a>}
<a class="l" name="874" href="#874">874</a>
<a class="l" name="875" href="#875">875</a>TEST(MyDeathTest, TestOne) {
<a class="l" name="876" href="#876">876</a>  testing::FLAGS_gtest_death_test_style = "threadsafe";
<a class="l" name="877" href="#877">877</a>  // This test is run in the "threadsafe" style:
<a class="l" name="878" href="#878">878</a>  ASSERT_DEATH(ThisShouldDie(), "");
<a class="l" name="879" href="#879">879</a>}
<a class="hl" name="880" href="#880">880</a>
<a class="l" name="881" href="#881">881</a>TEST(MyDeathTest, TestTwo) {
<a class="l" name="882" href="#882">882</a>  // This test is run in the "fast" style:
<a class="l" name="883" href="#883">883</a>  ASSERT_DEATH(ThisShouldDie(), "");
<a class="l" name="884" href="#884">884</a>}
<a class="l" name="885" href="#885">885</a>```
<a class="l" name="886" href="#886">886</a>
<a class="l" name="887" href="#887">887</a>### Caveats
<a class="l" name="888" href="#888">888</a>
<a class="l" name="889" href="#889">889</a>The `statement` argument of `ASSERT_EXIT()` can be any valid C++ statement. If
<a class="hl" name="890" href="#890">890</a>it leaves the current function via a `return` statement or by throwing an
<a class="l" name="891" href="#891">891</a>exception, the death test is considered to have failed. Some googletest macros
<a class="l" name="892" href="#892">892</a>may return from the current function (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `ASSERT_TRUE()`), so be sure to avoid
<a class="l" name="893" href="#893">893</a>them in `statement`.
<a class="l" name="894" href="#894">894</a>
<a class="l" name="895" href="#895">895</a>Since `statement` runs in the child process, any in-memory side effect (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="l" name="896" href="#896">896</a>modifying a variable, releasing memory, etc) it causes will *not* be observable
<a class="l" name="897" href="#897">897</a>in the parent process. In particular, if you release memory in a death test,
<a class="l" name="898" href="#898">898</a>your program will fail the heap check as the parent process will never see the
<a class="l" name="899" href="#899">899</a>memory reclaimed. To solve this problem, you can
<a class="hl" name="900" href="#900">900</a>
<a class="l" name="901" href="#901">901</a>1.  try not to free memory in a death test;
<a class="l" name="902" href="#902">902</a>2.  free the memory again in the parent process; or
<a class="l" name="903" href="#903">903</a>3.  do not use the heap checker in your program.
<a class="l" name="904" href="#904">904</a>
<a class="l" name="905" href="#905">905</a>Due to an implementation detail, you cannot place multiple death test assertions
<a class="l" name="906" href="#906">906</a>on the same line; otherwise, compilation will fail with an unobvious error
<a class="l" name="907" href="#907">907</a>message.
<a class="l" name="908" href="#908">908</a>
<a class="l" name="909" href="#909">909</a>Despite the improved thread safety afforded by the "threadsafe" style of death
<a class="hl" name="910" href="#910">910</a>test, thread problems such as deadlock are still possible in the presence of
<a class="l" name="911" href="#911">911</a>handlers registered with `pthread_atfork(3)`.
<a class="l" name="912" href="#912">912</a>
<a class="l" name="913" href="#913">913</a>
<a class="l" name="914" href="#914">914</a>## Using Assertions in Sub-routines
<a class="l" name="915" href="#915">915</a>
<a class="l" name="916" href="#916">916</a>Note: If you want to put a series of test assertions in a subroutine to check
<a class="l" name="917" href="#917">917</a>for a complex condition, consider using
<a class="l" name="918" href="#918">918</a>[a custom GMock matcher](../..<a href="/googletest/s?path=/googlemock/docs/cook_book.md&amp;project=googletest">/googlemock/docs/cook_book.md</a>#NewMatchers)
<a class="l" name="919" href="#919">919</a>instead. This lets you provide a more readable error message in case of failure
<a class="hl" name="920" href="#920">920</a>and avoid all of the issues described below.
<a class="l" name="921" href="#921">921</a>
<a class="l" name="922" href="#922">922</a>### Adding Traces to Assertions
<a class="l" name="923" href="#923">923</a>
<a class="l" name="924" href="#924">924</a>If a test sub-routine is called from several places, when an assertion inside it
<a class="l" name="925" href="#925">925</a>fails, it can be hard to tell which invocation of the sub-routine the failure is
<a class="l" name="926" href="#926">926</a>from. You can alleviate this problem using extra logging or custom failure
<a class="l" name="927" href="#927">927</a>messages, but that usually clutters up your tests. A better solution is to use
<a class="l" name="928" href="#928">928</a>the `SCOPED_TRACE` macro or the `ScopedTrace` utility:
<a class="l" name="929" href="#929">929</a>
<a class="hl" name="930" href="#930">930</a>```c++
<a class="l" name="931" href="#931">931</a>SCOPED_TRACE(message);
<a class="l" name="932" href="#932">932</a>```
<a class="l" name="933" href="#933">933</a>```c++
<a class="l" name="934" href="#934">934</a>ScopedTrace trace("file_path", line_number, message);
<a class="l" name="935" href="#935">935</a>```
<a class="l" name="936" href="#936">936</a>
<a class="l" name="937" href="#937">937</a>where `message` can be anything streamable to `std::ostream`. `SCOPED_TRACE`
<a class="l" name="938" href="#938">938</a>macro will cause the current file name, line number, and the given message to be
<a class="l" name="939" href="#939">939</a>added in every failure message. `ScopedTrace` accepts explicit file name and
<a class="hl" name="940" href="#940">940</a>line number in arguments, which is useful for writing test helpers. The effect
<a class="l" name="941" href="#941">941</a>will be undone when the control leaves the current lexical scope.
<a class="l" name="942" href="#942">942</a>
<a class="l" name="943" href="#943">943</a>For example,
<a class="l" name="944" href="#944">944</a>
<a class="l" name="945" href="#945">945</a>```c++
<a class="l" name="946" href="#946">946</a>10: void Sub1(int n) {
<a class="l" name="947" href="#947">947</a>11:   EXPECT_EQ(Bar(n), 1);
<a class="l" name="948" href="#948">948</a>12:   EXPECT_EQ(Bar(n + 1), 2);
<a class="l" name="949" href="#949">949</a>13: }
<a class="hl" name="950" href="#950">950</a>14:
<a class="l" name="951" href="#951">951</a>15: TEST(FooTest, Bar) {
<a class="l" name="952" href="#952">952</a>16:   {
<a class="l" name="953" href="#953">953</a>17:     SCOPED_TRACE("A");  // This trace point will be included in
<a class="l" name="954" href="#954">954</a>18:                         // every failure in this scope.
<a class="l" name="955" href="#955">955</a>19:     Sub1(1);
<a class="l" name="956" href="#956">956</a>20:   }
<a class="l" name="957" href="#957">957</a>21:   // Now it won't.
<a class="l" name="958" href="#958">958</a>22:   Sub1(9);
<a class="l" name="959" href="#959">959</a>23: }
<a class="hl" name="960" href="#960">960</a>```
<a class="l" name="961" href="#961">961</a>
<a class="l" name="962" href="#962">962</a>could result in messages like these:
<a class="l" name="963" href="#963">963</a>
<a class="l" name="964" href="#964">964</a>```none
<a class="l" name="965" href="#965">965</a><a href="/googletest/s?path=path/to/foo_test.cc&amp;project=googletest">path/to/foo_test.cc</a>:11: Failure
<a class="l" name="966" href="#966">966</a>Value of: Bar(n)
<a class="l" name="967" href="#967">967</a>Expected: 1
<a class="l" name="968" href="#968">968</a>  Actual: 2
<a class="l" name="969" href="#969">969</a>Google Test trace:
<a class="hl" name="970" href="#970">970</a><a href="/googletest/s?path=path/to/foo_test.cc&amp;project=googletest">path/to/foo_test.cc</a>:17: A
<a class="l" name="971" href="#971">971</a>
<a class="l" name="972" href="#972">972</a><a href="/googletest/s?path=path/to/foo_test.cc&amp;project=googletest">path/to/foo_test.cc</a>:12: Failure
<a class="l" name="973" href="#973">973</a>Value of: Bar(n + 1)
<a class="l" name="974" href="#974">974</a>Expected: 2
<a class="l" name="975" href="#975">975</a>  Actual: 3
<a class="l" name="976" href="#976">976</a>```
<a class="l" name="977" href="#977">977</a>
<a class="l" name="978" href="#978">978</a>Without the trace, it would've been difficult to know which invocation of
<a class="l" name="979" href="#979">979</a>`Sub1()` the two failures come from respectively. (You could add an extra
<a class="hl" name="980" href="#980">980</a>message to each assertion in `Sub1()` to indicate the value of `n`, but that's
<a class="l" name="981" href="#981">981</a>tedious.)
<a class="l" name="982" href="#982">982</a>
<a class="l" name="983" href="#983">983</a>Some tips on using `SCOPED_TRACE`:
<a class="l" name="984" href="#984">984</a>
<a class="l" name="985" href="#985">985</a>1.  With a suitable message, it's often enough to use `SCOPED_TRACE` at the
<a class="l" name="986" href="#986">986</a>    beginning of a sub-routine, instead of at each call site.
<a class="l" name="987" href="#987">987</a>2.  When calling sub-routines inside a loop, make the loop iterator part of the
<a class="l" name="988" href="#988">988</a>    message in `SCOPED_TRACE` such that you can know which iteration the failure
<a class="l" name="989" href="#989">989</a>    is from.
<a class="hl" name="990" href="#990">990</a>3.  Sometimes the line number of the trace point is enough for identifying the
<a class="l" name="991" href="#991">991</a>    particular invocation of a sub-routine. In this case, you don't have to
<a class="l" name="992" href="#992">992</a>    choose a unique message for `SCOPED_TRACE`. You can simply use `""`.
<a class="l" name="993" href="#993">993</a>4.  You can use `SCOPED_TRACE` in an inner scope when there is one in the outer
<a class="l" name="994" href="#994">994</a>    scope. In this case, all active trace points will be included in the failure
<a class="l" name="995" href="#995">995</a>    messages, in reverse order they are encountered.
<a class="l" name="996" href="#996">996</a>5.  The trace dump is clickable in Emacs - hit `return` on a line number and
<a class="l" name="997" href="#997">997</a>    you'll be taken to that line in the source file!
<a class="l" name="998" href="#998">998</a>
<a class="l" name="999" href="#999">999</a>### Propagating Fatal Failures
<a class="hl" name="1000" href="#1000">1000</a>
<a class="l" name="1001" href="#1001">1001</a>A common pitfall when using `ASSERT_*` and `FAIL*` is not understanding that
<a class="l" name="1002" href="#1002">1002</a>when they fail they only abort the _current function_, not the entire test. For
<a class="l" name="1003" href="#1003">1003</a>example, the following test will segfault:
<a class="l" name="1004" href="#1004">1004</a>
<a class="l" name="1005" href="#1005">1005</a>```c++
<a class="l" name="1006" href="#1006">1006</a>void Subroutine() {
<a class="l" name="1007" href="#1007">1007</a>  // Generates a fatal failure and aborts the current function.
<a class="l" name="1008" href="#1008">1008</a>  ASSERT_EQ(1, 2);
<a class="l" name="1009" href="#1009">1009</a>
<a class="hl" name="1010" href="#1010">1010</a>  // The following won't be executed.
<a class="l" name="1011" href="#1011">1011</a>  ...
<a class="l" name="1012" href="#1012">1012</a>}
<a class="l" name="1013" href="#1013">1013</a>
<a class="l" name="1014" href="#1014">1014</a>TEST(FooTest, Bar) {
<a class="l" name="1015" href="#1015">1015</a>  Subroutine();  // The intended behavior is for the fatal failure
<a class="l" name="1016" href="#1016">1016</a>                 // in Subroutine() to abort the entire test.
<a class="l" name="1017" href="#1017">1017</a>
<a class="l" name="1018" href="#1018">1018</a>  // The actual behavior: the function goes on after Subroutine() returns.
<a class="l" name="1019" href="#1019">1019</a>  int* p = nullptr;
<a class="hl" name="1020" href="#1020">1020</a>  *p = 3;  // Segfault!
<a class="l" name="1021" href="#1021">1021</a>}
<a class="l" name="1022" href="#1022">1022</a>```
<a class="l" name="1023" href="#1023">1023</a>
<a class="l" name="1024" href="#1024">1024</a>To alleviate this, googletest provides three different solutions. You could use
<a class="l" name="1025" href="#1025">1025</a>either exceptions, the `(ASSERT|EXPECT)_NO_FATAL_FAILURE` assertions or the
<a class="l" name="1026" href="#1026">1026</a>`HasFatalFailure()` function. They are described in the following two
<a class="l" name="1027" href="#1027">1027</a>subsections.
<a class="l" name="1028" href="#1028">1028</a>
<a class="l" name="1029" href="#1029">1029</a>#### Asserting on Subroutines with an exception
<a class="hl" name="1030" href="#1030">1030</a>
<a class="l" name="1031" href="#1031">1031</a>The following code can turn ASSERT-failure into an exception:
<a class="l" name="1032" href="#1032">1032</a>
<a class="l" name="1033" href="#1033">1033</a>```c++
<a class="l" name="1034" href="#1034">1034</a>class ThrowListener : public testing::EmptyTestEventListener {
<a class="l" name="1035" href="#1035">1035</a>  void OnTestPartResult(const testing::TestPartResult&amp; result) override {
<a class="l" name="1036" href="#1036">1036</a>    if (<a href="/googletest/s?path=result.type&amp;project=googletest">result.type</a>() == testing::TestPartResult::kFatalFailure) {
<a class="l" name="1037" href="#1037">1037</a>      throw testing::AssertionException(result);
<a class="l" name="1038" href="#1038">1038</a>    }
<a class="l" name="1039" href="#1039">1039</a>  }
<a class="hl" name="1040" href="#1040">1040</a>};
<a class="l" name="1041" href="#1041">1041</a>int main(int argc, char** argv) {
<a class="l" name="1042" href="#1042">1042</a>  ...
<a class="l" name="1043" href="#1043">1043</a>  testing::UnitTest::GetInstance()-&gt;listeners().Append(new ThrowListener);
<a class="l" name="1044" href="#1044">1044</a>  return RUN_ALL_TESTS();
<a class="l" name="1045" href="#1045">1045</a>}
<a class="l" name="1046" href="#1046">1046</a>```
<a class="l" name="1047" href="#1047">1047</a>
<a class="l" name="1048" href="#1048">1048</a>This listener should be added after other listeners if you have any, otherwise
<a class="l" name="1049" href="#1049">1049</a>they won't see failed `OnTestPartResult`.
<a class="hl" name="1050" href="#1050">1050</a>
<a class="l" name="1051" href="#1051">1051</a>#### Asserting on Subroutines
<a class="l" name="1052" href="#1052">1052</a>
<a class="l" name="1053" href="#1053">1053</a>As shown above, if your test calls a subroutine that has an `ASSERT_*` failure
<a class="l" name="1054" href="#1054">1054</a>in it, the test will continue after the subroutine returns. This may not be what
<a class="l" name="1055" href="#1055">1055</a>you want.
<a class="l" name="1056" href="#1056">1056</a>
<a class="l" name="1057" href="#1057">1057</a>Often people want fatal failures to propagate like exceptions. For that
<a class="l" name="1058" href="#1058">1058</a>googletest offers the following macros:
<a class="l" name="1059" href="#1059">1059</a>
<a class="hl" name="1060" href="#1060">1060</a>Fatal assertion                       | Nonfatal assertion                    | Verifies
<a class="l" name="1061" href="#1061">1061</a>------------------------------------- | ------------------------------------- | --------
<a class="l" name="1062" href="#1062">1062</a>`ASSERT_NO_FATAL_FAILURE(statement);` | `EXPECT_NO_FATAL_FAILURE(statement);` | `statement` doesn't generate any new fatal failures in the current thread.
<a class="l" name="1063" href="#1063">1063</a>
<a class="l" name="1064" href="#1064">1064</a>Only failures in the thread that executes the assertion are checked to determine
<a class="l" name="1065" href="#1065">1065</a>the result of this type of assertions. If `statement` creates new threads,
<a class="l" name="1066" href="#1066">1066</a>failures in these threads are ignored.
<a class="l" name="1067" href="#1067">1067</a>
<a class="l" name="1068" href="#1068">1068</a>Examples:
<a class="l" name="1069" href="#1069">1069</a>
<a class="hl" name="1070" href="#1070">1070</a>```c++
<a class="l" name="1071" href="#1071">1071</a>ASSERT_NO_FATAL_FAILURE(Foo());
<a class="l" name="1072" href="#1072">1072</a>
<a class="l" name="1073" href="#1073">1073</a>int i;
<a class="l" name="1074" href="#1074">1074</a>EXPECT_NO_FATAL_FAILURE({
<a class="l" name="1075" href="#1075">1075</a>  i = Bar();
<a class="l" name="1076" href="#1076">1076</a>});
<a class="l" name="1077" href="#1077">1077</a>```
<a class="l" name="1078" href="#1078">1078</a>
<a class="l" name="1079" href="#1079">1079</a>Assertions from multiple threads are currently not supported on Windows.
<a class="hl" name="1080" href="#1080">1080</a>
<a class="l" name="1081" href="#1081">1081</a>#### Checking for Failures in the Current Test
<a class="l" name="1082" href="#1082">1082</a>
<a class="l" name="1083" href="#1083">1083</a>`HasFatalFailure()` in the `::testing::Test` class returns `true` if an
<a class="l" name="1084" href="#1084">1084</a>assertion in the current test has suffered a fatal failure. This allows
<a class="l" name="1085" href="#1085">1085</a>functions to catch fatal failures in a sub-routine and return early.
<a class="l" name="1086" href="#1086">1086</a>
<a class="l" name="1087" href="#1087">1087</a>```c++
<a class="l" name="1088" href="#1088">1088</a>class Test {
<a class="l" name="1089" href="#1089">1089</a> public:
<a class="hl" name="1090" href="#1090">1090</a>  ...
<a class="l" name="1091" href="#1091">1091</a>  static bool HasFatalFailure();
<a class="l" name="1092" href="#1092">1092</a>};
<a class="l" name="1093" href="#1093">1093</a>```
<a class="l" name="1094" href="#1094">1094</a>
<a class="l" name="1095" href="#1095">1095</a>The typical usage, which basically simulates the behavior of a thrown exception,
<a class="l" name="1096" href="#1096">1096</a>is:
<a class="l" name="1097" href="#1097">1097</a>
<a class="l" name="1098" href="#1098">1098</a>```c++
<a class="l" name="1099" href="#1099">1099</a>TEST(FooTest, Bar) {
<a class="hl" name="1100" href="#1100">1100</a>  Subroutine();
<a class="l" name="1101" href="#1101">1101</a>  // Aborts if Subroutine() had a fatal failure.
<a class="l" name="1102" href="#1102">1102</a>  if (HasFatalFailure()) return;
<a class="l" name="1103" href="#1103">1103</a>
<a class="l" name="1104" href="#1104">1104</a>  // The following won't be executed.
<a class="l" name="1105" href="#1105">1105</a>  ...
<a class="l" name="1106" href="#1106">1106</a>}
<a class="l" name="1107" href="#1107">1107</a>```
<a class="l" name="1108" href="#1108">1108</a>
<a class="l" name="1109" href="#1109">1109</a>If `HasFatalFailure()` is used outside of `TEST()` , `TEST_F()` , or a test
<a class="hl" name="1110" href="#1110">1110</a>fixture, you must add the `::testing::Test::` prefix, as in:
<a class="l" name="1111" href="#1111">1111</a>
<a class="l" name="1112" href="#1112">1112</a>```c++
<a class="l" name="1113" href="#1113">1113</a>if (testing::Test::HasFatalFailure()) return;
<a class="l" name="1114" href="#1114">1114</a>```
<a class="l" name="1115" href="#1115">1115</a>
<a class="l" name="1116" href="#1116">1116</a>Similarly, `HasNonfatalFailure()` returns `true` if the current test has at
<a class="l" name="1117" href="#1117">1117</a>least one non-fatal failure, and `HasFailure()` returns `true` if the current
<a class="l" name="1118" href="#1118">1118</a>test has at least one failure of either kind.
<a class="l" name="1119" href="#1119">1119</a>
<a class="hl" name="1120" href="#1120">1120</a>## Logging Additional Information
<a class="l" name="1121" href="#1121">1121</a>
<a class="l" name="1122" href="#1122">1122</a>In your test code, you can call `RecordProperty("key", value)` to log additional
<a class="l" name="1123" href="#1123">1123</a>information, where `value` can be either a string or an `int`. The *last* value
<a class="l" name="1124" href="#1124">1124</a>recorded for a key will be emitted to the
<a class="l" name="1125" href="#1125">1125</a>[XML output](#generating-an-xml-report) if you specify one. For example, the
<a class="l" name="1126" href="#1126">1126</a>test
<a class="l" name="1127" href="#1127">1127</a>
<a class="l" name="1128" href="#1128">1128</a>```c++
<a class="l" name="1129" href="#1129">1129</a>TEST_F(WidgetUsageTest, MinAndMaxWidgets) {
<a class="hl" name="1130" href="#1130">1130</a>  RecordProperty("MaximumWidgets", ComputeMaxUsage());
<a class="l" name="1131" href="#1131">1131</a>  RecordProperty("MinimumWidgets", ComputeMinUsage());
<a class="l" name="1132" href="#1132">1132</a>}
<a class="l" name="1133" href="#1133">1133</a>```
<a class="l" name="1134" href="#1134">1134</a>
<a class="l" name="1135" href="#1135">1135</a>will output XML like this:
<a class="l" name="1136" href="#1136">1136</a>
<a class="l" name="1137" href="#1137">1137</a>```xml
<a class="l" name="1138" href="#1138">1138</a>  ...
<a class="l" name="1139" href="#1139">1139</a>    &lt;testcase name="MinAndMaxWidgets" status="run" time="0.006" classname="WidgetUsageTest" MaximumWidgets="12" MinimumWidgets="9" /&gt;
<a class="hl" name="1140" href="#1140">1140</a>  ...
<a class="l" name="1141" href="#1141">1141</a>```
<a class="l" name="1142" href="#1142">1142</a>
<a class="l" name="1143" href="#1143">1143</a>&gt; NOTE:
<a class="l" name="1144" href="#1144">1144</a>&gt;
<a class="l" name="1145" href="#1145">1145</a>&gt; *   `RecordProperty()` is a static member of the `Test` class. Therefore it
<a class="l" name="1146" href="#1146">1146</a>&gt;     needs to be prefixed with `::testing::Test::` if used outside of the
<a class="l" name="1147" href="#1147">1147</a>&gt;     `TEST` body and the test fixture class.
<a class="l" name="1148" href="#1148">1148</a>&gt; *   *`key`* must be a valid XML attribute name, and cannot conflict with the
<a class="l" name="1149" href="#1149">1149</a>&gt;     ones already used by googletest (`name`, `status`, `time`, `classname`,
<a class="hl" name="1150" href="#1150">1150</a>&gt;     `type_param`, and `value_param`).
<a class="l" name="1151" href="#1151">1151</a>&gt; *   Calling `RecordProperty()` outside of the lifespan of a test is allowed.
<a class="l" name="1152" href="#1152">1152</a>&gt;     If it's called outside of a test but between a test suite's
<a class="l" name="1153" href="#1153">1153</a>&gt;     `SetUpTestSuite()` and `TearDownTestSuite()` methods, it will be
<a class="l" name="1154" href="#1154">1154</a>&gt;     attributed to the XML element for the test suite. If it's called outside
<a class="l" name="1155" href="#1155">1155</a>&gt;     of all test suites (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> in a test environment), it will be attributed to
<a class="l" name="1156" href="#1156">1156</a>&gt;     the top-level XML element.
<a class="l" name="1157" href="#1157">1157</a>
<a class="l" name="1158" href="#1158">1158</a>## Sharing Resources Between Tests in the Same Test Suite
<a class="l" name="1159" href="#1159">1159</a>
<a class="hl" name="1160" href="#1160">1160</a>googletest creates a new test fixture object for each test in order to make
<a class="l" name="1161" href="#1161">1161</a>tests independent and easier to debug. However, sometimes tests use resources
<a class="l" name="1162" href="#1162">1162</a>that are expensive to set up, making the one-copy-per-test model prohibitively
<a class="l" name="1163" href="#1163">1163</a>expensive.
<a class="l" name="1164" href="#1164">1164</a>
<a class="l" name="1165" href="#1165">1165</a>If the tests don't change the resource, there's no harm in their sharing a
<a class="l" name="1166" href="#1166">1166</a>single resource copy. So, in addition to per-test <a href="/googletest/s?path=set-up/tear-down&amp;project=googletest">set-up/tear-down</a>, googletest
<a class="l" name="1167" href="#1167">1167</a>also supports per-test-suite <a href="/googletest/s?path=set-up/tear-down&amp;project=googletest">set-up/tear-down</a>. To use it:
<a class="l" name="1168" href="#1168">1168</a>
<a class="l" name="1169" href="#1169">1169</a>1.  In your test fixture class (say `FooTest` ), declare as `static` some member
<a class="hl" name="1170" href="#1170">1170</a>    variables to hold the shared resources.
<a class="l" name="1171" href="#1171">1171</a>2.  Outside your test fixture class (typically just below it), define those
<a class="l" name="1172" href="#1172">1172</a>    member variables, optionally giving them initial values.
<a class="l" name="1173" href="#1173">1173</a>3.  In the same test fixture class, define a `static void SetUpTestSuite()`
<a class="l" name="1174" href="#1174">1174</a>    function (remember not to spell it as **`SetupTestSuite`** with a small
<a class="l" name="1175" href="#1175">1175</a>    `u`!) to set up the shared resources and a `static void TearDownTestSuite()`
<a class="l" name="1176" href="#1176">1176</a>    function to tear them down.
<a class="l" name="1177" href="#1177">1177</a>
<a class="l" name="1178" href="#1178">1178</a>That's it! googletest automatically calls `SetUpTestSuite()` before running the
<a class="l" name="1179" href="#1179">1179</a>*first test* in the `FooTest` test suite (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> before creating the first
<a class="hl" name="1180" href="#1180">1180</a>`FooTest` object), and calls `TearDownTestSuite()` after running the *last test*
<a class="l" name="1181" href="#1181">1181</a>in it (<a href="/googletest/s?path=i.e.&amp;project=googletest">i.e.</a> after deleting the last `FooTest` object). In between, the tests can
<a class="l" name="1182" href="#1182">1182</a>use the shared resources.
<a class="l" name="1183" href="#1183">1183</a>
<a class="l" name="1184" href="#1184">1184</a>Remember that the test order is undefined, so your code can't depend on a test
<a class="l" name="1185" href="#1185">1185</a>preceding or following another. Also, the tests must either not modify the state
<a class="l" name="1186" href="#1186">1186</a>of any shared resource, or, if they do modify the state, they must restore the
<a class="l" name="1187" href="#1187">1187</a>state to its original value before passing control to the next test.
<a class="l" name="1188" href="#1188">1188</a>
<a class="l" name="1189" href="#1189">1189</a>Here's an example of per-test-suite set-up and tear-down:
<a class="hl" name="1190" href="#1190">1190</a>
<a class="l" name="1191" href="#1191">1191</a>```c++
<a class="l" name="1192" href="#1192">1192</a>class FooTest : public testing::Test {
<a class="l" name="1193" href="#1193">1193</a> protected:
<a class="l" name="1194" href="#1194">1194</a>  // Per-test-suite set-up.
<a class="l" name="1195" href="#1195">1195</a>  // Called before the first test in this test suite.
<a class="l" name="1196" href="#1196">1196</a>  // Can be omitted if not needed.
<a class="l" name="1197" href="#1197">1197</a>  static void SetUpTestSuite() {
<a class="l" name="1198" href="#1198">1198</a>    shared_resource_ = new ...;
<a class="l" name="1199" href="#1199">1199</a>  }
<a class="hl" name="1200" href="#1200">1200</a>
<a class="l" name="1201" href="#1201">1201</a>  // Per-test-suite tear-down.
<a class="l" name="1202" href="#1202">1202</a>  // Called after the last test in this test suite.
<a class="l" name="1203" href="#1203">1203</a>  // Can be omitted if not needed.
<a class="l" name="1204" href="#1204">1204</a>  static void TearDownTestSuite() {
<a class="l" name="1205" href="#1205">1205</a>    delete shared_resource_;
<a class="l" name="1206" href="#1206">1206</a>    shared_resource_ = nullptr;
<a class="l" name="1207" href="#1207">1207</a>  }
<a class="l" name="1208" href="#1208">1208</a>
<a class="l" name="1209" href="#1209">1209</a>  // You can define per-test set-up logic as usual.
<a class="hl" name="1210" href="#1210">1210</a>  virtual void SetUp() { ... }
<a class="l" name="1211" href="#1211">1211</a>
<a class="l" name="1212" href="#1212">1212</a>  // You can define per-test tear-down logic as usual.
<a class="l" name="1213" href="#1213">1213</a>  virtual void TearDown() { ... }
<a class="l" name="1214" href="#1214">1214</a>
<a class="l" name="1215" href="#1215">1215</a>  // Some expensive resource shared by all tests.
<a class="l" name="1216" href="#1216">1216</a>  static T* shared_resource_;
<a class="l" name="1217" href="#1217">1217</a>};
<a class="l" name="1218" href="#1218">1218</a>
<a class="l" name="1219" href="#1219">1219</a>T* FooTest::shared_resource_ = nullptr;
<a class="hl" name="1220" href="#1220">1220</a>
<a class="l" name="1221" href="#1221">1221</a>TEST_F(FooTest, Test1) {
<a class="l" name="1222" href="#1222">1222</a>  ... you can refer to shared_resource_ here ...
<a class="l" name="1223" href="#1223">1223</a>}
<a class="l" name="1224" href="#1224">1224</a>
<a class="l" name="1225" href="#1225">1225</a>TEST_F(FooTest, Test2) {
<a class="l" name="1226" href="#1226">1226</a>  ... you can refer to shared_resource_ here ...
<a class="l" name="1227" href="#1227">1227</a>}
<a class="l" name="1228" href="#1228">1228</a>```
<a class="l" name="1229" href="#1229">1229</a>
<a class="hl" name="1230" href="#1230">1230</a>NOTE: Though the above code declares `SetUpTestSuite()` protected, it may
<a class="l" name="1231" href="#1231">1231</a>sometimes be necessary to declare it public, such as when using it with
<a class="l" name="1232" href="#1232">1232</a>`TEST_P`.
<a class="l" name="1233" href="#1233">1233</a>
<a class="l" name="1234" href="#1234">1234</a>## Global Set-Up and Tear-Down
<a class="l" name="1235" href="#1235">1235</a>
<a class="l" name="1236" href="#1236">1236</a>Just as you can do set-up and tear-down at the test level and the test suite
<a class="l" name="1237" href="#1237">1237</a>level, you can also do it at the test program level. Here's how.
<a class="l" name="1238" href="#1238">1238</a>
<a class="l" name="1239" href="#1239">1239</a>First, you subclass the `::testing::Environment` class to define a test
<a class="hl" name="1240" href="#1240">1240</a>environment, which knows how to set-up and tear-down:
<a class="l" name="1241" href="#1241">1241</a>
<a class="l" name="1242" href="#1242">1242</a>```c++
<a class="l" name="1243" href="#1243">1243</a>class Environment : public testing::Environment {
<a class="l" name="1244" href="#1244">1244</a> public:
<a class="l" name="1245" href="#1245">1245</a>  ~Environment() override {}
<a class="l" name="1246" href="#1246">1246</a>
<a class="l" name="1247" href="#1247">1247</a>  // Override this to define how to set up the environment.
<a class="l" name="1248" href="#1248">1248</a>  void SetUp() override {}
<a class="l" name="1249" href="#1249">1249</a>
<a class="hl" name="1250" href="#1250">1250</a>  // Override this to define how to tear down the environment.
<a class="l" name="1251" href="#1251">1251</a>  void TearDown() override {}
<a class="l" name="1252" href="#1252">1252</a>};
<a class="l" name="1253" href="#1253">1253</a>```
<a class="l" name="1254" href="#1254">1254</a>
<a class="l" name="1255" href="#1255">1255</a>Then, you register an instance of your environment class with googletest by
<a class="l" name="1256" href="#1256">1256</a>calling the `::testing::AddGlobalTestEnvironment()` function:
<a class="l" name="1257" href="#1257">1257</a>
<a class="l" name="1258" href="#1258">1258</a>```c++
<a class="l" name="1259" href="#1259">1259</a>Environment* AddGlobalTestEnvironment(Environment* env);
<a class="hl" name="1260" href="#1260">1260</a>```
<a class="l" name="1261" href="#1261">1261</a>
<a class="l" name="1262" href="#1262">1262</a>Now, when `RUN_ALL_TESTS()` is called, it first calls the `SetUp()` method of
<a class="l" name="1263" href="#1263">1263</a>each environment object, then runs the tests if none of the environments
<a class="l" name="1264" href="#1264">1264</a>reported fatal failures and `GTEST_SKIP()` was not called. `RUN_ALL_TESTS()`
<a class="l" name="1265" href="#1265">1265</a>always calls `TearDown()` with each environment object, regardless of whether or
<a class="l" name="1266" href="#1266">1266</a>not the tests were run.
<a class="l" name="1267" href="#1267">1267</a>
<a class="l" name="1268" href="#1268">1268</a>It's OK to register multiple environment objects. In this suite, their `SetUp()`
<a class="l" name="1269" href="#1269">1269</a>will be called in the order they are registered, and their `TearDown()` will be
<a class="hl" name="1270" href="#1270">1270</a>called in the reverse order.
<a class="l" name="1271" href="#1271">1271</a>
<a class="l" name="1272" href="#1272">1272</a>Note that googletest takes ownership of the registered environment objects.
<a class="l" name="1273" href="#1273">1273</a>Therefore **do not delete them** by yourself.
<a class="l" name="1274" href="#1274">1274</a>
<a class="l" name="1275" href="#1275">1275</a>You should call `AddGlobalTestEnvironment()` before `RUN_ALL_TESTS()` is called,
<a class="l" name="1276" href="#1276">1276</a>probably in `main()`. If you use `gtest_main`, you need to call this before
<a class="l" name="1277" href="#1277">1277</a>`main()` starts for it to take effect. One way to do this is to define a global
<a class="l" name="1278" href="#1278">1278</a>variable like this:
<a class="l" name="1279" href="#1279">1279</a>
<a class="hl" name="1280" href="#1280">1280</a>```c++
<a class="l" name="1281" href="#1281">1281</a>testing::Environment* const foo_env =
<a class="l" name="1282" href="#1282">1282</a>    testing::AddGlobalTestEnvironment(new FooEnvironment);
<a class="l" name="1283" href="#1283">1283</a>```
<a class="l" name="1284" href="#1284">1284</a>
<a class="l" name="1285" href="#1285">1285</a>However, we strongly recommend you to write your own `main()` and call
<a class="l" name="1286" href="#1286">1286</a>`AddGlobalTestEnvironment()` there, as relying on initialization of global
<a class="l" name="1287" href="#1287">1287</a>variables makes the code harder to read and may cause problems when you register
<a class="l" name="1288" href="#1288">1288</a>multiple environments from different translation units and the environments have
<a class="l" name="1289" href="#1289">1289</a>dependencies among them (remember that the compiler doesn't guarantee the order
<a class="hl" name="1290" href="#1290">1290</a>in which global variables from different translation units are initialized).
<a class="l" name="1291" href="#1291">1291</a>
<a class="l" name="1292" href="#1292">1292</a>## Value-Parameterized Tests
<a class="l" name="1293" href="#1293">1293</a>
<a class="l" name="1294" href="#1294">1294</a>*Value-parameterized tests* allow you to test your code with different
<a class="l" name="1295" href="#1295">1295</a>parameters without writing multiple copies of the same test. This is useful in a
<a class="l" name="1296" href="#1296">1296</a>number of situations, for example:
<a class="l" name="1297" href="#1297">1297</a>
<a class="l" name="1298" href="#1298">1298</a>*   You have a piece of code whose behavior is affected by one or more
<a class="l" name="1299" href="#1299">1299</a>    command-line flags. You want to make sure your code performs correctly for
<a class="hl" name="1300" href="#1300">1300</a>    various values of those flags.
<a class="l" name="1301" href="#1301">1301</a>*   You want to test different implementations of an OO interface.
<a class="l" name="1302" href="#1302">1302</a>*   You want to test your code over various inputs (<a href="/googletest/s?path=a.k.a.&amp;project=googletest">a.k.a.</a> data-driven testing).
<a class="l" name="1303" href="#1303">1303</a>    This feature is easy to abuse, so please exercise your good sense when doing
<a class="l" name="1304" href="#1304">1304</a>    it!
<a class="l" name="1305" href="#1305">1305</a>
<a class="l" name="1306" href="#1306">1306</a>### How to Write Value-Parameterized Tests
<a class="l" name="1307" href="#1307">1307</a>
<a class="l" name="1308" href="#1308">1308</a>To write value-parameterized tests, first you should define a fixture class. It
<a class="l" name="1309" href="#1309">1309</a>must be derived from both `testing::Test` and `testing::WithParamInterface&lt;T&gt;`
<a class="hl" name="1310" href="#1310">1310</a>(the latter is a pure interface), where `T` is the type of your parameter
<a class="l" name="1311" href="#1311">1311</a>values. For convenience, you can just derive the fixture class from
<a class="l" name="1312" href="#1312">1312</a>`testing::TestWithParam&lt;T&gt;`, which itself is derived from both `testing::Test`
<a class="l" name="1313" href="#1313">1313</a>and `testing::WithParamInterface&lt;T&gt;`. `T` can be any copyable type. If it's a
<a class="l" name="1314" href="#1314">1314</a>raw pointer, you are responsible for managing the lifespan of the pointed
<a class="l" name="1315" href="#1315">1315</a>values.
<a class="l" name="1316" href="#1316">1316</a>
<a class="l" name="1317" href="#1317">1317</a>NOTE: If your test fixture defines `SetUpTestSuite()` or `TearDownTestSuite()`
<a class="l" name="1318" href="#1318">1318</a>they must be declared **public** rather than **protected** in order to use
<a class="l" name="1319" href="#1319">1319</a>`TEST_P`.
<a class="hl" name="1320" href="#1320">1320</a>
<a class="l" name="1321" href="#1321">1321</a>```c++
<a class="l" name="1322" href="#1322">1322</a>class FooTest :
<a class="l" name="1323" href="#1323">1323</a>    public testing::TestWithParam&lt;const char*&gt; {
<a class="l" name="1324" href="#1324">1324</a>  // You can implement all the usual fixture class members here.
<a class="l" name="1325" href="#1325">1325</a>  // To access the test parameter, call GetParam() from class
<a class="l" name="1326" href="#1326">1326</a>  // TestWithParam&lt;T&gt;.
<a class="l" name="1327" href="#1327">1327</a>};
<a class="l" name="1328" href="#1328">1328</a>
<a class="l" name="1329" href="#1329">1329</a>// Or, when you want to add parameters to a pre-existing fixture class:
<a class="hl" name="1330" href="#1330">1330</a>class BaseTest : public testing::Test {
<a class="l" name="1331" href="#1331">1331</a>  ...
<a class="l" name="1332" href="#1332">1332</a>};
<a class="l" name="1333" href="#1333">1333</a>class BarTest : public BaseTest,
<a class="l" name="1334" href="#1334">1334</a>                public testing::WithParamInterface&lt;const char*&gt; {
<a class="l" name="1335" href="#1335">1335</a>  ...
<a class="l" name="1336" href="#1336">1336</a>};
<a class="l" name="1337" href="#1337">1337</a>```
<a class="l" name="1338" href="#1338">1338</a>
<a class="l" name="1339" href="#1339">1339</a>Then, use the `TEST_P` macro to define as many test patterns using this fixture
<a class="hl" name="1340" href="#1340">1340</a>as you want. The `_P` suffix is for "parameterized" or "pattern", whichever you
<a class="l" name="1341" href="#1341">1341</a>prefer to think.
<a class="l" name="1342" href="#1342">1342</a>
<a class="l" name="1343" href="#1343">1343</a>```c++
<a class="l" name="1344" href="#1344">1344</a>TEST_P(FooTest, DoesBlah) {
<a class="l" name="1345" href="#1345">1345</a>  // Inside a test, access the test parameter with the GetParam() method
<a class="l" name="1346" href="#1346">1346</a>  // of the TestWithParam&lt;T&gt; class:
<a class="l" name="1347" href="#1347">1347</a>  EXPECT_TRUE(<a href="/googletest/s?path=foo.Blah&amp;project=googletest">foo.Blah</a>(GetParam()));
<a class="l" name="1348" href="#1348">1348</a>  ...
<a class="l" name="1349" href="#1349">1349</a>}
<a class="hl" name="1350" href="#1350">1350</a>
<a class="l" name="1351" href="#1351">1351</a>TEST_P(FooTest, HasBlahBlah) {
<a class="l" name="1352" href="#1352">1352</a>  ...
<a class="l" name="1353" href="#1353">1353</a>}
<a class="l" name="1354" href="#1354">1354</a>```
<a class="l" name="1355" href="#1355">1355</a>
<a class="l" name="1356" href="#1356">1356</a>Finally, you can use `INSTANTIATE_TEST_SUITE_P` to instantiate the test suite
<a class="l" name="1357" href="#1357">1357</a>with any set of parameters you want. googletest defines a number of functions
<a class="l" name="1358" href="#1358">1358</a>for generating test parameters. They return what we call (surprise!) *parameter
<a class="l" name="1359" href="#1359">1359</a>generators*. Here is a summary of them, which are all in the `testing`
<a class="hl" name="1360" href="#1360">1360</a>namespace:
<a class="l" name="1361" href="#1361">1361</a>
<a class="l" name="1362" href="#1362">1362</a>&lt;!-- mdformat off(github rendering does not support multiline tables) --&gt;
<a class="l" name="1363" href="#1363">1363</a>
<a class="l" name="1364" href="#1364">1364</a>| Parameter Generator                                                                       | Behavior                                                                                                          |
<a class="l" name="1365" href="#1365">1365</a>| ----------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
<a class="l" name="1366" href="#1366">1366</a>| `Range(begin, end [, step])`                                                              | Yields values `{begin, begin+step, begin+step+step, ...}`. The values do not include `end`. `step` defaults to 1. |
<a class="l" name="1367" href="#1367">1367</a>| `Values(v1, v2, ..., vN)`                                                                 | Yields values `{v1, v2, ..., vN}`.                                                                                |
<a class="l" name="1368" href="#1368">1368</a>| `ValuesIn(container)` and  `ValuesIn(begin,end)`                                          | Yields values from a C-style array, an  STL-style container, or an iterator range `[begin, end)`                  |
<a class="l" name="1369" href="#1369">1369</a>| `Bool()`                                                                                  | Yields sequence `{false, true}`.                                                                                  |
<a class="hl" name="1370" href="#1370">1370</a>| `Combine(g1, g2, ..., gN)`                                                                | Yields all combinations (Cartesian product) as std\:\:tuples of the values generated by the `N` generators.       |
<a class="l" name="1371" href="#1371">1371</a>
<a class="l" name="1372" href="#1372">1372</a>&lt;!-- mdformat on--&gt;
<a class="l" name="1373" href="#1373">1373</a>
<a class="l" name="1374" href="#1374">1374</a>For more details, see the comments at the definitions of these functions.
<a class="l" name="1375" href="#1375">1375</a>
<a class="l" name="1376" href="#1376">1376</a>The following statement will instantiate tests from the `FooTest` test suite
<a class="l" name="1377" href="#1377">1377</a>each with parameter values `"meeny"`, `"miny"`, and `"moe"`.
<a class="l" name="1378" href="#1378">1378</a>
<a class="l" name="1379" href="#1379">1379</a>```c++
<a class="hl" name="1380" href="#1380">1380</a>INSTANTIATE_TEST_SUITE_P(InstantiationName,
<a class="l" name="1381" href="#1381">1381</a>                         FooTest,
<a class="l" name="1382" href="#1382">1382</a>                         testing::Values("meeny", "miny", "moe"));
<a class="l" name="1383" href="#1383">1383</a>```
<a class="l" name="1384" href="#1384">1384</a>
<a class="l" name="1385" href="#1385">1385</a>NOTE: The code above must be placed at global or namespace scope, not at
<a class="l" name="1386" href="#1386">1386</a>function scope.
<a class="l" name="1387" href="#1387">1387</a>
<a class="l" name="1388" href="#1388">1388</a>Per default, every `TEST_P` without a corresponding `INSTANTIATE_TEST_SUITE_P`
<a class="l" name="1389" href="#1389">1389</a>causes a failing test in test suite `GoogleTestVerification`. If you have a test
<a class="hl" name="1390" href="#1390">1390</a>suite where that omission is not an error, for example it is in a library that
<a class="l" name="1391" href="#1391">1391</a>may be linked in for other reason or where the list of test cases is dynamic and
<a class="l" name="1392" href="#1392">1392</a>may be empty, then this check can be suppressed by tagging the test suite:
<a class="l" name="1393" href="#1393">1393</a>
<a class="l" name="1394" href="#1394">1394</a>```c++
<a class="l" name="1395" href="#1395">1395</a>GTEST_ALLOW_UNINSTANTIATED_PARAMETERIZED_TEST(FooTest);
<a class="l" name="1396" href="#1396">1396</a>```
<a class="l" name="1397" href="#1397">1397</a>
<a class="l" name="1398" href="#1398">1398</a>To distinguish different instances of the pattern (yes, you can instantiate it
<a class="l" name="1399" href="#1399">1399</a>more than once), the first argument to `INSTANTIATE_TEST_SUITE_P` is a prefix
<a class="hl" name="1400" href="#1400">1400</a>that will be added to the actual test suite name. Remember to pick unique
<a class="l" name="1401" href="#1401">1401</a>prefixes for different instantiations. The tests from the instantiation above
<a class="l" name="1402" href="#1402">1402</a>will have these names:
<a class="l" name="1403" href="#1403">1403</a>
<a class="l" name="1404" href="#1404">1404</a>*   `<a href="/googletest/s?path=InstantiationName/FooTest.DoesBlah&amp;project=googletest">InstantiationName/FooTest.DoesBlah</a>/0` for `"meeny"`
<a class="l" name="1405" href="#1405">1405</a>*   `<a href="/googletest/s?path=InstantiationName/FooTest.DoesBlah&amp;project=googletest">InstantiationName/FooTest.DoesBlah</a>/1` for `"miny"`
<a class="l" name="1406" href="#1406">1406</a>*   `<a href="/googletest/s?path=InstantiationName/FooTest.DoesBlah&amp;project=googletest">InstantiationName/FooTest.DoesBlah</a>/2` for `"moe"`
<a class="l" name="1407" href="#1407">1407</a>*   `<a href="/googletest/s?path=InstantiationName/FooTest.HasBlahBlah&amp;project=googletest">InstantiationName/FooTest.HasBlahBlah</a>/0` for `"meeny"`
<a class="l" name="1408" href="#1408">1408</a>*   `<a href="/googletest/s?path=InstantiationName/FooTest.HasBlahBlah&amp;project=googletest">InstantiationName/FooTest.HasBlahBlah</a>/1` for `"miny"`
<a class="l" name="1409" href="#1409">1409</a>*   `<a href="/googletest/s?path=InstantiationName/FooTest.HasBlahBlah&amp;project=googletest">InstantiationName/FooTest.HasBlahBlah</a>/2` for `"moe"`
<a class="hl" name="1410" href="#1410">1410</a>
<a class="l" name="1411" href="#1411">1411</a>You can use these names in [`--gtest_filter`](#running-a-subset-of-the-tests).
<a class="l" name="1412" href="#1412">1412</a>
<a class="l" name="1413" href="#1413">1413</a>This statement will instantiate all tests from `FooTest` again, each with
<a class="l" name="1414" href="#1414">1414</a>parameter values `"cat"` and `"dog"`:
<a class="l" name="1415" href="#1415">1415</a>
<a class="l" name="1416" href="#1416">1416</a>```c++
<a class="l" name="1417" href="#1417">1417</a>const char* pets[] = {"cat", "dog"};
<a class="l" name="1418" href="#1418">1418</a>INSTANTIATE_TEST_SUITE_P(AnotherInstantiationName, FooTest,
<a class="l" name="1419" href="#1419">1419</a>                         testing::ValuesIn(pets));
<a class="hl" name="1420" href="#1420">1420</a>```
<a class="l" name="1421" href="#1421">1421</a>
<a class="l" name="1422" href="#1422">1422</a>The tests from the instantiation above will have these names:
<a class="l" name="1423" href="#1423">1423</a>
<a class="l" name="1424" href="#1424">1424</a>*   `<a href="/googletest/s?path=AnotherInstantiationName/FooTest.DoesBlah&amp;project=googletest">AnotherInstantiationName/FooTest.DoesBlah</a>/0` for `"cat"`
<a class="l" name="1425" href="#1425">1425</a>*   `<a href="/googletest/s?path=AnotherInstantiationName/FooTest.DoesBlah&amp;project=googletest">AnotherInstantiationName/FooTest.DoesBlah</a>/1` for `"dog"`
<a class="l" name="1426" href="#1426">1426</a>*   `<a href="/googletest/s?path=AnotherInstantiationName/FooTest.HasBlahBlah&amp;project=googletest">AnotherInstantiationName/FooTest.HasBlahBlah</a>/0` for `"cat"`
<a class="l" name="1427" href="#1427">1427</a>*   `<a href="/googletest/s?path=AnotherInstantiationName/FooTest.HasBlahBlah&amp;project=googletest">AnotherInstantiationName/FooTest.HasBlahBlah</a>/1` for `"dog"`
<a class="l" name="1428" href="#1428">1428</a>
<a class="l" name="1429" href="#1429">1429</a>Please note that `INSTANTIATE_TEST_SUITE_P` will instantiate *all* tests in the
<a class="hl" name="1430" href="#1430">1430</a>given test suite, whether their definitions come before or *after* the
<a class="l" name="1431" href="#1431">1431</a>`INSTANTIATE_TEST_SUITE_P` statement.
<a class="l" name="1432" href="#1432">1432</a>
<a class="l" name="1433" href="#1433">1433</a>You can see [<a href="/googletest/s?path=sample7_unittest.cc&amp;project=googletest">sample7_unittest.cc</a>] and [<a href="/googletest/s?path=sample8_unittest.cc&amp;project=googletest">sample8_unittest.cc</a>] for more examples.
<a class="l" name="1434" href="#1434">1434</a>
<a class="l" name="1435" href="#1435">1435</a>[<a href="/googletest/s?path=sample7_unittest.cc&amp;project=googletest">sample7_unittest.cc</a>]: ..<a href="/googletest/s?path=/samples/sample7_unittest.cc&amp;project=googletest">/samples/sample7_unittest.cc</a> "Parameterized Test example"
<a class="l" name="1436" href="#1436">1436</a>[<a href="/googletest/s?path=sample8_unittest.cc&amp;project=googletest">sample8_unittest.cc</a>]: ..<a href="/googletest/s?path=/samples/sample8_unittest.cc&amp;project=googletest">/samples/sample8_unittest.cc</a> "Parameterized Test example with multiple parameters"
<a class="l" name="1437" href="#1437">1437</a>
<a class="l" name="1438" href="#1438">1438</a>### Creating Value-Parameterized Abstract Tests
<a class="l" name="1439" href="#1439">1439</a>
<a class="hl" name="1440" href="#1440">1440</a>In the above, we define and instantiate `FooTest` in the *same* source file.
<a class="l" name="1441" href="#1441">1441</a>Sometimes you may want to define value-parameterized tests in a library and let
<a class="l" name="1442" href="#1442">1442</a>other people instantiate them later. This pattern is known as *abstract tests*.
<a class="l" name="1443" href="#1443">1443</a>As an example of its application, when you are designing an interface you can
<a class="l" name="1444" href="#1444">1444</a>write a standard suite of abstract tests (perhaps using a factory function as
<a class="l" name="1445" href="#1445">1445</a>the test parameter) that all implementations of the interface are expected to
<a class="l" name="1446" href="#1446">1446</a>pass. When someone implements the interface, they can instantiate your suite to
<a class="l" name="1447" href="#1447">1447</a>get all the interface-conformance tests for free.
<a class="l" name="1448" href="#1448">1448</a>
<a class="l" name="1449" href="#1449">1449</a>To define abstract tests, you should organize your code like this:
<a class="hl" name="1450" href="#1450">1450</a>
<a class="l" name="1451" href="#1451">1451</a>1.  Put the definition of the parameterized test fixture class (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `FooTest`)
<a class="l" name="1452" href="#1452">1452</a>    in a header file, say `<a href="/googletest/s?path=foo_param_test.h&amp;project=googletest">foo_param_test.h</a>`. Think of this as *declaring* your
<a class="l" name="1453" href="#1453">1453</a>    abstract tests.
<a class="l" name="1454" href="#1454">1454</a>2.  Put the `TEST_P` definitions in `<a href="/googletest/s?path=foo_param_test.cc&amp;project=googletest">foo_param_test.cc</a>`, which includes
<a class="l" name="1455" href="#1455">1455</a>    `<a href="/googletest/s?path=foo_param_test.h&amp;project=googletest">foo_param_test.h</a>`. Think of this as *implementing* your abstract tests.
<a class="l" name="1456" href="#1456">1456</a>
<a class="l" name="1457" href="#1457">1457</a>Once they are defined, you can instantiate them by including `<a href="/googletest/s?path=foo_param_test.h&amp;project=googletest">foo_param_test.h</a>`,
<a class="l" name="1458" href="#1458">1458</a>invoking `INSTANTIATE_TEST_SUITE_P()`, and depending on the library target that
<a class="l" name="1459" href="#1459">1459</a>contains `<a href="/googletest/s?path=foo_param_test.cc&amp;project=googletest">foo_param_test.cc</a>`. You can instantiate the same abstract test suite
<a class="hl" name="1460" href="#1460">1460</a>multiple times, possibly in different source files.
<a class="l" name="1461" href="#1461">1461</a>
<a class="l" name="1462" href="#1462">1462</a>### Specifying Names for Value-Parameterized Test Parameters
<a class="l" name="1463" href="#1463">1463</a>
<a class="l" name="1464" href="#1464">1464</a>The optional last argument to `INSTANTIATE_TEST_SUITE_P()` allows the user to
<a class="l" name="1465" href="#1465">1465</a>specify a function or functor that generates custom test name suffixes based on
<a class="l" name="1466" href="#1466">1466</a>the test parameters. The function should accept one argument of type
<a class="l" name="1467" href="#1467">1467</a>`testing::TestParamInfo&lt;class ParamType&gt;`, and return `std::string`.
<a class="l" name="1468" href="#1468">1468</a>
<a class="l" name="1469" href="#1469">1469</a>`testing::PrintToStringParamName` is a builtin test suffix generator that
<a class="hl" name="1470" href="#1470">1470</a>returns the value of `testing::PrintToString(GetParam())`. It does not work for
<a class="l" name="1471" href="#1471">1471</a>`std::string` or C strings.
<a class="l" name="1472" href="#1472">1472</a>
<a class="l" name="1473" href="#1473">1473</a>NOTE: test names must be non-empty, unique, and may only contain ASCII
<a class="l" name="1474" href="#1474">1474</a>alphanumeric characters. In particular, they
<a class="l" name="1475" href="#1475">1475</a>[should not contain underscores](<a href="/googletest/s?path=faq.md&amp;project=googletest">faq.md</a>#why-should-test-suite-names-and-test-names-not-contain-underscore)
<a class="l" name="1476" href="#1476">1476</a>
<a class="l" name="1477" href="#1477">1477</a>```c++
<a class="l" name="1478" href="#1478">1478</a>class MyTestSuite : public testing::TestWithParam&lt;int&gt; {};
<a class="l" name="1479" href="#1479">1479</a>
<a class="hl" name="1480" href="#1480">1480</a>TEST_P(MyTestSuite, MyTest)
<a class="l" name="1481" href="#1481">1481</a>{
<a class="l" name="1482" href="#1482">1482</a>  std::cout &lt;&lt; "Example Test Param: " &lt;&lt; GetParam() &lt;&lt; std::endl;
<a class="l" name="1483" href="#1483">1483</a>}
<a class="l" name="1484" href="#1484">1484</a>
<a class="l" name="1485" href="#1485">1485</a>INSTANTIATE_TEST_SUITE_P(MyGroup, MyTestSuite, testing::Range(0, 10),
<a class="l" name="1486" href="#1486">1486</a>                         testing::PrintToStringParamName());
<a class="l" name="1487" href="#1487">1487</a>```
<a class="l" name="1488" href="#1488">1488</a>
<a class="l" name="1489" href="#1489">1489</a>Providing a custom functor allows for more control over test parameter name
<a class="hl" name="1490" href="#1490">1490</a>generation, especially for types where the automatic conversion does not
<a class="l" name="1491" href="#1491">1491</a>generate helpful parameter names (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> strings as demonstrated above). The
<a class="l" name="1492" href="#1492">1492</a>following example illustrates this for multiple parameters, an enumeration type
<a class="l" name="1493" href="#1493">1493</a>and a string, and also demonstrates how to combine generators. It uses a lambda
<a class="l" name="1494" href="#1494">1494</a>for conciseness:
<a class="l" name="1495" href="#1495">1495</a>
<a class="l" name="1496" href="#1496">1496</a>```c++
<a class="l" name="1497" href="#1497">1497</a>enum class MyType { MY_FOO = 0, MY_BAR = 1 };
<a class="l" name="1498" href="#1498">1498</a>
<a class="l" name="1499" href="#1499">1499</a>class MyTestSuite : public testing::TestWithParam&lt;std::tuple&lt;MyType, std::string&gt;&gt; {
<a class="hl" name="1500" href="#1500">1500</a>};
<a class="l" name="1501" href="#1501">1501</a>
<a class="l" name="1502" href="#1502">1502</a>INSTANTIATE_TEST_SUITE_P(
<a class="l" name="1503" href="#1503">1503</a>    MyGroup, MyTestSuite,
<a class="l" name="1504" href="#1504">1504</a>    testing::Combine(
<a class="l" name="1505" href="#1505">1505</a>        testing::Values(MyType::VALUE_0, MyType::VALUE_1),
<a class="l" name="1506" href="#1506">1506</a>        testing::ValuesIn("", "")),
<a class="l" name="1507" href="#1507">1507</a>    [](const testing::TestParamInfo&lt;MyTestSuite::ParamType&gt;&amp; info) {
<a class="l" name="1508" href="#1508">1508</a>      std::string name = absl::StrCat(
<a class="l" name="1509" href="#1509">1509</a>          std::get&lt;0&gt;(<a href="/googletest/s?path=info.param&amp;project=googletest">info.param</a>) == MY_FOO ? "Foo" : "Bar", "_",
<a class="hl" name="1510" href="#1510">1510</a>          std::get&lt;1&gt;(<a href="/googletest/s?path=info.param&amp;project=googletest">info.param</a>));
<a class="l" name="1511" href="#1511">1511</a>      absl::c_replace_if(name, [](char c) { return !std::isalnum(c); }, '_');
<a class="l" name="1512" href="#1512">1512</a>      return name;
<a class="l" name="1513" href="#1513">1513</a>    });
<a class="l" name="1514" href="#1514">1514</a>```
<a class="l" name="1515" href="#1515">1515</a>
<a class="l" name="1516" href="#1516">1516</a>## Typed Tests
<a class="l" name="1517" href="#1517">1517</a>
<a class="l" name="1518" href="#1518">1518</a>Suppose you have multiple implementations of the same interface and want to make
<a class="l" name="1519" href="#1519">1519</a>sure that all of them satisfy some common requirements. Or, you may have defined
<a class="hl" name="1520" href="#1520">1520</a>several types that are supposed to conform to the same "concept" and you want to
<a class="l" name="1521" href="#1521">1521</a>verify it. In both cases, you want the same test logic repeated for different
<a class="l" name="1522" href="#1522">1522</a>types.
<a class="l" name="1523" href="#1523">1523</a>
<a class="l" name="1524" href="#1524">1524</a>While you can write one `TEST` or `TEST_F` for each type you want to test (and
<a class="l" name="1525" href="#1525">1525</a>you may even factor the test logic into a function template that you invoke from
<a class="l" name="1526" href="#1526">1526</a>the `TEST`), it's tedious and doesn't scale: if you want `m` tests over `n`
<a class="l" name="1527" href="#1527">1527</a>types, you'll end up writing `m*n` `TEST`s.
<a class="l" name="1528" href="#1528">1528</a>
<a class="l" name="1529" href="#1529">1529</a>*Typed tests* allow you to repeat the same test logic over a list of types. You
<a class="hl" name="1530" href="#1530">1530</a>only need to write the test logic once, although you must know the type list
<a class="l" name="1531" href="#1531">1531</a>when writing typed tests. Here's how you do it:
<a class="l" name="1532" href="#1532">1532</a>
<a class="l" name="1533" href="#1533">1533</a>First, define a fixture class template. It should be parameterized by a type.
<a class="l" name="1534" href="#1534">1534</a>Remember to derive it from `::testing::Test`:
<a class="l" name="1535" href="#1535">1535</a>
<a class="l" name="1536" href="#1536">1536</a>```c++
<a class="l" name="1537" href="#1537">1537</a>template &lt;typename T&gt;
<a class="l" name="1538" href="#1538">1538</a>class FooTest : public testing::Test {
<a class="l" name="1539" href="#1539">1539</a> public:
<a class="hl" name="1540" href="#1540">1540</a>  ...
<a class="l" name="1541" href="#1541">1541</a>  using List = std::list&lt;T&gt;;
<a class="l" name="1542" href="#1542">1542</a>  static T shared_;
<a class="l" name="1543" href="#1543">1543</a>  T value_;
<a class="l" name="1544" href="#1544">1544</a>};
<a class="l" name="1545" href="#1545">1545</a>```
<a class="l" name="1546" href="#1546">1546</a>
<a class="l" name="1547" href="#1547">1547</a>Next, associate a list of types with the test suite, which will be repeated for
<a class="l" name="1548" href="#1548">1548</a>each type in the list:
<a class="l" name="1549" href="#1549">1549</a>
<a class="hl" name="1550" href="#1550">1550</a>```c++
<a class="l" name="1551" href="#1551">1551</a>using MyTypes = ::testing::Types&lt;char, int, unsigned int&gt;;
<a class="l" name="1552" href="#1552">1552</a>TYPED_TEST_SUITE(FooTest, MyTypes);
<a class="l" name="1553" href="#1553">1553</a>```
<a class="l" name="1554" href="#1554">1554</a>
<a class="l" name="1555" href="#1555">1555</a>The type alias (`using` or `typedef`) is necessary for the `TYPED_TEST_SUITE`
<a class="l" name="1556" href="#1556">1556</a>macro to parse correctly. Otherwise the compiler will think that each comma in
<a class="l" name="1557" href="#1557">1557</a>the type list introduces a new macro argument.
<a class="l" name="1558" href="#1558">1558</a>
<a class="l" name="1559" href="#1559">1559</a>Then, use `TYPED_TEST()` instead of `TEST_F()` to define a typed test for this
<a class="hl" name="1560" href="#1560">1560</a>test suite. You can repeat this as many times as you want:
<a class="l" name="1561" href="#1561">1561</a>
<a class="l" name="1562" href="#1562">1562</a>```c++
<a class="l" name="1563" href="#1563">1563</a>TYPED_TEST(FooTest, DoesBlah) {
<a class="l" name="1564" href="#1564">1564</a>  // Inside a test, refer to the special name TypeParam to get the type
<a class="l" name="1565" href="#1565">1565</a>  // parameter.  Since we are inside a derived class template, C++ requires
<a class="l" name="1566" href="#1566">1566</a>  // us to visit the members of FooTest via 'this'.
<a class="l" name="1567" href="#1567">1567</a>  TypeParam n = this-&gt;value_;
<a class="l" name="1568" href="#1568">1568</a>
<a class="l" name="1569" href="#1569">1569</a>  // To visit static members of the fixture, add the 'TestFixture::'
<a class="hl" name="1570" href="#1570">1570</a>  // prefix.
<a class="l" name="1571" href="#1571">1571</a>  n += TestFixture::shared_;
<a class="l" name="1572" href="#1572">1572</a>
<a class="l" name="1573" href="#1573">1573</a>  // To refer to typedefs in the fixture, add the 'typename TestFixture::'
<a class="l" name="1574" href="#1574">1574</a>  // prefix.  The 'typename' is required to satisfy the compiler.
<a class="l" name="1575" href="#1575">1575</a>  typename TestFixture::List values;
<a class="l" name="1576" href="#1576">1576</a>
<a class="l" name="1577" href="#1577">1577</a>  <a href="/googletest/s?path=values.push_back&amp;project=googletest">values.push_back</a>(n);
<a class="l" name="1578" href="#1578">1578</a>  ...
<a class="l" name="1579" href="#1579">1579</a>}
<a class="hl" name="1580" href="#1580">1580</a>
<a class="l" name="1581" href="#1581">1581</a>TYPED_TEST(FooTest, HasPropertyA) { ... }
<a class="l" name="1582" href="#1582">1582</a>```
<a class="l" name="1583" href="#1583">1583</a>
<a class="l" name="1584" href="#1584">1584</a>You can see [<a href="/googletest/s?path=sample6_unittest.cc&amp;project=googletest">sample6_unittest.cc</a>] for a complete example.
<a class="l" name="1585" href="#1585">1585</a>
<a class="l" name="1586" href="#1586">1586</a>[<a href="/googletest/s?path=sample6_unittest.cc&amp;project=googletest">sample6_unittest.cc</a>]: ..<a href="/googletest/s?path=/samples/sample6_unittest.cc&amp;project=googletest">/samples/sample6_unittest.cc</a> "Typed Test example"
<a class="l" name="1587" href="#1587">1587</a>
<a class="l" name="1588" href="#1588">1588</a>## Type-Parameterized Tests
<a class="l" name="1589" href="#1589">1589</a>
<a class="hl" name="1590" href="#1590">1590</a>*Type-parameterized tests* are like typed tests, except that they don't require
<a class="l" name="1591" href="#1591">1591</a>you to know the list of types ahead of time. Instead, you can define the test
<a class="l" name="1592" href="#1592">1592</a>logic first and instantiate it with different type lists later. You can even
<a class="l" name="1593" href="#1593">1593</a>instantiate it more than once in the same program.
<a class="l" name="1594" href="#1594">1594</a>
<a class="l" name="1595" href="#1595">1595</a>If you are designing an interface or concept, you can define a suite of
<a class="l" name="1596" href="#1596">1596</a>type-parameterized tests to verify properties that any valid implementation of
<a class="l" name="1597" href="#1597">1597</a>the <a href="/googletest/s?path=interface/concept&amp;project=googletest">interface/concept</a> should have. Then, the author of each implementation can
<a class="l" name="1598" href="#1598">1598</a>just instantiate the test suite with their type to verify that it conforms to
<a class="l" name="1599" href="#1599">1599</a>the requirements, without having to write similar tests repeatedly. Here's an
<a class="hl" name="1600" href="#1600">1600</a>example:
<a class="l" name="1601" href="#1601">1601</a>
<a class="l" name="1602" href="#1602">1602</a>First, define a fixture class template, as we did with typed tests:
<a class="l" name="1603" href="#1603">1603</a>
<a class="l" name="1604" href="#1604">1604</a>```c++
<a class="l" name="1605" href="#1605">1605</a>template &lt;typename T&gt;
<a class="l" name="1606" href="#1606">1606</a>class FooTest : public testing::Test {
<a class="l" name="1607" href="#1607">1607</a>  ...
<a class="l" name="1608" href="#1608">1608</a>};
<a class="l" name="1609" href="#1609">1609</a>```
<a class="hl" name="1610" href="#1610">1610</a>
<a class="l" name="1611" href="#1611">1611</a>Next, declare that you will define a type-parameterized test suite:
<a class="l" name="1612" href="#1612">1612</a>
<a class="l" name="1613" href="#1613">1613</a>```c++
<a class="l" name="1614" href="#1614">1614</a>TYPED_TEST_SUITE_P(FooTest);
<a class="l" name="1615" href="#1615">1615</a>```
<a class="l" name="1616" href="#1616">1616</a>
<a class="l" name="1617" href="#1617">1617</a>Then, use `TYPED_TEST_P()` to define a type-parameterized test. You can repeat
<a class="l" name="1618" href="#1618">1618</a>this as many times as you want:
<a class="l" name="1619" href="#1619">1619</a>
<a class="hl" name="1620" href="#1620">1620</a>```c++
<a class="l" name="1621" href="#1621">1621</a>TYPED_TEST_P(FooTest, DoesBlah) {
<a class="l" name="1622" href="#1622">1622</a>  // Inside a test, refer to TypeParam to get the type parameter.
<a class="l" name="1623" href="#1623">1623</a>  TypeParam n = 0;
<a class="l" name="1624" href="#1624">1624</a>  ...
<a class="l" name="1625" href="#1625">1625</a>}
<a class="l" name="1626" href="#1626">1626</a>
<a class="l" name="1627" href="#1627">1627</a>TYPED_TEST_P(FooTest, HasPropertyA) { ... }
<a class="l" name="1628" href="#1628">1628</a>```
<a class="l" name="1629" href="#1629">1629</a>
<a class="hl" name="1630" href="#1630">1630</a>Now the tricky part: you need to register all test patterns using the
<a class="l" name="1631" href="#1631">1631</a>`REGISTER_TYPED_TEST_SUITE_P` macro before you can instantiate them. The first
<a class="l" name="1632" href="#1632">1632</a>argument of the macro is the test suite name; the rest are the names of the
<a class="l" name="1633" href="#1633">1633</a>tests in this test suite:
<a class="l" name="1634" href="#1634">1634</a>
<a class="l" name="1635" href="#1635">1635</a>```c++
<a class="l" name="1636" href="#1636">1636</a>REGISTER_TYPED_TEST_SUITE_P(FooTest,
<a class="l" name="1637" href="#1637">1637</a>                            DoesBlah, HasPropertyA);
<a class="l" name="1638" href="#1638">1638</a>```
<a class="l" name="1639" href="#1639">1639</a>
<a class="hl" name="1640" href="#1640">1640</a>Finally, you are free to instantiate the pattern with the types you want. If you
<a class="l" name="1641" href="#1641">1641</a>put the above code in a header file, you can `#include` it in multiple C++
<a class="l" name="1642" href="#1642">1642</a>source files and instantiate it multiple times.
<a class="l" name="1643" href="#1643">1643</a>
<a class="l" name="1644" href="#1644">1644</a>```c++
<a class="l" name="1645" href="#1645">1645</a>using MyTypes = ::testing::Types&lt;char, int, unsigned int&gt;;
<a class="l" name="1646" href="#1646">1646</a>INSTANTIATE_TYPED_TEST_SUITE_P(My, FooTest, MyTypes);
<a class="l" name="1647" href="#1647">1647</a>```
<a class="l" name="1648" href="#1648">1648</a>
<a class="l" name="1649" href="#1649">1649</a>To distinguish different instances of the pattern, the first argument to the
<a class="hl" name="1650" href="#1650">1650</a>`INSTANTIATE_TYPED_TEST_SUITE_P` macro is a prefix that will be added to the
<a class="l" name="1651" href="#1651">1651</a>actual test suite name. Remember to pick unique prefixes for different
<a class="l" name="1652" href="#1652">1652</a>instances.
<a class="l" name="1653" href="#1653">1653</a>
<a class="l" name="1654" href="#1654">1654</a>In the special case where the type list contains only one type, you can write
<a class="l" name="1655" href="#1655">1655</a>that type directly without `::testing::Types&lt;...&gt;`, like this:
<a class="l" name="1656" href="#1656">1656</a>
<a class="l" name="1657" href="#1657">1657</a>```c++
<a class="l" name="1658" href="#1658">1658</a>INSTANTIATE_TYPED_TEST_SUITE_P(My, FooTest, int);
<a class="l" name="1659" href="#1659">1659</a>```
<a class="hl" name="1660" href="#1660">1660</a>
<a class="l" name="1661" href="#1661">1661</a>You can see [<a href="/googletest/s?path=sample6_unittest.cc&amp;project=googletest">sample6_unittest.cc</a>] for a complete example.
<a class="l" name="1662" href="#1662">1662</a>
<a class="l" name="1663" href="#1663">1663</a>## Testing Private Code
<a class="l" name="1664" href="#1664">1664</a>
<a class="l" name="1665" href="#1665">1665</a>If you change your software's internal implementation, your tests should not
<a class="l" name="1666" href="#1666">1666</a>break as long as the change is not observable by users. Therefore, **per the
<a class="l" name="1667" href="#1667">1667</a>black-box testing principle, most of the time you should test your code through
<a class="l" name="1668" href="#1668">1668</a>its public interfaces.**
<a class="l" name="1669" href="#1669">1669</a>
<a class="hl" name="1670" href="#1670">1670</a>**If you still find yourself needing to test internal implementation code,
<a class="l" name="1671" href="#1671">1671</a>consider if there's a better design.** The desire to test internal
<a class="l" name="1672" href="#1672">1672</a>implementation is often a sign that the class is doing too much. Consider
<a class="l" name="1673" href="#1673">1673</a>extracting an implementation class, and testing it. Then use that implementation
<a class="l" name="1674" href="#1674">1674</a>class in the original class.
<a class="l" name="1675" href="#1675">1675</a>
<a class="l" name="1676" href="#1676">1676</a>If you absolutely have to test non-public interface code though, you can. There
<a class="l" name="1677" href="#1677">1677</a>are two cases to consider:
<a class="l" name="1678" href="#1678">1678</a>
<a class="l" name="1679" href="#1679">1679</a>*   Static functions ( *not* the same as static member functions!) or unnamed
<a class="hl" name="1680" href="#1680">1680</a>    namespaces, and
<a class="l" name="1681" href="#1681">1681</a>*   Private or protected class members
<a class="l" name="1682" href="#1682">1682</a>
<a class="l" name="1683" href="#1683">1683</a>To test them, we use the following special techniques:
<a class="l" name="1684" href="#1684">1684</a>
<a class="l" name="1685" href="#1685">1685</a>*   Both static functions and <a href="/googletest/s?path=definitions/declarations&amp;project=googletest">definitions/declarations</a> in an unnamed namespace
<a class="l" name="1686" href="#1686">1686</a>    are only visible within the same translation unit. To test them, you can
<a class="l" name="1687" href="#1687">1687</a>    `#include` the entire `.cc` file being tested in your `*<a href="/googletest/s?path=_test.cc&amp;project=googletest">_test.cc</a>` file.
<a class="l" name="1688" href="#1688">1688</a>    (#including `.cc` files is not a good way to reuse code - you should not do
<a class="l" name="1689" href="#1689">1689</a>    this in production code!)
<a class="hl" name="1690" href="#1690">1690</a>
<a class="l" name="1691" href="#1691">1691</a>    However, a better approach is to move the private code into the
<a class="l" name="1692" href="#1692">1692</a>    `foo::internal` namespace, where `foo` is the namespace your project
<a class="l" name="1693" href="#1693">1693</a>    normally uses, and put the private declarations in a `*<a href="/googletest/s?path=-internal.h&amp;project=googletest">-internal.h</a>` file.
<a class="l" name="1694" href="#1694">1694</a>    Your production `.cc` files and your tests are allowed to include this
<a class="l" name="1695" href="#1695">1695</a>    internal header, but your clients are not. This way, you can fully test your
<a class="l" name="1696" href="#1696">1696</a>    internal implementation without leaking it to your clients.
<a class="l" name="1697" href="#1697">1697</a>
<a class="l" name="1698" href="#1698">1698</a>*   Private class members are only accessible from within the class or by
<a class="l" name="1699" href="#1699">1699</a>    friends. To access a class' private members, you can declare your test
<a class="hl" name="1700" href="#1700">1700</a>    fixture as a friend to the class and define accessors in your fixture. Tests
<a class="l" name="1701" href="#1701">1701</a>    using the fixture can then access the private members of your production
<a class="l" name="1702" href="#1702">1702</a>    class via the accessors in the fixture. Note that even though your fixture
<a class="l" name="1703" href="#1703">1703</a>    is a friend to your production class, your tests are not automatically
<a class="l" name="1704" href="#1704">1704</a>    friends to it, as they are technically defined in sub-classes of the
<a class="l" name="1705" href="#1705">1705</a>    fixture.
<a class="l" name="1706" href="#1706">1706</a>
<a class="l" name="1707" href="#1707">1707</a>    Another way to test private members is to refactor them into an
<a class="l" name="1708" href="#1708">1708</a>    implementation class, which is then declared in a `*<a href="/googletest/s?path=-internal.h&amp;project=googletest">-internal.h</a>` file. Your
<a class="l" name="1709" href="#1709">1709</a>    clients aren't allowed to include this header but your tests can. Such is
<a class="hl" name="1710" href="#1710">1710</a>    called the
<a class="l" name="1711" href="#1711">1711</a>    [Pimpl](<a href="https://www.gamedev.net/articles/programming/general-and-gameplay-programming/the-c-pimpl-r1794/">https://www.gamedev.net/articles/programming/general-and-gameplay-programming/the-c-pimpl-r1794/</a>)
<a class="l" name="1712" href="#1712">1712</a>    (Private Implementation) idiom.
<a class="l" name="1713" href="#1713">1713</a>
<a class="l" name="1714" href="#1714">1714</a>    Or, you can declare an individual test as a friend of your class by adding
<a class="l" name="1715" href="#1715">1715</a>    this line in the class body:
<a class="l" name="1716" href="#1716">1716</a>
<a class="l" name="1717" href="#1717">1717</a>    ```c++
<a class="l" name="1718" href="#1718">1718</a>        FRIEND_TEST(TestSuiteName, TestName);
<a class="l" name="1719" href="#1719">1719</a>    ```
<a class="hl" name="1720" href="#1720">1720</a>
<a class="l" name="1721" href="#1721">1721</a>    For example,
<a class="l" name="1722" href="#1722">1722</a>
<a class="l" name="1723" href="#1723">1723</a>    ```c++
<a class="l" name="1724" href="#1724">1724</a>    // <a href="/googletest/s?path=foo.h&amp;project=googletest">foo.h</a>
<a class="l" name="1725" href="#1725">1725</a>    class Foo {
<a class="l" name="1726" href="#1726">1726</a>      ...
<a class="l" name="1727" href="#1727">1727</a>     private:
<a class="l" name="1728" href="#1728">1728</a>      FRIEND_TEST(FooTest, BarReturnsZeroOnNull);
<a class="l" name="1729" href="#1729">1729</a>
<a class="hl" name="1730" href="#1730">1730</a>      int Bar(void* x);
<a class="l" name="1731" href="#1731">1731</a>    };
<a class="l" name="1732" href="#1732">1732</a>
<a class="l" name="1733" href="#1733">1733</a>    // <a href="/googletest/s?path=foo_test.cc&amp;project=googletest">foo_test.cc</a>
<a class="l" name="1734" href="#1734">1734</a>    ...
<a class="l" name="1735" href="#1735">1735</a>    TEST(FooTest, BarReturnsZeroOnNull) {
<a class="l" name="1736" href="#1736">1736</a>      Foo foo;
<a class="l" name="1737" href="#1737">1737</a>      EXPECT_EQ(<a href="/googletest/s?path=foo.Bar&amp;project=googletest">foo.Bar</a>(NULL), 0);  // Uses Foo's private member Bar().
<a class="l" name="1738" href="#1738">1738</a>    }
<a class="l" name="1739" href="#1739">1739</a>    ```
<a class="hl" name="1740" href="#1740">1740</a>
<a class="l" name="1741" href="#1741">1741</a>    Pay special attention when your class is defined in a namespace, as you
<a class="l" name="1742" href="#1742">1742</a>    should define your test fixtures and tests in the same namespace if you want
<a class="l" name="1743" href="#1743">1743</a>    them to be friends of your class. For example, if the code to be tested
<a class="l" name="1744" href="#1744">1744</a>    looks like:
<a class="l" name="1745" href="#1745">1745</a>
<a class="l" name="1746" href="#1746">1746</a>    ```c++
<a class="l" name="1747" href="#1747">1747</a>    namespace my_namespace {
<a class="l" name="1748" href="#1748">1748</a>
<a class="l" name="1749" href="#1749">1749</a>    class Foo {
<a class="hl" name="1750" href="#1750">1750</a>      friend class FooTest;
<a class="l" name="1751" href="#1751">1751</a>      FRIEND_TEST(FooTest, Bar);
<a class="l" name="1752" href="#1752">1752</a>      FRIEND_TEST(FooTest, Baz);
<a class="l" name="1753" href="#1753">1753</a>      ... definition of the class Foo ...
<a class="l" name="1754" href="#1754">1754</a>    };
<a class="l" name="1755" href="#1755">1755</a>
<a class="l" name="1756" href="#1756">1756</a>    }  // namespace my_namespace
<a class="l" name="1757" href="#1757">1757</a>    ```
<a class="l" name="1758" href="#1758">1758</a>
<a class="l" name="1759" href="#1759">1759</a>    Your test code should be something like:
<a class="hl" name="1760" href="#1760">1760</a>
<a class="l" name="1761" href="#1761">1761</a>    ```c++
<a class="l" name="1762" href="#1762">1762</a>    namespace my_namespace {
<a class="l" name="1763" href="#1763">1763</a>
<a class="l" name="1764" href="#1764">1764</a>    class FooTest : public testing::Test {
<a class="l" name="1765" href="#1765">1765</a>     protected:
<a class="l" name="1766" href="#1766">1766</a>      ...
<a class="l" name="1767" href="#1767">1767</a>    };
<a class="l" name="1768" href="#1768">1768</a>
<a class="l" name="1769" href="#1769">1769</a>    TEST_F(FooTest, Bar) { ... }
<a class="hl" name="1770" href="#1770">1770</a>    TEST_F(FooTest, Baz) { ... }
<a class="l" name="1771" href="#1771">1771</a>
<a class="l" name="1772" href="#1772">1772</a>    }  // namespace my_namespace
<a class="l" name="1773" href="#1773">1773</a>    ```
<a class="l" name="1774" href="#1774">1774</a>
<a class="l" name="1775" href="#1775">1775</a>## "Catching" Failures
<a class="l" name="1776" href="#1776">1776</a>
<a class="l" name="1777" href="#1777">1777</a>If you are building a testing utility on top of googletest, you'll want to test
<a class="l" name="1778" href="#1778">1778</a>your utility. What framework would you use to test it? googletest, of course.
<a class="l" name="1779" href="#1779">1779</a>
<a class="hl" name="1780" href="#1780">1780</a>The challenge is to verify that your testing utility reports failures correctly.
<a class="l" name="1781" href="#1781">1781</a>In frameworks that report a failure by throwing an exception, you could catch
<a class="l" name="1782" href="#1782">1782</a>the exception and assert on it. But googletest doesn't use exceptions, so how do
<a class="l" name="1783" href="#1783">1783</a>we test that a piece of code generates an expected failure?
<a class="l" name="1784" href="#1784">1784</a>
<a class="l" name="1785" href="#1785">1785</a>`"<a href="/googletest/s?path=gtest/gtest-spi.h&amp;project=googletest">gtest/gtest-spi.h</a>"` contains some constructs to do this. After #including this header,
<a class="l" name="1786" href="#1786">1786</a>you can use
<a class="l" name="1787" href="#1787">1787</a>
<a class="l" name="1788" href="#1788">1788</a>```c++
<a class="l" name="1789" href="#1789">1789</a>  EXPECT_FATAL_FAILURE(statement, substring);
<a class="hl" name="1790" href="#1790">1790</a>```
<a class="l" name="1791" href="#1791">1791</a>
<a class="l" name="1792" href="#1792">1792</a>to assert that `statement` generates a fatal (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `ASSERT_*`) failure in the
<a class="l" name="1793" href="#1793">1793</a>current thread whose message contains the given `substring`, or use
<a class="l" name="1794" href="#1794">1794</a>
<a class="l" name="1795" href="#1795">1795</a>```c++
<a class="l" name="1796" href="#1796">1796</a>  EXPECT_NONFATAL_FAILURE(statement, substring);
<a class="l" name="1797" href="#1797">1797</a>```
<a class="l" name="1798" href="#1798">1798</a>
<a class="l" name="1799" href="#1799">1799</a>if you are expecting a non-fatal (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `EXPECT_*`) failure.
<a class="hl" name="1800" href="#1800">1800</a>
<a class="l" name="1801" href="#1801">1801</a>Only failures in the current thread are checked to determine the result of this
<a class="l" name="1802" href="#1802">1802</a>type of expectations. If `statement` creates new threads, failures in these
<a class="l" name="1803" href="#1803">1803</a>threads are also ignored. If you want to catch failures in other threads as
<a class="l" name="1804" href="#1804">1804</a>well, use one of the following macros instead:
<a class="l" name="1805" href="#1805">1805</a>
<a class="l" name="1806" href="#1806">1806</a>```c++
<a class="l" name="1807" href="#1807">1807</a>  EXPECT_FATAL_FAILURE_ON_ALL_THREADS(statement, substring);
<a class="l" name="1808" href="#1808">1808</a>  EXPECT_NONFATAL_FAILURE_ON_ALL_THREADS(statement, substring);
<a class="l" name="1809" href="#1809">1809</a>```
<a class="hl" name="1810" href="#1810">1810</a>
<a class="l" name="1811" href="#1811">1811</a>NOTE: Assertions from multiple threads are currently not supported on Windows.
<a class="l" name="1812" href="#1812">1812</a>
<a class="l" name="1813" href="#1813">1813</a>For technical reasons, there are some caveats:
<a class="l" name="1814" href="#1814">1814</a>
<a class="l" name="1815" href="#1815">1815</a>1.  You cannot stream a failure message to either macro.
<a class="l" name="1816" href="#1816">1816</a>
<a class="l" name="1817" href="#1817">1817</a>2.  `statement` in `EXPECT_FATAL_FAILURE{_ON_ALL_THREADS}()` cannot reference
<a class="l" name="1818" href="#1818">1818</a>    local non-static variables or non-static members of `this` object.
<a class="l" name="1819" href="#1819">1819</a>
<a class="hl" name="1820" href="#1820">1820</a>3.  `statement` in `EXPECT_FATAL_FAILURE{_ON_ALL_THREADS}()` cannot return a
<a class="l" name="1821" href="#1821">1821</a>    value.
<a class="l" name="1822" href="#1822">1822</a>
<a class="l" name="1823" href="#1823">1823</a>## Registering tests programmatically
<a class="l" name="1824" href="#1824">1824</a>
<a class="l" name="1825" href="#1825">1825</a>The `TEST` macros handle the vast majority of all use cases, but there are few
<a class="l" name="1826" href="#1826">1826</a>where runtime registration logic is required. For those cases, the framework
<a class="l" name="1827" href="#1827">1827</a>provides the `::testing::RegisterTest` that allows callers to register arbitrary
<a class="l" name="1828" href="#1828">1828</a>tests dynamically.
<a class="l" name="1829" href="#1829">1829</a>
<a class="hl" name="1830" href="#1830">1830</a>This is an advanced API only to be used when the `TEST` macros are insufficient.
<a class="l" name="1831" href="#1831">1831</a>The macros should be preferred when possible, as they avoid most of the
<a class="l" name="1832" href="#1832">1832</a>complexity of calling this function.
<a class="l" name="1833" href="#1833">1833</a>
<a class="l" name="1834" href="#1834">1834</a>It provides the following signature:
<a class="l" name="1835" href="#1835">1835</a>
<a class="l" name="1836" href="#1836">1836</a>```c++
<a class="l" name="1837" href="#1837">1837</a>template &lt;typename Factory&gt;
<a class="l" name="1838" href="#1838">1838</a>TestInfo* RegisterTest(const char* test_suite_name, const char* test_name,
<a class="l" name="1839" href="#1839">1839</a>                       const char* type_param, const char* value_param,
<a class="hl" name="1840" href="#1840">1840</a>                       const char* file, int line, Factory factory);
<a class="l" name="1841" href="#1841">1841</a>```
<a class="l" name="1842" href="#1842">1842</a>
<a class="l" name="1843" href="#1843">1843</a>The `factory` argument is a factory callable (move-constructible) object or
<a class="l" name="1844" href="#1844">1844</a>function pointer that creates a new instance of the Test object. It handles
<a class="l" name="1845" href="#1845">1845</a>ownership to the caller. The signature of the callable is `Fixture*()`, where
<a class="l" name="1846" href="#1846">1846</a>`Fixture` is the test fixture class for the test. All tests registered with the
<a class="l" name="1847" href="#1847">1847</a>same `test_suite_name` must return the same fixture type. This is checked at
<a class="l" name="1848" href="#1848">1848</a>runtime.
<a class="l" name="1849" href="#1849">1849</a>
<a class="hl" name="1850" href="#1850">1850</a>The framework will infer the fixture class from the factory and will call the
<a class="l" name="1851" href="#1851">1851</a>`SetUpTestSuite` and `TearDownTestSuite` for it.
<a class="l" name="1852" href="#1852">1852</a>
<a class="l" name="1853" href="#1853">1853</a>Must be called before `RUN_ALL_TESTS()` is invoked, otherwise behavior is
<a class="l" name="1854" href="#1854">1854</a>undefined.
<a class="l" name="1855" href="#1855">1855</a>
<a class="l" name="1856" href="#1856">1856</a>Use case example:
<a class="l" name="1857" href="#1857">1857</a>
<a class="l" name="1858" href="#1858">1858</a>```c++
<a class="l" name="1859" href="#1859">1859</a>class MyFixture : public testing::Test {
<a class="hl" name="1860" href="#1860">1860</a> public:
<a class="l" name="1861" href="#1861">1861</a>  // All of these optional, just like in regular macro usage.
<a class="l" name="1862" href="#1862">1862</a>  static void SetUpTestSuite() { ... }
<a class="l" name="1863" href="#1863">1863</a>  static void TearDownTestSuite() { ... }
<a class="l" name="1864" href="#1864">1864</a>  void SetUp() override { ... }
<a class="l" name="1865" href="#1865">1865</a>  void TearDown() override { ... }
<a class="l" name="1866" href="#1866">1866</a>};
<a class="l" name="1867" href="#1867">1867</a>
<a class="l" name="1868" href="#1868">1868</a>class MyTest : public MyFixture {
<a class="l" name="1869" href="#1869">1869</a> public:
<a class="hl" name="1870" href="#1870">1870</a>  explicit MyTest(int data) : data_(data) {}
<a class="l" name="1871" href="#1871">1871</a>  void TestBody() override { ... }
<a class="l" name="1872" href="#1872">1872</a>
<a class="l" name="1873" href="#1873">1873</a> private:
<a class="l" name="1874" href="#1874">1874</a>  int data_;
<a class="l" name="1875" href="#1875">1875</a>};
<a class="l" name="1876" href="#1876">1876</a>
<a class="l" name="1877" href="#1877">1877</a>void RegisterMyTests(const std::vector&lt;int&gt;&amp; values) {
<a class="l" name="1878" href="#1878">1878</a>  for (int v : values) {
<a class="l" name="1879" href="#1879">1879</a>    testing::RegisterTest(
<a class="hl" name="1880" href="#1880">1880</a>        "MyFixture", ("Test" + std::to_string(v)).c_str(), nullptr,
<a class="l" name="1881" href="#1881">1881</a>        std::to_string(v).c_str(),
<a class="l" name="1882" href="#1882">1882</a>        __FILE__, __LINE__,
<a class="l" name="1883" href="#1883">1883</a>        // Important to use the fixture type as the return type here.
<a class="l" name="1884" href="#1884">1884</a>        [=]() -&gt; MyFixture* { return new MyTest(v); });
<a class="l" name="1885" href="#1885">1885</a>  }
<a class="l" name="1886" href="#1886">1886</a>}
<a class="l" name="1887" href="#1887">1887</a>...
<a class="l" name="1888" href="#1888">1888</a>int main(int argc, char** argv) {
<a class="l" name="1889" href="#1889">1889</a>  std::vector&lt;int&gt; values_to_test = LoadValuesFromConfig();
<a class="hl" name="1890" href="#1890">1890</a>  RegisterMyTests(values_to_test);
<a class="l" name="1891" href="#1891">1891</a>  ...
<a class="l" name="1892" href="#1892">1892</a>  return RUN_ALL_TESTS();
<a class="l" name="1893" href="#1893">1893</a>}
<a class="l" name="1894" href="#1894">1894</a>```
<a class="l" name="1895" href="#1895">1895</a>## Getting the Current Test's Name
<a class="l" name="1896" href="#1896">1896</a>
<a class="l" name="1897" href="#1897">1897</a>Sometimes a function may need to know the name of the currently running test.
<a class="l" name="1898" href="#1898">1898</a>For example, you may be using the `SetUp()` method of your test fixture to set
<a class="l" name="1899" href="#1899">1899</a>the golden file name based on which test is running. The `::testing::TestInfo`
<a class="hl" name="1900" href="#1900">1900</a>class has this information:
<a class="l" name="1901" href="#1901">1901</a>
<a class="l" name="1902" href="#1902">1902</a>```c++
<a class="l" name="1903" href="#1903">1903</a>namespace testing {
<a class="l" name="1904" href="#1904">1904</a>
<a class="l" name="1905" href="#1905">1905</a>class TestInfo {
<a class="l" name="1906" href="#1906">1906</a> public:
<a class="l" name="1907" href="#1907">1907</a>  // Returns the test suite name and the test name, respectively.
<a class="l" name="1908" href="#1908">1908</a>  //
<a class="l" name="1909" href="#1909">1909</a>  // Do NOT delete or free the return value - it's managed by the
<a class="hl" name="1910" href="#1910">1910</a>  // TestInfo class.
<a class="l" name="1911" href="#1911">1911</a>  const char* test_suite_name() const;
<a class="l" name="1912" href="#1912">1912</a>  const char* name() const;
<a class="l" name="1913" href="#1913">1913</a>};
<a class="l" name="1914" href="#1914">1914</a>
<a class="l" name="1915" href="#1915">1915</a>}
<a class="l" name="1916" href="#1916">1916</a>```
<a class="l" name="1917" href="#1917">1917</a>
<a class="l" name="1918" href="#1918">1918</a>To obtain a `TestInfo` object for the currently running test, call
<a class="l" name="1919" href="#1919">1919</a>`current_test_info()` on the `UnitTest` singleton object:
<a class="hl" name="1920" href="#1920">1920</a>
<a class="l" name="1921" href="#1921">1921</a>```c++
<a class="l" name="1922" href="#1922">1922</a>  // Gets information about the currently running test.
<a class="l" name="1923" href="#1923">1923</a>  // Do NOT delete the returned object - it's managed by the UnitTest class.
<a class="l" name="1924" href="#1924">1924</a>  const testing::TestInfo* const test_info =
<a class="l" name="1925" href="#1925">1925</a>      testing::UnitTest::GetInstance()-&gt;current_test_info();
<a class="l" name="1926" href="#1926">1926</a>
<a class="l" name="1927" href="#1927">1927</a>  printf("We are in test %s of test suite %s.\n",
<a class="l" name="1928" href="#1928">1928</a>         test_info-&gt;name(),
<a class="l" name="1929" href="#1929">1929</a>         test_info-&gt;test_suite_name());
<a class="hl" name="1930" href="#1930">1930</a>```
<a class="l" name="1931" href="#1931">1931</a>
<a class="l" name="1932" href="#1932">1932</a>`current_test_info()` returns a null pointer if no test is running. In
<a class="l" name="1933" href="#1933">1933</a>particular, you cannot find the test suite name in `SetUpTestSuite()`,
<a class="l" name="1934" href="#1934">1934</a>`TearDownTestSuite()` (where you know the test suite name implicitly), or
<a class="l" name="1935" href="#1935">1935</a>functions called from them.
<a class="l" name="1936" href="#1936">1936</a>
<a class="l" name="1937" href="#1937">1937</a>## Extending googletest by Handling Test Events
<a class="l" name="1938" href="#1938">1938</a>
<a class="l" name="1939" href="#1939">1939</a>googletest provides an **event listener API** to let you receive notifications
<a class="hl" name="1940" href="#1940">1940</a>about the progress of a test program and test failures. The events you can
<a class="l" name="1941" href="#1941">1941</a>listen to include the start and end of the test program, a test suite, or a test
<a class="l" name="1942" href="#1942">1942</a>method, among others. You may use this API to augment or replace the standard
<a class="l" name="1943" href="#1943">1943</a>console output, replace the XML output, or provide a completely different form
<a class="l" name="1944" href="#1944">1944</a>of output, such as a GUI or a database. You can also use test events as
<a class="l" name="1945" href="#1945">1945</a>checkpoints to implement a resource leak checker, for example.
<a class="l" name="1946" href="#1946">1946</a>
<a class="l" name="1947" href="#1947">1947</a>### Defining Event Listeners
<a class="l" name="1948" href="#1948">1948</a>
<a class="l" name="1949" href="#1949">1949</a>To define a event listener, you subclass either testing::TestEventListener or
<a class="hl" name="1950" href="#1950">1950</a>testing::EmptyTestEventListener The former is an (abstract) interface, where
<a class="l" name="1951" href="#1951">1951</a>*each pure virtual method can be overridden to handle a test event* (For
<a class="l" name="1952" href="#1952">1952</a>example, when a test starts, the `OnTestStart()` method will be called.). The
<a class="l" name="1953" href="#1953">1953</a>latter provides an empty implementation of all methods in the interface, such
<a class="l" name="1954" href="#1954">1954</a>that a subclass only needs to override the methods it cares about.
<a class="l" name="1955" href="#1955">1955</a>
<a class="l" name="1956" href="#1956">1956</a>When an event is fired, its context is passed to the handler function as an
<a class="l" name="1957" href="#1957">1957</a>argument. The following argument types are used:
<a class="l" name="1958" href="#1958">1958</a>
<a class="l" name="1959" href="#1959">1959</a>*   UnitTest reflects the state of the entire test program,
<a class="hl" name="1960" href="#1960">1960</a>*   TestSuite has information about a test suite, which can contain one or more
<a class="l" name="1961" href="#1961">1961</a>    tests,
<a class="l" name="1962" href="#1962">1962</a>*   TestInfo contains the state of a test, and
<a class="l" name="1963" href="#1963">1963</a>*   TestPartResult represents the result of a test assertion.
<a class="l" name="1964" href="#1964">1964</a>
<a class="l" name="1965" href="#1965">1965</a>An event handler function can examine the argument it receives to find out
<a class="l" name="1966" href="#1966">1966</a>interesting information about the event and the test program's state.
<a class="l" name="1967" href="#1967">1967</a>
<a class="l" name="1968" href="#1968">1968</a>Here's an example:
<a class="l" name="1969" href="#1969">1969</a>
<a class="hl" name="1970" href="#1970">1970</a>```c++
<a class="l" name="1971" href="#1971">1971</a>  class MinimalistPrinter : public testing::EmptyTestEventListener {
<a class="l" name="1972" href="#1972">1972</a>    // Called before a test starts.
<a class="l" name="1973" href="#1973">1973</a>    virtual void OnTestStart(const testing::TestInfo&amp; test_info) {
<a class="l" name="1974" href="#1974">1974</a>      printf("*** Test %s.%s starting.\n",
<a class="l" name="1975" href="#1975">1975</a>             <a href="/googletest/s?path=test_info.test_suite_name&amp;project=googletest">test_info.test_suite_name</a>(), <a href="/googletest/s?path=test_info.name&amp;project=googletest">test_info.name</a>());
<a class="l" name="1976" href="#1976">1976</a>    }
<a class="l" name="1977" href="#1977">1977</a>
<a class="l" name="1978" href="#1978">1978</a>    // Called after a failed assertion or a SUCCESS().
<a class="l" name="1979" href="#1979">1979</a>    virtual void OnTestPartResult(const testing::TestPartResult&amp; test_part_result) {
<a class="hl" name="1980" href="#1980">1980</a>      printf("%s in %s:%d\n%s\n",
<a class="l" name="1981" href="#1981">1981</a>             <a href="/googletest/s?path=test_part_result.failed&amp;project=googletest">test_part_result.failed</a>() ? "*** Failure" : "Success",
<a class="l" name="1982" href="#1982">1982</a>             <a href="/googletest/s?path=test_part_result.file_name&amp;project=googletest">test_part_result.file_name</a>(),
<a class="l" name="1983" href="#1983">1983</a>             <a href="/googletest/s?path=test_part_result.line_number&amp;project=googletest">test_part_result.line_number</a>(),
<a class="l" name="1984" href="#1984">1984</a>             <a href="/googletest/s?path=test_part_result.summary&amp;project=googletest">test_part_result.summary</a>());
<a class="l" name="1985" href="#1985">1985</a>    }
<a class="l" name="1986" href="#1986">1986</a>
<a class="l" name="1987" href="#1987">1987</a>    // Called after a test ends.
<a class="l" name="1988" href="#1988">1988</a>    virtual void OnTestEnd(const testing::TestInfo&amp; test_info) {
<a class="l" name="1989" href="#1989">1989</a>      printf("*** Test %s.%s ending.\n",
<a class="hl" name="1990" href="#1990">1990</a>             <a href="/googletest/s?path=test_info.test_suite_name&amp;project=googletest">test_info.test_suite_name</a>(), <a href="/googletest/s?path=test_info.name&amp;project=googletest">test_info.name</a>());
<a class="l" name="1991" href="#1991">1991</a>    }
<a class="l" name="1992" href="#1992">1992</a>  };
<a class="l" name="1993" href="#1993">1993</a>```
<a class="l" name="1994" href="#1994">1994</a>
<a class="l" name="1995" href="#1995">1995</a>### Using Event Listeners
<a class="l" name="1996" href="#1996">1996</a>
<a class="l" name="1997" href="#1997">1997</a>To use the event listener you have defined, add an instance of it to the
<a class="l" name="1998" href="#1998">1998</a>googletest event listener list (represented by class TestEventListeners - note
<a class="l" name="1999" href="#1999">1999</a>the "s" at the end of the name) in your `main()` function, before calling
<a class="hl" name="2000" href="#2000">2000</a>`RUN_ALL_TESTS()`:
<a class="l" name="2001" href="#2001">2001</a>
<a class="l" name="2002" href="#2002">2002</a>```c++
<a class="l" name="2003" href="#2003">2003</a>int main(int argc, char** argv) {
<a class="l" name="2004" href="#2004">2004</a>  testing::InitGoogleTest(&amp;argc, argv);
<a class="l" name="2005" href="#2005">2005</a>  // Gets hold of the event listener list.
<a class="l" name="2006" href="#2006">2006</a>  testing::TestEventListeners&amp; listeners =
<a class="l" name="2007" href="#2007">2007</a>      testing::UnitTest::GetInstance()-&gt;listeners();
<a class="l" name="2008" href="#2008">2008</a>  // Adds a listener to the end.  googletest takes the ownership.
<a class="l" name="2009" href="#2009">2009</a>  <a href="/googletest/s?path=listeners.Append&amp;project=googletest">listeners.Append</a>(new MinimalistPrinter);
<a class="hl" name="2010" href="#2010">2010</a>  return RUN_ALL_TESTS();
<a class="l" name="2011" href="#2011">2011</a>}
<a class="l" name="2012" href="#2012">2012</a>```
<a class="l" name="2013" href="#2013">2013</a>
<a class="l" name="2014" href="#2014">2014</a>There's only one problem: the default test result printer is still in effect, so
<a class="l" name="2015" href="#2015">2015</a>its output will mingle with the output from your minimalist printer. To suppress
<a class="l" name="2016" href="#2016">2016</a>the default printer, just release it from the event listener list and delete it.
<a class="l" name="2017" href="#2017">2017</a>You can do so by adding one line:
<a class="l" name="2018" href="#2018">2018</a>
<a class="l" name="2019" href="#2019">2019</a>```c++
<a class="hl" name="2020" href="#2020">2020</a>  ...
<a class="l" name="2021" href="#2021">2021</a>  delete <a href="/googletest/s?path=listeners.Release&amp;project=googletest">listeners.Release</a>(<a href="/googletest/s?path=listeners.default_result_printer&amp;project=googletest">listeners.default_result_printer</a>());
<a class="l" name="2022" href="#2022">2022</a>  <a href="/googletest/s?path=listeners.Append&amp;project=googletest">listeners.Append</a>(new MinimalistPrinter);
<a class="l" name="2023" href="#2023">2023</a>  return RUN_ALL_TESTS();
<a class="l" name="2024" href="#2024">2024</a>```
<a class="l" name="2025" href="#2025">2025</a>
<a class="l" name="2026" href="#2026">2026</a>Now, sit back and enjoy a completely different output from your tests. For more
<a class="l" name="2027" href="#2027">2027</a>details, see [<a href="/googletest/s?path=sample9_unittest.cc&amp;project=googletest">sample9_unittest.cc</a>].
<a class="l" name="2028" href="#2028">2028</a>
<a class="l" name="2029" href="#2029">2029</a>[<a href="/googletest/s?path=sample9_unittest.cc&amp;project=googletest">sample9_unittest.cc</a>]: ..<a href="/googletest/s?path=/samples/sample9_unittest.cc&amp;project=googletest">/samples/sample9_unittest.cc</a> "Event listener example"
<a class="hl" name="2030" href="#2030">2030</a>
<a class="l" name="2031" href="#2031">2031</a>You may append more than one listener to the list. When an `On*Start()` or
<a class="l" name="2032" href="#2032">2032</a>`OnTestPartResult()` event is fired, the listeners will receive it in the order
<a class="l" name="2033" href="#2033">2033</a>they appear in the list (since new listeners are added to the end of the list,
<a class="l" name="2034" href="#2034">2034</a>the default text printer and the default XML generator will receive the event
<a class="l" name="2035" href="#2035">2035</a>first). An `On*End()` event will be received by the listeners in the *reverse*
<a class="l" name="2036" href="#2036">2036</a>order. This allows output by listeners added later to be framed by output from
<a class="l" name="2037" href="#2037">2037</a>listeners added earlier.
<a class="l" name="2038" href="#2038">2038</a>
<a class="l" name="2039" href="#2039">2039</a>### Generating Failures in Listeners
<a class="hl" name="2040" href="#2040">2040</a>
<a class="l" name="2041" href="#2041">2041</a>You may use failure-raising macros (`EXPECT_*()`, `ASSERT_*()`, `FAIL()`, etc)
<a class="l" name="2042" href="#2042">2042</a>when processing an event. There are some restrictions:
<a class="l" name="2043" href="#2043">2043</a>
<a class="l" name="2044" href="#2044">2044</a>1.  You cannot generate any failure in `OnTestPartResult()` (otherwise it will
<a class="l" name="2045" href="#2045">2045</a>    cause `OnTestPartResult()` to be called recursively).
<a class="l" name="2046" href="#2046">2046</a>2.  A listener that handles `OnTestPartResult()` is not allowed to generate any
<a class="l" name="2047" href="#2047">2047</a>    failure.
<a class="l" name="2048" href="#2048">2048</a>
<a class="l" name="2049" href="#2049">2049</a>When you add listeners to the listener list, you should put listeners that
<a class="hl" name="2050" href="#2050">2050</a>handle `OnTestPartResult()` *before* listeners that can generate failures. This
<a class="l" name="2051" href="#2051">2051</a>ensures that failures generated by the latter are attributed to the right test
<a class="l" name="2052" href="#2052">2052</a>by the former.
<a class="l" name="2053" href="#2053">2053</a>
<a class="l" name="2054" href="#2054">2054</a>See [<a href="/googletest/s?path=sample10_unittest.cc&amp;project=googletest">sample10_unittest.cc</a>] for an example of a failure-raising listener.
<a class="l" name="2055" href="#2055">2055</a>
<a class="l" name="2056" href="#2056">2056</a>[<a href="/googletest/s?path=sample10_unittest.cc&amp;project=googletest">sample10_unittest.cc</a>]: ..<a href="/googletest/s?path=/samples/sample10_unittest.cc&amp;project=googletest">/samples/sample10_unittest.cc</a> "Failure-raising listener example"
<a class="l" name="2057" href="#2057">2057</a>
<a class="l" name="2058" href="#2058">2058</a>## Running Test Programs: Advanced Options
<a class="l" name="2059" href="#2059">2059</a>
<a class="hl" name="2060" href="#2060">2060</a>googletest test programs are ordinary executables. Once built, you can run them
<a class="l" name="2061" href="#2061">2061</a>directly and affect their behavior via the following environment variables
<a class="l" name="2062" href="#2062">2062</a><a href="/googletest/s?path=and/or&amp;project=googletest">and/or</a> command line flags. For the flags to work, your programs must call
<a class="l" name="2063" href="#2063">2063</a>`::testing::InitGoogleTest()` before calling `RUN_ALL_TESTS()`.
<a class="l" name="2064" href="#2064">2064</a>
<a class="l" name="2065" href="#2065">2065</a>To see a list of supported flags and their usage, please run your test program
<a class="l" name="2066" href="#2066">2066</a>with the `--help` flag. You can also use `-h`, `-?`, or `/?` for short.
<a class="l" name="2067" href="#2067">2067</a>
<a class="l" name="2068" href="#2068">2068</a>If an option is specified both by an environment variable and by a flag, the
<a class="l" name="2069" href="#2069">2069</a>latter takes precedence.
<a class="hl" name="2070" href="#2070">2070</a>
<a class="l" name="2071" href="#2071">2071</a>### Selecting Tests
<a class="l" name="2072" href="#2072">2072</a>
<a class="l" name="2073" href="#2073">2073</a>#### Listing Test Names
<a class="l" name="2074" href="#2074">2074</a>
<a class="l" name="2075" href="#2075">2075</a>Sometimes it is necessary to list the available tests in a program before
<a class="l" name="2076" href="#2076">2076</a>running them so that a filter may be applied if needed. Including the flag
<a class="l" name="2077" href="#2077">2077</a>`--gtest_list_tests` overrides all other flags and lists tests in the following
<a class="l" name="2078" href="#2078">2078</a>format:
<a class="l" name="2079" href="#2079">2079</a>
<a class="hl" name="2080" href="#2080">2080</a>```none
<a class="l" name="2081" href="#2081">2081</a>TestSuite1.
<a class="l" name="2082" href="#2082">2082</a>  TestName1
<a class="l" name="2083" href="#2083">2083</a>  TestName2
<a class="l" name="2084" href="#2084">2084</a>TestSuite2.
<a class="l" name="2085" href="#2085">2085</a>  TestName
<a class="l" name="2086" href="#2086">2086</a>```
<a class="l" name="2087" href="#2087">2087</a>
<a class="l" name="2088" href="#2088">2088</a>None of the tests listed are actually run if the flag is provided. There is no
<a class="l" name="2089" href="#2089">2089</a>corresponding environment variable for this flag.
<a class="hl" name="2090" href="#2090">2090</a>
<a class="l" name="2091" href="#2091">2091</a>#### Running a Subset of the Tests
<a class="l" name="2092" href="#2092">2092</a>
<a class="l" name="2093" href="#2093">2093</a>By default, a googletest program runs all tests the user has defined. Sometimes,
<a class="l" name="2094" href="#2094">2094</a>you want to run only a subset of the tests (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> for debugging or quickly
<a class="l" name="2095" href="#2095">2095</a>verifying a change). If you set the `GTEST_FILTER` environment variable or the
<a class="l" name="2096" href="#2096">2096</a>`--gtest_filter` flag to a filter string, googletest will only run the tests
<a class="l" name="2097" href="#2097">2097</a>whose full names (in the form of `<a href="/googletest/s?path=TestSuiteName.TestName&amp;project=googletest">TestSuiteName.TestName</a>`) match the filter.
<a class="l" name="2098" href="#2098">2098</a>
<a class="l" name="2099" href="#2099">2099</a>The format of a filter is a '`:`'-separated list of wildcard patterns (called
<a class="hl" name="2100" href="#2100">2100</a>the *positive patterns*) optionally followed by a '`-`' and another
<a class="l" name="2101" href="#2101">2101</a>'`:`'-separated pattern list (called the *negative patterns*). A test matches
<a class="l" name="2102" href="#2102">2102</a>the filter if and only if it matches any of the positive patterns but does not
<a class="l" name="2103" href="#2103">2103</a>match any of the negative patterns.
<a class="l" name="2104" href="#2104">2104</a>
<a class="l" name="2105" href="#2105">2105</a>A pattern may contain `'*'` (matches any string) or `'?'` (matches any single
<a class="l" name="2106" href="#2106">2106</a>character). For convenience, the filter `'*-NegativePatterns'` can be also
<a class="l" name="2107" href="#2107">2107</a>written as `'-NegativePatterns'`.
<a class="l" name="2108" href="#2108">2108</a>
<a class="l" name="2109" href="#2109">2109</a>For example:
<a class="hl" name="2110" href="#2110">2110</a>
<a class="l" name="2111" href="#2111">2111</a>*   `./foo_test` Has no flag, and thus runs all its tests.
<a class="l" name="2112" href="#2112">2112</a>*   `./foo_test --gtest_filter=*` Also runs everything, due to the single
<a class="l" name="2113" href="#2113">2113</a>    match-everything `*` value.
<a class="l" name="2114" href="#2114">2114</a>*   `./foo_test --gtest_filter=FooTest.*` Runs everything in test suite
<a class="l" name="2115" href="#2115">2115</a>    `FooTest` .
<a class="l" name="2116" href="#2116">2116</a>*   `./foo_test --gtest_filter=*Null*:*Constructor*` Runs any test whose full
<a class="l" name="2117" href="#2117">2117</a>    name contains either `"Null"` or `"Constructor"` .
<a class="l" name="2118" href="#2118">2118</a>*   `./foo_test --gtest_filter=-*DeathTest.*` Runs all non-death tests.
<a class="l" name="2119" href="#2119">2119</a>*   `./foo_test --gtest_filter=FooTest.*<a href="/googletest/s?path=-FooTest.Bar&amp;project=googletest">-FooTest.Bar</a>` Runs everything in test
<a class="hl" name="2120" href="#2120">2120</a>    suite `FooTest` except `<a href="/googletest/s?path=FooTest.Bar&amp;project=googletest">FooTest.Bar</a>`.
<a class="l" name="2121" href="#2121">2121</a>*   `./foo_test --gtest_filter=FooTest.*:BarTest.*<a href="/googletest/s?path=-FooTest.Bar&amp;project=googletest">-FooTest.Bar</a>:<a href="/googletest/s?path=BarTest.Foo&amp;project=googletest">BarTest.Foo</a>` Runs
<a class="l" name="2122" href="#2122">2122</a>    everything in test suite `FooTest` except `<a href="/googletest/s?path=FooTest.Bar&amp;project=googletest">FooTest.Bar</a>` and everything in
<a class="l" name="2123" href="#2123">2123</a>    test suite `BarTest` except `<a href="/googletest/s?path=BarTest.Foo&amp;project=googletest">BarTest.Foo</a>`.
<a class="l" name="2124" href="#2124">2124</a>
<a class="l" name="2125" href="#2125">2125</a>#### Stop test execution upon first failure
<a class="l" name="2126" href="#2126">2126</a>
<a class="l" name="2127" href="#2127">2127</a>By default, a googletest program runs all tests the user has defined. In some
<a class="l" name="2128" href="#2128">2128</a>cases (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> iterative test development &amp; execution) it may be desirable stop
<a class="l" name="2129" href="#2129">2129</a>test execution upon first failure (trading improved latency for completeness).
<a class="hl" name="2130" href="#2130">2130</a>If `GTEST_FAIL_FAST` environment variable or `--gtest_fail_fast` flag is set,
<a class="l" name="2131" href="#2131">2131</a>the test runner will stop execution as soon as the first test failure is
<a class="l" name="2132" href="#2132">2132</a>found.
<a class="l" name="2133" href="#2133">2133</a>
<a class="l" name="2134" href="#2134">2134</a>#### Temporarily Disabling Tests
<a class="l" name="2135" href="#2135">2135</a>
<a class="l" name="2136" href="#2136">2136</a>If you have a broken test that you cannot fix right away, you can add the
<a class="l" name="2137" href="#2137">2137</a>`DISABLED_` prefix to its name. This will exclude it from execution. This is
<a class="l" name="2138" href="#2138">2138</a>better than commenting out the code or using `#if 0`, as disabled tests are
<a class="l" name="2139" href="#2139">2139</a>still compiled (and thus won't rot).
<a class="hl" name="2140" href="#2140">2140</a>
<a class="l" name="2141" href="#2141">2141</a>If you need to disable all tests in a test suite, you can either add `DISABLED_`
<a class="l" name="2142" href="#2142">2142</a>to the front of the name of each test, or alternatively add it to the front of
<a class="l" name="2143" href="#2143">2143</a>the test suite name.
<a class="l" name="2144" href="#2144">2144</a>
<a class="l" name="2145" href="#2145">2145</a>For example, the following tests won't be run by googletest, even though they
<a class="l" name="2146" href="#2146">2146</a>will still be compiled:
<a class="l" name="2147" href="#2147">2147</a>
<a class="l" name="2148" href="#2148">2148</a>```c++
<a class="l" name="2149" href="#2149">2149</a>// Tests that Foo does Abc.
<a class="hl" name="2150" href="#2150">2150</a>TEST(FooTest, DISABLED_DoesAbc) { ... }
<a class="l" name="2151" href="#2151">2151</a>
<a class="l" name="2152" href="#2152">2152</a>class DISABLED_BarTest : public testing::Test { ... };
<a class="l" name="2153" href="#2153">2153</a>
<a class="l" name="2154" href="#2154">2154</a>// Tests that Bar does Xyz.
<a class="l" name="2155" href="#2155">2155</a>TEST_F(DISABLED_BarTest, DoesXyz) { ... }
<a class="l" name="2156" href="#2156">2156</a>```
<a class="l" name="2157" href="#2157">2157</a>
<a class="l" name="2158" href="#2158">2158</a>NOTE: This feature should only be used for temporary pain-relief. You still have
<a class="l" name="2159" href="#2159">2159</a>to fix the disabled tests at a later date. As a reminder, googletest will print
<a class="hl" name="2160" href="#2160">2160</a>a banner warning you if a test program contains any disabled tests.
<a class="l" name="2161" href="#2161">2161</a>
<a class="l" name="2162" href="#2162">2162</a>TIP: You can easily count the number of disabled tests you have using `gsearch`
<a class="l" name="2163" href="#2163">2163</a><a href="/googletest/s?path=and/or&amp;project=googletest">and/or</a> `grep`. This number can be used as a metric for improving your test
<a class="l" name="2164" href="#2164">2164</a>quality.
<a class="l" name="2165" href="#2165">2165</a>
<a class="l" name="2166" href="#2166">2166</a>#### Temporarily Enabling Disabled Tests
<a class="l" name="2167" href="#2167">2167</a>
<a class="l" name="2168" href="#2168">2168</a>To include disabled tests in test execution, just invoke the test program with
<a class="l" name="2169" href="#2169">2169</a>the `--gtest_also_run_disabled_tests` flag or set the
<a class="hl" name="2170" href="#2170">2170</a>`GTEST_ALSO_RUN_DISABLED_TESTS` environment variable to a value other than `0`.
<a class="l" name="2171" href="#2171">2171</a>You can combine this with the `--gtest_filter` flag to further select which
<a class="l" name="2172" href="#2172">2172</a>disabled tests to run.
<a class="l" name="2173" href="#2173">2173</a>
<a class="l" name="2174" href="#2174">2174</a>### Repeating the Tests
<a class="l" name="2175" href="#2175">2175</a>
<a class="l" name="2176" href="#2176">2176</a>Once in a while you'll run into a test whose result is hit-or-miss. Perhaps it
<a class="l" name="2177" href="#2177">2177</a>will fail only 1% of the time, making it rather hard to reproduce the bug under
<a class="l" name="2178" href="#2178">2178</a>a debugger. This can be a major source of frustration.
<a class="l" name="2179" href="#2179">2179</a>
<a class="hl" name="2180" href="#2180">2180</a>The `--gtest_repeat` flag allows you to repeat all (or selected) test methods in
<a class="l" name="2181" href="#2181">2181</a>a program many times. Hopefully, a flaky test will eventually fail and give you
<a class="l" name="2182" href="#2182">2182</a>a chance to debug. Here's how to use it:
<a class="l" name="2183" href="#2183">2183</a>
<a class="l" name="2184" href="#2184">2184</a>```none
<a class="l" name="2185" href="#2185">2185</a>$ foo_test --gtest_repeat=1000
<a class="l" name="2186" href="#2186">2186</a>Repeat foo_test 1000 times and don't stop at failures.
<a class="l" name="2187" href="#2187">2187</a>
<a class="l" name="2188" href="#2188">2188</a>$ foo_test --gtest_repeat=-1
<a class="l" name="2189" href="#2189">2189</a>A negative count means repeating forever.
<a class="hl" name="2190" href="#2190">2190</a>
<a class="l" name="2191" href="#2191">2191</a>$ foo_test --gtest_repeat=1000 --gtest_break_on_failure
<a class="l" name="2192" href="#2192">2192</a>Repeat foo_test 1000 times, stopping at the first failure.  This
<a class="l" name="2193" href="#2193">2193</a>is especially useful when running under a debugger: when the test
<a class="l" name="2194" href="#2194">2194</a>fails, it will drop into the debugger and you can then inspect
<a class="l" name="2195" href="#2195">2195</a>variables and stacks.
<a class="l" name="2196" href="#2196">2196</a>
<a class="l" name="2197" href="#2197">2197</a>$ foo_test --gtest_repeat=1000 --gtest_filter=FooBar.*
<a class="l" name="2198" href="#2198">2198</a>Repeat the tests whose name matches the filter 1000 times.
<a class="l" name="2199" href="#2199">2199</a>```
<a class="hl" name="2200" href="#2200">2200</a>
<a class="l" name="2201" href="#2201">2201</a>If your test program contains
<a class="l" name="2202" href="#2202">2202</a>[global <a href="/googletest/s?path=set-up/tear-down&amp;project=googletest">set-up/tear-down</a>](#global-set-up-and-tear-down) code, it will be
<a class="l" name="2203" href="#2203">2203</a>repeated in each iteration as well, as the flakiness may be in it. You can also
<a class="l" name="2204" href="#2204">2204</a>specify the repeat count by setting the `GTEST_REPEAT` environment variable.
<a class="l" name="2205" href="#2205">2205</a>
<a class="l" name="2206" href="#2206">2206</a>### Shuffling the Tests
<a class="l" name="2207" href="#2207">2207</a>
<a class="l" name="2208" href="#2208">2208</a>You can specify the `--gtest_shuffle` flag (or set the `GTEST_SHUFFLE`
<a class="l" name="2209" href="#2209">2209</a>environment variable to `1`) to run the tests in a program in a random order.
<a class="hl" name="2210" href="#2210">2210</a>This helps to reveal bad dependencies between tests.
<a class="l" name="2211" href="#2211">2211</a>
<a class="l" name="2212" href="#2212">2212</a>By default, googletest uses a random seed calculated from the current time.
<a class="l" name="2213" href="#2213">2213</a>Therefore you'll get a different order every time. The console output includes
<a class="l" name="2214" href="#2214">2214</a>the random seed value, such that you can reproduce an order-related test failure
<a class="l" name="2215" href="#2215">2215</a>later. To specify the random seed explicitly, use the `--gtest_random_seed=SEED`
<a class="l" name="2216" href="#2216">2216</a>flag (or set the `GTEST_RANDOM_SEED` environment variable), where `SEED` is an
<a class="l" name="2217" href="#2217">2217</a>integer in the range [0, 99999]. The seed value 0 is special: it tells
<a class="l" name="2218" href="#2218">2218</a>googletest to do the default behavior of calculating the seed from the current
<a class="l" name="2219" href="#2219">2219</a>time.
<a class="hl" name="2220" href="#2220">2220</a>
<a class="l" name="2221" href="#2221">2221</a>If you combine this with `--gtest_repeat=N`, googletest will pick a different
<a class="l" name="2222" href="#2222">2222</a>random seed and re-shuffle the tests in each iteration.
<a class="l" name="2223" href="#2223">2223</a>
<a class="l" name="2224" href="#2224">2224</a>### Controlling Test Output
<a class="l" name="2225" href="#2225">2225</a>
<a class="l" name="2226" href="#2226">2226</a>#### Colored Terminal Output
<a class="l" name="2227" href="#2227">2227</a>
<a class="l" name="2228" href="#2228">2228</a>googletest can use colors in its terminal output to make it easier to spot the
<a class="l" name="2229" href="#2229">2229</a>important information:
<a class="hl" name="2230" href="#2230">2230</a>
<a class="l" name="2231" href="#2231">2231</a>&lt;code&gt;
<a class="l" name="2232" href="#2232">2232</a>...&lt;br/&gt;
<a class="l" name="2233" href="#2233">2233</a>  &lt;font color="green"&gt;[----------]&lt;/font&gt;&lt;font color="black"&gt; 1 test from
<a class="l" name="2234" href="#2234">2234</a>  FooTest&lt;/font&gt;&lt;br/&gt;
<a class="l" name="2235" href="#2235">2235</a>  &lt;font color="green"&gt;[ RUN &amp;nbsp; &amp;nbsp; &amp;nbsp;]&lt;/font&gt;&lt;font color="black"&gt;
<a class="l" name="2236" href="#2236">2236</a>  <a href="/googletest/s?path=FooTest.DoesAbc&amp;project=googletest">FooTest.DoesAbc</a>&lt;/font&gt;&lt;br/&gt;
<a class="l" name="2237" href="#2237">2237</a>  &lt;font color="green"&gt;[ &amp;nbsp; &amp;nbsp; &amp;nbsp; OK ]&lt;/font&gt;&lt;font color="black"&gt;
<a class="l" name="2238" href="#2238">2238</a>  <a href="/googletest/s?path=FooTest.DoesAbc&amp;project=googletest">FooTest.DoesAbc</a> &lt;/font&gt;&lt;br/&gt;
<a class="l" name="2239" href="#2239">2239</a>  &lt;font color="green"&gt;[----------]&lt;/font&gt;&lt;font color="black"&gt;
<a class="hl" name="2240" href="#2240">2240</a>  2 tests from BarTest&lt;/font&gt;&lt;br/&gt;
<a class="l" name="2241" href="#2241">2241</a>  &lt;font color="green"&gt;[ RUN &amp;nbsp; &amp;nbsp; &amp;nbsp;]&lt;/font&gt;&lt;font color="black"&gt;
<a class="l" name="2242" href="#2242">2242</a>  <a href="/googletest/s?path=BarTest.HasXyzProperty&amp;project=googletest">BarTest.HasXyzProperty</a> &lt;/font&gt;&lt;br/&gt;
<a class="l" name="2243" href="#2243">2243</a>  &lt;font color="green"&gt;[ &amp;nbsp; &amp;nbsp; &amp;nbsp; OK ]&lt;/font&gt;&lt;font color="black"&gt;
<a class="l" name="2244" href="#2244">2244</a>  <a href="/googletest/s?path=BarTest.HasXyzProperty&amp;project=googletest">BarTest.HasXyzProperty</a>&lt;/font&gt;&lt;br/&gt;
<a class="l" name="2245" href="#2245">2245</a>  &lt;font color="green"&gt;[ RUN &amp;nbsp; &amp;nbsp; &amp;nbsp;]&lt;/font&gt;&lt;font color="black"&gt;
<a class="l" name="2246" href="#2246">2246</a>  <a href="/googletest/s?path=BarTest.ReturnsTrueOnSuccess&amp;project=googletest">BarTest.ReturnsTrueOnSuccess</a> ... some error messages ...&lt;/font&gt;&lt;br/&gt;
<a class="l" name="2247" href="#2247">2247</a>  &lt;font color="red"&gt;[ &amp;nbsp; FAILED ]&lt;/font&gt;&lt;font color="black"&gt;
<a class="l" name="2248" href="#2248">2248</a>  <a href="/googletest/s?path=BarTest.ReturnsTrueOnSuccess&amp;project=googletest">BarTest.ReturnsTrueOnSuccess</a> ...&lt;/font&gt;&lt;br/&gt;
<a class="l" name="2249" href="#2249">2249</a>  &lt;font color="green"&gt;[==========]&lt;/font&gt;&lt;font color="black"&gt;
<a class="hl" name="2250" href="#2250">2250</a>  30 tests from 14 test suites ran.&lt;/font&gt;&lt;br/&gt;
<a class="l" name="2251" href="#2251">2251</a>  &lt;font color="green"&gt;[ &amp;nbsp; PASSED ]&lt;/font&gt;&lt;font color="black"&gt;
<a class="l" name="2252" href="#2252">2252</a>  28 tests.&lt;/font&gt;&lt;br/&gt;
<a class="l" name="2253" href="#2253">2253</a>  &lt;font color="red"&gt;[ &amp;nbsp; FAILED ]&lt;/font&gt;&lt;font color="black"&gt;
<a class="l" name="2254" href="#2254">2254</a>  2 tests, listed below:&lt;/font&gt;&lt;br/&gt;
<a class="l" name="2255" href="#2255">2255</a>  &lt;font color="red"&gt;[ &amp;nbsp; FAILED ]&lt;/font&gt;&lt;font color="black"&gt;
<a class="l" name="2256" href="#2256">2256</a>  <a href="/googletest/s?path=BarTest.ReturnsTrueOnSuccess&amp;project=googletest">BarTest.ReturnsTrueOnSuccess</a>&lt;/font&gt;&lt;br/&gt;
<a class="l" name="2257" href="#2257">2257</a>  &lt;font color="red"&gt;[ &amp;nbsp; FAILED ]&lt;/font&gt;&lt;font color="black"&gt;
<a class="l" name="2258" href="#2258">2258</a>  <a href="/googletest/s?path=AnotherTest.DoesXyz&amp;project=googletest">AnotherTest.DoesXyz</a>&lt;br/&gt;
<a class="l" name="2259" href="#2259">2259</a>&lt;br/&gt;
<a class="hl" name="2260" href="#2260">2260</a>  2 FAILED TESTS
<a class="l" name="2261" href="#2261">2261</a>  &lt;/font&gt;
<a class="l" name="2262" href="#2262">2262</a>&lt;/code&gt;
<a class="l" name="2263" href="#2263">2263</a>
<a class="l" name="2264" href="#2264">2264</a>You can set the `GTEST_COLOR` environment variable or the `--gtest_color`
<a class="l" name="2265" href="#2265">2265</a>command line flag to `yes`, `no`, or `auto` (the default) to enable colors,
<a class="l" name="2266" href="#2266">2266</a>disable colors, or let googletest decide. When the value is `auto`, googletest
<a class="l" name="2267" href="#2267">2267</a>will use colors if and only if the output goes to a terminal and (on non-Windows
<a class="l" name="2268" href="#2268">2268</a>platforms) the `TERM` environment variable is set to `xterm` or `xterm-color`.
<a class="l" name="2269" href="#2269">2269</a>
<a class="hl" name="2270" href="#2270">2270</a>#### Suppressing test passes
<a class="l" name="2271" href="#2271">2271</a>
<a class="l" name="2272" href="#2272">2272</a>By default, googletest prints 1 line of output for each test, indicating if it
<a class="l" name="2273" href="#2273">2273</a>passed or failed. To show only test failures, run the test program with
<a class="l" name="2274" href="#2274">2274</a>`--gtest_brief=1`, or set the GTEST_BRIEF environment variable to `1`.
<a class="l" name="2275" href="#2275">2275</a>
<a class="l" name="2276" href="#2276">2276</a>#### Suppressing the Elapsed Time
<a class="l" name="2277" href="#2277">2277</a>
<a class="l" name="2278" href="#2278">2278</a>By default, googletest prints the time it takes to run each test. To disable
<a class="l" name="2279" href="#2279">2279</a>that, run the test program with the `--gtest_print_time=0` command line flag, or
<a class="hl" name="2280" href="#2280">2280</a>set the GTEST_PRINT_TIME environment variable to `0`.
<a class="l" name="2281" href="#2281">2281</a>
<a class="l" name="2282" href="#2282">2282</a>#### Suppressing UTF-8 Text Output
<a class="l" name="2283" href="#2283">2283</a>
<a class="l" name="2284" href="#2284">2284</a>In case of assertion failures, googletest prints expected and actual values of
<a class="l" name="2285" href="#2285">2285</a>type `string` both as hex-encoded strings as well as in readable UTF-8 text if
<a class="l" name="2286" href="#2286">2286</a>they contain valid non-ASCII UTF-8 characters. If you want to suppress the UTF-8
<a class="l" name="2287" href="#2287">2287</a>text because, for example, you don't have an UTF-8 compatible output medium, run
<a class="l" name="2288" href="#2288">2288</a>the test program with `--gtest_print_utf8=0` or set the `GTEST_PRINT_UTF8`
<a class="l" name="2289" href="#2289">2289</a>environment variable to `0`.
<a class="hl" name="2290" href="#2290">2290</a>
<a class="l" name="2291" href="#2291">2291</a>
<a class="l" name="2292" href="#2292">2292</a>
<a class="l" name="2293" href="#2293">2293</a>#### Generating an XML Report
<a class="l" name="2294" href="#2294">2294</a>
<a class="l" name="2295" href="#2295">2295</a>googletest can emit a detailed XML report to a file in addition to its normal
<a class="l" name="2296" href="#2296">2296</a>textual output. The report contains the duration of each test, and thus can help
<a class="l" name="2297" href="#2297">2297</a>you identify slow tests.
<a class="l" name="2298" href="#2298">2298</a>
<a class="l" name="2299" href="#2299">2299</a>To generate the XML report, set the `GTEST_OUTPUT` environment variable or the
<a class="hl" name="2300" href="#2300">2300</a>`--gtest_output` flag to the string `"xml:path_to_output_file"`, which will
<a class="l" name="2301" href="#2301">2301</a>create the file at the given location. You can also just use the string `"xml"`,
<a class="l" name="2302" href="#2302">2302</a>in which case the output can be found in the `<a href="/googletest/s?path=test_detail.xml&amp;project=googletest">test_detail.xml</a>` file in the
<a class="l" name="2303" href="#2303">2303</a>current directory.
<a class="l" name="2304" href="#2304">2304</a>
<a class="l" name="2305" href="#2305">2305</a>If you specify a directory (for example, `"xml:<a href="/googletest/s?path=output/directory&amp;project=googletest">output/directory</a>/"` on Linux or
<a class="l" name="2306" href="#2306">2306</a>`"xml:output\directory\"` on Windows), googletest will create the XML file in
<a class="l" name="2307" href="#2307">2307</a>that directory, named after the test executable (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `<a href="/googletest/s?path=foo_test.xml&amp;project=googletest">foo_test.xml</a>` for test
<a class="l" name="2308" href="#2308">2308</a>program `foo_test` or `<a href="/googletest/s?path=foo_test.exe&amp;project=googletest">foo_test.exe</a>`). If the file already exists (perhaps left
<a class="l" name="2309" href="#2309">2309</a>over from a previous run), googletest will pick a different name (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a>
<a class="hl" name="2310" href="#2310">2310</a>`<a href="/googletest/s?path=foo_test_1.xml&amp;project=googletest">foo_test_1.xml</a>`) to avoid overwriting it.
<a class="l" name="2311" href="#2311">2311</a>
<a class="l" name="2312" href="#2312">2312</a>The report is based on the `junitreport` Ant task. Since that format was
<a class="l" name="2313" href="#2313">2313</a>originally intended for Java, a little interpretation is required to make it
<a class="l" name="2314" href="#2314">2314</a>apply to googletest tests, as shown here:
<a class="l" name="2315" href="#2315">2315</a>
<a class="l" name="2316" href="#2316">2316</a>```xml
<a class="l" name="2317" href="#2317">2317</a>&lt;testsuites name="AllTests" ...&gt;
<a class="l" name="2318" href="#2318">2318</a>  &lt;testsuite name="test_case_name" ...&gt;
<a class="l" name="2319" href="#2319">2319</a>    &lt;testcase    name="test_name" ...&gt;
<a class="hl" name="2320" href="#2320">2320</a>      &lt;failure message="..."/&gt;
<a class="l" name="2321" href="#2321">2321</a>      &lt;failure message="..."/&gt;
<a class="l" name="2322" href="#2322">2322</a>      &lt;failure message="..."/&gt;
<a class="l" name="2323" href="#2323">2323</a>    &lt;/testcase&gt;
<a class="l" name="2324" href="#2324">2324</a>  &lt;/testsuite&gt;
<a class="l" name="2325" href="#2325">2325</a>&lt;/testsuites&gt;
<a class="l" name="2326" href="#2326">2326</a>```
<a class="l" name="2327" href="#2327">2327</a>
<a class="l" name="2328" href="#2328">2328</a>*   The root `&lt;testsuites&gt;` element corresponds to the entire test program.
<a class="l" name="2329" href="#2329">2329</a>*   `&lt;testsuite&gt;` elements correspond to googletest test suites.
<a class="hl" name="2330" href="#2330">2330</a>*   `&lt;testcase&gt;` elements correspond to googletest test functions.
<a class="l" name="2331" href="#2331">2331</a>
<a class="l" name="2332" href="#2332">2332</a>For instance, the following program
<a class="l" name="2333" href="#2333">2333</a>
<a class="l" name="2334" href="#2334">2334</a>```c++
<a class="l" name="2335" href="#2335">2335</a>TEST(MathTest, Addition) { ... }
<a class="l" name="2336" href="#2336">2336</a>TEST(MathTest, Subtraction) { ... }
<a class="l" name="2337" href="#2337">2337</a>TEST(LogicTest, NonContradiction) { ... }
<a class="l" name="2338" href="#2338">2338</a>```
<a class="l" name="2339" href="#2339">2339</a>
<a class="hl" name="2340" href="#2340">2340</a>could generate this report:
<a class="l" name="2341" href="#2341">2341</a>
<a class="l" name="2342" href="#2342">2342</a>```xml
<a class="l" name="2343" href="#2343">2343</a>&lt;?xml version="1.0" encoding="UTF-8"?&gt;
<a class="l" name="2344" href="#2344">2344</a>&lt;testsuites tests="3" failures="1" errors="0" time="0.035" timestamp="2011-10-31T18:52:42" name="AllTests"&gt;
<a class="l" name="2345" href="#2345">2345</a>  &lt;testsuite name="MathTest" tests="2" failures="1" errors="0" time="0.015"&gt;
<a class="l" name="2346" href="#2346">2346</a>    &lt;testcase name="Addition" status="run" time="0.007" classname=""&gt;
<a class="l" name="2347" href="#2347">2347</a>      &lt;failure message="Value of: add(1, 1)&amp;#x0A;  Actual: 3&amp;#x0A;Expected: 2" type=""&gt;...&lt;/failure&gt;
<a class="l" name="2348" href="#2348">2348</a>      &lt;failure message="Value of: add(1, -1)&amp;#x0A;  Actual: 1&amp;#x0A;Expected: 0" type=""&gt;...&lt;/failure&gt;
<a class="l" name="2349" href="#2349">2349</a>    &lt;/testcase&gt;
<a class="hl" name="2350" href="#2350">2350</a>    &lt;testcase name="Subtraction" status="run" time="0.005" classname=""&gt;
<a class="l" name="2351" href="#2351">2351</a>    &lt;/testcase&gt;
<a class="l" name="2352" href="#2352">2352</a>  &lt;/testsuite&gt;
<a class="l" name="2353" href="#2353">2353</a>  &lt;testsuite name="LogicTest" tests="1" failures="0" errors="0" time="0.005"&gt;
<a class="l" name="2354" href="#2354">2354</a>    &lt;testcase name="NonContradiction" status="run" time="0.005" classname=""&gt;
<a class="l" name="2355" href="#2355">2355</a>    &lt;/testcase&gt;
<a class="l" name="2356" href="#2356">2356</a>  &lt;/testsuite&gt;
<a class="l" name="2357" href="#2357">2357</a>&lt;/testsuites&gt;
<a class="l" name="2358" href="#2358">2358</a>```
<a class="l" name="2359" href="#2359">2359</a>
<a class="hl" name="2360" href="#2360">2360</a>Things to note:
<a class="l" name="2361" href="#2361">2361</a>
<a class="l" name="2362" href="#2362">2362</a>*   The `tests` attribute of a `&lt;testsuites&gt;` or `&lt;testsuite&gt;` element tells how
<a class="l" name="2363" href="#2363">2363</a>    many test functions the googletest program or test suite contains, while the
<a class="l" name="2364" href="#2364">2364</a>    `failures` attribute tells how many of them failed.
<a class="l" name="2365" href="#2365">2365</a>
<a class="l" name="2366" href="#2366">2366</a>*   The `time` attribute expresses the duration of the test, test suite, or
<a class="l" name="2367" href="#2367">2367</a>    entire test program in seconds.
<a class="l" name="2368" href="#2368">2368</a>
<a class="l" name="2369" href="#2369">2369</a>*   The `timestamp` attribute records the local date and time of the test
<a class="hl" name="2370" href="#2370">2370</a>    execution.
<a class="l" name="2371" href="#2371">2371</a>
<a class="l" name="2372" href="#2372">2372</a>*   Each `&lt;failure&gt;` element corresponds to a single failed googletest
<a class="l" name="2373" href="#2373">2373</a>    assertion.
<a class="l" name="2374" href="#2374">2374</a>
<a class="l" name="2375" href="#2375">2375</a>#### Generating a JSON Report
<a class="l" name="2376" href="#2376">2376</a>
<a class="l" name="2377" href="#2377">2377</a>googletest can also emit a JSON report as an alternative format to XML. To
<a class="l" name="2378" href="#2378">2378</a>generate the JSON report, set the `GTEST_OUTPUT` environment variable or the
<a class="l" name="2379" href="#2379">2379</a>`--gtest_output` flag to the string `"json:path_to_output_file"`, which will
<a class="hl" name="2380" href="#2380">2380</a>create the file at the given location. You can also just use the string
<a class="l" name="2381" href="#2381">2381</a>`"json"`, in which case the output can be found in the `<a href="/googletest/s?path=test_detail.json&amp;project=googletest">test_detail.json</a>` file
<a class="l" name="2382" href="#2382">2382</a>in the current directory.
<a class="l" name="2383" href="#2383">2383</a>
<a class="l" name="2384" href="#2384">2384</a>The report format conforms to the following JSON Schema:
<a class="l" name="2385" href="#2385">2385</a>
<a class="l" name="2386" href="#2386">2386</a>```json
<a class="l" name="2387" href="#2387">2387</a>{
<a class="l" name="2388" href="#2388">2388</a>  "$schema": "<a href="http://json-schema.org/schema">http://json-schema.org/schema</a>#",
<a class="l" name="2389" href="#2389">2389</a>  "type": "object",
<a class="hl" name="2390" href="#2390">2390</a>  "definitions": {
<a class="l" name="2391" href="#2391">2391</a>    "TestCase": {
<a class="l" name="2392" href="#2392">2392</a>      "type": "object",
<a class="l" name="2393" href="#2393">2393</a>      "properties": {
<a class="l" name="2394" href="#2394">2394</a>        "name": { "type": "string" },
<a class="l" name="2395" href="#2395">2395</a>        "tests": { "type": "integer" },
<a class="l" name="2396" href="#2396">2396</a>        "failures": { "type": "integer" },
<a class="l" name="2397" href="#2397">2397</a>        "disabled": { "type": "integer" },
<a class="l" name="2398" href="#2398">2398</a>        "time": { "type": "string" },
<a class="l" name="2399" href="#2399">2399</a>        "testsuite": {
<a class="hl" name="2400" href="#2400">2400</a>          "type": "array",
<a class="l" name="2401" href="#2401">2401</a>          "items": {
<a class="l" name="2402" href="#2402">2402</a>            "$ref": "#<a href="/googletest/s?path=/definitions/TestInfo&amp;project=googletest">/definitions/TestInfo</a>"
<a class="l" name="2403" href="#2403">2403</a>          }
<a class="l" name="2404" href="#2404">2404</a>        }
<a class="l" name="2405" href="#2405">2405</a>      }
<a class="l" name="2406" href="#2406">2406</a>    },
<a class="l" name="2407" href="#2407">2407</a>    "TestInfo": {
<a class="l" name="2408" href="#2408">2408</a>      "type": "object",
<a class="l" name="2409" href="#2409">2409</a>      "properties": {
<a class="hl" name="2410" href="#2410">2410</a>        "name": { "type": "string" },
<a class="l" name="2411" href="#2411">2411</a>        "status": {
<a class="l" name="2412" href="#2412">2412</a>          "type": "string",
<a class="l" name="2413" href="#2413">2413</a>          "enum": ["RUN", "NOTRUN"]
<a class="l" name="2414" href="#2414">2414</a>        },
<a class="l" name="2415" href="#2415">2415</a>        "time": { "type": "string" },
<a class="l" name="2416" href="#2416">2416</a>        "classname": { "type": "string" },
<a class="l" name="2417" href="#2417">2417</a>        "failures": {
<a class="l" name="2418" href="#2418">2418</a>          "type": "array",
<a class="l" name="2419" href="#2419">2419</a>          "items": {
<a class="hl" name="2420" href="#2420">2420</a>            "$ref": "#<a href="/googletest/s?path=/definitions/Failure&amp;project=googletest">/definitions/Failure</a>"
<a class="l" name="2421" href="#2421">2421</a>          }
<a class="l" name="2422" href="#2422">2422</a>        }
<a class="l" name="2423" href="#2423">2423</a>      }
<a class="l" name="2424" href="#2424">2424</a>    },
<a class="l" name="2425" href="#2425">2425</a>    "Failure": {
<a class="l" name="2426" href="#2426">2426</a>      "type": "object",
<a class="l" name="2427" href="#2427">2427</a>      "properties": {
<a class="l" name="2428" href="#2428">2428</a>        "failures": { "type": "string" },
<a class="l" name="2429" href="#2429">2429</a>        "type": { "type": "string" }
<a class="hl" name="2430" href="#2430">2430</a>      }
<a class="l" name="2431" href="#2431">2431</a>    }
<a class="l" name="2432" href="#2432">2432</a>  },
<a class="l" name="2433" href="#2433">2433</a>  "properties": {
<a class="l" name="2434" href="#2434">2434</a>    "tests": { "type": "integer" },
<a class="l" name="2435" href="#2435">2435</a>    "failures": { "type": "integer" },
<a class="l" name="2436" href="#2436">2436</a>    "disabled": { "type": "integer" },
<a class="l" name="2437" href="#2437">2437</a>    "errors": { "type": "integer" },
<a class="l" name="2438" href="#2438">2438</a>    "timestamp": {
<a class="l" name="2439" href="#2439">2439</a>      "type": "string",
<a class="hl" name="2440" href="#2440">2440</a>      "format": "date-time"
<a class="l" name="2441" href="#2441">2441</a>    },
<a class="l" name="2442" href="#2442">2442</a>    "time": { "type": "string" },
<a class="l" name="2443" href="#2443">2443</a>    "name": { "type": "string" },
<a class="l" name="2444" href="#2444">2444</a>    "testsuites": {
<a class="l" name="2445" href="#2445">2445</a>      "type": "array",
<a class="l" name="2446" href="#2446">2446</a>      "items": {
<a class="l" name="2447" href="#2447">2447</a>        "$ref": "#<a href="/googletest/s?path=/definitions/TestCase&amp;project=googletest">/definitions/TestCase</a>"
<a class="l" name="2448" href="#2448">2448</a>      }
<a class="l" name="2449" href="#2449">2449</a>    }
<a class="hl" name="2450" href="#2450">2450</a>  }
<a class="l" name="2451" href="#2451">2451</a>}
<a class="l" name="2452" href="#2452">2452</a>```
<a class="l" name="2453" href="#2453">2453</a>
<a class="l" name="2454" href="#2454">2454</a>The report uses the format that conforms to the following Proto3 using the
<a class="l" name="2455" href="#2455">2455</a>[JSON encoding](<a href="https://developers.google.com/protocol-buffers/docs/proto3">https://developers.google.com/protocol-buffers/docs/proto3</a>#json):
<a class="l" name="2456" href="#2456">2456</a>
<a class="l" name="2457" href="#2457">2457</a>```proto
<a class="l" name="2458" href="#2458">2458</a>syntax = "proto3";
<a class="l" name="2459" href="#2459">2459</a>
<a class="hl" name="2460" href="#2460">2460</a>package googletest;
<a class="l" name="2461" href="#2461">2461</a>
<a class="l" name="2462" href="#2462">2462</a>import "<a href="/googletest/s?path=google/protobuf/timestamp.proto&amp;project=googletest">google/protobuf/timestamp.proto</a>";
<a class="l" name="2463" href="#2463">2463</a>import "<a href="/googletest/s?path=google/protobuf/duration.proto&amp;project=googletest">google/protobuf/duration.proto</a>";
<a class="l" name="2464" href="#2464">2464</a>
<a class="l" name="2465" href="#2465">2465</a>message UnitTest {
<a class="l" name="2466" href="#2466">2466</a>  int32 tests = 1;
<a class="l" name="2467" href="#2467">2467</a>  int32 failures = 2;
<a class="l" name="2468" href="#2468">2468</a>  int32 disabled = 3;
<a class="l" name="2469" href="#2469">2469</a>  int32 errors = 4;
<a class="hl" name="2470" href="#2470">2470</a>  <a href="/googletest/s?path=google.protobuf.Timestamp&amp;project=googletest">google.protobuf.Timestamp</a> timestamp = 5;
<a class="l" name="2471" href="#2471">2471</a>  <a href="/googletest/s?path=google.protobuf.Duration&amp;project=googletest">google.protobuf.Duration</a> time = 6;
<a class="l" name="2472" href="#2472">2472</a>  string name = 7;
<a class="l" name="2473" href="#2473">2473</a>  repeated TestCase testsuites = 8;
<a class="l" name="2474" href="#2474">2474</a>}
<a class="l" name="2475" href="#2475">2475</a>
<a class="l" name="2476" href="#2476">2476</a>message TestCase {
<a class="l" name="2477" href="#2477">2477</a>  string name = 1;
<a class="l" name="2478" href="#2478">2478</a>  int32 tests = 2;
<a class="l" name="2479" href="#2479">2479</a>  int32 failures = 3;
<a class="hl" name="2480" href="#2480">2480</a>  int32 disabled = 4;
<a class="l" name="2481" href="#2481">2481</a>  int32 errors = 5;
<a class="l" name="2482" href="#2482">2482</a>  <a href="/googletest/s?path=google.protobuf.Duration&amp;project=googletest">google.protobuf.Duration</a> time = 6;
<a class="l" name="2483" href="#2483">2483</a>  repeated TestInfo testsuite = 7;
<a class="l" name="2484" href="#2484">2484</a>}
<a class="l" name="2485" href="#2485">2485</a>
<a class="l" name="2486" href="#2486">2486</a>message TestInfo {
<a class="l" name="2487" href="#2487">2487</a>  string name = 1;
<a class="l" name="2488" href="#2488">2488</a>  enum Status {
<a class="l" name="2489" href="#2489">2489</a>    RUN = 0;
<a class="hl" name="2490" href="#2490">2490</a>    NOTRUN = 1;
<a class="l" name="2491" href="#2491">2491</a>  }
<a class="l" name="2492" href="#2492">2492</a>  Status status = 2;
<a class="l" name="2493" href="#2493">2493</a>  <a href="/googletest/s?path=google.protobuf.Duration&amp;project=googletest">google.protobuf.Duration</a> time = 3;
<a class="l" name="2494" href="#2494">2494</a>  string classname = 4;
<a class="l" name="2495" href="#2495">2495</a>  message Failure {
<a class="l" name="2496" href="#2496">2496</a>    string failures = 1;
<a class="l" name="2497" href="#2497">2497</a>    string type = 2;
<a class="l" name="2498" href="#2498">2498</a>  }
<a class="l" name="2499" href="#2499">2499</a>  repeated Failure failures = 5;
<a class="hl" name="2500" href="#2500">2500</a>}
<a class="l" name="2501" href="#2501">2501</a>```
<a class="l" name="2502" href="#2502">2502</a>
<a class="l" name="2503" href="#2503">2503</a>For instance, the following program
<a class="l" name="2504" href="#2504">2504</a>
<a class="l" name="2505" href="#2505">2505</a>```c++
<a class="l" name="2506" href="#2506">2506</a>TEST(MathTest, Addition) { ... }
<a class="l" name="2507" href="#2507">2507</a>TEST(MathTest, Subtraction) { ... }
<a class="l" name="2508" href="#2508">2508</a>TEST(LogicTest, NonContradiction) { ... }
<a class="l" name="2509" href="#2509">2509</a>```
<a class="hl" name="2510" href="#2510">2510</a>
<a class="l" name="2511" href="#2511">2511</a>could generate this report:
<a class="l" name="2512" href="#2512">2512</a>
<a class="l" name="2513" href="#2513">2513</a>```json
<a class="l" name="2514" href="#2514">2514</a>{
<a class="l" name="2515" href="#2515">2515</a>  "tests": 3,
<a class="l" name="2516" href="#2516">2516</a>  "failures": 1,
<a class="l" name="2517" href="#2517">2517</a>  "errors": 0,
<a class="l" name="2518" href="#2518">2518</a>  "time": "0.035s",
<a class="l" name="2519" href="#2519">2519</a>  "timestamp": "2011-10-31T18:52:42Z",
<a class="hl" name="2520" href="#2520">2520</a>  "name": "AllTests",
<a class="l" name="2521" href="#2521">2521</a>  "testsuites": [
<a class="l" name="2522" href="#2522">2522</a>    {
<a class="l" name="2523" href="#2523">2523</a>      "name": "MathTest",
<a class="l" name="2524" href="#2524">2524</a>      "tests": 2,
<a class="l" name="2525" href="#2525">2525</a>      "failures": 1,
<a class="l" name="2526" href="#2526">2526</a>      "errors": 0,
<a class="l" name="2527" href="#2527">2527</a>      "time": "0.015s",
<a class="l" name="2528" href="#2528">2528</a>      "testsuite": [
<a class="l" name="2529" href="#2529">2529</a>        {
<a class="hl" name="2530" href="#2530">2530</a>          "name": "Addition",
<a class="l" name="2531" href="#2531">2531</a>          "status": "RUN",
<a class="l" name="2532" href="#2532">2532</a>          "time": "0.007s",
<a class="l" name="2533" href="#2533">2533</a>          "classname": "",
<a class="l" name="2534" href="#2534">2534</a>          "failures": [
<a class="l" name="2535" href="#2535">2535</a>            {
<a class="l" name="2536" href="#2536">2536</a>              "message": "Value of: add(1, 1)\n  Actual: 3\nExpected: 2",
<a class="l" name="2537" href="#2537">2537</a>              "type": ""
<a class="l" name="2538" href="#2538">2538</a>            },
<a class="l" name="2539" href="#2539">2539</a>            {
<a class="hl" name="2540" href="#2540">2540</a>              "message": "Value of: add(1, -1)\n  Actual: 1\nExpected: 0",
<a class="l" name="2541" href="#2541">2541</a>              "type": ""
<a class="l" name="2542" href="#2542">2542</a>            }
<a class="l" name="2543" href="#2543">2543</a>          ]
<a class="l" name="2544" href="#2544">2544</a>        },
<a class="l" name="2545" href="#2545">2545</a>        {
<a class="l" name="2546" href="#2546">2546</a>          "name": "Subtraction",
<a class="l" name="2547" href="#2547">2547</a>          "status": "RUN",
<a class="l" name="2548" href="#2548">2548</a>          "time": "0.005s",
<a class="l" name="2549" href="#2549">2549</a>          "classname": ""
<a class="hl" name="2550" href="#2550">2550</a>        }
<a class="l" name="2551" href="#2551">2551</a>      ]
<a class="l" name="2552" href="#2552">2552</a>    },
<a class="l" name="2553" href="#2553">2553</a>    {
<a class="l" name="2554" href="#2554">2554</a>      "name": "LogicTest",
<a class="l" name="2555" href="#2555">2555</a>      "tests": 1,
<a class="l" name="2556" href="#2556">2556</a>      "failures": 0,
<a class="l" name="2557" href="#2557">2557</a>      "errors": 0,
<a class="l" name="2558" href="#2558">2558</a>      "time": "0.005s",
<a class="l" name="2559" href="#2559">2559</a>      "testsuite": [
<a class="hl" name="2560" href="#2560">2560</a>        {
<a class="l" name="2561" href="#2561">2561</a>          "name": "NonContradiction",
<a class="l" name="2562" href="#2562">2562</a>          "status": "RUN",
<a class="l" name="2563" href="#2563">2563</a>          "time": "0.005s",
<a class="l" name="2564" href="#2564">2564</a>          "classname": ""
<a class="l" name="2565" href="#2565">2565</a>        }
<a class="l" name="2566" href="#2566">2566</a>      ]
<a class="l" name="2567" href="#2567">2567</a>    }
<a class="l" name="2568" href="#2568">2568</a>  ]
<a class="l" name="2569" href="#2569">2569</a>}
<a class="hl" name="2570" href="#2570">2570</a>```
<a class="l" name="2571" href="#2571">2571</a>
<a class="l" name="2572" href="#2572">2572</a>IMPORTANT: The exact format of the JSON document is subject to change.
<a class="l" name="2573" href="#2573">2573</a>
<a class="l" name="2574" href="#2574">2574</a>### Controlling How Failures Are Reported
<a class="l" name="2575" href="#2575">2575</a>
<a class="l" name="2576" href="#2576">2576</a>#### Detecting Test Premature Exit
<a class="l" name="2577" href="#2577">2577</a>
<a class="l" name="2578" href="#2578">2578</a>Google Test implements the _premature-exit-file_ protocol for test runners
<a class="l" name="2579" href="#2579">2579</a>to catch any kind of unexpected exits of test programs. Upon start,
<a class="hl" name="2580" href="#2580">2580</a>Google Test creates the file which will be automatically deleted after
<a class="l" name="2581" href="#2581">2581</a>all work has been finished. Then, the test runner can check if this file
<a class="l" name="2582" href="#2582">2582</a>exists. In case the file remains undeleted, the inspected test has exited
<a class="l" name="2583" href="#2583">2583</a>prematurely.
<a class="l" name="2584" href="#2584">2584</a>
<a class="l" name="2585" href="#2585">2585</a>This feature is enabled only if the `TEST_PREMATURE_EXIT_FILE` environment
<a class="l" name="2586" href="#2586">2586</a>variable has been set.
<a class="l" name="2587" href="#2587">2587</a>
<a class="l" name="2588" href="#2588">2588</a>#### Turning Assertion Failures into Break-Points
<a class="l" name="2589" href="#2589">2589</a>
<a class="hl" name="2590" href="#2590">2590</a>When running test programs under a debugger, it's very convenient if the
<a class="l" name="2591" href="#2591">2591</a>debugger can catch an assertion failure and automatically drop into interactive
<a class="l" name="2592" href="#2592">2592</a>mode. googletest's *break-on-failure* mode supports this behavior.
<a class="l" name="2593" href="#2593">2593</a>
<a class="l" name="2594" href="#2594">2594</a>To enable it, set the `GTEST_BREAK_ON_FAILURE` environment variable to a value
<a class="l" name="2595" href="#2595">2595</a>other than `0`. Alternatively, you can use the `--gtest_break_on_failure`
<a class="l" name="2596" href="#2596">2596</a>command line flag.
<a class="l" name="2597" href="#2597">2597</a>
<a class="l" name="2598" href="#2598">2598</a>#### Disabling Catching Test-Thrown Exceptions
<a class="l" name="2599" href="#2599">2599</a>
<a class="hl" name="2600" href="#2600">2600</a>googletest can be used either with or without exceptions enabled. If a test
<a class="l" name="2601" href="#2601">2601</a>throws a C++ exception or (on Windows) a structured exception (SEH), by default
<a class="l" name="2602" href="#2602">2602</a>googletest catches it, reports it as a test failure, and continues with the next
<a class="l" name="2603" href="#2603">2603</a>test method. This maximizes the coverage of a test run. Also, on Windows an
<a class="l" name="2604" href="#2604">2604</a>uncaught exception will cause a pop-up window, so catching the exceptions allows
<a class="l" name="2605" href="#2605">2605</a>you to run the tests automatically.
<a class="l" name="2606" href="#2606">2606</a>
<a class="l" name="2607" href="#2607">2607</a>When debugging the test failures, however, you may instead want the exceptions
<a class="l" name="2608" href="#2608">2608</a>to be handled by the debugger, such that you can examine the call stack when an
<a class="l" name="2609" href="#2609">2609</a>exception is thrown. To achieve that, set the `GTEST_CATCH_EXCEPTIONS`
<a class="hl" name="2610" href="#2610">2610</a>environment variable to `0`, or use the `--gtest_catch_exceptions=0` flag when
<a class="l" name="2611" href="#2611">2611</a>running the tests.
<a class="l" name="2612" href="#2612">2612</a>
<a class="l" name="2613" href="#2613">2613</a>### Sanitizer Integration
<a class="l" name="2614" href="#2614">2614</a>
<a class="l" name="2615" href="#2615">2615</a>The
<a class="l" name="2616" href="#2616">2616</a>[Undefined Behavior Sanitizer](<a href="https://clang.llvm.org/docs/UndefinedBehaviorSanitizer.html">https://clang.llvm.org/docs/UndefinedBehaviorSanitizer.html</a>),
<a class="l" name="2617" href="#2617">2617</a>[Address Sanitizer](<a href="https://github.com/google/sanitizers/wiki/AddressSanitizer">https://github.com/google/sanitizers/wiki/AddressSanitizer</a>),
<a class="l" name="2618" href="#2618">2618</a>and
<a class="l" name="2619" href="#2619">2619</a>[Thread Sanitizer](<a href="https://github.com/google/sanitizers/wiki/ThreadSanitizerCppManual">https://github.com/google/sanitizers/wiki/ThreadSanitizerCppManual</a>)
<a class="hl" name="2620" href="#2620">2620</a>all provide weak functions that you can override to trigger explicit failures
<a class="l" name="2621" href="#2621">2621</a>when they detect sanitizer errors, such as creating a reference from `nullptr`.
<a class="l" name="2622" href="#2622">2622</a>To override these functions, place definitions for them in a source file that
<a class="l" name="2623" href="#2623">2623</a>you compile as part of your main binary:
<a class="l" name="2624" href="#2624">2624</a>
<a class="l" name="2625" href="#2625">2625</a>```
<a class="l" name="2626" href="#2626">2626</a>extern "C" {
<a class="l" name="2627" href="#2627">2627</a>void __ubsan_on_report() {
<a class="l" name="2628" href="#2628">2628</a>  FAIL() &lt;&lt; "Encountered an undefined behavior sanitizer error";
<a class="l" name="2629" href="#2629">2629</a>}
<a class="hl" name="2630" href="#2630">2630</a>void __asan_on_error() {
<a class="l" name="2631" href="#2631">2631</a>  FAIL() &lt;&lt; "Encountered an address sanitizer error";
<a class="l" name="2632" href="#2632">2632</a>}
<a class="l" name="2633" href="#2633">2633</a>void __tsan_on_report() {
<a class="l" name="2634" href="#2634">2634</a>  FAIL() &lt;&lt; "Encountered a thread sanitizer error";
<a class="l" name="2635" href="#2635">2635</a>}
<a class="l" name="2636" href="#2636">2636</a>}  // extern "C"
<a class="l" name="2637" href="#2637">2637</a>```
<a class="l" name="2638" href="#2638">2638</a>
<a class="l" name="2639" href="#2639">2639</a>After compiling your project with one of the sanitizers enabled, if a particular
<a class="hl" name="2640" href="#2640">2640</a>test triggers a sanitizer error, googletest will report that it failed.
<a class="l" name="2641" href="#2641">2641</a>