<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["_SVN_INFO_URL_RE",43],["__author__",31]]],["Namespace","xn",[["os",34],["re",35]]],["Function","xf",[["GetCommandOutput",46],["GetSvnInfo",55],["GetSvnTrunk",69],["IsInGMockSvn",81],["IsInGTestSvn",76]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c"># Copyright 2013 Google Inc. All Rights Reserved.</span>
<a class="l" name="2" href="#2">2</a><span class="c">#</span>
<a class="l" name="3" href="#3">3</a><span class="c"># Redistribution and use in source and binary forms, with or without</span>
<a class="l" name="4" href="#4">4</a><span class="c"># modification, are permitted provided that the following conditions are</span>
<a class="l" name="5" href="#5">5</a><span class="c"># met:</span>
<a class="l" name="6" href="#6">6</a><span class="c">#</span>
<a class="l" name="7" href="#7">7</a><span class="c">#     * Redistributions of source code must retain the above copyright</span>
<a class="l" name="8" href="#8">8</a><span class="c"># notice, this list of conditions and the following disclaimer.</span>
<a class="l" name="9" href="#9">9</a><span class="c">#     * Redistributions in binary form must reproduce the above</span>
<a class="hl" name="10" href="#10">10</a><span class="c"># copyright notice, this list of conditions and the following disclaimer</span>
<a class="l" name="11" href="#11">11</a><span class="c"># in the documentation <a href="/googletest/s?path=and/">and</a>/<a href="/googletest/s?path=and/or">or</a> other materials provided with the</span>
<a class="l" name="12" href="#12">12</a><span class="c"># distribution.</span>
<a class="l" name="13" href="#13">13</a><span class="c">#     * Neither the name of Google Inc. nor the names of its</span>
<a class="l" name="14" href="#14">14</a><span class="c"># contributors may be used to endorse or promote products derived from</span>
<a class="l" name="15" href="#15">15</a><span class="c"># this software without specific prior written permission.</span>
<a class="l" name="16" href="#16">16</a><span class="c">#</span>
<a class="l" name="17" href="#17">17</a><span class="c"># THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS</span>
<a class="l" name="18" href="#18">18</a><span class="c"># "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT</span>
<a class="l" name="19" href="#19">19</a><span class="c"># LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR</span>
<a class="hl" name="20" href="#20">20</a><span class="c"># A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT</span>
<a class="l" name="21" href="#21">21</a><span class="c"># OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,</span>
<a class="l" name="22" href="#22">22</a><span class="c"># SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT</span>
<a class="l" name="23" href="#23">23</a><span class="c"># LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,</span>
<a class="l" name="24" href="#24">24</a><span class="c"># DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY</span>
<a class="l" name="25" href="#25">25</a><span class="c"># THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT</span>
<a class="l" name="26" href="#26">26</a><span class="c"># (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE</span>
<a class="l" name="27" href="#27">27</a><span class="c"># OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</span>
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a><span class="s">"""Shared utilities for writing scripts for Google <a href="/googletest/s?path=Test/">Test</a>/<a href="/googletest/s?path=Test/Mock">Mock</a>."""</span>
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a><a href="/googletest/s?refs=__author__&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">__author__</a> = <span class="s">'wan@google.com (Zhanyong Wan)'</span>
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a><b>import</b> <a class="xn" name="os"/><a href="/googletest/s?refs=os&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">os</a>
<a class="l" name="35" href="#35">35</a><b>import</b> <a class="xn" name="re"/><a href="/googletest/s?refs=re&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">re</a>
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>
<a class="l" name="38" href="#38">38</a><span class="c"># Matches the line from 'svn info .' output that describes what SVN</span>
<a class="l" name="39" href="#39">39</a><span class="c"># path the current local directory corresponds to.  For example, in</span>
<a class="hl" name="40" href="#40">40</a><span class="c"># a googletest SVN workspace's <a href="/googletest/s?path=trunk/">trunk</a>/<a href="/googletest/s?path=trunk/test">test</a> directory, the output will be:</span>
<a class="l" name="41" href="#41">41</a><span class="c">#</span>
<a class="l" name="42" href="#42">42</a><span class="c"># URL: <a href="https://googletest.googlecode.com/svn/trunk/test">https://googletest.googlecode.com/svn/trunk/test</a></span>
<a class="l" name="43" href="#43">43</a><a href="/googletest/s?refs=_SVN_INFO_URL_RE&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">_SVN_INFO_URL_RE</a> = <a class="d intelliWindow-symbol" href="#re" data-definition-place="defined-in-file">re</a>.<a href="/googletest/s?defs=compile&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">compile</a>(r<span class="s">'^URL: https://(\w+)\.googlecode\.<a href="/googletest/s?path=com/">com</a>/<a href="/googletest/s?path=com/svn">svn</a>(.*)'</span>)
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a><b>def</b> <a class="xf" name="GetCommandOutput"/><a href="/googletest/s?refs=GetCommandOutput&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">GetCommandOutput</a>(<a href="/googletest/s?defs=command&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">command</a>):
<a class="l" name="47" href="#47">47</a>  <span class="s">"""Runs the shell command and returns its stdout as a list of lines."""</span>
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>  f = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=popen&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">popen</a>(<a href="/googletest/s?defs=command&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">command</a>, <span class="s">'r'</span>)
<a class="hl" name="50" href="#50">50</a>  <a href="/googletest/s?defs=lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a> = [<a href="/googletest/s?defs=line&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">line</a>.<a href="/googletest/s?defs=strip&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">strip</a>() <b>for</b> <a href="/googletest/s?defs=line&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">line</a> <b>in</b> f.<a href="/googletest/s?defs=readlines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">readlines</a>()]
<a class="l" name="51" href="#51">51</a>  f.<a href="/googletest/s?defs=close&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">close</a>()
<a class="l" name="52" href="#52">52</a>  <b>return</b> <a href="/googletest/s?defs=lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a>
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a><b>def</b> <a class="xf" name="GetSvnInfo"/><a href="/googletest/s?refs=GetSvnInfo&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">GetSvnInfo</a>():
<a class="l" name="56" href="#56">56</a>  <span class="s">"""Returns the project name and the current SVN workspace's root path."""</span>
<a class="l" name="57" href="#57">57</a>
<a class="l" name="58" href="#58">58</a>  <b>for</b> <a href="/googletest/s?defs=line&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">line</a> <b>in</b> <a class="d intelliWindow-symbol" href="#GetCommandOutput" data-definition-place="defined-in-file">GetCommandOutput</a>(<span class="s">'svn info .'</span>):
<a class="l" name="59" href="#59">59</a>    m = <a class="d intelliWindow-symbol" href="#_SVN_INFO_URL_RE" data-definition-place="defined-in-file">_SVN_INFO_URL_RE</a>.<a href="/googletest/s?defs=match&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a>(<a href="/googletest/s?defs=line&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">line</a>)
<a class="hl" name="60" href="#60">60</a>    <b>if</b> m:
<a class="l" name="61" href="#61">61</a>      <a href="/googletest/s?defs=project&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">project</a> = m.<a href="/googletest/s?defs=group&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">group</a>(<span class="n">1</span>)  <span class="c"># googletest or googlemock</span>
<a class="l" name="62" href="#62">62</a>      <a href="/googletest/s?defs=rel_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rel_path</a> = m.<a href="/googletest/s?defs=group&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">group</a>(<span class="n">2</span>)
<a class="l" name="63" href="#63">63</a>      <a href="/googletest/s?defs=root&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">root</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=realpath&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">realpath</a>(<a href="/googletest/s?defs=rel_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rel_path</a>.<a href="/googletest/s?defs=count&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">count</a>(<span class="s">'/'</span>) * <span class="s">'../'</span>)
<a class="l" name="64" href="#64">64</a>      <b>return</b> <a href="/googletest/s?defs=project&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">project</a>, <a href="/googletest/s?defs=root&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">root</a>
<a class="l" name="65" href="#65">65</a>
<a class="l" name="66" href="#66">66</a>  <b>return</b> <b>None</b>, <b>None</b>
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a><b>def</b> <a class="xf" name="GetSvnTrunk"/><a href="/googletest/s?refs=GetSvnTrunk&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">GetSvnTrunk</a>():
<a class="hl" name="70" href="#70">70</a>  <span class="s">"""Returns the current SVN workspace's trunk root path."""</span>
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a>  _, <a href="/googletest/s?defs=root&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">root</a> = <a class="d intelliWindow-symbol" href="#GetSvnInfo" data-definition-place="defined-in-file">GetSvnInfo</a>()
<a class="l" name="73" href="#73">73</a>  <b>return</b> <a href="/googletest/s?defs=root&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">root</a> + <span class="s">'/trunk'</span> <b>if</b> <a href="/googletest/s?defs=root&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">root</a> <b>else</b> <b>None</b>
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a><b>def</b> <a class="xf" name="IsInGTestSvn"/><a href="/googletest/s?refs=IsInGTestSvn&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">IsInGTestSvn</a>():
<a class="l" name="77" href="#77">77</a>  <a href="/googletest/s?defs=project&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">project</a>, _ = <a class="d intelliWindow-symbol" href="#GetSvnInfo" data-definition-place="defined-in-file">GetSvnInfo</a>()
<a class="l" name="78" href="#78">78</a>  <b>return</b> <a href="/googletest/s?defs=project&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">project</a> == <span class="s">'googletest'</span>
<a class="l" name="79" href="#79">79</a>
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a><b>def</b> <a class="xf" name="IsInGMockSvn"/><a href="/googletest/s?refs=IsInGMockSvn&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">IsInGMockSvn</a>():
<a class="l" name="82" href="#82">82</a>  <a href="/googletest/s?defs=project&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">project</a>, _ = <a class="d intelliWindow-symbol" href="#GetSvnInfo" data-definition-place="defined-in-file">GetSvnInfo</a>()
<a class="l" name="83" href="#83">83</a>  <b>return</b> <a href="/googletest/s?defs=project&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">project</a> == <span class="s">'googlemock'</span>
<a class="l" name="84" href="#84">84</a>