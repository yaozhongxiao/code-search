<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["SUBST_PATH_ENV_VAR_NAME",15]]],["Namespace","xn",[["os",11],["subprocess",12],["sys",13]]],["Function","xf",[["main",17]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/googletest/s?path=/usr/">usr</a>/<a href="/googletest/s?path=/usr/bin/">bin</a>/<a href="/googletest/s?path=/usr/bin/env">env</a> python</span>
<a class="l" name="2" href="#2">2</a><span class="c">#</span>
<a class="l" name="3" href="#3">3</a><span class="c"># Copyright 2010 Google Inc. All Rights Reserved.</span>
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a><span class="s">"""Runs program specified in the command line with the substituted PATH.
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>   This script is needed for to support building under Pulse which is unable
<a class="l" name="8" href="#8">8</a>   to override the existing PATH variable.
<a class="l" name="9" href="#9">9</a>"""</span>
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a><b>import</b> <a class="xn" name="os"/><a href="/googletest/s?refs=os&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">os</a>
<a class="l" name="12" href="#12">12</a><b>import</b> <a class="xn" name="subprocess"/><a href="/googletest/s?refs=subprocess&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">subprocess</a>
<a class="l" name="13" href="#13">13</a><b>import</b> <a class="xn" name="sys"/><a href="/googletest/s?refs=sys&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">sys</a>
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a><a class="xv" name="SUBST_PATH_ENV_VAR_NAME"/><a href="/googletest/s?refs=SUBST_PATH_ENV_VAR_NAME&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">SUBST_PATH_ENV_VAR_NAME</a> = <span class="s">"SUBST_PATH"</span>
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a><b>def</b> <a class="xf" name="main"/><a href="/googletest/s?refs=main&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">main</a>():
<a class="l" name="18" href="#18">18</a>  <b>if</b> <a class="d intelliWindow-symbol" href="#SUBST_PATH_ENV_VAR_NAME" data-definition-place="defined-in-file">SUBST_PATH_ENV_VAR_NAME</a> <b>in</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=environ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">environ</a>:
<a class="l" name="19" href="#19">19</a>    <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=environ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">environ</a>[<span class="s">"PATH"</span>] = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=environ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">environ</a>[<a class="d intelliWindow-symbol" href="#SUBST_PATH_ENV_VAR_NAME" data-definition-place="defined-in-file">SUBST_PATH_ENV_VAR_NAME</a>]
<a class="hl" name="20" href="#20">20</a>
<a class="l" name="21" href="#21">21</a>  <a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a> = <a class="d intelliWindow-symbol" href="#subprocess" data-definition-place="defined-in-file">subprocess</a>.<a href="/googletest/s?defs=Popen&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Popen</a>(<a class="d intelliWindow-symbol" href="#sys" data-definition-place="defined-in-file">sys</a>.<a href="/googletest/s?defs=argv&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>[<span class="n">1</span>:]).<a href="/googletest/s?defs=wait&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">wait</a>()
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a>  <span class="c"># exit_code is negative (-signal) if the process has been terminated by</span>
<a class="l" name="24" href="#24">24</a>  <span class="c"># a signal. Returning negative exit code is not portable and so we return</span>
<a class="l" name="25" href="#25">25</a>  <span class="c"># 100 instead.</span>
<a class="l" name="26" href="#26">26</a>  <b>if</b> <a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a> &lt; <span class="n">0</span>:
<a class="l" name="27" href="#27">27</a>    <a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a> = <span class="n">100</span>
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a>  <a class="d intelliWindow-symbol" href="#sys" data-definition-place="defined-in-file">sys</a>.<a href="/googletest/s?defs=exit&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit</a>(<a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>)
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a><b>if</b> <a href="/googletest/s?defs=__name__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__name__</a> == <span class="s">"__main__"</span>:
<a class="l" name="32" href="#32">32</a>  <a class="d intelliWindow-symbol" href="#main" data-definition-place="defined-in-file">main</a>()
<a class="l" name="33" href="#33">33</a>