<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["COMMAND",37],["TESTBRIDGE_NAME",38],["binary_name",36]]],["Class","xc",[["GTestTestFilterTest",46]]],["Namespace","xn",[["gtest_test_utils",34],["os",32]]],["Function","xf",[["Assert",41]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/googletest/s?path=/usr/">usr</a>/<a href="/googletest/s?path=/usr/bin/">bin</a>/<a href="/googletest/s?path=/usr/bin/env">env</a> python</span>
<a class="l" name="2" href="#2">2</a><span class="c">#</span>
<a class="l" name="3" href="#3">3</a><span class="c"># Copyright 2018 Google LLC. All rights reserved.</span>
<a class="l" name="4" href="#4">4</a><span class="c">#</span>
<a class="l" name="5" href="#5">5</a><span class="c"># Redistribution and use in source and binary forms, with or without</span>
<a class="l" name="6" href="#6">6</a><span class="c"># modification, are permitted provided that the following conditions are</span>
<a class="l" name="7" href="#7">7</a><span class="c"># met:</span>
<a class="l" name="8" href="#8">8</a><span class="c">#</span>
<a class="l" name="9" href="#9">9</a><span class="c">#     * Redistributions of source code must retain the above copyright</span>
<a class="hl" name="10" href="#10">10</a><span class="c"># notice, this list of conditions and the following disclaimer.</span>
<a class="l" name="11" href="#11">11</a><span class="c">#     * Redistributions in binary form must reproduce the above</span>
<a class="l" name="12" href="#12">12</a><span class="c"># copyright notice, this list of conditions and the following disclaimer</span>
<a class="l" name="13" href="#13">13</a><span class="c"># in the documentation <a href="/googletest/s?path=and/">and</a>/<a href="/googletest/s?path=and/or">or</a> other materials provided with the</span>
<a class="l" name="14" href="#14">14</a><span class="c"># distribution.</span>
<a class="l" name="15" href="#15">15</a><span class="c">#     * Neither the name of Google Inc. nor the names of its</span>
<a class="l" name="16" href="#16">16</a><span class="c"># contributors may be used to endorse or promote products derived from</span>
<a class="l" name="17" href="#17">17</a><span class="c"># this software without specific prior written permission.</span>
<a class="l" name="18" href="#18">18</a><span class="c">#</span>
<a class="l" name="19" href="#19">19</a><span class="c"># THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS</span>
<a class="hl" name="20" href="#20">20</a><span class="c"># "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT</span>
<a class="l" name="21" href="#21">21</a><span class="c"># LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR</span>
<a class="l" name="22" href="#22">22</a><span class="c"># A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT</span>
<a class="l" name="23" href="#23">23</a><span class="c"># OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,</span>
<a class="l" name="24" href="#24">24</a><span class="c"># SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT</span>
<a class="l" name="25" href="#25">25</a><span class="c"># LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,</span>
<a class="l" name="26" href="#26">26</a><span class="c"># DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY</span>
<a class="l" name="27" href="#27">27</a><span class="c"># THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT</span>
<a class="l" name="28" href="#28">28</a><span class="c"># (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE</span>
<a class="l" name="29" href="#29">29</a><span class="c"># OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</span>
<a class="hl" name="30" href="#30">30</a><span class="s">"""Verifies that Google Test uses filter provided via testbridge."""</span>
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a><b>import</b> <a class="xn" name="os"/><a href="/googletest/s?refs=os&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">os</a>
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a><b>import</b> <a class="xn" name="gtest_test_utils"/><a href="/googletest/s?refs=gtest_test_utils&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">gtest_test_utils</a>
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a><a class="xv" name="binary_name"/><a href="/googletest/s?refs=binary_name&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">binary_name</a> = <span class="s">'gtest_testbridge_test_'</span>
<a class="l" name="37" href="#37">37</a><a class="xv" name="COMMAND"/><a href="/googletest/s?refs=COMMAND&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">COMMAND</a> = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTestExecutablePath&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTestExecutablePath</a>(<a class="d intelliWindow-symbol" href="#binary_name" data-definition-place="defined-in-file">binary_name</a>)
<a class="l" name="38" href="#38">38</a><a class="xv" name="TESTBRIDGE_NAME"/><a href="/googletest/s?refs=TESTBRIDGE_NAME&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">TESTBRIDGE_NAME</a> = <span class="s">'TESTBRIDGE_TEST_ONLY'</span>
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a><b>def</b> <a class="xf" name="Assert"/><a href="/googletest/s?refs=Assert&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">Assert</a>(<a href="/googletest/s?defs=condition&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">condition</a>):
<a class="l" name="42" href="#42">42</a>  <b>if</b> <b>not</b> <a href="/googletest/s?defs=condition&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">condition</a>:
<a class="l" name="43" href="#43">43</a>    <b>raise</b> <a href="/googletest/s?defs=AssertionError&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">AssertionError</a>
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a><b>class</b> <a class="xc" name="GTestTestFilterTest"/><a href="/googletest/s?refs=GTestTestFilterTest&amp;project=googletest" class="xc intelliWindow-symbol" data-definition-place="def">GTestTestFilterTest</a>(<a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=TestCase&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TestCase</a>):
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>  <b>def</b> <a class="xmb" name="testTestExecutionIsFiltered"/><a href="/googletest/s?refs=testTestExecutionIsFiltered&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testTestExecutionIsFiltered</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="49" href="#49">49</a>    <span class="s">"""Tests that the test filter is picked up from the testbridge env var."""</span>
<a class="hl" name="50" href="#50">50</a>    <a href="/googletest/s?defs=subprocess_env&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">subprocess_env</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=environ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">environ</a>.<a href="/googletest/s?defs=copy&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">copy</a>()
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a>    <a href="/googletest/s?defs=subprocess_env&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">subprocess_env</a>[<a class="d intelliWindow-symbol" href="#TESTBRIDGE_NAME" data-definition-place="defined-in-file">TESTBRIDGE_NAME</a>] = <span class="s">'*.TestThatSucceeds'</span>
<a class="l" name="53" href="#53">53</a>    p = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=Subprocess&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Subprocess</a>(<a class="d intelliWindow-symbol" href="#COMMAND" data-definition-place="defined-in-file">COMMAND</a>, <a href="/googletest/s?defs=env&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">env</a>=<a href="/googletest/s?defs=subprocess_env&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">subprocess_env</a>)
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertEquals&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertEquals</a>(<span class="n">0</span>, p.<a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>)
<a class="l" name="56" href="#56">56</a>
<a class="l" name="57" href="#57">57</a>    <a class="d intelliWindow-symbol" href="#Assert" data-definition-place="defined-in-file">Assert</a>(<span class="s">'filter = *.TestThatSucceeds'</span> <b>in</b> p.<a href="/googletest/s?defs=output&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output</a>)
<a class="l" name="58" href="#58">58</a>    <a class="d intelliWindow-symbol" href="#Assert" data-definition-place="defined-in-file">Assert</a>(<span class="s">'[       OK ] TestFilterTest.TestThatSucceeds'</span> <b>in</b> p.<a href="/googletest/s?defs=output&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output</a>)
<a class="l" name="59" href="#59">59</a>    <a class="d intelliWindow-symbol" href="#Assert" data-definition-place="defined-in-file">Assert</a>(<span class="s">'[  PASSED  ] 1 test.'</span> <b>in</b> p.<a href="/googletest/s?defs=output&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output</a>)
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a><b>if</b> <a href="/googletest/s?defs=__name__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__name__</a> == <span class="s">'__main__'</span>:
<a class="l" name="63" href="#63">63</a>  <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=Main&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Main</a>()
<a class="l" name="64" href="#64">64</a>