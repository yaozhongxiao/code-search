<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["EXPECTED_EMPTY",615],["EXPECTED_FILTERED",572],["EXPECTED_NON_EMPTY",59],["GTEST_DEFAULT_OUTPUT_FILE",46],["GTEST_FILTER_FLAG",43],["GTEST_LIST_TESTS_FLAG",44],["GTEST_OUTPUT_FLAG",45],["GTEST_PROGRAM_NAME",47],["GTEST_PROGRAM_PATH",626],["NO_STACKTRACE_SUPPORT_FLAG",50],["STACK_TRACE_TEMPLATE",55],["STACK_TRACE_TEMPLATE",57],["SUPPORTS_STACK_TRACES",52],["SUPPORTS_TYPED_TESTS",628]]],["Class","xc",[["GTestJsonOutputUnitTest",632]]],["Namespace","xn",[["datetime",33],["errno",34],["gtest_json_test_utils",40],["gtest_test_utils",41],["json",35],["os",36],["re",37],["sys",38]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/googletest/s?path=/usr/">usr</a>/<a href="/googletest/s?path=/usr/bin/">bin</a>/<a href="/googletest/s?path=/usr/bin/env">env</a> python</span>
<a class="l" name="2" href="#2">2</a><span class="c"># Copyright 2018, Google Inc.</span>
<a class="l" name="3" href="#3">3</a><span class="c"># All rights reserved.</span>
<a class="l" name="4" href="#4">4</a><span class="c">#</span>
<a class="l" name="5" href="#5">5</a><span class="c"># Redistribution and use in source and binary forms, with or without</span>
<a class="l" name="6" href="#6">6</a><span class="c"># modification, are permitted provided that the following conditions are</span>
<a class="l" name="7" href="#7">7</a><span class="c"># met:</span>
<a class="l" name="8" href="#8">8</a><span class="c">#</span>
<a class="l" name="9" href="#9">9</a><span class="c">#     * Redistributions of source code must retain the above copyright</span>
<a class="hl" name="10" href="#10">10</a><span class="c"># notice, this list of conditions and the following disclaimer.</span>
<a class="l" name="11" href="#11">11</a><span class="c">#     * Redistributions in binary form must reproduce the above</span>
<a class="l" name="12" href="#12">12</a><span class="c"># copyright notice, this list of conditions and the following disclaimer</span>
<a class="l" name="13" href="#13">13</a><span class="c"># in the documentation <a href="/googletest/s?path=and/">and</a>/<a href="/googletest/s?path=and/or">or</a> other materials provided with the</span>
<a class="l" name="14" href="#14">14</a><span class="c"># distribution.</span>
<a class="l" name="15" href="#15">15</a><span class="c">#     * Neither the name of Google Inc. nor the names of its</span>
<a class="l" name="16" href="#16">16</a><span class="c"># contributors may be used to endorse or promote products derived from</span>
<a class="l" name="17" href="#17">17</a><span class="c"># this software without specific prior written permission.</span>
<a class="l" name="18" href="#18">18</a><span class="c">#</span>
<a class="l" name="19" href="#19">19</a><span class="c"># THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS</span>
<a class="hl" name="20" href="#20">20</a><span class="c"># "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT</span>
<a class="l" name="21" href="#21">21</a><span class="c"># LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR</span>
<a class="l" name="22" href="#22">22</a><span class="c"># A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT</span>
<a class="l" name="23" href="#23">23</a><span class="c"># OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,</span>
<a class="l" name="24" href="#24">24</a><span class="c"># SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT</span>
<a class="l" name="25" href="#25">25</a><span class="c"># LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,</span>
<a class="l" name="26" href="#26">26</a><span class="c"># DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY</span>
<a class="l" name="27" href="#27">27</a><span class="c"># THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT</span>
<a class="l" name="28" href="#28">28</a><span class="c"># (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE</span>
<a class="l" name="29" href="#29">29</a><span class="c"># OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</span>
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a><span class="s">"""Unit test for the gtest_json_output module."""</span>
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a><b>import</b> <a class="xn" name="datetime"/><a href="/googletest/s?refs=datetime&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">datetime</a>
<a class="l" name="34" href="#34">34</a><b>import</b> <a class="xn" name="errno"/><a href="/googletest/s?refs=errno&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">errno</a>
<a class="l" name="35" href="#35">35</a><b>import</b> <a class="xn" name="json"/><a href="/googletest/s?refs=json&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">json</a>
<a class="l" name="36" href="#36">36</a><b>import</b> <a class="xn" name="os"/><a href="/googletest/s?refs=os&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">os</a>
<a class="l" name="37" href="#37">37</a><b>import</b> <a class="xn" name="re"/><a href="/googletest/s?refs=re&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">re</a>
<a class="l" name="38" href="#38">38</a><b>import</b> <a class="xn" name="sys"/><a href="/googletest/s?refs=sys&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">sys</a>
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a><b>import</b> <a class="xn" name="gtest_json_test_utils"/><a href="/googletest/s?refs=gtest_json_test_utils&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">gtest_json_test_utils</a>
<a class="l" name="41" href="#41">41</a><b>import</b> <a class="xn" name="gtest_test_utils"/><a href="/googletest/s?refs=gtest_test_utils&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">gtest_test_utils</a>
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a><a class="xv" name="GTEST_FILTER_FLAG"/><a href="/googletest/s?refs=GTEST_FILTER_FLAG&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_FILTER_FLAG</a> = <span class="s">'--gtest_filter'</span>
<a class="l" name="44" href="#44">44</a><a class="xv" name="GTEST_LIST_TESTS_FLAG"/><a href="/googletest/s?refs=GTEST_LIST_TESTS_FLAG&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_LIST_TESTS_FLAG</a> = <span class="s">'--gtest_list_tests'</span>
<a class="l" name="45" href="#45">45</a><a class="xv" name="GTEST_OUTPUT_FLAG"/><a href="/googletest/s?refs=GTEST_OUTPUT_FLAG&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_OUTPUT_FLAG</a> = <span class="s">'--gtest_output'</span>
<a class="l" name="46" href="#46">46</a><a class="xv" name="GTEST_DEFAULT_OUTPUT_FILE"/><a href="/googletest/s?refs=GTEST_DEFAULT_OUTPUT_FILE&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_DEFAULT_OUTPUT_FILE</a> = <span class="s">'test_detail.json'</span>
<a class="l" name="47" href="#47">47</a><a class="xv" name="GTEST_PROGRAM_NAME"/><a href="/googletest/s?refs=GTEST_PROGRAM_NAME&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_PROGRAM_NAME</a> = <span class="s">'gtest_xml_output_unittest_'</span>
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a><span class="c"># The flag indicating stacktraces are not supported</span>
<a class="hl" name="50" href="#50">50</a><a class="xv" name="NO_STACKTRACE_SUPPORT_FLAG"/><a href="/googletest/s?refs=NO_STACKTRACE_SUPPORT_FLAG&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">NO_STACKTRACE_SUPPORT_FLAG</a> = <span class="s">'--no_stacktrace_support'</span>
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a><a class="xv" name="SUPPORTS_STACK_TRACES"/><a href="/googletest/s?refs=SUPPORTS_STACK_TRACES&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">SUPPORTS_STACK_TRACES</a> = <a class="d intelliWindow-symbol" href="#NO_STACKTRACE_SUPPORT_FLAG" data-definition-place="defined-in-file">NO_STACKTRACE_SUPPORT_FLAG</a> <b>not</b> <b>in</b> <a class="d intelliWindow-symbol" href="#sys" data-definition-place="defined-in-file">sys</a>.<a href="/googletest/s?defs=argv&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a><b>if</b> <a class="d intelliWindow-symbol" href="#SUPPORTS_STACK_TRACES" data-definition-place="defined-in-file">SUPPORTS_STACK_TRACES</a>:
<a class="l" name="55" href="#55">55</a>  <a class="xv" name="STACK_TRACE_TEMPLATE"/><a href="/googletest/s?refs=STACK_TRACE_TEMPLATE&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">STACK_TRACE_TEMPLATE</a> = <span class="s">'\nStack trace:\n*'</span>
<a class="l" name="56" href="#56">56</a><b>else</b>:
<a class="l" name="57" href="#57">57</a>  <a class="xv" name="STACK_TRACE_TEMPLATE"/><a href="/googletest/s?refs=STACK_TRACE_TEMPLATE&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">STACK_TRACE_TEMPLATE</a> = <span class="s">''</span>
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a><a class="xv" name="EXPECTED_NON_EMPTY"/><a href="/googletest/s?refs=EXPECTED_NON_EMPTY&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">EXPECTED_NON_EMPTY</a> = {
<a class="hl" name="60" href="#60">60</a>    u<span class="s">'tests'</span>:
<a class="l" name="61" href="#61">61</a>        <span class="n">26</span>,
<a class="l" name="62" href="#62">62</a>    u<span class="s">'failures'</span>:
<a class="l" name="63" href="#63">63</a>        <span class="n">5</span>,
<a class="l" name="64" href="#64">64</a>    u<span class="s">'disabled'</span>:
<a class="l" name="65" href="#65">65</a>        <span class="n">2</span>,
<a class="l" name="66" href="#66">66</a>    u<span class="s">'errors'</span>:
<a class="l" name="67" href="#67">67</a>        <span class="n">0</span>,
<a class="l" name="68" href="#68">68</a>    u<span class="s">'timestamp'</span>:
<a class="l" name="69" href="#69">69</a>        u<span class="s">'*'</span>,
<a class="hl" name="70" href="#70">70</a>    u<span class="s">'time'</span>:
<a class="l" name="71" href="#71">71</a>        u<span class="s">'*'</span>,
<a class="l" name="72" href="#72">72</a>    u<span class="s">'ad_hoc_property'</span>:
<a class="l" name="73" href="#73">73</a>        u<span class="s">'42'</span>,
<a class="l" name="74" href="#74">74</a>    u<span class="s">'name'</span>:
<a class="l" name="75" href="#75">75</a>        u<span class="s">'AllTests'</span>,
<a class="l" name="76" href="#76">76</a>    u<span class="s">'testsuites'</span>: [{
<a class="l" name="77" href="#77">77</a>        u<span class="s">'name'</span>:
<a class="l" name="78" href="#78">78</a>            u<span class="s">'SuccessfulTest'</span>,
<a class="l" name="79" href="#79">79</a>        u<span class="s">'tests'</span>:
<a class="hl" name="80" href="#80">80</a>            <span class="n">1</span>,
<a class="l" name="81" href="#81">81</a>        u<span class="s">'failures'</span>:
<a class="l" name="82" href="#82">82</a>            <span class="n">0</span>,
<a class="l" name="83" href="#83">83</a>        u<span class="s">'disabled'</span>:
<a class="l" name="84" href="#84">84</a>            <span class="n">0</span>,
<a class="l" name="85" href="#85">85</a>        u<span class="s">'errors'</span>:
<a class="l" name="86" href="#86">86</a>            <span class="n">0</span>,
<a class="l" name="87" href="#87">87</a>        u<span class="s">'time'</span>:
<a class="l" name="88" href="#88">88</a>            u<span class="s">'*'</span>,
<a class="l" name="89" href="#89">89</a>        u<span class="s">'timestamp'</span>:
<a class="hl" name="90" href="#90">90</a>            u<span class="s">'*'</span>,
<a class="l" name="91" href="#91">91</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="92" href="#92">92</a>            u<span class="s">'name'</span>: u<span class="s">'Succeeds'</span>,
<a class="l" name="93" href="#93">93</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="94" href="#94">94</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="95" href="#95">95</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="96" href="#96">96</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="97" href="#97">97</a>            u<span class="s">'classname'</span>: u<span class="s">'SuccessfulTest'</span>
<a class="l" name="98" href="#98">98</a>        }]
<a class="l" name="99" href="#99">99</a>    }, {
<a class="hl" name="100" href="#100">100</a>        u<span class="s">'name'</span>:
<a class="l" name="101" href="#101">101</a>            u<span class="s">'FailedTest'</span>,
<a class="l" name="102" href="#102">102</a>        u<span class="s">'tests'</span>:
<a class="l" name="103" href="#103">103</a>            <span class="n">1</span>,
<a class="l" name="104" href="#104">104</a>        u<span class="s">'failures'</span>:
<a class="l" name="105" href="#105">105</a>            <span class="n">1</span>,
<a class="l" name="106" href="#106">106</a>        u<span class="s">'disabled'</span>:
<a class="l" name="107" href="#107">107</a>            <span class="n">0</span>,
<a class="l" name="108" href="#108">108</a>        u<span class="s">'errors'</span>:
<a class="l" name="109" href="#109">109</a>            <span class="n">0</span>,
<a class="hl" name="110" href="#110">110</a>        u<span class="s">'time'</span>:
<a class="l" name="111" href="#111">111</a>            u<span class="s">'*'</span>,
<a class="l" name="112" href="#112">112</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="113" href="#113">113</a>            u<span class="s">'*'</span>,
<a class="l" name="114" href="#114">114</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="115" href="#115">115</a>            u<span class="s">'name'</span>:
<a class="l" name="116" href="#116">116</a>                u<span class="s">'Fails'</span>,
<a class="l" name="117" href="#117">117</a>            u<span class="s">'status'</span>:
<a class="l" name="118" href="#118">118</a>                u<span class="s">'RUN'</span>,
<a class="l" name="119" href="#119">119</a>            u<span class="s">'result'</span>:
<a class="hl" name="120" href="#120">120</a>                u<span class="s">'COMPLETED'</span>,
<a class="l" name="121" href="#121">121</a>            u<span class="s">'time'</span>:
<a class="l" name="122" href="#122">122</a>                u<span class="s">'*'</span>,
<a class="l" name="123" href="#123">123</a>            u<span class="s">'timestamp'</span>:
<a class="l" name="124" href="#124">124</a>                u<span class="s">'*'</span>,
<a class="l" name="125" href="#125">125</a>            u<span class="s">'classname'</span>:
<a class="l" name="126" href="#126">126</a>                u<span class="s">'FailedTest'</span>,
<a class="l" name="127" href="#127">127</a>            u<span class="s">'failures'</span>: [{
<a class="l" name="128" href="#128">128</a>                u<span class="s">'failure'</span>: u<span class="s">'gtest_xml_output_unittest_.cc:*\n'</span>
<a class="l" name="129" href="#129">129</a>                            u<span class="s">'Expected equality of these values:\n'</span>
<a class="hl" name="130" href="#130">130</a>                            u<span class="s">'  1\n  2'</span> + <a href="/googletest/s?defs=STACK_TRACE_TEMPLATE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">STACK_TRACE_TEMPLATE</a>,
<a class="l" name="131" href="#131">131</a>                u<span class="s">'type'</span>: u<span class="s">''</span>
<a class="l" name="132" href="#132">132</a>            }]
<a class="l" name="133" href="#133">133</a>        }]
<a class="l" name="134" href="#134">134</a>    }, {
<a class="l" name="135" href="#135">135</a>        u<span class="s">'name'</span>:
<a class="l" name="136" href="#136">136</a>            u<span class="s">'DisabledTest'</span>,
<a class="l" name="137" href="#137">137</a>        u<span class="s">'tests'</span>:
<a class="l" name="138" href="#138">138</a>            <span class="n">1</span>,
<a class="l" name="139" href="#139">139</a>        u<span class="s">'failures'</span>:
<a class="hl" name="140" href="#140">140</a>            <span class="n">0</span>,
<a class="l" name="141" href="#141">141</a>        u<span class="s">'disabled'</span>:
<a class="l" name="142" href="#142">142</a>            <span class="n">1</span>,
<a class="l" name="143" href="#143">143</a>        u<span class="s">'errors'</span>:
<a class="l" name="144" href="#144">144</a>            <span class="n">0</span>,
<a class="l" name="145" href="#145">145</a>        u<span class="s">'time'</span>:
<a class="l" name="146" href="#146">146</a>            u<span class="s">'*'</span>,
<a class="l" name="147" href="#147">147</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="148" href="#148">148</a>            u<span class="s">'*'</span>,
<a class="l" name="149" href="#149">149</a>        u<span class="s">'testsuite'</span>: [{
<a class="hl" name="150" href="#150">150</a>            u<span class="s">'name'</span>: u<span class="s">'DISABLED_test_not_run'</span>,
<a class="l" name="151" href="#151">151</a>            u<span class="s">'status'</span>: u<span class="s">'NOTRUN'</span>,
<a class="l" name="152" href="#152">152</a>            u<span class="s">'result'</span>: u<span class="s">'SUPPRESSED'</span>,
<a class="l" name="153" href="#153">153</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="154" href="#154">154</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="155" href="#155">155</a>            u<span class="s">'classname'</span>: u<span class="s">'DisabledTest'</span>
<a class="l" name="156" href="#156">156</a>        }]
<a class="l" name="157" href="#157">157</a>    }, {
<a class="l" name="158" href="#158">158</a>        u<span class="s">'name'</span>:
<a class="l" name="159" href="#159">159</a>            u<span class="s">'SkippedTest'</span>,
<a class="hl" name="160" href="#160">160</a>        u<span class="s">'tests'</span>:
<a class="l" name="161" href="#161">161</a>            <span class="n">3</span>,
<a class="l" name="162" href="#162">162</a>        u<span class="s">'failures'</span>:
<a class="l" name="163" href="#163">163</a>            <span class="n">1</span>,
<a class="l" name="164" href="#164">164</a>        u<span class="s">'disabled'</span>:
<a class="l" name="165" href="#165">165</a>            <span class="n">0</span>,
<a class="l" name="166" href="#166">166</a>        u<span class="s">'errors'</span>:
<a class="l" name="167" href="#167">167</a>            <span class="n">0</span>,
<a class="l" name="168" href="#168">168</a>        u<span class="s">'time'</span>:
<a class="l" name="169" href="#169">169</a>            u<span class="s">'*'</span>,
<a class="hl" name="170" href="#170">170</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="171" href="#171">171</a>            u<span class="s">'*'</span>,
<a class="l" name="172" href="#172">172</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="173" href="#173">173</a>            u<span class="s">'name'</span>: u<span class="s">'Skipped'</span>,
<a class="l" name="174" href="#174">174</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="175" href="#175">175</a>            u<span class="s">'result'</span>: u<span class="s">'SKIPPED'</span>,
<a class="l" name="176" href="#176">176</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="177" href="#177">177</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="178" href="#178">178</a>            u<span class="s">'classname'</span>: u<span class="s">'SkippedTest'</span>
<a class="l" name="179" href="#179">179</a>        }, {
<a class="hl" name="180" href="#180">180</a>            u<span class="s">'name'</span>: u<span class="s">'SkippedWithMessage'</span>,
<a class="l" name="181" href="#181">181</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="182" href="#182">182</a>            u<span class="s">'result'</span>: u<span class="s">'SKIPPED'</span>,
<a class="l" name="183" href="#183">183</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="184" href="#184">184</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="185" href="#185">185</a>            u<span class="s">'classname'</span>: u<span class="s">'SkippedTest'</span>
<a class="l" name="186" href="#186">186</a>        }, {
<a class="l" name="187" href="#187">187</a>            u<span class="s">'name'</span>:
<a class="l" name="188" href="#188">188</a>                u<span class="s">'SkippedAfterFailure'</span>,
<a class="l" name="189" href="#189">189</a>            u<span class="s">'status'</span>:
<a class="hl" name="190" href="#190">190</a>                u<span class="s">'RUN'</span>,
<a class="l" name="191" href="#191">191</a>            u<span class="s">'result'</span>:
<a class="l" name="192" href="#192">192</a>                u<span class="s">'COMPLETED'</span>,
<a class="l" name="193" href="#193">193</a>            u<span class="s">'time'</span>:
<a class="l" name="194" href="#194">194</a>                u<span class="s">'*'</span>,
<a class="l" name="195" href="#195">195</a>            u<span class="s">'timestamp'</span>:
<a class="l" name="196" href="#196">196</a>                u<span class="s">'*'</span>,
<a class="l" name="197" href="#197">197</a>            u<span class="s">'classname'</span>:
<a class="l" name="198" href="#198">198</a>                u<span class="s">'SkippedTest'</span>,
<a class="l" name="199" href="#199">199</a>            u<span class="s">'failures'</span>: [{
<a class="hl" name="200" href="#200">200</a>                u<span class="s">'failure'</span>: u<span class="s">'gtest_xml_output_unittest_.cc:*\n'</span>
<a class="l" name="201" href="#201">201</a>                            u<span class="s">'Expected equality of these values:\n'</span>
<a class="l" name="202" href="#202">202</a>                            u<span class="s">'  1\n  2'</span> + <a href="/googletest/s?defs=STACK_TRACE_TEMPLATE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">STACK_TRACE_TEMPLATE</a>,
<a class="l" name="203" href="#203">203</a>                u<span class="s">'type'</span>: u<span class="s">''</span>
<a class="l" name="204" href="#204">204</a>            }]
<a class="l" name="205" href="#205">205</a>        }]
<a class="l" name="206" href="#206">206</a>    }, {
<a class="l" name="207" href="#207">207</a>        u<span class="s">'name'</span>:
<a class="l" name="208" href="#208">208</a>            u<span class="s">'MixedResultTest'</span>,
<a class="l" name="209" href="#209">209</a>        u<span class="s">'tests'</span>:
<a class="hl" name="210" href="#210">210</a>            <span class="n">3</span>,
<a class="l" name="211" href="#211">211</a>        u<span class="s">'failures'</span>:
<a class="l" name="212" href="#212">212</a>            <span class="n">1</span>,
<a class="l" name="213" href="#213">213</a>        u<span class="s">'disabled'</span>:
<a class="l" name="214" href="#214">214</a>            <span class="n">1</span>,
<a class="l" name="215" href="#215">215</a>        u<span class="s">'errors'</span>:
<a class="l" name="216" href="#216">216</a>            <span class="n">0</span>,
<a class="l" name="217" href="#217">217</a>        u<span class="s">'time'</span>:
<a class="l" name="218" href="#218">218</a>            u<span class="s">'*'</span>,
<a class="l" name="219" href="#219">219</a>        u<span class="s">'timestamp'</span>:
<a class="hl" name="220" href="#220">220</a>            u<span class="s">'*'</span>,
<a class="l" name="221" href="#221">221</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="222" href="#222">222</a>            u<span class="s">'name'</span>: u<span class="s">'Succeeds'</span>,
<a class="l" name="223" href="#223">223</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="224" href="#224">224</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="225" href="#225">225</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="226" href="#226">226</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="227" href="#227">227</a>            u<span class="s">'classname'</span>: u<span class="s">'MixedResultTest'</span>
<a class="l" name="228" href="#228">228</a>        }, {
<a class="l" name="229" href="#229">229</a>            u<span class="s">'name'</span>:
<a class="hl" name="230" href="#230">230</a>                u<span class="s">'Fails'</span>,
<a class="l" name="231" href="#231">231</a>            u<span class="s">'status'</span>:
<a class="l" name="232" href="#232">232</a>                u<span class="s">'RUN'</span>,
<a class="l" name="233" href="#233">233</a>            u<span class="s">'result'</span>:
<a class="l" name="234" href="#234">234</a>                u<span class="s">'COMPLETED'</span>,
<a class="l" name="235" href="#235">235</a>            u<span class="s">'time'</span>:
<a class="l" name="236" href="#236">236</a>                u<span class="s">'*'</span>,
<a class="l" name="237" href="#237">237</a>            u<span class="s">'timestamp'</span>:
<a class="l" name="238" href="#238">238</a>                u<span class="s">'*'</span>,
<a class="l" name="239" href="#239">239</a>            u<span class="s">'classname'</span>:
<a class="hl" name="240" href="#240">240</a>                u<span class="s">'MixedResultTest'</span>,
<a class="l" name="241" href="#241">241</a>            u<span class="s">'failures'</span>: [{
<a class="l" name="242" href="#242">242</a>                u<span class="s">'failure'</span>: u<span class="s">'gtest_xml_output_unittest_.cc:*\n'</span>
<a class="l" name="243" href="#243">243</a>                            u<span class="s">'Expected equality of these values:\n'</span>
<a class="l" name="244" href="#244">244</a>                            u<span class="s">'  1\n  2'</span> + <a href="/googletest/s?defs=STACK_TRACE_TEMPLATE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">STACK_TRACE_TEMPLATE</a>,
<a class="l" name="245" href="#245">245</a>                u<span class="s">'type'</span>: u<span class="s">''</span>
<a class="l" name="246" href="#246">246</a>            }, {
<a class="l" name="247" href="#247">247</a>                u<span class="s">'failure'</span>: u<span class="s">'gtest_xml_output_unittest_.cc:*\n'</span>
<a class="l" name="248" href="#248">248</a>                            u<span class="s">'Expected equality of these values:\n'</span>
<a class="l" name="249" href="#249">249</a>                            u<span class="s">'  2\n  3'</span> + <a href="/googletest/s?defs=STACK_TRACE_TEMPLATE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">STACK_TRACE_TEMPLATE</a>,
<a class="hl" name="250" href="#250">250</a>                u<span class="s">'type'</span>: u<span class="s">''</span>
<a class="l" name="251" href="#251">251</a>            }]
<a class="l" name="252" href="#252">252</a>        }, {
<a class="l" name="253" href="#253">253</a>            u<span class="s">'name'</span>: u<span class="s">'DISABLED_test'</span>,
<a class="l" name="254" href="#254">254</a>            u<span class="s">'status'</span>: u<span class="s">'NOTRUN'</span>,
<a class="l" name="255" href="#255">255</a>            u<span class="s">'result'</span>: u<span class="s">'SUPPRESSED'</span>,
<a class="l" name="256" href="#256">256</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="257" href="#257">257</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="258" href="#258">258</a>            u<span class="s">'classname'</span>: u<span class="s">'MixedResultTest'</span>
<a class="l" name="259" href="#259">259</a>        }]
<a class="hl" name="260" href="#260">260</a>    }, {
<a class="l" name="261" href="#261">261</a>        u<span class="s">'name'</span>:
<a class="l" name="262" href="#262">262</a>            u<span class="s">'XmlQuotingTest'</span>,
<a class="l" name="263" href="#263">263</a>        u<span class="s">'tests'</span>:
<a class="l" name="264" href="#264">264</a>            <span class="n">1</span>,
<a class="l" name="265" href="#265">265</a>        u<span class="s">'failures'</span>:
<a class="l" name="266" href="#266">266</a>            <span class="n">1</span>,
<a class="l" name="267" href="#267">267</a>        u<span class="s">'disabled'</span>:
<a class="l" name="268" href="#268">268</a>            <span class="n">0</span>,
<a class="l" name="269" href="#269">269</a>        u<span class="s">'errors'</span>:
<a class="hl" name="270" href="#270">270</a>            <span class="n">0</span>,
<a class="l" name="271" href="#271">271</a>        u<span class="s">'time'</span>:
<a class="l" name="272" href="#272">272</a>            u<span class="s">'*'</span>,
<a class="l" name="273" href="#273">273</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="274" href="#274">274</a>            u<span class="s">'*'</span>,
<a class="l" name="275" href="#275">275</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="276" href="#276">276</a>            u<span class="s">'name'</span>:
<a class="l" name="277" href="#277">277</a>                u<span class="s">'OutputsCData'</span>,
<a class="l" name="278" href="#278">278</a>            u<span class="s">'status'</span>:
<a class="l" name="279" href="#279">279</a>                u<span class="s">'RUN'</span>,
<a class="hl" name="280" href="#280">280</a>            u<span class="s">'result'</span>:
<a class="l" name="281" href="#281">281</a>                u<span class="s">'COMPLETED'</span>,
<a class="l" name="282" href="#282">282</a>            u<span class="s">'time'</span>:
<a class="l" name="283" href="#283">283</a>                u<span class="s">'*'</span>,
<a class="l" name="284" href="#284">284</a>            u<span class="s">'timestamp'</span>:
<a class="l" name="285" href="#285">285</a>                u<span class="s">'*'</span>,
<a class="l" name="286" href="#286">286</a>            u<span class="s">'classname'</span>:
<a class="l" name="287" href="#287">287</a>                u<span class="s">'XmlQuotingTest'</span>,
<a class="l" name="288" href="#288">288</a>            u<span class="s">'failures'</span>: [{
<a class="l" name="289" href="#289">289</a>                u<span class="s">'failure'</span>: u<span class="s">'gtest_xml_output_unittest_.cc:*\n'</span>
<a class="hl" name="290" href="#290">290</a>                            u<span class="s">'Failed\nXML output: &lt;?xml encoding="utf-8"&gt;'</span>
<a class="l" name="291" href="#291">291</a>                            u<span class="s">'&lt;top&gt;&lt;![CDATA[cdata text]]&gt;&lt;/top&gt;'</span> +
<a class="l" name="292" href="#292">292</a>                            <a href="/googletest/s?defs=STACK_TRACE_TEMPLATE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">STACK_TRACE_TEMPLATE</a>,
<a class="l" name="293" href="#293">293</a>                u<span class="s">'type'</span>: u<span class="s">''</span>
<a class="l" name="294" href="#294">294</a>            }]
<a class="l" name="295" href="#295">295</a>        }]
<a class="l" name="296" href="#296">296</a>    }, {
<a class="l" name="297" href="#297">297</a>        u<span class="s">'name'</span>:
<a class="l" name="298" href="#298">298</a>            u<span class="s">'InvalidCharactersTest'</span>,
<a class="l" name="299" href="#299">299</a>        u<span class="s">'tests'</span>:
<a class="hl" name="300" href="#300">300</a>            <span class="n">1</span>,
<a class="l" name="301" href="#301">301</a>        u<span class="s">'failures'</span>:
<a class="l" name="302" href="#302">302</a>            <span class="n">1</span>,
<a class="l" name="303" href="#303">303</a>        u<span class="s">'disabled'</span>:
<a class="l" name="304" href="#304">304</a>            <span class="n">0</span>,
<a class="l" name="305" href="#305">305</a>        u<span class="s">'errors'</span>:
<a class="l" name="306" href="#306">306</a>            <span class="n">0</span>,
<a class="l" name="307" href="#307">307</a>        u<span class="s">'time'</span>:
<a class="l" name="308" href="#308">308</a>            u<span class="s">'*'</span>,
<a class="l" name="309" href="#309">309</a>        u<span class="s">'timestamp'</span>:
<a class="hl" name="310" href="#310">310</a>            u<span class="s">'*'</span>,
<a class="l" name="311" href="#311">311</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="312" href="#312">312</a>            u<span class="s">'name'</span>:
<a class="l" name="313" href="#313">313</a>                u<span class="s">'InvalidCharactersInMessage'</span>,
<a class="l" name="314" href="#314">314</a>            u<span class="s">'status'</span>:
<a class="l" name="315" href="#315">315</a>                u<span class="s">'RUN'</span>,
<a class="l" name="316" href="#316">316</a>            u<span class="s">'result'</span>:
<a class="l" name="317" href="#317">317</a>                u<span class="s">'COMPLETED'</span>,
<a class="l" name="318" href="#318">318</a>            u<span class="s">'time'</span>:
<a class="l" name="319" href="#319">319</a>                u<span class="s">'*'</span>,
<a class="hl" name="320" href="#320">320</a>            u<span class="s">'timestamp'</span>:
<a class="l" name="321" href="#321">321</a>                u<span class="s">'*'</span>,
<a class="l" name="322" href="#322">322</a>            u<span class="s">'classname'</span>:
<a class="l" name="323" href="#323">323</a>                u<span class="s">'InvalidCharactersTest'</span>,
<a class="l" name="324" href="#324">324</a>            u<span class="s">'failures'</span>: [{
<a class="l" name="325" href="#325">325</a>                u<span class="s">'failure'</span>: u<span class="s">'gtest_xml_output_unittest_.cc:*\n'</span>
<a class="l" name="326" href="#326">326</a>                            u<span class="s">'Failed\nInvalid characters in brackets'</span>
<a class="l" name="327" href="#327">327</a>                            u<span class="s">' [\x01\x02]'</span> + <a href="/googletest/s?defs=STACK_TRACE_TEMPLATE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">STACK_TRACE_TEMPLATE</a>,
<a class="l" name="328" href="#328">328</a>                u<span class="s">'type'</span>: u<span class="s">''</span>
<a class="l" name="329" href="#329">329</a>            }]
<a class="hl" name="330" href="#330">330</a>        }]
<a class="l" name="331" href="#331">331</a>    }, {
<a class="l" name="332" href="#332">332</a>        u<span class="s">'name'</span>:
<a class="l" name="333" href="#333">333</a>            u<span class="s">'PropertyRecordingTest'</span>,
<a class="l" name="334" href="#334">334</a>        u<span class="s">'tests'</span>:
<a class="l" name="335" href="#335">335</a>            <span class="n">4</span>,
<a class="l" name="336" href="#336">336</a>        u<span class="s">'failures'</span>:
<a class="l" name="337" href="#337">337</a>            <span class="n">0</span>,
<a class="l" name="338" href="#338">338</a>        u<span class="s">'disabled'</span>:
<a class="l" name="339" href="#339">339</a>            <span class="n">0</span>,
<a class="hl" name="340" href="#340">340</a>        u<span class="s">'errors'</span>:
<a class="l" name="341" href="#341">341</a>            <span class="n">0</span>,
<a class="l" name="342" href="#342">342</a>        u<span class="s">'time'</span>:
<a class="l" name="343" href="#343">343</a>            u<span class="s">'*'</span>,
<a class="l" name="344" href="#344">344</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="345" href="#345">345</a>            u<span class="s">'*'</span>,
<a class="l" name="346" href="#346">346</a>        u<span class="s">'SetUpTestSuite'</span>:
<a class="l" name="347" href="#347">347</a>            u<span class="s">'yes'</span>,
<a class="l" name="348" href="#348">348</a>        u<span class="s">'TearDownTestSuite'</span>:
<a class="l" name="349" href="#349">349</a>            u<span class="s">'aye'</span>,
<a class="hl" name="350" href="#350">350</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="351" href="#351">351</a>            u<span class="s">'name'</span>: u<span class="s">'OneProperty'</span>,
<a class="l" name="352" href="#352">352</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="353" href="#353">353</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="354" href="#354">354</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="355" href="#355">355</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="356" href="#356">356</a>            u<span class="s">'classname'</span>: u<span class="s">'PropertyRecordingTest'</span>,
<a class="l" name="357" href="#357">357</a>            u<span class="s">'key_1'</span>: u<span class="s">'1'</span>
<a class="l" name="358" href="#358">358</a>        }, {
<a class="l" name="359" href="#359">359</a>            u<span class="s">'name'</span>: u<span class="s">'IntValuedProperty'</span>,
<a class="hl" name="360" href="#360">360</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="361" href="#361">361</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="362" href="#362">362</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="363" href="#363">363</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="364" href="#364">364</a>            u<span class="s">'classname'</span>: u<span class="s">'PropertyRecordingTest'</span>,
<a class="l" name="365" href="#365">365</a>            u<span class="s">'key_int'</span>: u<span class="s">'1'</span>
<a class="l" name="366" href="#366">366</a>        }, {
<a class="l" name="367" href="#367">367</a>            u<span class="s">'name'</span>: u<span class="s">'ThreeProperties'</span>,
<a class="l" name="368" href="#368">368</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="369" href="#369">369</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="hl" name="370" href="#370">370</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="371" href="#371">371</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="372" href="#372">372</a>            u<span class="s">'classname'</span>: u<span class="s">'PropertyRecordingTest'</span>,
<a class="l" name="373" href="#373">373</a>            u<span class="s">'key_1'</span>: u<span class="s">'1'</span>,
<a class="l" name="374" href="#374">374</a>            u<span class="s">'key_2'</span>: u<span class="s">'2'</span>,
<a class="l" name="375" href="#375">375</a>            u<span class="s">'key_3'</span>: u<span class="s">'3'</span>
<a class="l" name="376" href="#376">376</a>        }, {
<a class="l" name="377" href="#377">377</a>            u<span class="s">'name'</span>: u<span class="s">'TwoValuesForOneKeyUsesLastValue'</span>,
<a class="l" name="378" href="#378">378</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="379" href="#379">379</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="hl" name="380" href="#380">380</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="381" href="#381">381</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="382" href="#382">382</a>            u<span class="s">'classname'</span>: u<span class="s">'PropertyRecordingTest'</span>,
<a class="l" name="383" href="#383">383</a>            u<span class="s">'key_1'</span>: u<span class="s">'2'</span>
<a class="l" name="384" href="#384">384</a>        }]
<a class="l" name="385" href="#385">385</a>    }, {
<a class="l" name="386" href="#386">386</a>        u<span class="s">'name'</span>:
<a class="l" name="387" href="#387">387</a>            u<span class="s">'NoFixtureTest'</span>,
<a class="l" name="388" href="#388">388</a>        u<span class="s">'tests'</span>:
<a class="l" name="389" href="#389">389</a>            <span class="n">3</span>,
<a class="hl" name="390" href="#390">390</a>        u<span class="s">'failures'</span>:
<a class="l" name="391" href="#391">391</a>            <span class="n">0</span>,
<a class="l" name="392" href="#392">392</a>        u<span class="s">'disabled'</span>:
<a class="l" name="393" href="#393">393</a>            <span class="n">0</span>,
<a class="l" name="394" href="#394">394</a>        u<span class="s">'errors'</span>:
<a class="l" name="395" href="#395">395</a>            <span class="n">0</span>,
<a class="l" name="396" href="#396">396</a>        u<span class="s">'time'</span>:
<a class="l" name="397" href="#397">397</a>            u<span class="s">'*'</span>,
<a class="l" name="398" href="#398">398</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="399" href="#399">399</a>            u<span class="s">'*'</span>,
<a class="hl" name="400" href="#400">400</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="401" href="#401">401</a>            u<span class="s">'name'</span>: u<span class="s">'RecordProperty'</span>,
<a class="l" name="402" href="#402">402</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="403" href="#403">403</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="404" href="#404">404</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="405" href="#405">405</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="406" href="#406">406</a>            u<span class="s">'classname'</span>: u<span class="s">'NoFixtureTest'</span>,
<a class="l" name="407" href="#407">407</a>            u<span class="s">'key'</span>: u<span class="s">'1'</span>
<a class="l" name="408" href="#408">408</a>        }, {
<a class="l" name="409" href="#409">409</a>            u<span class="s">'name'</span>: u<span class="s">'ExternalUtilityThatCallsRecordIntValuedProperty'</span>,
<a class="hl" name="410" href="#410">410</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="411" href="#411">411</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="412" href="#412">412</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="413" href="#413">413</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="414" href="#414">414</a>            u<span class="s">'classname'</span>: u<span class="s">'NoFixtureTest'</span>,
<a class="l" name="415" href="#415">415</a>            u<span class="s">'key_for_utility_int'</span>: u<span class="s">'1'</span>
<a class="l" name="416" href="#416">416</a>        }, {
<a class="l" name="417" href="#417">417</a>            u<span class="s">'name'</span>: u<span class="s">'ExternalUtilityThatCallsRecordStringValuedProperty'</span>,
<a class="l" name="418" href="#418">418</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="419" href="#419">419</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="hl" name="420" href="#420">420</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="421" href="#421">421</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="422" href="#422">422</a>            u<span class="s">'classname'</span>: u<span class="s">'NoFixtureTest'</span>,
<a class="l" name="423" href="#423">423</a>            u<span class="s">'key_for_utility_string'</span>: u<span class="s">'1'</span>
<a class="l" name="424" href="#424">424</a>        }]
<a class="l" name="425" href="#425">425</a>    }, {
<a class="l" name="426" href="#426">426</a>        u<span class="s">'name'</span>:
<a class="l" name="427" href="#427">427</a>            u<span class="s">'TypedTest/0'</span>,
<a class="l" name="428" href="#428">428</a>        u<span class="s">'tests'</span>:
<a class="l" name="429" href="#429">429</a>            <span class="n">1</span>,
<a class="hl" name="430" href="#430">430</a>        u<span class="s">'failures'</span>:
<a class="l" name="431" href="#431">431</a>            <span class="n">0</span>,
<a class="l" name="432" href="#432">432</a>        u<span class="s">'disabled'</span>:
<a class="l" name="433" href="#433">433</a>            <span class="n">0</span>,
<a class="l" name="434" href="#434">434</a>        u<span class="s">'errors'</span>:
<a class="l" name="435" href="#435">435</a>            <span class="n">0</span>,
<a class="l" name="436" href="#436">436</a>        u<span class="s">'time'</span>:
<a class="l" name="437" href="#437">437</a>            u<span class="s">'*'</span>,
<a class="l" name="438" href="#438">438</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="439" href="#439">439</a>            u<span class="s">'*'</span>,
<a class="hl" name="440" href="#440">440</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="441" href="#441">441</a>            u<span class="s">'name'</span>: u<span class="s">'HasTypeParamAttribute'</span>,
<a class="l" name="442" href="#442">442</a>            u<span class="s">'type_param'</span>: u<span class="s">'int'</span>,
<a class="l" name="443" href="#443">443</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="444" href="#444">444</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="445" href="#445">445</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="446" href="#446">446</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="447" href="#447">447</a>            u<span class="s">'classname'</span>: u<span class="s">'TypedTest/0'</span>
<a class="l" name="448" href="#448">448</a>        }]
<a class="l" name="449" href="#449">449</a>    }, {
<a class="hl" name="450" href="#450">450</a>        u<span class="s">'name'</span>:
<a class="l" name="451" href="#451">451</a>            u<span class="s">'TypedTest/1'</span>,
<a class="l" name="452" href="#452">452</a>        u<span class="s">'tests'</span>:
<a class="l" name="453" href="#453">453</a>            <span class="n">1</span>,
<a class="l" name="454" href="#454">454</a>        u<span class="s">'failures'</span>:
<a class="l" name="455" href="#455">455</a>            <span class="n">0</span>,
<a class="l" name="456" href="#456">456</a>        u<span class="s">'disabled'</span>:
<a class="l" name="457" href="#457">457</a>            <span class="n">0</span>,
<a class="l" name="458" href="#458">458</a>        u<span class="s">'errors'</span>:
<a class="l" name="459" href="#459">459</a>            <span class="n">0</span>,
<a class="hl" name="460" href="#460">460</a>        u<span class="s">'time'</span>:
<a class="l" name="461" href="#461">461</a>            u<span class="s">'*'</span>,
<a class="l" name="462" href="#462">462</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="463" href="#463">463</a>            u<span class="s">'*'</span>,
<a class="l" name="464" href="#464">464</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="465" href="#465">465</a>            u<span class="s">'name'</span>: u<span class="s">'HasTypeParamAttribute'</span>,
<a class="l" name="466" href="#466">466</a>            u<span class="s">'type_param'</span>: u<span class="s">'long'</span>,
<a class="l" name="467" href="#467">467</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="468" href="#468">468</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="469" href="#469">469</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="hl" name="470" href="#470">470</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="471" href="#471">471</a>            u<span class="s">'classname'</span>: u<span class="s">'TypedTest/1'</span>
<a class="l" name="472" href="#472">472</a>        }]
<a class="l" name="473" href="#473">473</a>    }, {
<a class="l" name="474" href="#474">474</a>        u<span class="s">'name'</span>:
<a class="l" name="475" href="#475">475</a>            u<span class="s">'<a href="/googletest/s?path=Single/">Single</a>/<a href="/googletest/s?path=Single/TypeParameterizedTestSuite">TypeParameterizedTestSuite</a>/0'</span>,
<a class="l" name="476" href="#476">476</a>        u<span class="s">'tests'</span>:
<a class="l" name="477" href="#477">477</a>            <span class="n">1</span>,
<a class="l" name="478" href="#478">478</a>        u<span class="s">'failures'</span>:
<a class="l" name="479" href="#479">479</a>            <span class="n">0</span>,
<a class="hl" name="480" href="#480">480</a>        u<span class="s">'disabled'</span>:
<a class="l" name="481" href="#481">481</a>            <span class="n">0</span>,
<a class="l" name="482" href="#482">482</a>        u<span class="s">'errors'</span>:
<a class="l" name="483" href="#483">483</a>            <span class="n">0</span>,
<a class="l" name="484" href="#484">484</a>        u<span class="s">'time'</span>:
<a class="l" name="485" href="#485">485</a>            u<span class="s">'*'</span>,
<a class="l" name="486" href="#486">486</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="487" href="#487">487</a>            u<span class="s">'*'</span>,
<a class="l" name="488" href="#488">488</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="489" href="#489">489</a>            u<span class="s">'name'</span>: u<span class="s">'HasTypeParamAttribute'</span>,
<a class="hl" name="490" href="#490">490</a>            u<span class="s">'type_param'</span>: u<span class="s">'int'</span>,
<a class="l" name="491" href="#491">491</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="492" href="#492">492</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="493" href="#493">493</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="494" href="#494">494</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="495" href="#495">495</a>            u<span class="s">'classname'</span>: u<span class="s">'<a href="/googletest/s?path=Single/">Single</a>/<a href="/googletest/s?path=Single/TypeParameterizedTestSuite">TypeParameterizedTestSuite</a>/0'</span>
<a class="l" name="496" href="#496">496</a>        }]
<a class="l" name="497" href="#497">497</a>    }, {
<a class="l" name="498" href="#498">498</a>        u<span class="s">'name'</span>:
<a class="l" name="499" href="#499">499</a>            u<span class="s">'<a href="/googletest/s?path=Single/">Single</a>/<a href="/googletest/s?path=Single/TypeParameterizedTestSuite">TypeParameterizedTestSuite</a>/1'</span>,
<a class="hl" name="500" href="#500">500</a>        u<span class="s">'tests'</span>:
<a class="l" name="501" href="#501">501</a>            <span class="n">1</span>,
<a class="l" name="502" href="#502">502</a>        u<span class="s">'failures'</span>:
<a class="l" name="503" href="#503">503</a>            <span class="n">0</span>,
<a class="l" name="504" href="#504">504</a>        u<span class="s">'disabled'</span>:
<a class="l" name="505" href="#505">505</a>            <span class="n">0</span>,
<a class="l" name="506" href="#506">506</a>        u<span class="s">'errors'</span>:
<a class="l" name="507" href="#507">507</a>            <span class="n">0</span>,
<a class="l" name="508" href="#508">508</a>        u<span class="s">'time'</span>:
<a class="l" name="509" href="#509">509</a>            u<span class="s">'*'</span>,
<a class="hl" name="510" href="#510">510</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="511" href="#511">511</a>            u<span class="s">'*'</span>,
<a class="l" name="512" href="#512">512</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="513" href="#513">513</a>            u<span class="s">'name'</span>: u<span class="s">'HasTypeParamAttribute'</span>,
<a class="l" name="514" href="#514">514</a>            u<span class="s">'type_param'</span>: u<span class="s">'long'</span>,
<a class="l" name="515" href="#515">515</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="516" href="#516">516</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="517" href="#517">517</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="518" href="#518">518</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="519" href="#519">519</a>            u<span class="s">'classname'</span>: u<span class="s">'<a href="/googletest/s?path=Single/">Single</a>/<a href="/googletest/s?path=Single/TypeParameterizedTestSuite">TypeParameterizedTestSuite</a>/1'</span>
<a class="hl" name="520" href="#520">520</a>        }]
<a class="l" name="521" href="#521">521</a>    }, {
<a class="l" name="522" href="#522">522</a>        u<span class="s">'name'</span>:
<a class="l" name="523" href="#523">523</a>            u<span class="s">'<a href="/googletest/s?path=Single/">Single</a>/<a href="/googletest/s?path=Single/ValueParamTest">ValueParamTest</a>'</span>,
<a class="l" name="524" href="#524">524</a>        u<span class="s">'tests'</span>:
<a class="l" name="525" href="#525">525</a>            <span class="n">4</span>,
<a class="l" name="526" href="#526">526</a>        u<span class="s">'failures'</span>:
<a class="l" name="527" href="#527">527</a>            <span class="n">0</span>,
<a class="l" name="528" href="#528">528</a>        u<span class="s">'disabled'</span>:
<a class="l" name="529" href="#529">529</a>            <span class="n">0</span>,
<a class="hl" name="530" href="#530">530</a>        u<span class="s">'errors'</span>:
<a class="l" name="531" href="#531">531</a>            <span class="n">0</span>,
<a class="l" name="532" href="#532">532</a>        u<span class="s">'time'</span>:
<a class="l" name="533" href="#533">533</a>            u<span class="s">'*'</span>,
<a class="l" name="534" href="#534">534</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="535" href="#535">535</a>            u<span class="s">'*'</span>,
<a class="l" name="536" href="#536">536</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="537" href="#537">537</a>            u<span class="s">'name'</span>: u<span class="s">'HasValueParamAttribute/0'</span>,
<a class="l" name="538" href="#538">538</a>            u<span class="s">'value_param'</span>: u<span class="s">'33'</span>,
<a class="l" name="539" href="#539">539</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="hl" name="540" href="#540">540</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="541" href="#541">541</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="542" href="#542">542</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="543" href="#543">543</a>            u<span class="s">'classname'</span>: u<span class="s">'<a href="/googletest/s?path=Single/">Single</a>/<a href="/googletest/s?path=Single/ValueParamTest">ValueParamTest</a>'</span>
<a class="l" name="544" href="#544">544</a>        }, {
<a class="l" name="545" href="#545">545</a>            u<span class="s">'name'</span>: u<span class="s">'HasValueParamAttribute/1'</span>,
<a class="l" name="546" href="#546">546</a>            u<span class="s">'value_param'</span>: u<span class="s">'42'</span>,
<a class="l" name="547" href="#547">547</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="548" href="#548">548</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="549" href="#549">549</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="hl" name="550" href="#550">550</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="551" href="#551">551</a>            u<span class="s">'classname'</span>: u<span class="s">'<a href="/googletest/s?path=Single/">Single</a>/<a href="/googletest/s?path=Single/ValueParamTest">ValueParamTest</a>'</span>
<a class="l" name="552" href="#552">552</a>        }, {
<a class="l" name="553" href="#553">553</a>            u<span class="s">'name'</span>: u<span class="s">'AnotherTestThatHasValueParamAttribute/0'</span>,
<a class="l" name="554" href="#554">554</a>            u<span class="s">'value_param'</span>: u<span class="s">'33'</span>,
<a class="l" name="555" href="#555">555</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="556" href="#556">556</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="557" href="#557">557</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="558" href="#558">558</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="559" href="#559">559</a>            u<span class="s">'classname'</span>: u<span class="s">'<a href="/googletest/s?path=Single/">Single</a>/<a href="/googletest/s?path=Single/ValueParamTest">ValueParamTest</a>'</span>
<a class="hl" name="560" href="#560">560</a>        }, {
<a class="l" name="561" href="#561">561</a>            u<span class="s">'name'</span>: u<span class="s">'AnotherTestThatHasValueParamAttribute/1'</span>,
<a class="l" name="562" href="#562">562</a>            u<span class="s">'value_param'</span>: u<span class="s">'42'</span>,
<a class="l" name="563" href="#563">563</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="564" href="#564">564</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="565" href="#565">565</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="566" href="#566">566</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="567" href="#567">567</a>            u<span class="s">'classname'</span>: u<span class="s">'<a href="/googletest/s?path=Single/">Single</a>/<a href="/googletest/s?path=Single/ValueParamTest">ValueParamTest</a>'</span>
<a class="l" name="568" href="#568">568</a>        }]
<a class="l" name="569" href="#569">569</a>    }]
<a class="hl" name="570" href="#570">570</a>}
<a class="l" name="571" href="#571">571</a>
<a class="l" name="572" href="#572">572</a><a class="xv" name="EXPECTED_FILTERED"/><a href="/googletest/s?refs=EXPECTED_FILTERED&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">EXPECTED_FILTERED</a> = {
<a class="l" name="573" href="#573">573</a>    u<span class="s">'tests'</span>:
<a class="l" name="574" href="#574">574</a>        <span class="n">1</span>,
<a class="l" name="575" href="#575">575</a>    u<span class="s">'failures'</span>:
<a class="l" name="576" href="#576">576</a>        <span class="n">0</span>,
<a class="l" name="577" href="#577">577</a>    u<span class="s">'disabled'</span>:
<a class="l" name="578" href="#578">578</a>        <span class="n">0</span>,
<a class="l" name="579" href="#579">579</a>    u<span class="s">'errors'</span>:
<a class="hl" name="580" href="#580">580</a>        <span class="n">0</span>,
<a class="l" name="581" href="#581">581</a>    u<span class="s">'time'</span>:
<a class="l" name="582" href="#582">582</a>        u<span class="s">'*'</span>,
<a class="l" name="583" href="#583">583</a>    u<span class="s">'timestamp'</span>:
<a class="l" name="584" href="#584">584</a>        u<span class="s">'*'</span>,
<a class="l" name="585" href="#585">585</a>    u<span class="s">'name'</span>:
<a class="l" name="586" href="#586">586</a>        u<span class="s">'AllTests'</span>,
<a class="l" name="587" href="#587">587</a>    u<span class="s">'ad_hoc_property'</span>:
<a class="l" name="588" href="#588">588</a>        u<span class="s">'42'</span>,
<a class="l" name="589" href="#589">589</a>    u<span class="s">'testsuites'</span>: [{
<a class="hl" name="590" href="#590">590</a>        u<span class="s">'name'</span>:
<a class="l" name="591" href="#591">591</a>            u<span class="s">'SuccessfulTest'</span>,
<a class="l" name="592" href="#592">592</a>        u<span class="s">'tests'</span>:
<a class="l" name="593" href="#593">593</a>            <span class="n">1</span>,
<a class="l" name="594" href="#594">594</a>        u<span class="s">'failures'</span>:
<a class="l" name="595" href="#595">595</a>            <span class="n">0</span>,
<a class="l" name="596" href="#596">596</a>        u<span class="s">'disabled'</span>:
<a class="l" name="597" href="#597">597</a>            <span class="n">0</span>,
<a class="l" name="598" href="#598">598</a>        u<span class="s">'errors'</span>:
<a class="l" name="599" href="#599">599</a>            <span class="n">0</span>,
<a class="hl" name="600" href="#600">600</a>        u<span class="s">'time'</span>:
<a class="l" name="601" href="#601">601</a>            u<span class="s">'*'</span>,
<a class="l" name="602" href="#602">602</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="603" href="#603">603</a>            u<span class="s">'*'</span>,
<a class="l" name="604" href="#604">604</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="605" href="#605">605</a>            u<span class="s">'name'</span>: u<span class="s">'Succeeds'</span>,
<a class="l" name="606" href="#606">606</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="607" href="#607">607</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="608" href="#608">608</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="609" href="#609">609</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="hl" name="610" href="#610">610</a>            u<span class="s">'classname'</span>: u<span class="s">'SuccessfulTest'</span>,
<a class="l" name="611" href="#611">611</a>        }]
<a class="l" name="612" href="#612">612</a>    }],
<a class="l" name="613" href="#613">613</a>}
<a class="l" name="614" href="#614">614</a>
<a class="l" name="615" href="#615">615</a><a class="xv" name="EXPECTED_EMPTY"/><a href="/googletest/s?refs=EXPECTED_EMPTY&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">EXPECTED_EMPTY</a> = {
<a class="l" name="616" href="#616">616</a>    u<span class="s">'tests'</span>: <span class="n">0</span>,
<a class="l" name="617" href="#617">617</a>    u<span class="s">'failures'</span>: <span class="n">0</span>,
<a class="l" name="618" href="#618">618</a>    u<span class="s">'disabled'</span>: <span class="n">0</span>,
<a class="l" name="619" href="#619">619</a>    u<span class="s">'errors'</span>: <span class="n">0</span>,
<a class="hl" name="620" href="#620">620</a>    u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="621" href="#621">621</a>    u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="622" href="#622">622</a>    u<span class="s">'name'</span>: u<span class="s">'AllTests'</span>,
<a class="l" name="623" href="#623">623</a>    u<span class="s">'testsuites'</span>: [],
<a class="l" name="624" href="#624">624</a>}
<a class="l" name="625" href="#625">625</a>
<a class="l" name="626" href="#626">626</a><a class="xv" name="GTEST_PROGRAM_PATH"/><a href="/googletest/s?refs=GTEST_PROGRAM_PATH&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_PROGRAM_PATH</a> = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTestExecutablePath&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTestExecutablePath</a>(<a class="d intelliWindow-symbol" href="#GTEST_PROGRAM_NAME" data-definition-place="defined-in-file">GTEST_PROGRAM_NAME</a>)
<a class="l" name="627" href="#627">627</a>
<a class="l" name="628" href="#628">628</a><a class="xv" name="SUPPORTS_TYPED_TESTS"/><a href="/googletest/s?refs=SUPPORTS_TYPED_TESTS&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">SUPPORTS_TYPED_TESTS</a> = <span class="s">'TypedTest'</span> <b>in</b> <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=Subprocess&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Subprocess</a>(
<a class="l" name="629" href="#629">629</a>    [<a class="d intelliWindow-symbol" href="#GTEST_PROGRAM_PATH" data-definition-place="defined-in-file">GTEST_PROGRAM_PATH</a>, <a class="d intelliWindow-symbol" href="#GTEST_LIST_TESTS_FLAG" data-definition-place="defined-in-file">GTEST_LIST_TESTS_FLAG</a>], <a href="/googletest/s?defs=capture_stderr&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">capture_stderr</a>=<a href="/googletest/s?defs=False&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">False</a>).<a href="/googletest/s?defs=output&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output</a>
<a class="hl" name="630" href="#630">630</a>
<a class="l" name="631" href="#631">631</a>
<a class="l" name="632" href="#632">632</a><b>class</b> <a class="xc" name="GTestJsonOutputUnitTest"/><a href="/googletest/s?refs=GTestJsonOutputUnitTest&amp;project=googletest" class="xc intelliWindow-symbol" data-definition-place="def">GTestJsonOutputUnitTest</a>(<a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=TestCase&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TestCase</a>):
<a class="l" name="633" href="#633">633</a>  <span class="s">"""Unit test for Google Test's JSON output functionality.
<a class="l" name="634" href="#634">634</a>  """</span>
<a class="l" name="635" href="#635">635</a>
<a class="l" name="636" href="#636">636</a>  <span class="c"># This test currently breaks on platforms that do not support typed and</span>
<a class="l" name="637" href="#637">637</a>  <span class="c"># type-parameterized tests, so we don't run it under them.</span>
<a class="l" name="638" href="#638">638</a>  <b>if</b> <a class="d intelliWindow-symbol" href="#SUPPORTS_TYPED_TESTS" data-definition-place="defined-in-file">SUPPORTS_TYPED_TESTS</a>:
<a class="l" name="639" href="#639">639</a>
<a class="hl" name="640" href="#640">640</a>    <b>def</b> <a class="xmb" name="testNonEmptyJsonOutput"/><a href="/googletest/s?refs=testNonEmptyJsonOutput&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testNonEmptyJsonOutput</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="641" href="#641">641</a>      <span class="s">"""Verifies JSON output for a Google Test binary with non-empty output.
<a class="l" name="642" href="#642">642</a>
<a class="l" name="643" href="#643">643</a>      Runs a test program that generates a non-empty JSON output, and
<a class="l" name="644" href="#644">644</a>      tests that the JSON output is expected.
<a class="l" name="645" href="#645">645</a>      """</span>
<a class="l" name="646" href="#646">646</a>      <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#_TestJsonOutput" data-definition-place="defined-in-file">_TestJsonOutput</a>(<a class="d intelliWindow-symbol" href="#GTEST_PROGRAM_NAME" data-definition-place="defined-in-file">GTEST_PROGRAM_NAME</a>, <a class="d intelliWindow-symbol" href="#EXPECTED_NON_EMPTY" data-definition-place="defined-in-file">EXPECTED_NON_EMPTY</a>, <span class="n">1</span>)
<a class="l" name="647" href="#647">647</a>
<a class="l" name="648" href="#648">648</a>  <b>def</b> <a class="xmb" name="testEmptyJsonOutput"/><a href="/googletest/s?refs=testEmptyJsonOutput&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testEmptyJsonOutput</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="649" href="#649">649</a>    <span class="s">"""Verifies JSON output for a Google Test binary without actual tests.
<a class="hl" name="650" href="#650">650</a>
<a class="l" name="651" href="#651">651</a>    Runs a test program that generates an empty JSON output, and
<a class="l" name="652" href="#652">652</a>    tests that the JSON output is expected.
<a class="l" name="653" href="#653">653</a>    """</span>
<a class="l" name="654" href="#654">654</a>
<a class="l" name="655" href="#655">655</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#_TestJsonOutput" data-definition-place="defined-in-file">_TestJsonOutput</a>(<span class="s">'gtest_no_test_unittest'</span>, <a class="d intelliWindow-symbol" href="#EXPECTED_EMPTY" data-definition-place="defined-in-file">EXPECTED_EMPTY</a>, <span class="n">0</span>)
<a class="l" name="656" href="#656">656</a>
<a class="l" name="657" href="#657">657</a>  <b>def</b> <a class="xmb" name="testTimestampValue"/><a href="/googletest/s?refs=testTimestampValue&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testTimestampValue</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="658" href="#658">658</a>    <span class="s">"""Checks whether the timestamp attribute in the JSON output is valid.
<a class="l" name="659" href="#659">659</a>
<a class="hl" name="660" href="#660">660</a>    Runs a test program that generates an empty JSON output, and checks if
<a class="l" name="661" href="#661">661</a>    the timestamp attribute in the testsuites tag is valid.
<a class="l" name="662" href="#662">662</a>    """</span>
<a class="l" name="663" href="#663">663</a>    <a href="/googletest/s?defs=actual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual</a> = <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#_GetJsonOutput" data-definition-place="defined-in-file">_GetJsonOutput</a>(<span class="s">'gtest_no_test_unittest'</span>, [], <span class="n">0</span>)
<a class="l" name="664" href="#664">664</a>    <a href="/googletest/s?defs=date_time_str&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date_time_str</a> = <a href="/googletest/s?defs=actual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual</a>[<span class="s">'timestamp'</span>]
<a class="l" name="665" href="#665">665</a>    <span class="c"># datetime.strptime() is only available in Python 2.5+ so we have to</span>
<a class="l" name="666" href="#666">666</a>    <span class="c"># parse the expected datetime manually.</span>
<a class="l" name="667" href="#667">667</a>    <a href="/googletest/s?defs=match&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a> = <a class="d intelliWindow-symbol" href="#re" data-definition-place="defined-in-file">re</a>.<a href="/googletest/s?defs=match&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a>(r<span class="s">'(\d+)-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)'</span>, <a href="/googletest/s?defs=date_time_str&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date_time_str</a>)
<a class="l" name="668" href="#668">668</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertTrue&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertTrue</a>(
<a class="l" name="669" href="#669">669</a>        <a class="d intelliWindow-symbol" href="#re" data-definition-place="defined-in-file">re</a>.<a href="/googletest/s?defs=match&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a>,
<a class="hl" name="670" href="#670">670</a>        <span class="s">'JSON datettime string %s has incorrect format'</span> % <a href="/googletest/s?defs=date_time_str&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date_time_str</a>)
<a class="l" name="671" href="#671">671</a>    <a href="/googletest/s?defs=date_time_from_json&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date_time_from_json</a> = <a class="d intelliWindow-symbol" href="#datetime" data-definition-place="defined-in-file">datetime</a>.<a class="d intelliWindow-symbol" href="#datetime" data-definition-place="defined-in-file">datetime</a>(
<a class="l" name="672" href="#672">672</a>        <a href="/googletest/s?defs=year&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">year</a>=<a href="/googletest/s?defs=int&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">int</a>(<a href="/googletest/s?defs=match&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a>.<a href="/googletest/s?defs=group&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">group</a>(<span class="n">1</span>)), <a href="/googletest/s?defs=month&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">month</a>=<a href="/googletest/s?defs=int&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">int</a>(<a href="/googletest/s?defs=match&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a>.<a href="/googletest/s?defs=group&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">group</a>(<span class="n">2</span>)),
<a class="l" name="673" href="#673">673</a>        <a href="/googletest/s?defs=day&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">day</a>=<a href="/googletest/s?defs=int&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">int</a>(<a href="/googletest/s?defs=match&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a>.<a href="/googletest/s?defs=group&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">group</a>(<span class="n">3</span>)), <a href="/googletest/s?defs=hour&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">hour</a>=<a href="/googletest/s?defs=int&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">int</a>(<a href="/googletest/s?defs=match&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a>.<a href="/googletest/s?defs=group&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">group</a>(<span class="n">4</span>)),
<a class="l" name="674" href="#674">674</a>        <a href="/googletest/s?defs=minute&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">minute</a>=<a href="/googletest/s?defs=int&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">int</a>(<a href="/googletest/s?defs=match&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a>.<a href="/googletest/s?defs=group&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">group</a>(<span class="n">5</span>)), <a href="/googletest/s?defs=second&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">second</a>=<a href="/googletest/s?defs=int&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">int</a>(<a href="/googletest/s?defs=match&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a>.<a href="/googletest/s?defs=group&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">group</a>(<span class="n">6</span>)))
<a class="l" name="675" href="#675">675</a>
<a class="l" name="676" href="#676">676</a>    <a href="/googletest/s?defs=time_delta&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">time_delta</a> = <a href="/googletest/s?defs=abs&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">abs</a>(<a class="d intelliWindow-symbol" href="#datetime" data-definition-place="defined-in-file">datetime</a>.<a class="d intelliWindow-symbol" href="#datetime" data-definition-place="defined-in-file">datetime</a>.<a href="/googletest/s?defs=now&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">now</a>() - <a href="/googletest/s?defs=date_time_from_json&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date_time_from_json</a>)
<a class="l" name="677" href="#677">677</a>    <span class="c"># timestamp value should be near the current local time</span>
<a class="l" name="678" href="#678">678</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertTrue&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertTrue</a>(<a href="/googletest/s?defs=time_delta&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">time_delta</a> &lt; <a class="d intelliWindow-symbol" href="#datetime" data-definition-place="defined-in-file">datetime</a>.<a href="/googletest/s?defs=timedelta&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">timedelta</a>(<a href="/googletest/s?defs=seconds&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">seconds</a>=<span class="n">600</span>),
<a class="l" name="679" href="#679">679</a>                    <span class="s">'time_delta is %s'</span> % <a href="/googletest/s?defs=time_delta&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">time_delta</a>)
<a class="hl" name="680" href="#680">680</a>
<a class="l" name="681" href="#681">681</a>  <b>def</b> <a class="xmb" name="testDefaultOutputFile"/><a href="/googletest/s?refs=testDefaultOutputFile&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testDefaultOutputFile</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="682" href="#682">682</a>    <span class="s">"""Verifies the default output file name.
<a class="l" name="683" href="#683">683</a>
<a class="l" name="684" href="#684">684</a>    Confirms that Google Test produces an JSON output file with the expected
<a class="l" name="685" href="#685">685</a>    default name if no name is explicitly specified.
<a class="l" name="686" href="#686">686</a>    """</span>
<a class="l" name="687" href="#687">687</a>    <a href="/googletest/s?defs=output_file&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTempDir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTempDir</a>(),
<a class="l" name="688" href="#688">688</a>                               <a class="d intelliWindow-symbol" href="#GTEST_DEFAULT_OUTPUT_FILE" data-definition-place="defined-in-file">GTEST_DEFAULT_OUTPUT_FILE</a>)
<a class="l" name="689" href="#689">689</a>    <a href="/googletest/s?defs=gtest_prog_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_path</a> = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTestExecutablePath&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTestExecutablePath</a>(
<a class="hl" name="690" href="#690">690</a>        <span class="s">'gtest_no_test_unittest'</span>)
<a class="l" name="691" href="#691">691</a>    <b>try</b>:
<a class="l" name="692" href="#692">692</a>      <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=remove&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">remove</a>(<a href="/googletest/s?defs=output_file&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file</a>)
<a class="l" name="693" href="#693">693</a>    <b>except</b> <a href="/googletest/s?defs=OSError&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">OSError</a>:
<a class="l" name="694" href="#694">694</a>      e = <a class="d intelliWindow-symbol" href="#sys" data-definition-place="defined-in-file">sys</a>.<a href="/googletest/s?defs=exc_info&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exc_info</a>()[<span class="n">1</span>]
<a class="l" name="695" href="#695">695</a>      <b>if</b> e.<a class="d intelliWindow-symbol" href="#errno" data-definition-place="defined-in-file">errno</a> != <a class="d intelliWindow-symbol" href="#errno" data-definition-place="defined-in-file">errno</a>.<a href="/googletest/s?defs=ENOENT&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ENOENT</a>:
<a class="l" name="696" href="#696">696</a>        <b>raise</b>
<a class="l" name="697" href="#697">697</a>
<a class="l" name="698" href="#698">698</a>    p = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=Subprocess&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Subprocess</a>(
<a class="l" name="699" href="#699">699</a>        [<a href="/googletest/s?defs=gtest_prog_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_path</a>, <span class="s">'%s=json'</span> % <a class="d intelliWindow-symbol" href="#GTEST_OUTPUT_FLAG" data-definition-place="defined-in-file">GTEST_OUTPUT_FLAG</a>],
<a class="hl" name="700" href="#700">700</a>        <a href="/googletest/s?defs=working_dir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">working_dir</a>=<a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTempDir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTempDir</a>())
<a class="l" name="701" href="#701">701</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assert_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assert_</a>(p.<a href="/googletest/s?defs=exited&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exited</a>)
<a class="l" name="702" href="#702">702</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertEquals&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertEquals</a>(<span class="n">0</span>, p.<a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>)
<a class="l" name="703" href="#703">703</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assert_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assert_</a>(<a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=isfile&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">isfile</a>(<a href="/googletest/s?defs=output_file&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file</a>))
<a class="l" name="704" href="#704">704</a>
<a class="l" name="705" href="#705">705</a>  <b>def</b> <a class="xmb" name="testSuppressedJsonOutput"/><a href="/googletest/s?refs=testSuppressedJsonOutput&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testSuppressedJsonOutput</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="706" href="#706">706</a>    <span class="s">"""Verifies that no JSON output is generated.
<a class="l" name="707" href="#707">707</a>
<a class="l" name="708" href="#708">708</a>    Tests that no JSON file is generated if the default JSON listener is
<a class="l" name="709" href="#709">709</a>    shut down before RUN_ALL_TESTS is invoked.
<a class="hl" name="710" href="#710">710</a>    """</span>
<a class="l" name="711" href="#711">711</a>
<a class="l" name="712" href="#712">712</a>    <a href="/googletest/s?defs=json_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json_path</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTempDir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTempDir</a>(),
<a class="l" name="713" href="#713">713</a>                             <a class="d intelliWindow-symbol" href="#GTEST_PROGRAM_NAME" data-definition-place="defined-in-file">GTEST_PROGRAM_NAME</a> + <span class="s">'out.json'</span>)
<a class="l" name="714" href="#714">714</a>    <b>if</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=isfile&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">isfile</a>(<a href="/googletest/s?defs=json_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json_path</a>):
<a class="l" name="715" href="#715">715</a>      <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=remove&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">remove</a>(<a href="/googletest/s?defs=json_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json_path</a>)
<a class="l" name="716" href="#716">716</a>
<a class="l" name="717" href="#717">717</a>    <a href="/googletest/s?defs=command&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">command</a> = [<a class="d intelliWindow-symbol" href="#GTEST_PROGRAM_PATH" data-definition-place="defined-in-file">GTEST_PROGRAM_PATH</a>,
<a class="l" name="718" href="#718">718</a>               <span class="s">'%s=json:%s'</span> % (<a class="d intelliWindow-symbol" href="#GTEST_OUTPUT_FLAG" data-definition-place="defined-in-file">GTEST_OUTPUT_FLAG</a>, <a href="/googletest/s?defs=json_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json_path</a>),
<a class="l" name="719" href="#719">719</a>               <span class="s">'--shut_down_xml'</span>]
<a class="hl" name="720" href="#720">720</a>    p = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=Subprocess&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Subprocess</a>(<a href="/googletest/s?defs=command&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">command</a>)
<a class="l" name="721" href="#721">721</a>    <b>if</b> p.<a href="/googletest/s?defs=terminated_by_signal&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">terminated_by_signal</a>:
<a class="l" name="722" href="#722">722</a>      <span class="c"># p.signal is available only if p.terminated_by_signal is True.</span>
<a class="l" name="723" href="#723">723</a>      <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertFalse&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertFalse</a>(
<a class="l" name="724" href="#724">724</a>          p.<a href="/googletest/s?defs=terminated_by_signal&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">terminated_by_signal</a>,
<a class="l" name="725" href="#725">725</a>          <span class="s">'%s was killed by signal %d'</span> % (<a class="d intelliWindow-symbol" href="#GTEST_PROGRAM_NAME" data-definition-place="defined-in-file">GTEST_PROGRAM_NAME</a>, p.<a href="/googletest/s?defs=signal&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">signal</a>))
<a class="l" name="726" href="#726">726</a>    <b>else</b>:
<a class="l" name="727" href="#727">727</a>      <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assert_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assert_</a>(p.<a href="/googletest/s?defs=exited&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exited</a>)
<a class="l" name="728" href="#728">728</a>      <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertEquals&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertEquals</a>(<span class="n">1</span>, p.<a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>,
<a class="l" name="729" href="#729">729</a>                        <span class="s">"'%s' exited with code %s, which doesn't match "</span>
<a class="hl" name="730" href="#730">730</a>                        <span class="s">'the expected exit code %s.'</span>
<a class="l" name="731" href="#731">731</a>                        % (<a href="/googletest/s?defs=command&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">command</a>, p.<a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>, <span class="n">1</span>))
<a class="l" name="732" href="#732">732</a>
<a class="l" name="733" href="#733">733</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assert_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assert_</a>(<b>not</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=isfile&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">isfile</a>(<a href="/googletest/s?defs=json_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json_path</a>))
<a class="l" name="734" href="#734">734</a>
<a class="l" name="735" href="#735">735</a>  <b>def</b> <a class="xmb" name="testFilteredTestJsonOutput"/><a href="/googletest/s?refs=testFilteredTestJsonOutput&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testFilteredTestJsonOutput</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="736" href="#736">736</a>    <span class="s">"""Verifies JSON output when a filter is applied.
<a class="l" name="737" href="#737">737</a>
<a class="l" name="738" href="#738">738</a>    Runs a test program that executes only some tests and verifies that
<a class="l" name="739" href="#739">739</a>    non-selected tests do not show up in the JSON output.
<a class="hl" name="740" href="#740">740</a>    """</span>
<a class="l" name="741" href="#741">741</a>
<a class="l" name="742" href="#742">742</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#_TestJsonOutput" data-definition-place="defined-in-file">_TestJsonOutput</a>(<a class="d intelliWindow-symbol" href="#GTEST_PROGRAM_NAME" data-definition-place="defined-in-file">GTEST_PROGRAM_NAME</a>, <a class="d intelliWindow-symbol" href="#EXPECTED_FILTERED" data-definition-place="defined-in-file">EXPECTED_FILTERED</a>, <span class="n">0</span>,
<a class="l" name="743" href="#743">743</a>                         <a href="/googletest/s?defs=extra_args&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">extra_args</a>=[<span class="s">'%s=SuccessfulTest.*'</span> % <a class="d intelliWindow-symbol" href="#GTEST_FILTER_FLAG" data-definition-place="defined-in-file">GTEST_FILTER_FLAG</a>])
<a class="l" name="744" href="#744">744</a>
<a class="l" name="745" href="#745">745</a>  <b>def</b> <a href="/googletest/s?refs=_GetJsonOutput&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">_GetJsonOutput</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>, <a href="/googletest/s?defs=gtest_prog_name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_name</a>, <a href="/googletest/s?defs=extra_args&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">extra_args</a>, <a href="/googletest/s?defs=expected_exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_exit_code</a>):
<a class="l" name="746" href="#746">746</a>    <span class="s">"""Returns the JSON output generated by running the program gtest_prog_name.
<a class="l" name="747" href="#747">747</a>
<a class="l" name="748" href="#748">748</a>    Furthermore, the program's exit code must be expected_exit_code.
<a class="l" name="749" href="#749">749</a>
<a class="hl" name="750" href="#750">750</a>    Args:
<a class="l" name="751" href="#751">751</a>      gtest_prog_name: Google Test binary name.
<a class="l" name="752" href="#752">752</a>      extra_args: extra arguments to binary invocation.
<a class="l" name="753" href="#753">753</a>      expected_exit_code: program's exit code.
<a class="l" name="754" href="#754">754</a>    """</span>
<a class="l" name="755" href="#755">755</a>    <a href="/googletest/s?defs=json_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json_path</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTempDir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTempDir</a>(),
<a class="l" name="756" href="#756">756</a>                             <a href="/googletest/s?defs=gtest_prog_name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_name</a> + <span class="s">'out.json'</span>)
<a class="l" name="757" href="#757">757</a>    <a href="/googletest/s?defs=gtest_prog_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_path</a> = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTestExecutablePath&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTestExecutablePath</a>(<a href="/googletest/s?defs=gtest_prog_name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_name</a>)
<a class="l" name="758" href="#758">758</a>
<a class="l" name="759" href="#759">759</a>    <a href="/googletest/s?defs=command&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">command</a> = (
<a class="hl" name="760" href="#760">760</a>        [<a href="/googletest/s?defs=gtest_prog_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_path</a>, <span class="s">'%s=json:%s'</span> % (<a class="d intelliWindow-symbol" href="#GTEST_OUTPUT_FLAG" data-definition-place="defined-in-file">GTEST_OUTPUT_FLAG</a>, <a href="/googletest/s?defs=json_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json_path</a>)] +
<a class="l" name="761" href="#761">761</a>        <a href="/googletest/s?defs=extra_args&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">extra_args</a>
<a class="l" name="762" href="#762">762</a>    )
<a class="l" name="763" href="#763">763</a>    p = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=Subprocess&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Subprocess</a>(<a href="/googletest/s?defs=command&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">command</a>)
<a class="l" name="764" href="#764">764</a>    <b>if</b> p.<a href="/googletest/s?defs=terminated_by_signal&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">terminated_by_signal</a>:
<a class="l" name="765" href="#765">765</a>      <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assert_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assert_</a>(<a href="/googletest/s?defs=False&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">False</a>,
<a class="l" name="766" href="#766">766</a>                   <span class="s">'%s was killed by signal %d'</span> % (<a href="/googletest/s?defs=gtest_prog_name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_name</a>, p.<a href="/googletest/s?defs=signal&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">signal</a>))
<a class="l" name="767" href="#767">767</a>    <b>else</b>:
<a class="l" name="768" href="#768">768</a>      <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assert_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assert_</a>(p.<a href="/googletest/s?defs=exited&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exited</a>)
<a class="l" name="769" href="#769">769</a>      <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertEquals&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertEquals</a>(<a href="/googletest/s?defs=expected_exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_exit_code</a>, p.<a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>,
<a class="hl" name="770" href="#770">770</a>                        <span class="s">"'%s' exited with code %s, which doesn't match "</span>
<a class="l" name="771" href="#771">771</a>                        <span class="s">'the expected exit code %s.'</span>
<a class="l" name="772" href="#772">772</a>                        % (<a href="/googletest/s?defs=command&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">command</a>, p.<a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>, <a href="/googletest/s?defs=expected_exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_exit_code</a>))
<a class="l" name="773" href="#773">773</a>    <b>with</b> <a href="/googletest/s?defs=open&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">open</a>(<a href="/googletest/s?defs=json_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json_path</a>) <b>as</b> f:
<a class="l" name="774" href="#774">774</a>      <a href="/googletest/s?defs=actual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual</a> = <a class="d intelliWindow-symbol" href="#json" data-definition-place="defined-in-file">json</a>.<a href="/googletest/s?defs=load&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">load</a>(f)
<a class="l" name="775" href="#775">775</a>    <b>return</b> <a href="/googletest/s?defs=actual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual</a>
<a class="l" name="776" href="#776">776</a>
<a class="l" name="777" href="#777">777</a>  <b>def</b> <a href="/googletest/s?refs=_TestJsonOutput&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">_TestJsonOutput</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>, <a href="/googletest/s?defs=gtest_prog_name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_name</a>, <a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>,
<a class="l" name="778" href="#778">778</a>                      <a href="/googletest/s?defs=expected_exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_exit_code</a>, <a href="/googletest/s?defs=extra_args&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">extra_args</a>=<b>None</b>):
<a class="l" name="779" href="#779">779</a>    <span class="s">"""Checks the JSON output generated by the Google Test binary.
<a class="hl" name="780" href="#780">780</a>
<a class="l" name="781" href="#781">781</a>    Asserts that the JSON document generated by running the program
<a class="l" name="782" href="#782">782</a>    gtest_prog_name matches expected_json, a string containing another
<a class="l" name="783" href="#783">783</a>    JSON document.  Furthermore, the program's exit code must be
<a class="l" name="784" href="#784">784</a>    expected_exit_code.
<a class="l" name="785" href="#785">785</a>
<a class="l" name="786" href="#786">786</a>    Args:
<a class="l" name="787" href="#787">787</a>      gtest_prog_name: Google Test binary name.
<a class="l" name="788" href="#788">788</a>      expected: expected output.
<a class="l" name="789" href="#789">789</a>      expected_exit_code: program's exit code.
<a class="hl" name="790" href="#790">790</a>      extra_args: extra arguments to binary invocation.
<a class="l" name="791" href="#791">791</a>    """</span>
<a class="l" name="792" href="#792">792</a>
<a class="l" name="793" href="#793">793</a>    <a href="/googletest/s?defs=actual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual</a> = <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#_GetJsonOutput" data-definition-place="defined-in-file">_GetJsonOutput</a>(<a href="/googletest/s?defs=gtest_prog_name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_name</a>, <a href="/googletest/s?defs=extra_args&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">extra_args</a> <b>or</b> [],
<a class="l" name="794" href="#794">794</a>                                 <a href="/googletest/s?defs=expected_exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_exit_code</a>)
<a class="l" name="795" href="#795">795</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertEqual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertEqual</a>(<a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>, <a class="d intelliWindow-symbol" href="#gtest_json_test_utils" data-definition-place="defined-in-file">gtest_json_test_utils</a>.<a href="/googletest/s?defs=normalize&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">normalize</a>(<a href="/googletest/s?defs=actual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual</a>))
<a class="l" name="796" href="#796">796</a>
<a class="l" name="797" href="#797">797</a>
<a class="l" name="798" href="#798">798</a><b>if</b> <a href="/googletest/s?defs=__name__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__name__</a> == <span class="s">'__main__'</span>:
<a class="l" name="799" href="#799">799</a>  <b>if</b> <a class="d intelliWindow-symbol" href="#NO_STACKTRACE_SUPPORT_FLAG" data-definition-place="defined-in-file">NO_STACKTRACE_SUPPORT_FLAG</a> <b>in</b> <a class="d intelliWindow-symbol" href="#sys" data-definition-place="defined-in-file">sys</a>.<a href="/googletest/s?defs=argv&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>:
<a class="hl" name="800" href="#800">800</a>    <span class="c"># unittest.main() can't handle unknown flags</span>
<a class="l" name="801" href="#801">801</a>    <a class="d intelliWindow-symbol" href="#sys" data-definition-place="defined-in-file">sys</a>.<a href="/googletest/s?defs=argv&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>.<a href="/googletest/s?defs=remove&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">remove</a>(<a class="d intelliWindow-symbol" href="#NO_STACKTRACE_SUPPORT_FLAG" data-definition-place="defined-in-file">NO_STACKTRACE_SUPPORT_FLAG</a>)
<a class="l" name="802" href="#802">802</a>
<a class="l" name="803" href="#803">803</a>  <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=environ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">environ</a>[<span class="s">'GTEST_STACK_TRACE_DEPTH'</span>] = <span class="s">'1'</span>
<a class="l" name="804" href="#804">804</a>  <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=Main&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Main</a>()
<a class="l" name="805" href="#805">805</a>