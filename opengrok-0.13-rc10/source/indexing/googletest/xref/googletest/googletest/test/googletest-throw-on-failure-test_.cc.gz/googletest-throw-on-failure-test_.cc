<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Function","xf",[["TerminateHandler",46],["main",52]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">// Copyright 2009, Google Inc.</span>
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span><span class="c">// All rights reserved.</span>
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span><span class="c">// Redistribution and use in source and binary forms, with or without</span>
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span><span class="c">// modification, are permitted provided that the following conditions are</span>
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span><span class="c">// met:</span>
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span><span class="c">//     * Redistributions of source code must retain the above copyright</span>
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span><span class="c">// notice, this list of conditions and the following disclaimer.</span>
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span><span class="c">//     * Redistributions in binary form must reproduce the above</span>
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span><span class="c">// copyright notice, this list of conditions and the following disclaimer</span>
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span><span class="c">// in the documentation <a href="/googletest/s?path=and/">and</a>/<a href="/googletest/s?path=and/or">or</a> other materials provided with the</span>
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span><span class="c">// distribution.</span>
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span><span class="c">//     * Neither the name of Google Inc. nor the names of its</span>
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span><span class="c">// contributors may be used to endorse or promote products derived from</span>
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span><span class="c">// this software without specific prior written permission.</span>
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span><span class="c">// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span><span class="c">// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR</span>
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span><span class="c">// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT</span>
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span><span class="c">// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span><span class="c">// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span><span class="c">// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span><span class="c">// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><span class="c">// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT</span>
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span><span class="c">// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><span class="c">// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</span>
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span><span class="c">// Tests Google Test's throw-on-failure mode with exceptions disabled.</span>
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span><span class="c">// This program must be compiled with exceptions disabled.  It will be</span>
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span><span class="c">// invoked by googletest-throw-on-failure-test.py, and is expected to exit</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span><span class="c">// with non-zero in the throw-on-failure mode or 0 otherwise.</span>
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=gtest/">gtest</a>/<a href="/googletest/s?path=gtest/gtest.h">gtest.h</a>"</span>
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>#<b>include</b> &lt;<a href="/googletest/s?path=stdio.h">stdio.h</a>&gt;                      <span class="c">// for fflush, fprintf, NULL, etc.</span>
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>#<b>include</b> &lt;<a href="/googletest/s?path=stdlib.h">stdlib.h</a>&gt;                     <span class="c">// for exit</span>
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>#<b>include</b> &lt;<a href="/googletest/s?path=exception">exception</a>&gt;                    <span class="c">// for set_terminate</span>
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span><span class="c">// This terminate handler aborts the program using exit() rather than abort().</span>
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span><span class="c">// This avoids showing pop-ups on Windows systems and core dumps on Unix-like</span>
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span><span class="c">// ones.</span>
<span id='scope_id_d587968c' class='scope-head'><span class='scope-signature'>TerminateHandler()</span><a class="l" name="46" href="#46">46</a><a href="#" onclick='fold(this.parentNode.id)' id='scope_id_d587968c_fold_icon'><span class='fold-icon'>&nbsp;</span></a><b>void</b> <a class="xf" name="TerminateHandler"/><a href="/googletest/s?refs=TerminateHandler&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">TerminateHandler</a>() &#123;</span>
<span id='scope_id_d587968c_fold' class='scope-body'><a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=fprintf&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fprintf</a>(<a href="/googletest/s?defs=stderr&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">stderr</a>, <span class="s">"%s\n"</span>, <span class="s">"Unhandled C++ exception terminating the program."</span>)&#59;
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=fflush&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fflush</a>(<a href="/googletest/s?defs=nullptr&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">nullptr</a>)&#59;
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=exit&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit</a>(<span class="n">1</span>)&#59;
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>&#125;
</span><a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span>
<span id='scope_id_97665ea3' class='scope-head'><span class='scope-signature'>main(int argc, char** argv)</span><a class="l" name="52" href="#52">52</a><a href="#" onclick='fold(this.parentNode.id)' id='scope_id_97665ea3_fold_icon'><span class='fold-icon'>&nbsp;</span></a><b>int</b> <a class="xf" name="main"/><a href="/googletest/s?refs=main&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">main</a>(<b>int</b> <a class="xa" name="argc"/><a href="/googletest/s?refs=argc&amp;project=googletest" class="xa intelliWindow-symbol" data-definition-place="def">argc</a>, <b>char</b>** <a class="xa" name="argv"/><a href="/googletest/s?refs=argv&amp;project=googletest" class="xa intelliWindow-symbol" data-definition-place="def">argv</a>) &#123;</span>
<span id='scope_id_97665ea3_fold' class='scope-body'><a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>#<b>if</b> <a href="/googletest/s?defs=GTEST_HAS_EXCEPTIONS&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GTEST_HAS_EXCEPTIONS</a>
<a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=std&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">std</a>::<a href="/googletest/s?defs=set_terminate&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">set_terminate</a>(&amp;<a class="d intelliWindow-symbol" href="#TerminateHandler" data-definition-place="defined-in-file">TerminateHandler</a>)&#59;
<a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span>#<b>endif</b>
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=testing&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">testing</a>::<a href="/googletest/s?defs=InitGoogleTest&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">InitGoogleTest</a>(&amp;<a class="d intelliWindow-symbol" href="#argc" data-definition-place="defined-in-file">argc</a>, <a class="d intelliWindow-symbol" href="#argv" data-definition-place="defined-in-file">argv</a>)&#59;
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="58" href="#58">58</a><span class='fold-space'>&nbsp;</span>  <span class="c">// We want to ensure that people can use Google Test assertions in</span>
<a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>  <span class="c">// other testing frameworks, as long as they initialize Google Test</span>
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span>  <span class="c">// properly and set the throw-on-failure mode.  Therefore, we don't</span>
<a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>  <span class="c">// use Google Test's constructs for defining and running tests</span>
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span>  <span class="c">// (e.g. TEST and RUN_ALL_TESTS) here.</span>
<a class="l" name="63" href="#63">63</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span>  <span class="c">// In the throw-on-failure mode with exceptions disabled, this</span>
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span>  <span class="c">// assertion will cause the program to exit with a non-zero code.</span>
<a class="l" name="66" href="#66">66</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_EQ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_EQ</a>(<span class="n">2</span>, <span class="n">3</span>)&#59;
<a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="68" href="#68">68</a><span class='fold-space'>&nbsp;</span>  <span class="c">// When not in the throw-on-failure mode, the control will reach</span>
<a class="l" name="69" href="#69">69</a><span class='fold-space'>&nbsp;</span>  <span class="c">// here.</span>
<a class="hl" name="70" href="#70">70</a><span class='fold-space'>&nbsp;</span>  <b>return</b> 0&#59;
<a class="l" name="71" href="#71">71</a><span class='fold-space'>&nbsp;</span>&#125;
</span><a class="l" name="72" href="#72">72</a><span class='fold-space'>&nbsp;</span>