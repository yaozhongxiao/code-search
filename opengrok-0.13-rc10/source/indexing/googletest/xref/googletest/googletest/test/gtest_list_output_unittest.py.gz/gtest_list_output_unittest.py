<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["GTEST_LIST_TESTS_FLAG",45],["GTEST_OUTPUT_FLAG",46]]],["Class","xc",[["GTestListTestsOutputUnitTest",226]]],["Namespace","xn",[["gtest_test_utils",43],["os",41],["re",42]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/googletest/s?path=/usr/">usr</a>/<a href="/googletest/s?path=/usr/bin/">bin</a>/<a href="/googletest/s?path=/usr/bin/env">env</a> python</span>
<a class="l" name="2" href="#2">2</a><span class="c">#</span>
<a class="l" name="3" href="#3">3</a><span class="c"># Copyright 2006, Google Inc.</span>
<a class="l" name="4" href="#4">4</a><span class="c"># All rights reserved.</span>
<a class="l" name="5" href="#5">5</a><span class="c">#</span>
<a class="l" name="6" href="#6">6</a><span class="c"># Redistribution and use in source and binary forms, with or without</span>
<a class="l" name="7" href="#7">7</a><span class="c"># modification, are permitted provided that the following conditions are</span>
<a class="l" name="8" href="#8">8</a><span class="c"># met:</span>
<a class="l" name="9" href="#9">9</a><span class="c">#</span>
<a class="hl" name="10" href="#10">10</a><span class="c">#     * Redistributions of source code must retain the above copyright</span>
<a class="l" name="11" href="#11">11</a><span class="c"># notice, this list of conditions and the following disclaimer.</span>
<a class="l" name="12" href="#12">12</a><span class="c">#     * Redistributions in binary form must reproduce the above</span>
<a class="l" name="13" href="#13">13</a><span class="c"># copyright notice, this list of conditions and the following disclaimer</span>
<a class="l" name="14" href="#14">14</a><span class="c"># in the documentation <a href="/googletest/s?path=and/">and</a>/<a href="/googletest/s?path=and/or">or</a> other materials provided with the</span>
<a class="l" name="15" href="#15">15</a><span class="c"># distribution.</span>
<a class="l" name="16" href="#16">16</a><span class="c">#     * Neither the name of Google Inc. nor the names of its</span>
<a class="l" name="17" href="#17">17</a><span class="c"># contributors may be used to endorse or promote products derived from</span>
<a class="l" name="18" href="#18">18</a><span class="c"># this software without specific prior written permission.</span>
<a class="l" name="19" href="#19">19</a><span class="c">#</span>
<a class="hl" name="20" href="#20">20</a><span class="c"># THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS</span>
<a class="l" name="21" href="#21">21</a><span class="c"># "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT</span>
<a class="l" name="22" href="#22">22</a><span class="c"># LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR</span>
<a class="l" name="23" href="#23">23</a><span class="c"># A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT</span>
<a class="l" name="24" href="#24">24</a><span class="c"># OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,</span>
<a class="l" name="25" href="#25">25</a><span class="c"># SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT</span>
<a class="l" name="26" href="#26">26</a><span class="c"># LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,</span>
<a class="l" name="27" href="#27">27</a><span class="c"># DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY</span>
<a class="l" name="28" href="#28">28</a><span class="c"># THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT</span>
<a class="l" name="29" href="#29">29</a><span class="c"># (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE</span>
<a class="hl" name="30" href="#30">30</a><span class="c"># OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</span>
<a class="l" name="31" href="#31">31</a><span class="s">"""Unit test for Google Test's --gtest_list_tests flag.
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>A user can ask Google Test to list all tests by specifying the
<a class="l" name="34" href="#34">34</a>--gtest_list_tests flag. If output is requested, via --gtest_output=xml
<a class="l" name="35" href="#35">35</a>or --gtest_output=json, the tests are listed, with extra information in the
<a class="l" name="36" href="#36">36</a>output file.
<a class="l" name="37" href="#37">37</a>This script tests such functionality by invoking gtest_list_output_unittest_
<a class="l" name="38" href="#38">38</a> (a program written with Google Test) the command line flags.
<a class="l" name="39" href="#39">39</a>"""</span>
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a><b>import</b> <a class="xn" name="os"/><a href="/googletest/s?refs=os&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">os</a>
<a class="l" name="42" href="#42">42</a><b>import</b> <a class="xn" name="re"/><a href="/googletest/s?refs=re&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">re</a>
<a class="l" name="43" href="#43">43</a><b>import</b> <a class="xn" name="gtest_test_utils"/><a href="/googletest/s?refs=gtest_test_utils&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">gtest_test_utils</a>
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a><a class="xv" name="GTEST_LIST_TESTS_FLAG"/><a href="/googletest/s?refs=GTEST_LIST_TESTS_FLAG&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_LIST_TESTS_FLAG</a> = <span class="s">'--gtest_list_tests'</span>
<a class="l" name="46" href="#46">46</a><a class="xv" name="GTEST_OUTPUT_FLAG"/><a href="/googletest/s?refs=GTEST_OUTPUT_FLAG&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_OUTPUT_FLAG</a> = <span class="s">'--gtest_output'</span>
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a><a href="/googletest/s?defs=EXPECTED_XML&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECTED_XML</a> = <span class="s">"""&lt;\?xml version="1.0" encoding="UTF-8"\?&gt;
<a class="l" name="49" href="#49">49</a>&lt;testsuites tests="16" name="AllTests"&gt;
<a class="hl" name="50" href="#50">50</a>  &lt;testsuite name="FooTest" tests="2"&gt;
<a class="l" name="51" href="#51">51</a>    &lt;testcase name="Test1" file=".*gtest_list_output_unittest_.cc" line="43" /&gt;
<a class="l" name="52" href="#52">52</a>    &lt;testcase name="Test2" file=".*gtest_list_output_unittest_.cc" line="45" /&gt;
<a class="l" name="53" href="#53">53</a>  &lt;/testsuite&gt;
<a class="l" name="54" href="#54">54</a>  &lt;testsuite name="FooTestFixture" tests="2"&gt;
<a class="l" name="55" href="#55">55</a>    &lt;testcase name="Test3" file=".*gtest_list_output_unittest_.cc" line="48" /&gt;
<a class="l" name="56" href="#56">56</a>    &lt;testcase name="Test4" file=".*gtest_list_output_unittest_.cc" line="49" /&gt;
<a class="l" name="57" href="#57">57</a>  &lt;/testsuite&gt;
<a class="l" name="58" href="#58">58</a>  &lt;testsuite name="TypedTest/0" tests="2"&gt;
<a class="l" name="59" href="#59">59</a>    &lt;testcase name="Test7" type_param="int" file=".*gtest_list_output_unittest_.cc" line="61" /&gt;
<a class="hl" name="60" href="#60">60</a>    &lt;testcase name="Test8" type_param="int" file=".*gtest_list_output_unittest_.cc" line="62" /&gt;
<a class="l" name="61" href="#61">61</a>  &lt;/testsuite&gt;
<a class="l" name="62" href="#62">62</a>  &lt;testsuite name="TypedTest/1" tests="2"&gt;
<a class="l" name="63" href="#63">63</a>    &lt;testcase name="Test7" type_param="bool" file=".*gtest_list_output_unittest_.cc" line="61" /&gt;
<a class="l" name="64" href="#64">64</a>    &lt;testcase name="Test8" type_param="bool" file=".*gtest_list_output_unittest_.cc" line="62" /&gt;
<a class="l" name="65" href="#65">65</a>  &lt;/testsuite&gt;
<a class="l" name="66" href="#66">66</a>  &lt;testsuite name="<a href="/googletest/s?path=Single/">Single</a>/<a href="/googletest/s?path=Single/TypeParameterizedTestSuite">TypeParameterizedTestSuite</a>/0" tests="2"&gt;
<a class="l" name="67" href="#67">67</a>    &lt;testcase name="Test9" type_param="int" file=".*gtest_list_output_unittest_.cc" line="69" /&gt;
<a class="l" name="68" href="#68">68</a>    &lt;testcase name="Test10" type_param="int" file=".*gtest_list_output_unittest_.cc" line="70" /&gt;
<a class="l" name="69" href="#69">69</a>  &lt;/testsuite&gt;
<a class="hl" name="70" href="#70">70</a>  &lt;testsuite name="<a href="/googletest/s?path=Single/">Single</a>/<a href="/googletest/s?path=Single/TypeParameterizedTestSuite">TypeParameterizedTestSuite</a>/1" tests="2"&gt;
<a class="l" name="71" href="#71">71</a>    &lt;testcase name="Test9" type_param="bool" file=".*gtest_list_output_unittest_.cc" line="69" /&gt;
<a class="l" name="72" href="#72">72</a>    &lt;testcase name="Test10" type_param="bool" file=".*gtest_list_output_unittest_.cc" line="70" /&gt;
<a class="l" name="73" href="#73">73</a>  &lt;/testsuite&gt;
<a class="l" name="74" href="#74">74</a>  &lt;testsuite name="<a href="/googletest/s?path=ValueParam/">ValueParam</a>/<a href="/googletest/s?path=ValueParam/ValueParamTest">ValueParamTest</a>" tests="4"&gt;
<a class="l" name="75" href="#75">75</a>    &lt;testcase name="Test5/0" value_param="33" file=".*gtest_list_output_unittest_.cc" line="52" /&gt;
<a class="l" name="76" href="#76">76</a>    &lt;testcase name="Test5/1" value_param="42" file=".*gtest_list_output_unittest_.cc" line="52" /&gt;
<a class="l" name="77" href="#77">77</a>    &lt;testcase name="Test6/0" value_param="33" file=".*gtest_list_output_unittest_.cc" line="53" /&gt;
<a class="l" name="78" href="#78">78</a>    &lt;testcase name="Test6/1" value_param="42" file=".*gtest_list_output_unittest_.cc" line="53" /&gt;
<a class="l" name="79" href="#79">79</a>  &lt;/testsuite&gt;
<a class="hl" name="80" href="#80">80</a>&lt;/testsuites&gt;
<a class="l" name="81" href="#81">81</a>"""</span>
<a class="l" name="82" href="#82">82</a>
<a class="l" name="83" href="#83">83</a><a href="/googletest/s?defs=EXPECTED_JSON&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECTED_JSON</a> = <span class="s">"""{
<a class="l" name="84" href="#84">84</a>  "tests": 16,
<a class="l" name="85" href="#85">85</a>  "name": "AllTests",
<a class="l" name="86" href="#86">86</a>  "testsuites": \[
<a class="l" name="87" href="#87">87</a>    {
<a class="l" name="88" href="#88">88</a>      "name": "FooTest",
<a class="l" name="89" href="#89">89</a>      "tests": 2,
<a class="hl" name="90" href="#90">90</a>      "testsuite": \[
<a class="l" name="91" href="#91">91</a>        {
<a class="l" name="92" href="#92">92</a>          "name": "Test1",
<a class="l" name="93" href="#93">93</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="94" href="#94">94</a>          "line": 43
<a class="l" name="95" href="#95">95</a>        },
<a class="l" name="96" href="#96">96</a>        {
<a class="l" name="97" href="#97">97</a>          "name": "Test2",
<a class="l" name="98" href="#98">98</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="99" href="#99">99</a>          "line": 45
<a class="hl" name="100" href="#100">100</a>        }
<a class="l" name="101" href="#101">101</a>      \]
<a class="l" name="102" href="#102">102</a>    },
<a class="l" name="103" href="#103">103</a>    {
<a class="l" name="104" href="#104">104</a>      "name": "FooTestFixture",
<a class="l" name="105" href="#105">105</a>      "tests": 2,
<a class="l" name="106" href="#106">106</a>      "testsuite": \[
<a class="l" name="107" href="#107">107</a>        {
<a class="l" name="108" href="#108">108</a>          "name": "Test3",
<a class="l" name="109" href="#109">109</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="hl" name="110" href="#110">110</a>          "line": 48
<a class="l" name="111" href="#111">111</a>        },
<a class="l" name="112" href="#112">112</a>        {
<a class="l" name="113" href="#113">113</a>          "name": "Test4",
<a class="l" name="114" href="#114">114</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="115" href="#115">115</a>          "line": 49
<a class="l" name="116" href="#116">116</a>        }
<a class="l" name="117" href="#117">117</a>      \]
<a class="l" name="118" href="#118">118</a>    },
<a class="l" name="119" href="#119">119</a>    {
<a class="hl" name="120" href="#120">120</a>      "name": "TypedTest\\\\/0",
<a class="l" name="121" href="#121">121</a>      "tests": 2,
<a class="l" name="122" href="#122">122</a>      "testsuite": \[
<a class="l" name="123" href="#123">123</a>        {
<a class="l" name="124" href="#124">124</a>          "name": "Test7",
<a class="l" name="125" href="#125">125</a>          "type_param": "int",
<a class="l" name="126" href="#126">126</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="127" href="#127">127</a>          "line": 61
<a class="l" name="128" href="#128">128</a>        },
<a class="l" name="129" href="#129">129</a>        {
<a class="hl" name="130" href="#130">130</a>          "name": "Test8",
<a class="l" name="131" href="#131">131</a>          "type_param": "int",
<a class="l" name="132" href="#132">132</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="133" href="#133">133</a>          "line": 62
<a class="l" name="134" href="#134">134</a>        }
<a class="l" name="135" href="#135">135</a>      \]
<a class="l" name="136" href="#136">136</a>    },
<a class="l" name="137" href="#137">137</a>    {
<a class="l" name="138" href="#138">138</a>      "name": "TypedTest\\\\/1",
<a class="l" name="139" href="#139">139</a>      "tests": 2,
<a class="hl" name="140" href="#140">140</a>      "testsuite": \[
<a class="l" name="141" href="#141">141</a>        {
<a class="l" name="142" href="#142">142</a>          "name": "Test7",
<a class="l" name="143" href="#143">143</a>          "type_param": "bool",
<a class="l" name="144" href="#144">144</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="145" href="#145">145</a>          "line": 61
<a class="l" name="146" href="#146">146</a>        },
<a class="l" name="147" href="#147">147</a>        {
<a class="l" name="148" href="#148">148</a>          "name": "Test8",
<a class="l" name="149" href="#149">149</a>          "type_param": "bool",
<a class="hl" name="150" href="#150">150</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="151" href="#151">151</a>          "line": 62
<a class="l" name="152" href="#152">152</a>        }
<a class="l" name="153" href="#153">153</a>      \]
<a class="l" name="154" href="#154">154</a>    },
<a class="l" name="155" href="#155">155</a>    {
<a class="l" name="156" href="#156">156</a>      "name": "Single\\\\/TypeParameterizedTestSuite\\\\/0",
<a class="l" name="157" href="#157">157</a>      "tests": 2,
<a class="l" name="158" href="#158">158</a>      "testsuite": \[
<a class="l" name="159" href="#159">159</a>        {
<a class="hl" name="160" href="#160">160</a>          "name": "Test9",
<a class="l" name="161" href="#161">161</a>          "type_param": "int",
<a class="l" name="162" href="#162">162</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="163" href="#163">163</a>          "line": 69
<a class="l" name="164" href="#164">164</a>        },
<a class="l" name="165" href="#165">165</a>        {
<a class="l" name="166" href="#166">166</a>          "name": "Test10",
<a class="l" name="167" href="#167">167</a>          "type_param": "int",
<a class="l" name="168" href="#168">168</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="169" href="#169">169</a>          "line": 70
<a class="hl" name="170" href="#170">170</a>        }
<a class="l" name="171" href="#171">171</a>      \]
<a class="l" name="172" href="#172">172</a>    },
<a class="l" name="173" href="#173">173</a>    {
<a class="l" name="174" href="#174">174</a>      "name": "Single\\\\/TypeParameterizedTestSuite\\\\/1",
<a class="l" name="175" href="#175">175</a>      "tests": 2,
<a class="l" name="176" href="#176">176</a>      "testsuite": \[
<a class="l" name="177" href="#177">177</a>        {
<a class="l" name="178" href="#178">178</a>          "name": "Test9",
<a class="l" name="179" href="#179">179</a>          "type_param": "bool",
<a class="hl" name="180" href="#180">180</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="181" href="#181">181</a>          "line": 69
<a class="l" name="182" href="#182">182</a>        },
<a class="l" name="183" href="#183">183</a>        {
<a class="l" name="184" href="#184">184</a>          "name": "Test10",
<a class="l" name="185" href="#185">185</a>          "type_param": "bool",
<a class="l" name="186" href="#186">186</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="187" href="#187">187</a>          "line": 70
<a class="l" name="188" href="#188">188</a>        }
<a class="l" name="189" href="#189">189</a>      \]
<a class="hl" name="190" href="#190">190</a>    },
<a class="l" name="191" href="#191">191</a>    {
<a class="l" name="192" href="#192">192</a>      "name": "ValueParam\\\\/ValueParamTest",
<a class="l" name="193" href="#193">193</a>      "tests": 4,
<a class="l" name="194" href="#194">194</a>      "testsuite": \[
<a class="l" name="195" href="#195">195</a>        {
<a class="l" name="196" href="#196">196</a>          "name": "Test5\\\\/0",
<a class="l" name="197" href="#197">197</a>          "value_param": "33",
<a class="l" name="198" href="#198">198</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="199" href="#199">199</a>          "line": 52
<a class="hl" name="200" href="#200">200</a>        },
<a class="l" name="201" href="#201">201</a>        {
<a class="l" name="202" href="#202">202</a>          "name": "Test5\\\\/1",
<a class="l" name="203" href="#203">203</a>          "value_param": "42",
<a class="l" name="204" href="#204">204</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="205" href="#205">205</a>          "line": 52
<a class="l" name="206" href="#206">206</a>        },
<a class="l" name="207" href="#207">207</a>        {
<a class="l" name="208" href="#208">208</a>          "name": "Test6\\\\/0",
<a class="l" name="209" href="#209">209</a>          "value_param": "33",
<a class="hl" name="210" href="#210">210</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="211" href="#211">211</a>          "line": 53
<a class="l" name="212" href="#212">212</a>        },
<a class="l" name="213" href="#213">213</a>        {
<a class="l" name="214" href="#214">214</a>          "name": "Test6\\\\/1",
<a class="l" name="215" href="#215">215</a>          "value_param": "42",
<a class="l" name="216" href="#216">216</a>          "file": ".*gtest_list_output_unittest_.cc",
<a class="l" name="217" href="#217">217</a>          "line": 53
<a class="l" name="218" href="#218">218</a>        }
<a class="l" name="219" href="#219">219</a>      \]
<a class="hl" name="220" href="#220">220</a>    }
<a class="l" name="221" href="#221">221</a>  \]
<a class="l" name="222" href="#222">222</a>}
<a class="l" name="223" href="#223">223</a>"""</span>
<a class="l" name="224" href="#224">224</a>
<a class="l" name="225" href="#225">225</a>
<a class="l" name="226" href="#226">226</a><b>class</b> <a class="xc" name="GTestListTestsOutputUnitTest"/><a href="/googletest/s?refs=GTestListTestsOutputUnitTest&amp;project=googletest" class="xc intelliWindow-symbol" data-definition-place="def">GTestListTestsOutputUnitTest</a>(<a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=TestCase&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TestCase</a>):
<a class="l" name="227" href="#227">227</a>  <span class="s">"""Unit test for Google Test's list tests with output to file functionality.
<a class="l" name="228" href="#228">228</a>  """</span>
<a class="l" name="229" href="#229">229</a>
<a class="hl" name="230" href="#230">230</a>  <b>def</b> <a class="xmb" name="testXml"/><a href="/googletest/s?refs=testXml&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testXml</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="231" href="#231">231</a>    <span class="s">"""Verifies XML output for listing tests in a Google Test binary.
<a class="l" name="232" href="#232">232</a>
<a class="l" name="233" href="#233">233</a>    Runs a test program that generates an empty XML output, and
<a class="l" name="234" href="#234">234</a>    tests that the XML output is expected.
<a class="l" name="235" href="#235">235</a>    """</span>
<a class="l" name="236" href="#236">236</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#_TestOutput" data-definition-place="defined-in-file">_TestOutput</a>(<span class="s">'xml'</span>, <a href="/googletest/s?defs=EXPECTED_XML&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECTED_XML</a>)
<a class="l" name="237" href="#237">237</a>
<a class="l" name="238" href="#238">238</a>  <b>def</b> <a class="xmb" name="testJSON"/><a href="/googletest/s?refs=testJSON&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testJSON</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="239" href="#239">239</a>    <span class="s">"""Verifies XML output for listing tests in a Google Test binary.
<a class="hl" name="240" href="#240">240</a>
<a class="l" name="241" href="#241">241</a>    Runs a test program that generates an empty XML output, and
<a class="l" name="242" href="#242">242</a>    tests that the XML output is expected.
<a class="l" name="243" href="#243">243</a>    """</span>
<a class="l" name="244" href="#244">244</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#_TestOutput" data-definition-place="defined-in-file">_TestOutput</a>(<span class="s">'json'</span>, <a href="/googletest/s?defs=EXPECTED_JSON&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECTED_JSON</a>)
<a class="l" name="245" href="#245">245</a>
<a class="l" name="246" href="#246">246</a>  <b>def</b> <a href="/googletest/s?refs=_GetOutput&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">_GetOutput</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>, <a href="/googletest/s?defs=out_format&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">out_format</a>):
<a class="l" name="247" href="#247">247</a>    <a href="/googletest/s?defs=file_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">file_path</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTempDir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTempDir</a>(),
<a class="l" name="248" href="#248">248</a>                             <span class="s">'test_out.'</span> + <a href="/googletest/s?defs=out_format&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">out_format</a>)
<a class="l" name="249" href="#249">249</a>    <a href="/googletest/s?defs=gtest_prog_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_path</a> = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTestExecutablePath&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTestExecutablePath</a>(
<a class="hl" name="250" href="#250">250</a>        <span class="s">'gtest_list_output_unittest_'</span>)
<a class="l" name="251" href="#251">251</a>
<a class="l" name="252" href="#252">252</a>    <a href="/googletest/s?defs=command&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">command</a> = ([
<a class="l" name="253" href="#253">253</a>        <a href="/googletest/s?defs=gtest_prog_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_path</a>,
<a class="l" name="254" href="#254">254</a>        <span class="s">'%s=%s:%s'</span> % (<a class="d intelliWindow-symbol" href="#GTEST_OUTPUT_FLAG" data-definition-place="defined-in-file">GTEST_OUTPUT_FLAG</a>, <a href="/googletest/s?defs=out_format&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">out_format</a>, <a href="/googletest/s?defs=file_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">file_path</a>),
<a class="l" name="255" href="#255">255</a>        <span class="s">'--gtest_list_tests'</span>
<a class="l" name="256" href="#256">256</a>    ])
<a class="l" name="257" href="#257">257</a>    <a href="/googletest/s?defs=environ_copy&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">environ_copy</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=environ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">environ</a>.<a href="/googletest/s?defs=copy&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">copy</a>()
<a class="l" name="258" href="#258">258</a>    p = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=Subprocess&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Subprocess</a>(
<a class="l" name="259" href="#259">259</a>        <a href="/googletest/s?defs=command&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">command</a>, <a href="/googletest/s?defs=env&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">env</a>=<a href="/googletest/s?defs=environ_copy&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">environ_copy</a>, <a href="/googletest/s?defs=working_dir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">working_dir</a>=<a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTempDir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTempDir</a>())
<a class="hl" name="260" href="#260">260</a>
<a class="l" name="261" href="#261">261</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertTrue&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertTrue</a>(p.<a href="/googletest/s?defs=exited&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exited</a>)
<a class="l" name="262" href="#262">262</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertEqual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertEqual</a>(<span class="n">0</span>, p.<a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>)
<a class="l" name="263" href="#263">263</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertTrue&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertTrue</a>(<a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=isfile&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">isfile</a>(<a href="/googletest/s?defs=file_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">file_path</a>))
<a class="l" name="264" href="#264">264</a>    <b>with</b> <a href="/googletest/s?defs=open&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">open</a>(<a href="/googletest/s?defs=file_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">file_path</a>) <b>as</b> f:
<a class="l" name="265" href="#265">265</a>      <a href="/googletest/s?defs=result&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">result</a> = f.<a href="/googletest/s?defs=read&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">read</a>()
<a class="l" name="266" href="#266">266</a>    <b>return</b> <a href="/googletest/s?defs=result&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">result</a>
<a class="l" name="267" href="#267">267</a>
<a class="l" name="268" href="#268">268</a>  <b>def</b> <a href="/googletest/s?refs=_TestOutput&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">_TestOutput</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>, <a href="/googletest/s?defs=test_format&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">test_format</a>, <a href="/googletest/s?defs=expected_output&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_output</a>):
<a class="l" name="269" href="#269">269</a>    <a href="/googletest/s?defs=actual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual</a> = <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#_GetOutput" data-definition-place="defined-in-file">_GetOutput</a>(<a href="/googletest/s?defs=test_format&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">test_format</a>)
<a class="hl" name="270" href="#270">270</a>    <a href="/googletest/s?defs=actual_lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual_lines</a> = <a href="/googletest/s?defs=actual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual</a>.<a href="/googletest/s?defs=splitlines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">splitlines</a>()
<a class="l" name="271" href="#271">271</a>    <a href="/googletest/s?defs=expected_lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_lines</a> = <a href="/googletest/s?defs=expected_output&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_output</a>.<a href="/googletest/s?defs=splitlines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">splitlines</a>()
<a class="l" name="272" href="#272">272</a>    <a href="/googletest/s?defs=line_count&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">line_count</a> = <span class="n">0</span>
<a class="l" name="273" href="#273">273</a>    <b>for</b> <a href="/googletest/s?defs=actual_line&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual_line</a> <b>in</b> <a href="/googletest/s?defs=actual_lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual_lines</a>:
<a class="l" name="274" href="#274">274</a>      <a href="/googletest/s?defs=expected_line&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_line</a> = <a href="/googletest/s?defs=expected_lines&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_lines</a>[<a href="/googletest/s?defs=line_count&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">line_count</a>]
<a class="l" name="275" href="#275">275</a>      <a href="/googletest/s?defs=expected_line_re&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_line_re</a> = <a class="d intelliWindow-symbol" href="#re" data-definition-place="defined-in-file">re</a>.<a href="/googletest/s?defs=compile&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">compile</a>(<a href="/googletest/s?defs=expected_line&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_line</a>.<a href="/googletest/s?defs=strip&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">strip</a>())
<a class="l" name="276" href="#276">276</a>      <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertTrue&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertTrue</a>(
<a class="l" name="277" href="#277">277</a>          <a href="/googletest/s?defs=expected_line_re&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_line_re</a>.<a href="/googletest/s?defs=match&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a>(<a href="/googletest/s?defs=actual_line&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual_line</a>.<a href="/googletest/s?defs=strip&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">strip</a>()),
<a class="l" name="278" href="#278">278</a>          (<span class="s">'actual output of "%s",\n'</span>
<a class="l" name="279" href="#279">279</a>           <span class="s">'which does not match expected regex of "%s"\n'</span>
<a class="hl" name="280" href="#280">280</a>           <span class="s">'on line %d'</span> % (<a href="/googletest/s?defs=actual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual</a>, <a href="/googletest/s?defs=expected_output&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected_output</a>, <a href="/googletest/s?defs=line_count&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">line_count</a>)))
<a class="l" name="281" href="#281">281</a>      <a href="/googletest/s?defs=line_count&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">line_count</a> = <a href="/googletest/s?defs=line_count&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">line_count</a> + <span class="n">1</span>
<a class="l" name="282" href="#282">282</a>
<a class="l" name="283" href="#283">283</a>
<a class="l" name="284" href="#284">284</a><b>if</b> <a href="/googletest/s?defs=__name__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__name__</a> == <span class="s">'__main__'</span>:
<a class="l" name="285" href="#285">285</a>  <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=environ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">environ</a>[<span class="s">'GTEST_STACK_TRACE_DEPTH'</span>] = <span class="s">'1'</span>
<a class="l" name="286" href="#286">286</a>  <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=Main&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Main</a>()
<a class="l" name="287" href="#287">287</a>