<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["EXPECTED_1",42],["EXPECTED_2",86],["GTEST_OUTPUT_1_TEST",39],["GTEST_OUTPUT_2_TEST",40],["GTEST_OUTPUT_SUBDIR",38]]],["Class","xc",[["GTestJsonOutFilesTest",131]]],["Namespace","xn",[["gtest_json_test_utils",35],["gtest_test_utils",36],["json",33],["os",34]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/googletest/s?path=/usr/">usr</a>/<a href="/googletest/s?path=/usr/bin/">bin</a>/<a href="/googletest/s?path=/usr/bin/env">env</a> python</span>
<a class="l" name="2" href="#2">2</a><span class="c"># Copyright 2018, Google Inc.</span>
<a class="l" name="3" href="#3">3</a><span class="c"># All rights reserved.</span>
<a class="l" name="4" href="#4">4</a><span class="c">#</span>
<a class="l" name="5" href="#5">5</a><span class="c"># Redistribution and use in source and binary forms, with or without</span>
<a class="l" name="6" href="#6">6</a><span class="c"># modification, are permitted provided that the following conditions are</span>
<a class="l" name="7" href="#7">7</a><span class="c"># met:</span>
<a class="l" name="8" href="#8">8</a><span class="c">#</span>
<a class="l" name="9" href="#9">9</a><span class="c">#     * Redistributions of source code must retain the above copyright</span>
<a class="hl" name="10" href="#10">10</a><span class="c"># notice, this list of conditions and the following disclaimer.</span>
<a class="l" name="11" href="#11">11</a><span class="c">#     * Redistributions in binary form must reproduce the above</span>
<a class="l" name="12" href="#12">12</a><span class="c"># copyright notice, this list of conditions and the following disclaimer</span>
<a class="l" name="13" href="#13">13</a><span class="c"># in the documentation <a href="/googletest/s?path=and/">and</a>/<a href="/googletest/s?path=and/or">or</a> other materials provided with the</span>
<a class="l" name="14" href="#14">14</a><span class="c"># distribution.</span>
<a class="l" name="15" href="#15">15</a><span class="c">#     * Neither the name of Google Inc. nor the names of its</span>
<a class="l" name="16" href="#16">16</a><span class="c"># contributors may be used to endorse or promote products derived from</span>
<a class="l" name="17" href="#17">17</a><span class="c"># this software without specific prior written permission.</span>
<a class="l" name="18" href="#18">18</a><span class="c">#</span>
<a class="l" name="19" href="#19">19</a><span class="c"># THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS</span>
<a class="hl" name="20" href="#20">20</a><span class="c"># "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT</span>
<a class="l" name="21" href="#21">21</a><span class="c"># LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR</span>
<a class="l" name="22" href="#22">22</a><span class="c"># A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT</span>
<a class="l" name="23" href="#23">23</a><span class="c"># OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,</span>
<a class="l" name="24" href="#24">24</a><span class="c"># SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT</span>
<a class="l" name="25" href="#25">25</a><span class="c"># LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,</span>
<a class="l" name="26" href="#26">26</a><span class="c"># DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY</span>
<a class="l" name="27" href="#27">27</a><span class="c"># THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT</span>
<a class="l" name="28" href="#28">28</a><span class="c"># (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE</span>
<a class="l" name="29" href="#29">29</a><span class="c"># OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</span>
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a><span class="s">"""Unit test for the gtest_json_output module."""</span>
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a><b>import</b> <a class="xn" name="json"/><a href="/googletest/s?refs=json&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">json</a>
<a class="l" name="34" href="#34">34</a><b>import</b> <a class="xn" name="os"/><a href="/googletest/s?refs=os&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">os</a>
<a class="l" name="35" href="#35">35</a><b>import</b> <a class="xn" name="gtest_json_test_utils"/><a href="/googletest/s?refs=gtest_json_test_utils&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">gtest_json_test_utils</a>
<a class="l" name="36" href="#36">36</a><b>import</b> <a class="xn" name="gtest_test_utils"/><a href="/googletest/s?refs=gtest_test_utils&amp;project=googletest" class="xn intelliWindow-symbol" data-definition-place="def">gtest_test_utils</a>
<a class="l" name="37" href="#37">37</a>
<a class="l" name="38" href="#38">38</a><a class="xv" name="GTEST_OUTPUT_SUBDIR"/><a href="/googletest/s?refs=GTEST_OUTPUT_SUBDIR&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_OUTPUT_SUBDIR</a> = <span class="s">'json_outfiles'</span>
<a class="l" name="39" href="#39">39</a><a class="xv" name="GTEST_OUTPUT_1_TEST"/><a href="/googletest/s?refs=GTEST_OUTPUT_1_TEST&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_OUTPUT_1_TEST</a> = <span class="s">'gtest_xml_outfile1_test_'</span>
<a class="hl" name="40" href="#40">40</a><a class="xv" name="GTEST_OUTPUT_2_TEST"/><a href="/googletest/s?refs=GTEST_OUTPUT_2_TEST&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">GTEST_OUTPUT_2_TEST</a> = <span class="s">'gtest_xml_outfile2_test_'</span>
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a><a class="xv" name="EXPECTED_1"/><a href="/googletest/s?refs=EXPECTED_1&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">EXPECTED_1</a> = {
<a class="l" name="43" href="#43">43</a>    u<span class="s">'tests'</span>:
<a class="l" name="44" href="#44">44</a>        <span class="n">1</span>,
<a class="l" name="45" href="#45">45</a>    u<span class="s">'failures'</span>:
<a class="l" name="46" href="#46">46</a>        <span class="n">0</span>,
<a class="l" name="47" href="#47">47</a>    u<span class="s">'disabled'</span>:
<a class="l" name="48" href="#48">48</a>        <span class="n">0</span>,
<a class="l" name="49" href="#49">49</a>    u<span class="s">'errors'</span>:
<a class="hl" name="50" href="#50">50</a>        <span class="n">0</span>,
<a class="l" name="51" href="#51">51</a>    u<span class="s">'time'</span>:
<a class="l" name="52" href="#52">52</a>        u<span class="s">'*'</span>,
<a class="l" name="53" href="#53">53</a>    u<span class="s">'timestamp'</span>:
<a class="l" name="54" href="#54">54</a>        u<span class="s">'*'</span>,
<a class="l" name="55" href="#55">55</a>    u<span class="s">'name'</span>:
<a class="l" name="56" href="#56">56</a>        u<span class="s">'AllTests'</span>,
<a class="l" name="57" href="#57">57</a>    u<span class="s">'testsuites'</span>: [{
<a class="l" name="58" href="#58">58</a>        u<span class="s">'name'</span>:
<a class="l" name="59" href="#59">59</a>            u<span class="s">'PropertyOne'</span>,
<a class="hl" name="60" href="#60">60</a>        u<span class="s">'tests'</span>:
<a class="l" name="61" href="#61">61</a>            <span class="n">1</span>,
<a class="l" name="62" href="#62">62</a>        u<span class="s">'failures'</span>:
<a class="l" name="63" href="#63">63</a>            <span class="n">0</span>,
<a class="l" name="64" href="#64">64</a>        u<span class="s">'disabled'</span>:
<a class="l" name="65" href="#65">65</a>            <span class="n">0</span>,
<a class="l" name="66" href="#66">66</a>        u<span class="s">'errors'</span>:
<a class="l" name="67" href="#67">67</a>            <span class="n">0</span>,
<a class="l" name="68" href="#68">68</a>        u<span class="s">'time'</span>:
<a class="l" name="69" href="#69">69</a>            u<span class="s">'*'</span>,
<a class="hl" name="70" href="#70">70</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="71" href="#71">71</a>            u<span class="s">'*'</span>,
<a class="l" name="72" href="#72">72</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="73" href="#73">73</a>            u<span class="s">'name'</span>: u<span class="s">'TestSomeProperties'</span>,
<a class="l" name="74" href="#74">74</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="75" href="#75">75</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="l" name="76" href="#76">76</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="77" href="#77">77</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="78" href="#78">78</a>            u<span class="s">'classname'</span>: u<span class="s">'PropertyOne'</span>,
<a class="l" name="79" href="#79">79</a>            u<span class="s">'SetUpProp'</span>: u<span class="s">'1'</span>,
<a class="hl" name="80" href="#80">80</a>            u<span class="s">'TestSomeProperty'</span>: u<span class="s">'1'</span>,
<a class="l" name="81" href="#81">81</a>            u<span class="s">'TearDownProp'</span>: u<span class="s">'1'</span>,
<a class="l" name="82" href="#82">82</a>        }],
<a class="l" name="83" href="#83">83</a>    }],
<a class="l" name="84" href="#84">84</a>}
<a class="l" name="85" href="#85">85</a>
<a class="l" name="86" href="#86">86</a><a class="xv" name="EXPECTED_2"/><a href="/googletest/s?refs=EXPECTED_2&amp;project=googletest" class="xv intelliWindow-symbol" data-definition-place="def">EXPECTED_2</a> = {
<a class="l" name="87" href="#87">87</a>    u<span class="s">'tests'</span>:
<a class="l" name="88" href="#88">88</a>        <span class="n">1</span>,
<a class="l" name="89" href="#89">89</a>    u<span class="s">'failures'</span>:
<a class="hl" name="90" href="#90">90</a>        <span class="n">0</span>,
<a class="l" name="91" href="#91">91</a>    u<span class="s">'disabled'</span>:
<a class="l" name="92" href="#92">92</a>        <span class="n">0</span>,
<a class="l" name="93" href="#93">93</a>    u<span class="s">'errors'</span>:
<a class="l" name="94" href="#94">94</a>        <span class="n">0</span>,
<a class="l" name="95" href="#95">95</a>    u<span class="s">'time'</span>:
<a class="l" name="96" href="#96">96</a>        u<span class="s">'*'</span>,
<a class="l" name="97" href="#97">97</a>    u<span class="s">'timestamp'</span>:
<a class="l" name="98" href="#98">98</a>        u<span class="s">'*'</span>,
<a class="l" name="99" href="#99">99</a>    u<span class="s">'name'</span>:
<a class="hl" name="100" href="#100">100</a>        u<span class="s">'AllTests'</span>,
<a class="l" name="101" href="#101">101</a>    u<span class="s">'testsuites'</span>: [{
<a class="l" name="102" href="#102">102</a>        u<span class="s">'name'</span>:
<a class="l" name="103" href="#103">103</a>            u<span class="s">'PropertyTwo'</span>,
<a class="l" name="104" href="#104">104</a>        u<span class="s">'tests'</span>:
<a class="l" name="105" href="#105">105</a>            <span class="n">1</span>,
<a class="l" name="106" href="#106">106</a>        u<span class="s">'failures'</span>:
<a class="l" name="107" href="#107">107</a>            <span class="n">0</span>,
<a class="l" name="108" href="#108">108</a>        u<span class="s">'disabled'</span>:
<a class="l" name="109" href="#109">109</a>            <span class="n">0</span>,
<a class="hl" name="110" href="#110">110</a>        u<span class="s">'errors'</span>:
<a class="l" name="111" href="#111">111</a>            <span class="n">0</span>,
<a class="l" name="112" href="#112">112</a>        u<span class="s">'time'</span>:
<a class="l" name="113" href="#113">113</a>            u<span class="s">'*'</span>,
<a class="l" name="114" href="#114">114</a>        u<span class="s">'timestamp'</span>:
<a class="l" name="115" href="#115">115</a>            u<span class="s">'*'</span>,
<a class="l" name="116" href="#116">116</a>        u<span class="s">'testsuite'</span>: [{
<a class="l" name="117" href="#117">117</a>            u<span class="s">'name'</span>: u<span class="s">'TestSomeProperties'</span>,
<a class="l" name="118" href="#118">118</a>            u<span class="s">'status'</span>: u<span class="s">'RUN'</span>,
<a class="l" name="119" href="#119">119</a>            u<span class="s">'result'</span>: u<span class="s">'COMPLETED'</span>,
<a class="hl" name="120" href="#120">120</a>            u<span class="s">'timestamp'</span>: u<span class="s">'*'</span>,
<a class="l" name="121" href="#121">121</a>            u<span class="s">'time'</span>: u<span class="s">'*'</span>,
<a class="l" name="122" href="#122">122</a>            u<span class="s">'classname'</span>: u<span class="s">'PropertyTwo'</span>,
<a class="l" name="123" href="#123">123</a>            u<span class="s">'SetUpProp'</span>: u<span class="s">'2'</span>,
<a class="l" name="124" href="#124">124</a>            u<span class="s">'TestSomeProperty'</span>: u<span class="s">'2'</span>,
<a class="l" name="125" href="#125">125</a>            u<span class="s">'TearDownProp'</span>: u<span class="s">'2'</span>,
<a class="l" name="126" href="#126">126</a>        }],
<a class="l" name="127" href="#127">127</a>    }],
<a class="l" name="128" href="#128">128</a>}
<a class="l" name="129" href="#129">129</a>
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a><b>class</b> <a class="xc" name="GTestJsonOutFilesTest"/><a href="/googletest/s?refs=GTestJsonOutFilesTest&amp;project=googletest" class="xc intelliWindow-symbol" data-definition-place="def">GTestJsonOutFilesTest</a>(<a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=TestCase&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TestCase</a>):
<a class="l" name="132" href="#132">132</a>  <span class="s">"""Unit test for Google Test's JSON output functionality."""</span>
<a class="l" name="133" href="#133">133</a>
<a class="l" name="134" href="#134">134</a>  <b>def</b> <a class="xmb" name="setUp"/><a href="/googletest/s?refs=setUp&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">setUp</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="135" href="#135">135</a>    <span class="c"># We want the trailing '/' that the last "" provides in os.path.join, for</span>
<a class="l" name="136" href="#136">136</a>    <span class="c"># telling Google Test to create an output directory instead of a single file</span>
<a class="l" name="137" href="#137">137</a>    <span class="c"># for xml output.</span>
<a class="l" name="138" href="#138">138</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=output_dir_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_dir_</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTempDir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTempDir</a>(),
<a class="l" name="139" href="#139">139</a>                                    <a class="d intelliWindow-symbol" href="#GTEST_OUTPUT_SUBDIR" data-definition-place="defined-in-file">GTEST_OUTPUT_SUBDIR</a>, <span class="s">''</span>)
<a class="hl" name="140" href="#140">140</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#DeleteFilesAndDir" data-definition-place="defined-in-file">DeleteFilesAndDir</a>()
<a class="l" name="141" href="#141">141</a>
<a class="l" name="142" href="#142">142</a>  <b>def</b> <a class="xmb" name="tearDown"/><a href="/googletest/s?refs=tearDown&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">tearDown</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="143" href="#143">143</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#DeleteFilesAndDir" data-definition-place="defined-in-file">DeleteFilesAndDir</a>()
<a class="l" name="144" href="#144">144</a>
<a class="l" name="145" href="#145">145</a>  <b>def</b> <a class="xmb" name="DeleteFilesAndDir"/><a href="/googletest/s?refs=DeleteFilesAndDir&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">DeleteFilesAndDir</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="146" href="#146">146</a>    <b>try</b>:
<a class="l" name="147" href="#147">147</a>      <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=remove&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">remove</a>(<a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=output_dir_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_dir_</a>, <a class="d intelliWindow-symbol" href="#GTEST_OUTPUT_1_TEST" data-definition-place="defined-in-file">GTEST_OUTPUT_1_TEST</a> + <span class="s">'.json'</span>))
<a class="l" name="148" href="#148">148</a>    <b>except</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=error&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">error</a>:
<a class="l" name="149" href="#149">149</a>      <b>pass</b>
<a class="hl" name="150" href="#150">150</a>    <b>try</b>:
<a class="l" name="151" href="#151">151</a>      <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=remove&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">remove</a>(<a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=output_dir_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_dir_</a>, <a class="d intelliWindow-symbol" href="#GTEST_OUTPUT_2_TEST" data-definition-place="defined-in-file">GTEST_OUTPUT_2_TEST</a> + <span class="s">'.json'</span>))
<a class="l" name="152" href="#152">152</a>    <b>except</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=error&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">error</a>:
<a class="l" name="153" href="#153">153</a>      <b>pass</b>
<a class="l" name="154" href="#154">154</a>    <b>try</b>:
<a class="l" name="155" href="#155">155</a>      <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=rmdir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rmdir</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=output_dir_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_dir_</a>)
<a class="l" name="156" href="#156">156</a>    <b>except</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=error&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">error</a>:
<a class="l" name="157" href="#157">157</a>      <b>pass</b>
<a class="l" name="158" href="#158">158</a>
<a class="l" name="159" href="#159">159</a>  <b>def</b> <a class="xmb" name="testOutfile1"/><a href="/googletest/s?refs=testOutfile1&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testOutfile1</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="hl" name="160" href="#160">160</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#_TestOutFile" data-definition-place="defined-in-file">_TestOutFile</a>(<a class="d intelliWindow-symbol" href="#GTEST_OUTPUT_1_TEST" data-definition-place="defined-in-file">GTEST_OUTPUT_1_TEST</a>, <a class="d intelliWindow-symbol" href="#EXPECTED_1" data-definition-place="defined-in-file">EXPECTED_1</a>)
<a class="l" name="161" href="#161">161</a>
<a class="l" name="162" href="#162">162</a>  <b>def</b> <a class="xmb" name="testOutfile2"/><a href="/googletest/s?refs=testOutfile2&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">testOutfile2</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>):
<a class="l" name="163" href="#163">163</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#_TestOutFile" data-definition-place="defined-in-file">_TestOutFile</a>(<a class="d intelliWindow-symbol" href="#GTEST_OUTPUT_2_TEST" data-definition-place="defined-in-file">GTEST_OUTPUT_2_TEST</a>, <a class="d intelliWindow-symbol" href="#EXPECTED_2" data-definition-place="defined-in-file">EXPECTED_2</a>)
<a class="l" name="164" href="#164">164</a>
<a class="l" name="165" href="#165">165</a>  <b>def</b> <a href="/googletest/s?refs=_TestOutFile&amp;project=googletest" class="xmb intelliWindow-symbol" data-definition-place="def">_TestOutFile</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>, <a href="/googletest/s?defs=test_name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">test_name</a>, <a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>):
<a class="l" name="166" href="#166">166</a>    <a href="/googletest/s?defs=gtest_prog_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_path</a> = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTestExecutablePath&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTestExecutablePath</a>(<a href="/googletest/s?defs=test_name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">test_name</a>)
<a class="l" name="167" href="#167">167</a>    <a href="/googletest/s?defs=command&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">command</a> = [<a href="/googletest/s?defs=gtest_prog_path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gtest_prog_path</a>, <span class="s">'--gtest_output=json:%s'</span> % <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=output_dir_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_dir_</a>]
<a class="l" name="168" href="#168">168</a>    p = <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=Subprocess&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Subprocess</a>(<a href="/googletest/s?defs=command&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">command</a>,
<a class="l" name="169" href="#169">169</a>                                    <a href="/googletest/s?defs=working_dir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">working_dir</a>=<a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=GetTempDir&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">GetTempDir</a>())
<a class="hl" name="170" href="#170">170</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assert_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assert_</a>(p.<a href="/googletest/s?defs=exited&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exited</a>)
<a class="l" name="171" href="#171">171</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertEquals&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertEquals</a>(<span class="n">0</span>, p.<a href="/googletest/s?defs=exit_code&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exit_code</a>)
<a class="l" name="172" href="#172">172</a>
<a class="l" name="173" href="#173">173</a>    <a href="/googletest/s?defs=output_file_name1&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file_name1</a> = <a href="/googletest/s?defs=test_name&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">test_name</a> + <span class="s">'.json'</span>
<a class="l" name="174" href="#174">174</a>    <a href="/googletest/s?defs=output_file1&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file1</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=output_dir_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_dir_</a>, <a href="/googletest/s?defs=output_file_name1&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file_name1</a>)
<a class="l" name="175" href="#175">175</a>    <a href="/googletest/s?defs=output_file_name2&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file_name2</a> = <span class="s">'lt-'</span> + <a href="/googletest/s?defs=output_file_name1&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file_name1</a>
<a class="l" name="176" href="#176">176</a>    <a href="/googletest/s?defs=output_file2&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file2</a> = <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=join&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=output_dir_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_dir_</a>, <a href="/googletest/s?defs=output_file_name2&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file_name2</a>)
<a class="l" name="177" href="#177">177</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assert_&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assert_</a>(<a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=isfile&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">isfile</a>(<a href="/googletest/s?defs=output_file1&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file1</a>) <b>or</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=isfile&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">isfile</a>(<a href="/googletest/s?defs=output_file2&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file2</a>),
<a class="l" name="178" href="#178">178</a>                 <a href="/googletest/s?defs=output_file1&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file1</a>)
<a class="l" name="179" href="#179">179</a>
<a class="hl" name="180" href="#180">180</a>    <b>if</b> <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=path&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/googletest/s?defs=isfile&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">isfile</a>(<a href="/googletest/s?defs=output_file1&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file1</a>):
<a class="l" name="181" href="#181">181</a>      <b>with</b> <a href="/googletest/s?defs=open&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">open</a>(<a href="/googletest/s?defs=output_file1&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file1</a>) <b>as</b> f:
<a class="l" name="182" href="#182">182</a>        <a href="/googletest/s?defs=actual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual</a> = <a class="d intelliWindow-symbol" href="#json" data-definition-place="defined-in-file">json</a>.<a href="/googletest/s?defs=load&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">load</a>(f)
<a class="l" name="183" href="#183">183</a>    <b>else</b>:
<a class="l" name="184" href="#184">184</a>      <b>with</b> <a href="/googletest/s?defs=open&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">open</a>(<a href="/googletest/s?defs=output_file2&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">output_file2</a>) <b>as</b> f:
<a class="l" name="185" href="#185">185</a>        <a href="/googletest/s?defs=actual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual</a> = <a class="d intelliWindow-symbol" href="#json" data-definition-place="defined-in-file">json</a>.<a href="/googletest/s?defs=load&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">load</a>(f)
<a class="l" name="186" href="#186">186</a>    <a href="/googletest/s?defs=self&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a href="/googletest/s?defs=assertEqual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">assertEqual</a>(<a href="/googletest/s?defs=expected&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a>, <a class="d intelliWindow-symbol" href="#gtest_json_test_utils" data-definition-place="defined-in-file">gtest_json_test_utils</a>.<a href="/googletest/s?defs=normalize&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">normalize</a>(<a href="/googletest/s?defs=actual&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">actual</a>))
<a class="l" name="187" href="#187">187</a>
<a class="l" name="188" href="#188">188</a>
<a class="l" name="189" href="#189">189</a><b>if</b> <a href="/googletest/s?defs=__name__&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__name__</a> == <span class="s">'__main__'</span>:
<a class="hl" name="190" href="#190">190</a>  <a class="d intelliWindow-symbol" href="#os" data-definition-place="defined-in-file">os</a>.<a href="/googletest/s?defs=environ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">environ</a>[<span class="s">'GTEST_STACK_TRACE_DEPTH'</span>] = <span class="s">'0'</span>
<a class="l" name="191" href="#191">191</a>  <a class="d intelliWindow-symbol" href="#gtest_test_utils" data-definition-place="defined-in-file">gtest_test_utils</a>.<a href="/googletest/s?defs=Main&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Main</a>()
<a class="l" name="192" href="#192">192</a>