<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>### Generic Build Instructions
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>#### Setup
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>To build GoogleTest and your tests that use it, you need to tell your build
<a class="l" name="6" href="#6">6</a>system where to find its headers and source files. The exact way to do it
<a class="l" name="7" href="#7">7</a>depends on which build system you use, and is usually straightforward.
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>### Build with CMake
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a>GoogleTest comes with a CMake build script
<a class="l" name="12" href="#12">12</a>([<a href="/googletest/s?path=CMakeLists.txt&amp;project=googletest">CMakeLists.txt</a>](<a href="https://github.com/google/googletest/blob/master/CMakeLists.txt">https://github.com/google/googletest/blob/master/CMakeLists.txt</a>))
<a class="l" name="13" href="#13">13</a>that can be used on a wide range of platforms ("C" stands for cross-platform.).
<a class="l" name="14" href="#14">14</a>If you don't have CMake installed already, you can download it for free from
<a class="l" name="15" href="#15">15</a>&lt;<a href="http://www.cmake.org/">http://www.cmake.org/</a>&gt;.
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a>CMake works by generating native makefiles or build projects that can be used in
<a class="l" name="18" href="#18">18</a>the compiler environment of your choice. You can either build GoogleTest as a
<a class="l" name="19" href="#19">19</a>standalone project or it can be incorporated into an existing CMake build for
<a class="hl" name="20" href="#20">20</a>another project.
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a>#### Standalone CMake Project
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a>When building GoogleTest as a standalone project, the typical workflow starts
<a class="l" name="25" href="#25">25</a>with
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a>```
<a class="l" name="28" href="#28">28</a>git clone <a href="https://github.com/google/googletest.git">https://github.com/google/googletest.git</a> -b release-1.10.0
<a class="l" name="29" href="#29">29</a>cd googletest        # Main directory of the cloned repository.
<a class="hl" name="30" href="#30">30</a>mkdir build          # Create a directory to hold the build output.
<a class="l" name="31" href="#31">31</a>cd build
<a class="l" name="32" href="#32">32</a>cmake ..             # Generate native build scripts for GoogleTest.
<a class="l" name="33" href="#33">33</a>```
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>The above command also includes GoogleMock by default. And so, if you want to
<a class="l" name="36" href="#36">36</a>build only GoogleTest, you should replace the last command with
<a class="l" name="37" href="#37">37</a>
<a class="l" name="38" href="#38">38</a>```
<a class="l" name="39" href="#39">39</a>cmake .. -DBUILD_GMOCK=OFF
<a class="hl" name="40" href="#40">40</a>```
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>If you are on a \*nix system, you should now see a Makefile in the current
<a class="l" name="43" href="#43">43</a>directory. Just type `make` to build GoogleTest. And then you can simply install
<a class="l" name="44" href="#44">44</a>GoogleTest if you are a system administrator.
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>```
<a class="l" name="47" href="#47">47</a>make
<a class="l" name="48" href="#48">48</a>sudo make install    # Install in <a href="/googletest/s?path=/usr/local&amp;project=googletest">/usr/local</a>/ by default
<a class="l" name="49" href="#49">49</a>```
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>If you use Windows and have Visual Studio installed, a `<a href="/googletest/s?path=gtest.sln&amp;project=googletest">gtest.sln</a>` file and
<a class="l" name="52" href="#52">52</a>several `.vcproj` files will be created. You can then build them using Visual
<a class="l" name="53" href="#53">53</a>Studio.
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>On Mac OS X with Xcode installed, a `.xcodeproj` file will be generated.
<a class="l" name="56" href="#56">56</a>
<a class="l" name="57" href="#57">57</a>#### Incorporating Into An Existing CMake Project
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>If you want to use GoogleTest in a project which already uses CMake, the easiest
<a class="hl" name="60" href="#60">60</a>way is to get installed libraries and headers.
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>*   Import GoogleTest by using `find_package` (or `pkg_check_modules`). For
<a class="l" name="63" href="#63">63</a>    example, if `find_package(GTest CONFIG REQUIRED)` is succeed, you can use
<a class="l" name="64" href="#64">64</a>    the libraries as `GTest::gtest`, `GTest::gmock`.
<a class="l" name="65" href="#65">65</a>
<a class="l" name="66" href="#66">66</a>And a more robust and flexible approach is to build GoogleTest as part of that
<a class="l" name="67" href="#67">67</a>project directly. This is done by making the GoogleTest source code available to
<a class="l" name="68" href="#68">68</a>the main build and adding it using CMake's `add_subdirectory()` command. This
<a class="l" name="69" href="#69">69</a>has the significant advantage that the same compiler and linker settings are
<a class="hl" name="70" href="#70">70</a>used between GoogleTest and the rest of your project, so issues associated with
<a class="l" name="71" href="#71">71</a>using incompatible libraries (eg <a href="/googletest/s?path=debug/release&amp;project=googletest">debug/release</a>), etc. are avoided. This is
<a class="l" name="72" href="#72">72</a>particularly useful on Windows. Making GoogleTest's source code available to the
<a class="l" name="73" href="#73">73</a>main build can be done a few different ways:
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>*   Download the GoogleTest source code manually and place it at a known
<a class="l" name="76" href="#76">76</a>    location. This is the least flexible approach and can make it more difficult
<a class="l" name="77" href="#77">77</a>    to use with continuous integration systems, etc.
<a class="l" name="78" href="#78">78</a>*   Embed the GoogleTest source code as a direct copy in the main project's
<a class="l" name="79" href="#79">79</a>    source tree. This is often the simplest approach, but is also the hardest to
<a class="hl" name="80" href="#80">80</a>    keep up to date. Some organizations may not permit this method.
<a class="l" name="81" href="#81">81</a>*   Add GoogleTest as a git submodule or equivalent. This may not always be
<a class="l" name="82" href="#82">82</a>    possible or appropriate. Git submodules, for example, have their own set of
<a class="l" name="83" href="#83">83</a>    advantages and drawbacks.
<a class="l" name="84" href="#84">84</a>*   Use CMake to download GoogleTest as part of the build's configure step. This
<a class="l" name="85" href="#85">85</a>    is just a little more complex, but doesn't have the limitations of the other
<a class="l" name="86" href="#86">86</a>    methods.
<a class="l" name="87" href="#87">87</a>
<a class="l" name="88" href="#88">88</a>The last of the above methods is implemented with a small piece of CMake code in
<a class="l" name="89" href="#89">89</a>a separate file (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> `<a href="/googletest/s?path=CMakeLists.txt.in&amp;project=googletest">CMakeLists.txt.in</a>`) which is copied to the build area and
<a class="hl" name="90" href="#90">90</a>then invoked as a sub-build _during the CMake stage_. That directory is then
<a class="l" name="91" href="#91">91</a>pulled into the main build with `add_subdirectory()`. For example:
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>New file `<a href="/googletest/s?path=CMakeLists.txt.in&amp;project=googletest">CMakeLists.txt.in</a>`:
<a class="l" name="94" href="#94">94</a>
<a class="l" name="95" href="#95">95</a>```cmake
<a class="l" name="96" href="#96">96</a>cmake_minimum_required(VERSION 2.8.2)
<a class="l" name="97" href="#97">97</a>
<a class="l" name="98" href="#98">98</a>project(googletest-download NONE)
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>include(ExternalProject)
<a class="l" name="101" href="#101">101</a>ExternalProject_Add(googletest
<a class="l" name="102" href="#102">102</a>  GIT_REPOSITORY    <a href="https://github.com/google/googletest.git">https://github.com/google/googletest.git</a>
<a class="l" name="103" href="#103">103</a>  GIT_TAG           master
<a class="l" name="104" href="#104">104</a>  SOURCE_DIR        "${CMAKE_CURRENT_BINARY_DIR}/googletest-src"
<a class="l" name="105" href="#105">105</a>  BINARY_DIR        "${CMAKE_CURRENT_BINARY_DIR}/googletest-build"
<a class="l" name="106" href="#106">106</a>  CONFIGURE_COMMAND ""
<a class="l" name="107" href="#107">107</a>  BUILD_COMMAND     ""
<a class="l" name="108" href="#108">108</a>  INSTALL_COMMAND   ""
<a class="l" name="109" href="#109">109</a>  TEST_COMMAND      ""
<a class="hl" name="110" href="#110">110</a>)
<a class="l" name="111" href="#111">111</a>```
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>Existing build's `<a href="/googletest/s?path=CMakeLists.txt&amp;project=googletest">CMakeLists.txt</a>`:
<a class="l" name="114" href="#114">114</a>
<a class="l" name="115" href="#115">115</a>```cmake
<a class="l" name="116" href="#116">116</a># Download and unpack googletest at configure time
<a class="l" name="117" href="#117">117</a>configure_file(<a href="/googletest/s?path=CMakeLists.txt.in&amp;project=googletest">CMakeLists.txt.in</a> <a href="/googletest/s?path=googletest-download/CMakeLists.txt&amp;project=googletest">googletest-download/CMakeLists.txt</a>)
<a class="l" name="118" href="#118">118</a>execute_process(COMMAND ${CMAKE_COMMAND} -G "${CMAKE_GENERATOR}" .
<a class="l" name="119" href="#119">119</a>  RESULT_VARIABLE result
<a class="hl" name="120" href="#120">120</a>  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/googletest-download )
<a class="l" name="121" href="#121">121</a>if(result)
<a class="l" name="122" href="#122">122</a>  message(FATAL_ERROR "CMake step for googletest failed: ${result}")
<a class="l" name="123" href="#123">123</a>endif()
<a class="l" name="124" href="#124">124</a>execute_process(COMMAND ${CMAKE_COMMAND} --build .
<a class="l" name="125" href="#125">125</a>  RESULT_VARIABLE result
<a class="l" name="126" href="#126">126</a>  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/googletest-download )
<a class="l" name="127" href="#127">127</a>if(result)
<a class="l" name="128" href="#128">128</a>  message(FATAL_ERROR "Build step for googletest failed: ${result}")
<a class="l" name="129" href="#129">129</a>endif()
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a># Prevent overriding the parent project's <a href="/googletest/s?path=compiler/linker&amp;project=googletest">compiler/linker</a>
<a class="l" name="132" href="#132">132</a># settings on Windows
<a class="l" name="133" href="#133">133</a>set(gtest_force_shared_crt ON CACHE BOOL "" FORCE)
<a class="l" name="134" href="#134">134</a>
<a class="l" name="135" href="#135">135</a># Add googletest directly to our build. This defines
<a class="l" name="136" href="#136">136</a># the gtest and gtest_main targets.
<a class="l" name="137" href="#137">137</a>add_subdirectory(${CMAKE_CURRENT_BINARY_DIR}/googletest-src
<a class="l" name="138" href="#138">138</a>                 ${CMAKE_CURRENT_BINARY_DIR}/googletest-build
<a class="l" name="139" href="#139">139</a>                 EXCLUDE_FROM_ALL)
<a class="hl" name="140" href="#140">140</a>
<a class="l" name="141" href="#141">141</a># The <a href="/googletest/s?path=gtest/gtest_main&amp;project=googletest">gtest/gtest_main</a> targets carry header search path
<a class="l" name="142" href="#142">142</a># dependencies automatically when using CMake 2.8.11 or
<a class="l" name="143" href="#143">143</a># later. Otherwise we have to add them here ourselves.
<a class="l" name="144" href="#144">144</a>if (CMAKE_VERSION VERSION_LESS 2.8.11)
<a class="l" name="145" href="#145">145</a>  include_directories("${gtest_SOURCE_DIR}/include")
<a class="l" name="146" href="#146">146</a>endif()
<a class="l" name="147" href="#147">147</a>
<a class="l" name="148" href="#148">148</a># Now simply link against gtest or gtest_main as needed. Eg
<a class="l" name="149" href="#149">149</a>add_executable(example <a href="/googletest/s?path=example.cpp&amp;project=googletest">example.cpp</a>)
<a class="hl" name="150" href="#150">150</a>target_link_libraries(example gtest_main)
<a class="l" name="151" href="#151">151</a>add_test(NAME example_test COMMAND example)
<a class="l" name="152" href="#152">152</a>```
<a class="l" name="153" href="#153">153</a>
<a class="l" name="154" href="#154">154</a>Note that this approach requires CMake 2.8.2 or later due to its use of the
<a class="l" name="155" href="#155">155</a>`ExternalProject_Add()` command. The above technique is discussed in more detail
<a class="l" name="156" href="#156">156</a>in [this separate article](<a href="http://crascit.com/2015/07/25/cmake-gtest/">http://crascit.com/2015/07/25/cmake-gtest/</a>) which
<a class="l" name="157" href="#157">157</a>also contains a link to a fully generalized implementation of the technique.
<a class="l" name="158" href="#158">158</a>
<a class="l" name="159" href="#159">159</a>##### Visual Studio Dynamic vs Static Runtimes
<a class="hl" name="160" href="#160">160</a>
<a class="l" name="161" href="#161">161</a>By default, new Visual Studio projects link the C runtimes dynamically but
<a class="l" name="162" href="#162">162</a>GoogleTest links them statically. This will generate an error that looks
<a class="l" name="163" href="#163">163</a>something like the following: <a href="/googletest/s?path=gtest.lib&amp;project=googletest">gtest.lib</a>(<a href="/googletest/s?path=gtest-all.obj&amp;project=googletest">gtest-all.obj</a>) : error LNK2038: mismatch
<a class="l" name="164" href="#164">164</a>detected for 'RuntimeLibrary': value 'MTd_StaticDebug' doesn't match value
<a class="l" name="165" href="#165">165</a>'MDd_DynamicDebug' in <a href="/googletest/s?path=main.obj&amp;project=googletest">main.obj</a>
<a class="l" name="166" href="#166">166</a>
<a class="l" name="167" href="#167">167</a>GoogleTest already has a CMake option for this: `gtest_force_shared_crt`
<a class="l" name="168" href="#168">168</a>
<a class="l" name="169" href="#169">169</a>Enabling this option will make gtest link the runtimes dynamically too, and
<a class="hl" name="170" href="#170">170</a>match the project in which it is included.
<a class="l" name="171" href="#171">171</a>
<a class="l" name="172" href="#172">172</a>#### C++ Standard Version
<a class="l" name="173" href="#173">173</a>
<a class="l" name="174" href="#174">174</a>An environment that supports C++11 is required in order to successfully build
<a class="l" name="175" href="#175">175</a>GoogleTest. One way to ensure this is to specify the standard in the top-level
<a class="l" name="176" href="#176">176</a>project, for example by using the `set(CMAKE_CXX_STANDARD 11)` command. If this
<a class="l" name="177" href="#177">177</a>is not feasible, for example in a C project using GoogleTest for validation,
<a class="l" name="178" href="#178">178</a>then it can be specified by adding it to the options for cmake via the
<a class="l" name="179" href="#179">179</a>`DCMAKE_CXX_FLAGS` option.
<a class="hl" name="180" href="#180">180</a>
<a class="l" name="181" href="#181">181</a>### Tweaking GoogleTest
<a class="l" name="182" href="#182">182</a>
<a class="l" name="183" href="#183">183</a>GoogleTest can be used in diverse environments. The default configuration may
<a class="l" name="184" href="#184">184</a>not work (or may not work well) out of the box in some environments. However,
<a class="l" name="185" href="#185">185</a>you can easily tweak GoogleTest by defining control macros on the compiler
<a class="l" name="186" href="#186">186</a>command line. Generally, these macros are named like `GTEST_XYZ` and you define
<a class="l" name="187" href="#187">187</a>them to either 1 or 0 to enable or disable a certain feature.
<a class="l" name="188" href="#188">188</a>
<a class="l" name="189" href="#189">189</a>We list the most frequently used macros below. For a complete list, see file
<a class="hl" name="190" href="#190">190</a>[<a href="/googletest/s?path=include/gtest/internal/gtest-port.h&amp;project=googletest">include/gtest/internal/gtest-port.h</a>](<a href="https://github.com/google/googletest/blob/master/googletest/include/gtest/internal/gtest-port.h">https://github.com/google/googletest/blob/master/googletest/include/gtest/internal/gtest-port.h</a>).
<a class="l" name="191" href="#191">191</a>
<a class="l" name="192" href="#192">192</a>### Multi-threaded Tests
<a class="l" name="193" href="#193">193</a>
<a class="l" name="194" href="#194">194</a>GoogleTest is thread-safe where the pthread library is available. After
<a class="l" name="195" href="#195">195</a>`#include "<a href="/googletest/s?path=gtest/gtest.h&amp;project=googletest">gtest/gtest.h</a>"`, you can check the
<a class="l" name="196" href="#196">196</a>`GTEST_IS_THREADSAFE` macro to see whether this is the case (yes if the macro is
<a class="l" name="197" href="#197">197</a>`#defined` to 1, no if it's undefined.).
<a class="l" name="198" href="#198">198</a>
<a class="l" name="199" href="#199">199</a>If GoogleTest doesn't correctly detect whether pthread is available in your
<a class="hl" name="200" href="#200">200</a>environment, you can force it with
<a class="l" name="201" href="#201">201</a>
<a class="l" name="202" href="#202">202</a>    -DGTEST_HAS_PTHREAD=1
<a class="l" name="203" href="#203">203</a>
<a class="l" name="204" href="#204">204</a>or
<a class="l" name="205" href="#205">205</a>
<a class="l" name="206" href="#206">206</a>    -DGTEST_HAS_PTHREAD=0
<a class="l" name="207" href="#207">207</a>
<a class="l" name="208" href="#208">208</a>When GoogleTest uses pthread, you may need to add flags to your compiler <a href="/googletest/s?path=and/or&amp;project=googletest">and/or</a>
<a class="l" name="209" href="#209">209</a>linker to select the pthread library, or you'll get link errors. If you use the
<a class="hl" name="210" href="#210">210</a>CMake script, this is taken care of for you. If you use your own build script,
<a class="l" name="211" href="#211">211</a>you'll need to read your compiler and linker's manual to figure out what flags
<a class="l" name="212" href="#212">212</a>to add.
<a class="l" name="213" href="#213">213</a>
<a class="l" name="214" href="#214">214</a>### As a Shared Library (DLL)
<a class="l" name="215" href="#215">215</a>
<a class="l" name="216" href="#216">216</a>GoogleTest is compact, so most users can build and link it as a static library
<a class="l" name="217" href="#217">217</a>for the simplicity. You can choose to use GoogleTest as a shared library (known
<a class="l" name="218" href="#218">218</a>as a DLL on Windows) if you prefer.
<a class="l" name="219" href="#219">219</a>
<a class="hl" name="220" href="#220">220</a>To compile *gtest* as a shared library, add
<a class="l" name="221" href="#221">221</a>
<a class="l" name="222" href="#222">222</a>    -DGTEST_CREATE_SHARED_LIBRARY=1
<a class="l" name="223" href="#223">223</a>
<a class="l" name="224" href="#224">224</a>to the compiler flags. You'll also need to tell the linker to produce a shared
<a class="l" name="225" href="#225">225</a>library instead - consult your linker's manual for how to do it.
<a class="l" name="226" href="#226">226</a>
<a class="l" name="227" href="#227">227</a>To compile your *tests* that use the gtest shared library, add
<a class="l" name="228" href="#228">228</a>
<a class="l" name="229" href="#229">229</a>    -DGTEST_LINKED_AS_SHARED_LIBRARY=1
<a class="hl" name="230" href="#230">230</a>
<a class="l" name="231" href="#231">231</a>to the compiler flags.
<a class="l" name="232" href="#232">232</a>
<a class="l" name="233" href="#233">233</a>Note: while the above steps aren't technically necessary today when using some
<a class="l" name="234" href="#234">234</a>compilers (<a href="/googletest/s?path=e.g.&amp;project=googletest">e.g.</a> GCC), they may become necessary in the future, if we decide to
<a class="l" name="235" href="#235">235</a>improve the speed of loading the library (see
<a class="l" name="236" href="#236">236</a>&lt;<a href="http://gcc.gnu.org/wiki/Visibility">http://gcc.gnu.org/wiki/Visibility</a>&gt; for details). Therefore you are recommended
<a class="l" name="237" href="#237">237</a>to always add the above flags when using GoogleTest as a shared library.
<a class="l" name="238" href="#238">238</a>Otherwise a future release of GoogleTest may break your build script.
<a class="l" name="239" href="#239">239</a>
<a class="hl" name="240" href="#240">240</a>### Avoiding Macro Name Clashes
<a class="l" name="241" href="#241">241</a>
<a class="l" name="242" href="#242">242</a>In C++, macros don't obey namespaces. Therefore two libraries that both define a
<a class="l" name="243" href="#243">243</a>macro of the same name will clash if you `#include` both definitions. In case a
<a class="l" name="244" href="#244">244</a>GoogleTest macro clashes with another library, you can force GoogleTest to
<a class="l" name="245" href="#245">245</a>rename its macro to avoid the conflict.
<a class="l" name="246" href="#246">246</a>
<a class="l" name="247" href="#247">247</a>Specifically, if both GoogleTest and some other code define macro FOO, you can
<a class="l" name="248" href="#248">248</a>add
<a class="l" name="249" href="#249">249</a>
<a class="hl" name="250" href="#250">250</a>    -DGTEST_DONT_DEFINE_FOO=1
<a class="l" name="251" href="#251">251</a>
<a class="l" name="252" href="#252">252</a>to the compiler flags to tell GoogleTest to change the macro's name from `FOO`
<a class="l" name="253" href="#253">253</a>to `GTEST_FOO`. Currently `FOO` can be `FAIL`, `SUCCEED`, or `TEST`. For
<a class="l" name="254" href="#254">254</a>example, with `-DGTEST_DONT_DEFINE_TEST=1`, you'll need to write
<a class="l" name="255" href="#255">255</a>
<a class="l" name="256" href="#256">256</a>    GTEST_TEST(SomeTest, DoesThis) { ... }
<a class="l" name="257" href="#257">257</a>
<a class="l" name="258" href="#258">258</a>instead of
<a class="l" name="259" href="#259">259</a>
<a class="hl" name="260" href="#260">260</a>    TEST(SomeTest, DoesThis) { ... }
<a class="l" name="261" href="#261">261</a>
<a class="l" name="262" href="#262">262</a>in order to define a test.
<a class="l" name="263" href="#263">263</a>