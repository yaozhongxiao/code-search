<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Function","xf",[["TEST",76],["TEST",100],["TEST",105],["TEST",116],["TEST",125],["TEST",133]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">// Copyright 2005, Google Inc.</span>
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span><span class="c">// All rights reserved.</span>
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span><span class="c">// Redistribution and use in source and binary forms, with or without</span>
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span><span class="c">// modification, are permitted provided that the following conditions are</span>
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span><span class="c">// met:</span>
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span><span class="c">//     * Redistributions of source code must retain the above copyright</span>
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span><span class="c">// notice, this list of conditions and the following disclaimer.</span>
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span><span class="c">//     * Redistributions in binary form must reproduce the above</span>
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span><span class="c">// copyright notice, this list of conditions and the following disclaimer</span>
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span><span class="c">// in the documentation <a href="/googletest/s?path=and/">and</a>/<a href="/googletest/s?path=and/or">or</a> other materials provided with the</span>
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span><span class="c">// distribution.</span>
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span><span class="c">//     * Neither the name of Google Inc. nor the names of its</span>
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span><span class="c">// contributors may be used to endorse or promote products derived from</span>
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span><span class="c">// this software without specific prior written permission.</span>
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span><span class="c">// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span><span class="c">// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR</span>
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span><span class="c">// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT</span>
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span><span class="c">// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span><span class="c">// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span><span class="c">// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span><span class="c">// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><span class="c">// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT</span>
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span><span class="c">// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><span class="c">// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</span>
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span><span class="c">// A sample program demonstrating using Google C++ testing framework.</span>
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span><span class="c">// This sample shows how to write a simple unit test for a function,</span>
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span><span class="c">// using Google C++ testing framework.</span>
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span><span class="c">// Writing a unit test using Google C++ testing framework is easy as 1-2-3:</span>
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span><span class="c">// Step 1. Include necessary header files such that the stuff your</span>
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span><span class="c">// test logic needs is declared.</span>
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span><span class="c">// Don't forget <a href="/googletest/s?path=gtest.h&amp;project=googletest">gtest.h</a>, which declares the testing framework.</span>
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>#<b>include</b> &lt;<a href="/googletest/s?path=limits.h">limits.h</a>&gt;
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=sample1.h&amp;project=googletest">sample1.h</a>"</span>
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>#<b>include</b> <span class="s">"<a href="/googletest/s?path=gtest/">gtest</a>/<a href="/googletest/s?path=gtest/gtest.h">gtest.h</a>"</span>
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span><b>namespace</b> &#123;
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span><span class="c">// Step 2. Use the TEST macro to define your tests.</span>
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span><span class="c">// TEST has two parameters: the test case name and the test name.</span>
<a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span><span class="c">// After using the macro, you should define your test logic between a</span>
<a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span><span class="c">// pair of braces.  You can use a bunch of macros to indicate the</span>
<a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span><span class="c">// success or failure of a test.  EXPECT_TRUE and EXPECT_EQ are</span>
<a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span><span class="c">// examples of such macros.  For a complete list, see <a href="/googletest/s?path=gtest.h&amp;project=googletest">gtest.h</a>.</span>
<a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span><span class="c">// &lt;TechnicalDetails&gt;</span>
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="58" href="#58">58</a><span class='fold-space'>&nbsp;</span><span class="c">// In Google Test, tests are grouped into test cases.  This is how we</span>
<a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span><span class="c">// keep test code organized.  You should put logically related tests</span>
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span><span class="c">// into the same test case.</span>
<a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span><span class="c">// The test case name and the test name should both be valid C++</span>
<a class="l" name="63" href="#63">63</a><span class='fold-space'>&nbsp;</span><span class="c">// identifiers.  And you should not use underscore (_) in the names.</span>
<a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span><span class="c">// Google Test guarantees that each test you define is run exactly</span>
<a class="l" name="66" href="#66">66</a><span class='fold-space'>&nbsp;</span><span class="c">// once, but it makes no guarantee on the order the tests are</span>
<a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span><span class="c">// executed.  Therefore, you should write your tests in such a way</span>
<a class="l" name="68" href="#68">68</a><span class='fold-space'>&nbsp;</span><span class="c">// that their results don't depend on their order.</span>
<a class="l" name="69" href="#69">69</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="hl" name="70" href="#70">70</a><span class='fold-space'>&nbsp;</span><span class="c">// &lt;/TechnicalDetails&gt;</span>
<a class="l" name="71" href="#71">71</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="72" href="#72">72</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="73" href="#73">73</a><span class='fold-space'>&nbsp;</span><span class="c">// Tests Factorial().</span>
<a class="l" name="74" href="#74">74</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="75" href="#75">75</a><span class='fold-space'>&nbsp;</span><span class="c">// Tests factorial of negative numbers.</span>
<span id='scope_id_87eb27c0' class='scope-head'><span class='scope-signature'>TEST(FactorialTest, Negative)</span><a class="l" name="76" href="#76">76</a><a href="#" onclick='fold(this.parentNode.id)' id='scope_id_87eb27c0_fold_icon'><span class='fold-icon'>&nbsp;</span></a><a class="xf" name="TEST"/><a href="/googletest/s?refs=TEST&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">TEST</a>(<a href="/googletest/s?defs=FactorialTest&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">FactorialTest</a>, <a href="/googletest/s?defs=Negative&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Negative</a>) &#123;</span>
<span id='scope_id_87eb27c0_fold' class='scope-body'><a class="l" name="77" href="#77">77</a><span class='fold-space'>&nbsp;</span>  <span class="c">// This test is named "Negative", and belongs to the "FactorialTest"</span>
<a class="l" name="78" href="#78">78</a><span class='fold-space'>&nbsp;</span>  <span class="c">// test case.</span>
<a class="l" name="79" href="#79">79</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_EQ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_EQ</a>(<span class="n">1</span>, <a href="/googletest/s?defs=Factorial&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Factorial</a>(-<span class="n">5</span>))&#59;
<a class="hl" name="80" href="#80">80</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_EQ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_EQ</a>(<span class="n">1</span>, <a href="/googletest/s?defs=Factorial&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Factorial</a>(-<span class="n">1</span>))&#59;
<a class="l" name="81" href="#81">81</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_GT&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_GT</a>(<a href="/googletest/s?defs=Factorial&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Factorial</a>(-<span class="n">10</span>), 0)&#59;
<a class="l" name="82" href="#82">82</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="83" href="#83">83</a><span class='fold-space'>&nbsp;</span>  <span class="c">// &lt;TechnicalDetails&gt;</span>
<a class="l" name="84" href="#84">84</a><span class='fold-space'>&nbsp;</span>  <span class="c">//</span>
<a class="l" name="85" href="#85">85</a><span class='fold-space'>&nbsp;</span>  <span class="c">// EXPECT_EQ(expected, actual) is the same as</span>
<a class="l" name="86" href="#86">86</a><span class='fold-space'>&nbsp;</span>  <span class="c">//</span>
<a class="l" name="87" href="#87">87</a><span class='fold-space'>&nbsp;</span>  <span class="c">//   EXPECT_TRUE((expected) == (actual))</span>
<a class="l" name="88" href="#88">88</a><span class='fold-space'>&nbsp;</span>  <span class="c">//</span>
<a class="l" name="89" href="#89">89</a><span class='fold-space'>&nbsp;</span>  <span class="c">// except that it will print both the expected value and the actual</span>
<a class="hl" name="90" href="#90">90</a><span class='fold-space'>&nbsp;</span>  <span class="c">// value when the assertion fails.  This is very helpful for</span>
<a class="l" name="91" href="#91">91</a><span class='fold-space'>&nbsp;</span>  <span class="c">// debugging.  Therefore in this case EXPECT_EQ is preferred.</span>
<a class="l" name="92" href="#92">92</a><span class='fold-space'>&nbsp;</span>  <span class="c">//</span>
<a class="l" name="93" href="#93">93</a><span class='fold-space'>&nbsp;</span>  <span class="c">// On the other hand, EXPECT_TRUE accepts any Boolean expression,</span>
<a class="l" name="94" href="#94">94</a><span class='fold-space'>&nbsp;</span>  <span class="c">// and is thus more general.</span>
<a class="l" name="95" href="#95">95</a><span class='fold-space'>&nbsp;</span>  <span class="c">//</span>
<a class="l" name="96" href="#96">96</a><span class='fold-space'>&nbsp;</span>  <span class="c">// &lt;/TechnicalDetails&gt;</span>
<a class="l" name="97" href="#97">97</a><span class='fold-space'>&nbsp;</span>&#125;
</span><a class="l" name="98" href="#98">98</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="99" href="#99">99</a><span class='fold-space'>&nbsp;</span><span class="c">// Tests factorial of 0.</span>
<span id='scope_id_cbe7fadb' class='scope-head'><span class='scope-signature'>TEST(FactorialTest, Zero)</span><a class="hl" name="100" href="#100">100</a><a href="#" onclick='fold(this.parentNode.id)' id='scope_id_cbe7fadb_fold_icon'><span class='fold-icon'>&nbsp;</span></a><a class="xf" name="TEST"/><a href="/googletest/s?refs=TEST&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">TEST</a>(<a href="/googletest/s?defs=FactorialTest&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">FactorialTest</a>, <a href="/googletest/s?defs=Zero&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Zero</a>) &#123;</span>
<span id='scope_id_cbe7fadb_fold' class='scope-body'><a class="l" name="101" href="#101">101</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_EQ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_EQ</a>(<span class="n">1</span>, <a href="/googletest/s?defs=Factorial&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Factorial</a>(0))&#59;
<a class="l" name="102" href="#102">102</a><span class='fold-space'>&nbsp;</span>&#125;
</span><a class="l" name="103" href="#103">103</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="104" href="#104">104</a><span class='fold-space'>&nbsp;</span><span class="c">// Tests factorial of positive numbers.</span>
<span id='scope_id_c5e366c5' class='scope-head'><span class='scope-signature'>TEST(FactorialTest, Positive)</span><a class="l" name="105" href="#105">105</a><a href="#" onclick='fold(this.parentNode.id)' id='scope_id_c5e366c5_fold_icon'><span class='fold-icon'>&nbsp;</span></a><a class="xf" name="TEST"/><a href="/googletest/s?refs=TEST&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">TEST</a>(<a href="/googletest/s?defs=FactorialTest&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">FactorialTest</a>, <a href="/googletest/s?defs=Positive&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Positive</a>) &#123;</span>
<span id='scope_id_c5e366c5_fold' class='scope-body'><a class="l" name="106" href="#106">106</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_EQ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_EQ</a>(<span class="n">1</span>, <a href="/googletest/s?defs=Factorial&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Factorial</a>(<span class="n">1</span>))&#59;
<a class="l" name="107" href="#107">107</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_EQ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_EQ</a>(<span class="n">2</span>, <a href="/googletest/s?defs=Factorial&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Factorial</a>(<span class="n">2</span>))&#59;
<a class="l" name="108" href="#108">108</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_EQ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_EQ</a>(<span class="n">6</span>, <a href="/googletest/s?defs=Factorial&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Factorial</a>(<span class="n">3</span>))&#59;
<a class="l" name="109" href="#109">109</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_EQ&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_EQ</a>(<span class="n">40320</span>, <a href="/googletest/s?defs=Factorial&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Factorial</a>(<span class="n">8</span>))&#59;
<a class="hl" name="110" href="#110">110</a><span class='fold-space'>&nbsp;</span>&#125;
</span><a class="l" name="111" href="#111">111</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="112" href="#112">112</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="113" href="#113">113</a><span class='fold-space'>&nbsp;</span><span class="c">// Tests IsPrime()</span>
<a class="l" name="114" href="#114">114</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="115" href="#115">115</a><span class='fold-space'>&nbsp;</span><span class="c">// Tests negative input.</span>
<span id='scope_id_b34c6519' class='scope-head'><span class='scope-signature'>TEST(IsPrimeTest, Negative)</span><a class="l" name="116" href="#116">116</a><a href="#" onclick='fold(this.parentNode.id)' id='scope_id_b34c6519_fold_icon'><span class='fold-icon'>&nbsp;</span></a><a class="xf" name="TEST"/><a href="/googletest/s?refs=TEST&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">TEST</a>(<a href="/googletest/s?defs=IsPrimeTest&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrimeTest</a>, <a href="/googletest/s?defs=Negative&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Negative</a>) &#123;</span>
<span id='scope_id_b34c6519_fold' class='scope-body'><a class="l" name="117" href="#117">117</a><span class='fold-space'>&nbsp;</span>  <span class="c">// This test belongs to the IsPrimeTest test case.</span>
<a class="l" name="118" href="#118">118</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="119" href="#119">119</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_FALSE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_FALSE</a>(<a href="/googletest/s?defs=IsPrime&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrime</a>(-<span class="n">1</span>))&#59;
<a class="hl" name="120" href="#120">120</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_FALSE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_FALSE</a>(<a href="/googletest/s?defs=IsPrime&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrime</a>(-<span class="n">2</span>))&#59;
<a class="l" name="121" href="#121">121</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_FALSE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_FALSE</a>(<a href="/googletest/s?defs=IsPrime&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrime</a>(<a href="/googletest/s?defs=INT_MIN&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">INT_MIN</a>))&#59;
<a class="l" name="122" href="#122">122</a><span class='fold-space'>&nbsp;</span>&#125;
</span><a class="l" name="123" href="#123">123</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="124" href="#124">124</a><span class='fold-space'>&nbsp;</span><span class="c">// Tests some trivial cases.</span>
<span id='scope_id_2b1fc279' class='scope-head'><span class='scope-signature'>TEST(IsPrimeTest, Trivial)</span><a class="l" name="125" href="#125">125</a><a href="#" onclick='fold(this.parentNode.id)' id='scope_id_2b1fc279_fold_icon'><span class='fold-icon'>&nbsp;</span></a><a class="xf" name="TEST"/><a href="/googletest/s?refs=TEST&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">TEST</a>(<a href="/googletest/s?defs=IsPrimeTest&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrimeTest</a>, <a href="/googletest/s?defs=Trivial&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Trivial</a>) &#123;</span>
<span id='scope_id_2b1fc279_fold' class='scope-body'><a class="l" name="126" href="#126">126</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_FALSE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_FALSE</a>(<a href="/googletest/s?defs=IsPrime&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrime</a>(0))&#59;
<a class="l" name="127" href="#127">127</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_FALSE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_FALSE</a>(<a href="/googletest/s?defs=IsPrime&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrime</a>(<span class="n">1</span>))&#59;
<a class="l" name="128" href="#128">128</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_TRUE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_TRUE</a>(<a href="/googletest/s?defs=IsPrime&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrime</a>(<span class="n">2</span>))&#59;
<a class="l" name="129" href="#129">129</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_TRUE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_TRUE</a>(<a href="/googletest/s?defs=IsPrime&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrime</a>(<span class="n">3</span>))&#59;
<a class="hl" name="130" href="#130">130</a><span class='fold-space'>&nbsp;</span>&#125;
</span><a class="l" name="131" href="#131">131</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="132" href="#132">132</a><span class='fold-space'>&nbsp;</span><span class="c">// Tests positive input.</span>
<span id='scope_id_f33f42ba' class='scope-head'><span class='scope-signature'>TEST(IsPrimeTest, Positive)</span><a class="l" name="133" href="#133">133</a><a href="#" onclick='fold(this.parentNode.id)' id='scope_id_f33f42ba_fold_icon'><span class='fold-icon'>&nbsp;</span></a><a class="xf" name="TEST"/><a href="/googletest/s?refs=TEST&amp;project=googletest" class="xf intelliWindow-symbol" data-definition-place="def">TEST</a>(<a href="/googletest/s?defs=IsPrimeTest&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrimeTest</a>, <a href="/googletest/s?defs=Positive&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Positive</a>) &#123;</span>
<span id='scope_id_f33f42ba_fold' class='scope-body'><a class="l" name="134" href="#134">134</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_FALSE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_FALSE</a>(<a href="/googletest/s?defs=IsPrime&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrime</a>(<span class="n">4</span>))&#59;
<a class="l" name="135" href="#135">135</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_TRUE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_TRUE</a>(<a href="/googletest/s?defs=IsPrime&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrime</a>(<span class="n">5</span>))&#59;
<a class="l" name="136" href="#136">136</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_FALSE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_FALSE</a>(<a href="/googletest/s?defs=IsPrime&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrime</a>(<span class="n">6</span>))&#59;
<a class="l" name="137" href="#137">137</a><span class='fold-space'>&nbsp;</span>  <a href="/googletest/s?defs=EXPECT_TRUE&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECT_TRUE</a>(<a href="/googletest/s?defs=IsPrime&amp;project=googletest" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IsPrime</a>(<span class="n">23</span>))&#59;
<a class="l" name="138" href="#138">138</a><span class='fold-space'>&nbsp;</span>&#125;
</span><a class="l" name="139" href="#139">139</a><span class='fold-space'>&nbsp;</span>&#125;  <span class="c">// namespace</span>
<a class="hl" name="140" href="#140">140</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="141" href="#141">141</a><span class='fold-space'>&nbsp;</span><span class="c">// Step 3. Call RUN_ALL_TESTS() in main().</span>
<a class="l" name="142" href="#142">142</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="143" href="#143">143</a><span class='fold-space'>&nbsp;</span><span class="c">// We do this by linking in <a href="/googletest/s?path=src/">src</a>/<a href="/googletest/s?path=src/gtest_main.cc">gtest_main.cc</a> file, which consists of</span>
<a class="l" name="144" href="#144">144</a><span class='fold-space'>&nbsp;</span><span class="c">// a main() function which calls RUN_ALL_TESTS() for us.</span>
<a class="l" name="145" href="#145">145</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="146" href="#146">146</a><span class='fold-space'>&nbsp;</span><span class="c">// This runs all the tests you've defined, prints the result, and</span>
<a class="l" name="147" href="#147">147</a><span class='fold-space'>&nbsp;</span><span class="c">// returns 0 if successful, or 1 otherwise.</span>
<a class="l" name="148" href="#148">148</a><span class='fold-space'>&nbsp;</span><span class="c">//</span>
<a class="l" name="149" href="#149">149</a><span class='fold-space'>&nbsp;</span><span class="c">// Did you notice that we didn't register the tests?  The</span>
<a class="hl" name="150" href="#150">150</a><span class='fold-space'>&nbsp;</span><span class="c">// RUN_ALL_TESTS() macro magically knows about all the tests we</span>
<a class="l" name="151" href="#151">151</a><span class='fold-space'>&nbsp;</span><span class="c">// defined.  Isn't this convenient?</span>
<a class="l" name="152" href="#152">152</a><span class='fold-space'>&nbsp;</span>